import React, { Component } from 'react';
import '../style/index.css'
import 'react-web-tabs/dist/react-web-tabs.css';
import { connect } from 'react-redux';
import swal from 'sweetalert2';
import ApiPortal from '../network/ApiPortal'
import {LogSystem} from "../log";
import * as ALERT from "../redux/actions/alertActions";
import Constant from "../constants/Constant"

class SystemConfigPage extends Component {

  constructor(props) {
    super(props);
    this.state = {
      simple:{
        adobe: false,
        bbb : false,
        vcrx: false,
      },
      vip: {
        adobe: false,
        bbb: false
      },
      checkedDeeplink: false,
      checkedVCR: false,
      numberEmpty:0,
      max:{
        simple: 0,
        sn: 0,
        vip: 0,
        vipSN: 0
      },
      role: ""
    };
  }

  componentDidMount() {
    console.log("componentDidMount config");
    const choosenApp = JSON.parse(localStorage.getItem('choosenApp'));

    if(choosenApp === undefined || choosenApp === null) {
      window.location.replace('/')
    }
    console.log(choosenApp);

    this.setState({role: choosenApp.studentTypeSupported});

    console.log(this.props.user);
    console.log("getVcrType");
    this.getVcrList();
    this.getDeepLinkStatus();
    this.getMixListClass();
    this.getEmptyNumber();
    this.getNumberStudent();
  }

  getVcrList = () => {
    ApiPortal.getVcrType().then(
        (res) => {
          LogSystem.info('Portal::API::getVcrType------------------------------: ');
          LogSystem.info(res);
          if(res.data.code === 200) {
            this.processGetVcrList(res.data);
          } else {
            ALERT.showToastAlter('Error',  res.data.message);
          }
        },
        (err) => {
          window.location.replace('/systemerror');
        }
    )
  }

  processGetVcrList = (data) =>{
    let lms = data.data.lms;
    this.setState({
      simple : {
        ...this.state.simple,
        adobe : lms.includes(Constant.VCR_TYPE_ADB),
        vcrx : lms.includes(Constant.VCR_TYPE_VCRX),
        bbb: lms.includes(Constant.VCR_TYPE_BBB)
      }
    });

    let vip = data.data.lms_vip;
    this.setState({
      vip : {
        ...this.state.vip,
        adobe : vip.includes(Constant.VCR_TYPE_ADB),
        bbb: vip.includes(Constant.VCR_TYPE_BBB)
      }
    });
  }

  getDeepLinkStatus = () =>{
    ApiPortal.getDeepLinkStatus().then(
        (res) => {
          LogSystem.info('Portal::API::getDeepLinkStatus------------------------------: ');
          LogSystem.info(res);
          if(res.data.code === 200) {
            this.setState({ checkedDeeplink : res.data.data});
          } else {
            ALERT.showToastAlter('Error',  res.data.message);
          }
        },
        (err) => {
          window.location.replace('/systemerror');
        }
    )
  }

  getMixListClass = () =>{
    ApiPortal.getMixListStatus().then(
        (res) => {
          LogSystem.info('Portal::API::getMixListStatus------------------------------: ');
          LogSystem.info(res);
          if(res.data.code === 200) {
            this.setState({ checkedVCR : res.data.data.includes("true")});
          } else {
            ALERT.showToastAlter('Error',  res.data.message);
          }
        },
        (err) => {
          window.location.replace('/systemerror');
        }
    )
  }

  getEmptyNumber = () =>{
    ApiPortal.getNumberEmpty().then(
        (res) => {
          LogSystem.info('Portal::API::getEmptyNumber------------------------------: ');
          LogSystem.info(res);
          if(res.data.code === 200) {
            this.setState({ numberEmpty : res.data.data});
          } else {
            ALERT.showToastAlter('Error',  res.data.message);
          }
        },
        (err) => {
          window.location.replace('/systemerror');
        }
    )
  }

  getNumberStudent = () =>{
    ApiPortal.getNumberStudent().then(
        (res) => {
          LogSystem.info('Portal::API::getNumberStudent------------------------------: ');
          LogSystem.info(res);LogSystem.info(res.data.data.LMS);LogSystem.info(res.data.data.LMS_SN);LogSystem.info(res.data.data.LMS_VIP);
          if(res.data.code === 200) {
            this.setState({
              max: {
                ...this.state.max,
                simple: res.data.data.LMS,
                sn: res.data.data.LMS_SN,
                vip: res.data.data.LMS_VIP,
                vipSN: res.data.data.LMS_VIP_SN
              }
            });
          } else {
            ALERT.showToastAlter('Error',  res.data.message);
          }
        },
        (err) => {
          window.location.replace('/systemerror');
        }
    )
  }

  onChange = (event) => {
    console.log("onChange");
    let className = event.target.className;
    let value = event.target.value;
    swal({
      title: 'Warning',
      text: "Bạn có chắc chắn muốn thay đổi cấu hình?",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Chắc chắn',
      cancelButtonText: 'Hủy'
    }).then((result) => {
      if (result.value) {
        this.onProcessChange(className, value);
      }
    })
  }

  onChangeNumber = (event) => {
    console.log("onChangeNumber");
    let className = event.target.className;
    let value = event.target.value;
    let messageErr = 'Bạn chỉ được phép nhập từ 1 -> 9!';

    switch(className) {
      case "number-empty-class":
        console.log("number-empty-class");
        if(!this.isValidNumberEmpty(value)){
          ALERT.showToastAlter('Error',  'Bạn chỉ được phép nhập từ 1 -> 99!');
          return;
        }
        this.setState({
          numberEmpty: value
        });
        break;
      case "number-student-simple":
        console.log("number-student-simple");
        if(!this.isValidNumberMax(value)){
          ALERT.showToastAlter('Error',  messageErr);
          return;
        }
        this.setState({
          max:{
            ...this.state.max,
            simple: value
          }
        });
        break;
      case "number-student-sn":
        console.log("number-student-sn");
        if(!this.isValidNumberMax(value)){
          ALERT.showToastAlter('Error',  messageErr);
          return;
        }
        this.setState({
          max:{
            ...this.state.max,
            sn: value
          }
        });
        break;
      case "number-student-vip":
        console.log("number-student-vip");
        if(!this.isValidNumberMax(value)){
          ALERT.showToastAlter('Error',  messageErr);
          return;
        }
        this.setState({
          max:{
            ...this.state.max,
            vip: value
          }
        });
        break;
      case "number-student-vip-sn":
        console.log("number-student-vip-sn");
        if(!this.isValidNumberMax(value)){
          ALERT.showToastAlter('Error',  messageErr);
          return;
        }
        this.setState({
          max:{
            ...this.state.max,
            vipSN: value
          }
        });
        break;
      default:
    }
  }

  onProcessChange = (className, value) =>{
    console.log("onChange");
    let listSimple = this.getListCurrentVcrSimple();
    let listVip = this.getListCurrentVcrVip();
    console.log(className, value);
    switch(className) {
      case "simple-ADOBE":
        console.log("simple-ADOBE");
        if(listSimple.includes(Constant.VCR_TYPE_ADB)){
          listSimple.splice(listSimple.indexOf(Constant.VCR_TYPE_ADB),1)
        }else{
          listSimple.push(Constant.VCR_TYPE_ADB)
        }
        this.updateVcrType(Constant.SERVICE_LMS, listSimple);
        break;
      case "simple-VCRX":
        console.log("simple-VCRX");
        if(listSimple.includes(Constant.VCR_TYPE_VCRX)){
          listSimple.splice(listSimple.indexOf(Constant.VCR_TYPE_VCRX),1)
        }else{
          listSimple.push(Constant.VCR_TYPE_VCRX)
        }
        this.updateVcrType(Constant.SERVICE_LMS, listSimple);
        break;
      case "simple-BBB":
        console.log("simple-BBB");
        if(listSimple.includes(Constant.VCR_TYPE_BBB)){
          listSimple.splice(listSimple.indexOf(Constant.VCR_TYPE_BBB),1)
        }else{
          listSimple.push(Constant.VCR_TYPE_BBB)
        }
        this.updateVcrType(Constant.SERVICE_LMS, listSimple);
        break;
      case "VIP-ADOBE":
        if(listVip.includes(Constant.VCR_TYPE_ADB)){
          listVip.splice(listVip.indexOf(Constant.VCR_TYPE_ADB),1)
        }else{
          listVip.push(Constant.VCR_TYPE_ADB)
        }
        this.updateVcrType(Constant.SERVICE_LMS_VIP, listVip);
        break;
      case "VIP-BBB":
        if(listVip.includes(Constant.VCR_TYPE_BBB)){
          listVip.splice(listVip.indexOf(Constant.VCR_TYPE_BBB),1)
        }else{
          listVip.push(Constant.VCR_TYPE_BBB)
        }
        this.updateVcrType(Constant.SERVICE_LMS_VIP, listVip);
        break;
      case "switch switch-deeplink":
        console.log("switch-deeplink");
        this.updateDeepLinkStatus();
        break;
      case "switch switch-list-class":
        console.log("switch-list-class");
        this.updateMixClassStatus();
        break;
      default:
    }
  }

  updateDeepLinkStatus = () =>{
    let status = !this.state.checkedDeeplink;
    ApiPortal.setDeepLinkStatus(status).then(
        (res) => {
          LogSystem.info('Portal::API::setDeepLinkStatus------------------------------: ');
          LogSystem.info(res);
          if(res.data.code === 200) {
            this.getDeepLinkStatus();
            this.showUpdateSuccessMessage();
          } else {
            this.showUpdateFailMessage();
          }
        },
        (err) => {
          window.location.replace('/systemerror');
        }
    )
  }

  updateMixClassStatus = () =>{
    let status = !this.state.checkedVCR;
    ApiPortal.setMixListStatus(status).then(
        (res) => {
          LogSystem.info('Portal::API::updateMixClassStatus------------------------------: ');
          LogSystem.info(res);
          if(res.data.code === 200) {
            this.getMixListClass();
            this.showUpdateSuccessMessage();
          } else {
            this.showUpdateFailMessage();
          }
        },
        (err) => {
          window.location.replace('/systemerror');
        }
    )
  }

  getListCurrentVcrSimple = () =>{
    let listVCR = [];
      if(this.state.simple.bbb) listVCR.push(Constant.VCR_TYPE_BBB);
      if(this.state.simple.adobe) listVCR.push(Constant.VCR_TYPE_ADB);
      if(this.state.simple.vcrx) listVCR.push(Constant.VCR_TYPE_VCRX);
    return listVCR;
  }

  getListCurrentVcrVip = () =>{
    let listVCR = [];
    if(this.state.vip.bbb) listVCR.push(Constant.VCR_TYPE_BBB);
    if(this.state.vip.adobe) listVCR.push(Constant.VCR_TYPE_ADB);
    return listVCR;
  }

  updateVcrType = (service, vcrTypes) =>{
    console.log("updateVcrType");
    if(!this.isValidArray(vcrTypes)){
      ALERT.showToastAlter('Error',  'Bạn phải chọn ít nhất 1 loại VCR');
      return;
    }
    let params = {
      serviceType: service,
      vcrTypes: vcrTypes
    };
    console.log(params);
    ApiPortal.updateVcrType(params).then(
        (res) => {
          LogSystem.info('Portal::API::updateVcrType------------------------------: ');
          LogSystem.info(res);
          if(res.data.code === 200) {
            this.getVcrList();
            this.showUpdateSuccessMessage();
          } else {
            this.showUpdateFailMessage();
          }
        },
        (err) => {
          window.location.replace('/systemerror');
        }
    )
  }

  isValidArray = (array) =>{
    return typeof array !== 'undefined' && array.length > 0;
  }

  renderListVcrSimple(type){
    if(type == Constant.ADMIN_TYPE_NORMAL || type == Constant.ADMIN_TYPE_ALL){
      return (
          <div>
            <p>Thường</p>
            <p><input className="simple-ADOBE" type="checkbox" checked={this.state.simple.adobe} onChange={this.onChange}/>&nbsp; ADOBE </p>
            <p><input className="simple-VCRX" type="checkbox"  checked={this.state.simple.vcrx} onChange={this.onChange}/>&nbsp; VCRX </p>
            {/*<p><input className="simple-BBB" type="checkbox" checked={this.state.simple.bbb} onChange={this.onChange}/>&nbsp; BBB </p>*/}
          </div>
      )
    }
  }

  renderListVcrVip(type){
    if(type == Constant.ADMIN_TYPE_VIP || type == Constant.ADMIN_TYPE_ALL){
      return (
          <div>
            <p>Vip</p>
            <p><input className="VIP-ADOBE" type="checkbox" checked={this.state.vip.adobe} onChange={this.onChange}/>&nbsp; ADOBE </p>
            {/*<p><input className="VIP-BBB" type="checkbox" checked={this.state.vip.bbb} onChange={this.onChange}/>&nbsp; BBB </p>*/}
          </div>
      )
    }
  }

  onSubmit = (event) =>{
    console.log("onSubmit");
    let className = event.target.className;
    swal({
      title: 'Warning',
      text: "Bạn có chắc chắn muốn thay đổi cấu hình?",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Chắc chắn',
      cancelButtonText: 'Hủy'
    }).then((result) => {
      if (result.value) {
        this.onProcessChangeNumber(className);
      }
    })
  }

  onProcessChangeNumber = (className) =>{
    if(className.includes("submit number-empty")){
      console.log("empty-class");
      this.updateNumberEmpty();
    }else{
      console.log("max-user");
      switch(className) {
        case "submit number-student-simple":
          console.log("number-student-simple");
          let simple = this.state.max.simple;
          if(!this.isValidSubmitNumber(simple)){
            this.showEmptyNumberMessage();
            return;
          }
          break;
        case "submit number-student-sn":
          console.log("number-student-sn");
          let sn = this.state.max.sn;
          if(!this.isValidSubmitNumber(sn)){
            this.showEmptyNumberMessage();
            return;
          }
          break;
        case "submit number-student-vip":
          console.log("number-student-vip");
          let vip = this.state.max.vip;
          if(!this.isValidSubmitNumber(vip)){
            this.showEmptyNumberMessage();
            return;
          }
          break;
        case "submit number-student-vip-sn":
          console.log("number-student-vip-sn");
          let vipSN = this.state.max.vipSN;
          if(!this.isValidSubmitNumber(vipSN)){
            this.showEmptyNumberMessage();
            return;
          }
          break;
        default:
      }
      this.updateMaxUser();
    }

  }

  updateMaxUser = () =>{

    let params = {
      "lms": this.state.max.simple,
      "lmsVip": this.state.max.vip,
      "lmsSN": this.state.max.sn,
      "lmsVipSN": this.state.max.vipSN,
    }
    ApiPortal.setNumberStudent(params).then(
        (res) => {
          LogSystem.info('Portal::API::setNumberStudent------------------------------: ');
          LogSystem.info(res);
          if(res.data.code === 200) {
            this.getNumberStudent();
            this.showUpdateSuccessMessage();
          } else {
            this.showUpdateFailMessage();
          }
        },
        (err) => {
          window.location.replace('/systemerror');
        }
    )
  }

  updateNumberEmpty = () =>{
    let value = this.state.numberEmpty;
    if(!this.isValidSubmitNumber(value)){
      this.showEmptyNumberMessage();
      return;
    }
    ApiPortal.setNumberEmpty(value).then(
        (res) => {
          LogSystem.info('Portal::API::setNumberEmpty------------------------------: ');
          LogSystem.info(res);
          if(res.data.code === 200) {
            this.getEmptyNumber();
            this.showUpdateSuccessMessage();
          } else {
            this.showUpdateFailMessage();
          }
        },
        (err) => {
          window.location.replace('/systemerror');
        }
    )
  }

  isValidSubmitNumber = (value) => {
    return value !== null && value !== '';
  }

  isValidNumberEmpty = (number) =>{
    return (number >=1 && number <= 99) || number == '';
  }

  isValidNumberMax = (number) =>{
    return (number >=1 && number <= 9) || number == '';
  }

  showUpdateSuccessMessage = () =>{
    ALERT.showToastAlter('Success',  Constant.MESSAGE_UPDATE_SUCCESS);
  }

  showUpdateFailMessage = () =>{
    ALERT.showToastAlter('Error',  Constant.MESSAGE_UPDATE_ERROR);
  }

  showEmptyNumberMessage = () =>{
    ALERT.showToastAlter('Error',  "Dữ liệu gửi lên không được để trống!");
  }

  render() {
    return (
        <div className="container">
          <div className="container">
            <div className="vcr-type">
              <h4>1. Thiết lập loại VCR</h4>
              {(this.renderListVcrSimple(this.state.role))}
              {(this.renderListVcrVip(this.state.role))}
            </div>
            <table>
              <tr>
                <td><h4>2. Thiết lập sử dụng Deeplink ADOBE</h4></td>
                <td>
                  <div className="">
                    <label>
                      <input ref="switch" checked={ this.state.checkedDeeplink } onChange={ this.onChange } className="switch switch-deeplink" type="checkbox" />
                      <div>
                        <div></div>
                      </div>
                    </label>
                  </div>
                </td>
              </tr>

              <tr>
                <td><h4>3. Thiết lập hiển thị danh sách lớp có cả Vip và Thường&nbsp;&nbsp;</h4></td>
                <td>
                  <div className="">
                    <label>
                      <input ref="switch" checked={ this.state.checkedVCR } onChange={ this.onChange } className="switch switch-list-class" type="checkbox" />
                      <div>
                        <div></div>
                      </div>
                    </label>
                  </div>
                </td>
              </tr>

              <tr>
                <td><h4>4. Thiết lập số lớp trống hiển thị</h4></td>
                <td>
                  <input className="number-empty-class" value={this.state.numberEmpty} onChange={ this.onChangeNumber } type="number" max="99" />
                  <span className="submit number-empty" onClick={this.onSubmit}>Submit</span>
                </td>
              </tr>

              <tr>
                <td><h4>5. Thiết lập số học viên tối đa trong lớp</h4></td>
                <td></td>
              </tr>
              {
                this.state.role == Constant.ADMIN_TYPE_NORMAL || this.state.role == Constant.ADMIN_TYPE_ALL
                    ?
                    <tr>
                      <td><p>&nbsp;&nbsp;Lớp Thường</p></td>
                      <td>
                        <input className="number-student-simple" value={this.state.max.simple} onChange={ this.onChangeNumber } type="number" max="99" />
                        <span className="submit number-student-simple" onClick={this.onSubmit}>Submit</span>
                      </td>
                    </tr>
                    :
                    <tr></tr>
              }
              {
                this.state.role == Constant.ADMIN_TYPE_NORMAL || this.state.role == Constant.ADMIN_TYPE_ALL
                    ?
                    <tr>
                      <td><p>&nbsp;&nbsp;Lớp Song ngữ thường</p></td>
                      <td>
                        <input className="number-student-sn" value={this.state.max.sn} onChange={ this.onChangeNumber } type="number" max="99" />
                        <span className="submit number-student-sn" onClick={this.onSubmit}>Submit</span>
                      </td>
                    </tr>
                    :
                    <tr></tr>
              }
              {
                this.state.role == Constant.ADMIN_TYPE_VIP || this.state.role == Constant.ADMIN_TYPE_ALL
                    ?
                    <tr>
                      <td><p>&nbsp;&nbsp;Lớp Vip</p></td>
                      <td>
                        <input className="number-student-vip" value={this.state.max.vip} onChange={ this.onChangeNumber } type="number" max="99" />
                        <span className="submit number-student-vip" onClick={this.onSubmit}>Submit</span>
                      </td>
                    </tr>
                    :
                    <tr></tr>
              }
              {
                this.state.role == Constant.ADMIN_TYPE_VIP || this.state.role == Constant.ADMIN_TYPE_ALL
                    ?
                    <tr>
                      <td><p>&nbsp;&nbsp;Lớp Song ngữ Vip</p></td>
                      <td>
                        <input className="number-student-vip-sn" value={this.state.max.vipSN} onChange={ this.onChangeNumber } type="number" max="99" />
                        <span className="submit number-student-vip-sn" onClick={this.onSubmit}>Submit</span>
                      </td>
                    </tr>
                    :
                    <tr></tr>
              }
            </table>

          </div>
        </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    apps: state.chooseAppReducer.apps
  }
}

const mapDispatchToProps = (dispatch, props) => {
  return {

  }
}

export default connect(mapStateToProps, mapDispatchToProps)(SystemConfigPage);