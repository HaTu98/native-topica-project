import React, { Component } from 'react';
import { connect } from 'react-redux';
import {uploadFile,  
        clearUploadedFiles, 
        submitNotification, 
        quickSendNotification, 
        getSenderDetail, 
        onChangeTab,
        validateStudentInfo} from '../redux/actions/notificationActions'
import InputReceiverTabs from '../components/notificationpush/InputReciverTabs';
import Datetime from 'react-datetime';
import '../style/react-datetime.css';
import InputErrorMessage from '../components/common/InputErrorMessage';
import swal from 'sweetalert2'
import CONSTANT from '../constants/Constant';
import {verifyToken} from '../redux/actions/loginActions'
import { BackupDataManager } from '../data/BackupDataManager';
import {LogSystem } from  '../log/index'
// import { Editor } from 'react-draft-wysiwyg';
import 'react-draft-wysiwyg/dist/react-draft-wysiwyg.css';
// import { EditorState , convertToRaw  } from 'draft-js';

// import uploadImageCallBack from '../data/UploadImage'

import EditorContent from '../components/notificationpush/EditorContent';
import ChoseThumbnail from '../components/notificationpush/ChoseThumbnail';
import ContentNotificationUtil from '../util/ContentNotificationUtil';
import * as ALERT from '../redux/actions/alertActions'
import { toast } from 'react-toastify';
import XSSUtil from '../util/XSSUtil';
// import CKEditor from "react-ckeditor-component";
var parser = require('cron-parser');

const NotificationType = {
    QUICKSEND: "QUICKSEND",
    PREPLAN: "PREPLAN",
    SCHEDULED: "SCHEDULED"
} 

const NotificationDeepLinkType = {
    HOME: "HOME",
    NOTIFY_DETAIL: "NOTIFY_DETAIL",
    LIVE_STREAM: "LIVE_STREAM",
    WEB: "WEB",
} 

const TemplateDefault = ["No", "Student Email"];

class NotificationPush extends Component {
    constructor(props) {
        super(props);
        this.state = {
            usernameReceivedList: [],
            title: '',
            body: '',
            bodyHtml: '',
            currentTab: 0,
            notificationType: '',
            deepLinkType: '',
            webLink: '',
            deepLinkTypeError: '',
            prePlanTime: '',
            cronExpression: '',
            titleError: null,
            bodyError: null,
            receiversTabError: null,
            isQuickSend: false,
            isSendOneTime: false,
            prePlanTimeError: '',
            cronExpressionError: '',
            notificationTypeError: '',
            editMode: false,
            imgUrl: null,
            appId: null,
            iconUrl: null,
            iconSentFrom: null,
            imageList: [],
            variableSet: TemplateDefault,
            personalInfos: null
        };
    }

    componentDidMount() {
        var url = new URL(window.location.href);
        var query_string = url.search;
        var search_params = new URLSearchParams(query_string); 
        var id = search_params.get('id');
        var appId = search_params.get('appId');
        // output : 100
        LogSystem.info('id: ' + id);
        LogSystem.info('appId: ' + appId)
        if(id !== null) {
            this.props.getSenderDetail(id);
            this.setState({editMode: true})
        } else  {
            this.setState({editMode: false})
        } 
        const chooseApp = BackupDataManager.getItem("choosenApp")
        if(chooseApp === undefined || chooseApp === null) {
            window.location.replace('/')
        }
        var app = JSON.parse(chooseApp);
        this.setState({
            appId: app.appId,
            iconUrl: app.iconUrl,
        }) 
    }

    componentWillMount () {
        LogSystem.info('componentWillMount------------------')
    }

    showValidateTitle = () => {
        if(this.state.titleError !== null) {
            return(<p className="text-danger">{this.state.titleError}</p>)
        }
    }

    showValidateBody = () => {
        if(this.state.bodyError !== null) {
            return(<p className="text-danger">{this.state.bodyError}</p>)
        }
    }

    onChangeTab = (tab) => {
        LogSystem.info('Portal::NotificationPush::onChangeTab::tab ' + tab);
        this.setState ({
            currentTab: tab,
            receiversTabError: null
        })
        this.props.onChangeTab()
    }

    onTitleChange = (e) => {
        this.setState({
            titleError: null
        })
        if(e.target.value.trim().length > 200) {
            this.setState({
                titleError: 'Tiêu đề không vượt quá 200 ký tự',
                title: e.target.value.trim().substring(0, 200)
            })
            return;
        }
        this.setState({
            title: e.target.value
        });
    } 


    onBodyChange = (e) => {
    } 

    validateTitleBeforSending = (title) => {
        LogSystem.info('validateTitleBeforSending: ' + title);
        if(title === null || title === '') {
            this.setState({
                titleError: 'Không cho phép trống trường tiêu đề'
            })
            return false;
        } 
        return true;
    } 

    validateBodyBeforSending = (body, bodyHtml) => {
        LogSystem.info('validateBodyBeforSending body: ' + body);
        LogSystem.info('validateBodyBeforSending bodyHtml: ' + bodyHtml);
        if(bodyHtml === null || bodyHtml === '') {
            this.setState({
                bodyError: 'Không cho phép trống trường nội dung'
            })
            return false;
        }
        if(body === null || body === '') {
            this.setState({
                bodyError: 'Nội dung phải chứa văn bản'
            })
            return false;
        }
        if(XSSUtil.isExistringScriptTag(body)) {
            this.setState({
                bodyError: 'không cho phép chưa thẻ script'
            })
            return false;
        } 
        return true;
    } 


    validateReceiversBeforSending = (receivers) => {
        LogSystem.info('validateReceiversBeforSending::receivers----------------------');
        LogSystem.info(receivers);
        if(receivers === undefined || receivers === null || receivers.length < 1) {
            this.setState({
                receiversTabError: 'Import file học viên hoặc chọn gửi tất cả'
            })
            return false;
        } else {
            this.setState({
                receiversTabError: undefined
            })
            return true;
        }
    }

    validateDeepLink = () => {
        if(this.state.deepLinkType === NotificationDeepLinkType.WEB 
            && (this.state.webLink === null || this.state.webLink === '')) {
                this.setState({
                    deepLinkTypeError: 'Điền link của trang web muốn tới ở đây khi chọn mở thông báo trên web'
                });
                return false;
            }
            return true;
    }

    onChange = (e) => {
        LogSystem.info('Portal::onChange ');
        LogSystem.info('Portal::onChange name: ' + e.target.name);
        LogSystem.info('Portal::onChange value: ' + ((e.target.type === 'checkbox') ?  e.target.checked : e.target.value));
        var target = e.target;
        var name = target.name;
        var value = target.type === 'checkbox' ? target.checked : target.value;
        this.setState({
            [name]: value
        });
    }

    onInput = (e) => {
        LogSystem.info('Portal::onInput ');
    }

    onSend = () => {
        LogSystem.info('send button from pager');
        LogSystem.info(this.state)
        const { personalInfos, currentTab, variableSet} = this.state;
        const title = this.state.title.trim();
        const body = this.state.body.trim();
        const bodyHtml = this.state.bodyHtml.trim();
        let status = true;
        status = this.validateTitleBeforSending(title) && status;
        status = this.validateBodyBeforSending(body, bodyHtml) && status;
        status = this.validateDeepLink() && status;
        status = this.validateTimeSent() && status;
        status =  this.validateCronExpression() && status;
        var isSendAll = false;
        if(currentTab === 0) {
            status = this.validateReceiversBeforSending(personalInfos) && status;
            isSendAll = false;
        } else {
            isSendAll = true;
            LogSystem.info('variableSet ----------------------------');
            LogSystem.info(variableSet);
            if(variableSet !== undefined && variableSet !== null && variableSet.length > 2) {
                ALERT.showToastAlter('Error',  'Không cho chép gửi tất cả khi nội dung notification chứa các biến', toast.TYPE.ERROR);
                status = false;
            }   
        }
        if(status === false) {
            return;
        } 
        var notificationData = {
            iconSentFrom: (this.state.iconSentFrom === null || this.state.iconSentFrom === 'null') ? '' : this.state.iconSentFrom,
            appId: this.state.appId,
            iconUrl: (this.state.iconUrl === null || this.state.iconUrl === 'null') ? '' : this.state.iconUrl,
            // title: encodeURI(title),
            // body: encodeURI((body.length > 250 ) ? body.substring(0, 250) : body),
            // bodyHtml: encodeURI(bodyHtml),
            title: title,
            body: (body.length > 250 ) ? body.substring(0, 250) : body,
            bodyHtml: bodyHtml,
            timeSent: this.state.prePlanTime * 1,
            cronExpression: (this.state.cronExpression === null) ? null : this.state.cronExpression.trim(),
            type: this.state.notificationType,
            imgUrl:  (this.state.imgUrl === null || this.state.imgUrl === 'null') ? '' : this.state.imgUrl,
            sendAll: isSendAll,
            personalInfos: personalInfos,
            deepLinkType:  (this.state.deepLinkType === null || this.state.deepLinkType === "") ? NotificationDeepLinkType.NOTIFY_DETAIL : this.state.deepLinkType,
            webLink:  (this.state.webLink === null) ? '' : this.state.webLink.trim()
        }
        var warningMessage = null;
        if(this.state.notificationType === CONSTANT.NotificationType.QUICKSEND) {
            warningMessage = 'Bạn chắc chắn muốn gửi thông báo không ?'
        } else {
            warningMessage = 'Bạn chắc chắn muốn tạo thông báo không ?'
        }
        
        swal({
            title: 'Warning',
            text: warningMessage,
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Chắc chắn',
			cancelButtonText: 'Hủy'
        }).then((result) => {
            if (result.value) {
                this.props.submitNotification(notificationData);
            }
        })
        
    }

    onChangeReceivers = (receivers) => {
        LogSystem.info('Portal::onChangeReceivers receivers -------------------------------------')
        LogSystem.info(receivers)
        this.setState({
            personalInfos: receivers,
        })
    }

    onEnteringReceivers = () => {
        this.setState({
            receiversTabError: undefined
        })
    }

    componentWillReceiveProps(nextProps){
        LogSystem.info('Portal::NotificationPush::componentWillReceiveProps nextProps: ');

        LogSystem.info(nextProps)
        if(nextProps){
            var {files, uploadedFile} = nextProps;
            this.setState({
                files: files,
                uploadedFile: uploadedFile
            });
            if(nextProps.uploadedFiles !== undefined) {
                this.setState({
                    receiversTabError: undefined
                }); 
            }
            if(this.state.editMode === true && nextProps.notificaitonPush !== null) {
                this.setState({
                    usernameReceivedList: nextProps.notificaitonPush.usernameReceivers,
                    title: nextProps.notificaitonPush.detailContent.title,
                    body: nextProps.notificaitonPush.detailContent.body,
                    bodyHtml: nextProps.notificaitonPush.detailContent.bodyHtml,
                    imgUrl: (nextProps.notificaitonPush.detailContent.imgUrl ===  null || nextProps.notificaitonPush.detailContent.imgUrl ===  "null") ? '' : nextProps.notificaitonPush.detailContent.imgUrl,
                    iconSentFrom: (nextProps.notificaitonPush.iconSentFrom ===  null || nextProps.notificaitonPush.iconSentFrom ===  "null") ? '' : nextProps.notificaitonPush.iconSentFrom,
                    currentTab: ((nextProps.notificaitonPush.sendAll === true ) ? 2 : 0)
                })

            } 
        }
    }

    

    /*------ PrePlan -----*/
    onBlurOfPrePlan = (date) => {
        LogSystem.info('Portal::onBlurOfPrePlan date: ' + date);
        this.setState({
            prePlanTime: (date === undefined) ? '' : date,
            prePlanTimeError: ''
        })
    }

    onChangeQuickSend = (e) => {
        var target = e.target;
        var name = target.name;
        var value = target.checked;
        this.setState({
            [name]: value,
            prePlanTime: '',
            prePlanTimeError: ''
        });
    }

    validateTimeSent = () => {
        const {prePlanTime, isQuickSend} = this.state; 
        if(this.state.notificationType === NotificationType.PREPLAN && this.state.prePlanTime === '') {
            this.setState({
                prePlanTimeError: "Yêu cầu chọn thời gian gửi khi chọn loại gửi một lần với lịch trình"
            })
            return false;
        }
        return true;
    }

    /* ------PrePlan ----*/

    /* ---Loai thông báo---*/

    onSelectNotificationType = (e) => {
        LogSystem.info(e.target.value);  
        this.setState({
            notificationType: e.target.value,
            prePlanTime: '',
            cronExpression: '',
            prePlanTimeError: '',
            cronExpressionError: '',
        });
    }

    /* --------------------*/
    /* ---------Deeplink-----------*/
    onSellectDeepLinkType = (e) => {
        LogSystem.info(e.target.value);  
        this.setState({
            deepLinkType: e.target.value
        });
        if(e.target.value !== NotificationDeepLinkType.WEB) {
            this.setState({
                webLink: null
            });
        }
    }

    /*---------GronExpression------------ */

    onCronExpressionChange = (e) => {
        if(e.target.value === undefined || e.target.value === null) {
            return;
        }
        var cron = e.target.value;
        LogSystem.info('cron --------------------------')
        LogSystem.info(cron)
        LogSystem.info('verify cron expression')
        // this.setState({
        //     [e.target.name]: cron,
        // });
        this.setState({
            [e.target.name]: cron,
            cronExpressionError: ''
        });
    }

    onCronExpressionBlur = (e) => {
        LogSystem.info('onCronExpressionBlur---------------');
        if(e.target.value === undefined || e.target.value === null) {
            return;
        }
        var cron = e.target.value.trim();
        LogSystem.info('cron : _' + cron + '_')
        LogSystem.info('verify cron expression')
        try {
            var interval = parser.parseExpression(cron);
            this.setState({
                [e.target.name]: cron,
                cronExpressionError: ''
            });
        } catch (err) {
            LogSystem.info('onCronExpressionBlur::catch err: ' + err);
            this.setState({         
                cronExpressionError: 'Không đúng định dạng Cron Expression'
            });
        }
    }


    onEditorChange(evt){
        LogSystem.info("onChange fired with event info: " + evt);
        var newContent = evt.editor.getData();
        LogSystem.info("newContent: " + newContent);    
        LogSystem.info("text: " + newContent.replace(/<\/?[^>]+>/ig, " "));
    }

    onChangeIsOneTime = (e) => {
        var target = e.target;
        var name = target.name;
        var value = target.checked;
        this.setState({
            [name]: value,
            cronExpression: '',
            cronExpressionError: ''
        });
    }

    validateCronExpression = () => { 
        if(this.state.cronExpressionError !== null && this.state.cronExpressionError !== '') return false;
        if(this.state.notificationType === NotificationType.SCHEDULED && this.state.cronExpression === '') {
            this.setState({
                cronExpressionError: "Yêu cầu thêm cron expression khi chọn loại gửi nhiều lần với lịch trình"
            })
            return false;
        }
        return true;
    }

    /*---------GronExpression------------ */

    validateNotificationType = () => {
        if(this.state.notificationType === undefined || this.state.notificationType === '') {
            this.setState({
                notificationTypeError: "Chưa chọn loại thông báo"
            })
            return true;
        }
        return false;
    }

    // Onchange CKeditor
    onChangeContent = (body, bodyHtml)  => {
        LogSystem.info("variableSet ---------------------------------");
        var variables = ContentNotificationUtil.getAllVariablesFromBody(body);
        LogSystem.info(variables);
        var variableSet = TemplateDefault;
        variableSet = variableSet.concat(Array.from(variables));
        LogSystem.info("onChangeContent::variableSet ---------------------");
        LogSystem.info(variableSet);
        this.setState({
            body,
            bodyHtml,
            variableSet: variableSet,
            bodyError: null
        });  
    }

    onImageListChange = (imageList) => {
        // LogSystem.info('NotificationPush::onImageListChange ');
        // LogSystem.info(imageList);
        this.setState({
            imageList: imageList
        });
    } 

    onChoseThumbnail = (thumbnail) => {
        this.setState({
            imgUrl: thumbnail
        });
    }

    clearTimeSent = () => {
        this.setState({
            prePlanTime: null
        })
    }

    render() {
        return (
            <div>
                <div className="row">
                    <div className="col-md-6">
                        <div className="panel panel-flat" style={{minHeight: 2000}}>
                            <div className="panel-heading">
                                <h5 className="panel-title">Loại thông báo - Người nhận</h5>
                            </div>
                            <div className="panel-body">

                                <div className="form-group">
                                    <label htmlFor="sel1">1. Loại thông báo <span className="text-danger">*</span></label>
                                    <select className="form-control" id="sel1" onChange={this.onSelectNotificationType}>
                                        <option value=''>-- Chọn loại thông báo --</option>
                                        <option value="QUICKSEND">Gửi Ngay</option>
                                        <option value="PREPLAN">Gửi Một Lần Theo Lịch</option>
                                        <option value="SCHEDULED">Gửi Nhiều Lần Theo Lịch</option>
                                    </select>
                                    <InputErrorMessage>{this.state.notificationTypeError}</InputErrorMessage>
                                </div>

                                <div className="form-group">
                                    <label htmlFor="pwd">2. Thời gian gửi <b className="text-primary"> [ Chỉ chọn với loại Gửi Một Lần Theo Lịch ] </b></label>
                                    <div className="picker_wrapper" >
                                        <Datetime data-toggle="tooltip" data-placement="top" title="Tooltip on top"
                                            id="prePlanTime"
                                            value={this.state.prePlanTime}
                                            name="prePlanTime"
                                            onChange={this.onBlurOfPrePlan}
                                            inputProps={{readOnly: "true", disabled: this.state.notificationType !== NotificationType.PREPLAN}}
                                            dateFormat="DD-MM-YYYY"
                                            closeOnSelect={true}
                                        />
                                         {(this.state.prePlanTime === null || this.state.prePlanTime === '') ? undefined : <button className="picker_clear_button" onClick={() => this.clearTimeSent()}><i className="icon-cross2"></i></button> } 
                                    </div>
                                    <InputErrorMessage>{this.state.prePlanTimeError}</InputErrorMessage>
                                </div>
                                <div className="form-group">    
                                    <label htmlFor="pwd">3. Lịch trình Cron Expression <b className="text-primary"> [ Chỉ chọn với loại Gửi Nhiều Lần Theo Lịch ]</b></label>
                                    <br></br>                                    
                                    <a className="underline-text" href="http://www.cronmaker.com/" target="_blank">Lấy Cron Expression ở đây</a>
                                            <input type="text" 
                                            className="form-control textarea-fixed-size" 
                                            id="cron-expression" 
                                            value={this.state.cronExpression}
                                            name ="cronExpression"
                                            disabled={this.state.notificationType !== NotificationType.SCHEDULED}
                                            onChange ={this.onCronExpressionChange}
                                            onBlur ={this.onCronExpressionBlur}
                                            ></input>
                                    <InputErrorMessage>{this.state.cronExpressionError}</InputErrorMessage>
                                </div>

                                <div className="form-group">
                                    <label htmlFor="sel1">4. DeepLink  <b className="text-primary"> [ Màn hình sẽ được mở khi click vào thông báo ]</b></label>
                                    <select className="form-control" id="sel1" onChange={this.onSellectDeepLinkType}>
                                        <option value=''>-- Chọn loại màn hình --</option>
                                        <option value={NotificationDeepLinkType.NOTIFY_DETAIL}>Mở trên màn hình chi tiết thông báo</option>
                                        <option value={NotificationDeepLinkType.WEB}>Mở thông báo trên web</option>
                                    </select>
                                </div>
                                {this.state.deepLinkType == NotificationDeepLinkType.WEB ? 
                                 <div className="form-group">
                                    <label htmlFor="webLink">Link trang web muốn mở notification <span className="text-danger">*</span> </label>
                                    <textarea type="text" 
                                            className="form-control textarea-fixed-size" 
                                            id="webLink" 
                                            value={this.state.webLink ===  null  ? '' : this.state.webLink}
                                            name ="webLink"
                                            rows="2" 
                                            onChange={this.onChange}></textarea>
                                    <InputErrorMessage>{this.state.deepLinkTypeError}</InputErrorMessage>
                                </div> : undefined }

                                <div className="form-group">   
                                    <label htmlFor="pwd" >5. Người nhận<span className="text-danger"> *</span> </label>
                                    <InputReceiverTabs
                                        onChangeReceivers = {this.onChangeReceivers}
                                        tab = {this.state.currentTab}
                                        onChangeTab = {this.onChangeTab}
                                        currentTab = {this.state.currentTab}
                                        receiversTabError={this.state.receiversTabError}
                                        onEnteringReceivers = {this.onEnteringReceivers}
                                        usernameReceivedList={this.state.usernameReceivedList}
                                        editMode={this.state.editMode}
                                        variableSet={this.state.variableSet}
                                        validateStudentInfo={this.props.validateStudentInfo}
                                        bodyHtml={this.state.body}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-6" >
                        <div className="panel panel-flat" style={{minHeight: 2000}}>
                            <div className="panel-heading">
                                <h5 className="panel-title">Nội dung</h5>
                            </div>

                            <div className="panel-body">

                                <div className="form-group">
                                    <label htmlFor="pwd" >6. Tiêu đề <span className="text-danger">*</span> </label>
                                    <textarea type="text" 
                                            className="form-control textarea-fixed-size" 
                                            id="pwd" 
                                            value={this.state.title ===  null  ? '' : this.state.title}
                                            name ="title"
                                            // maxLength="201"
                                            rows="4" 
                                            onChange={this.onTitleChange}></textarea>
                                    {this.showValidateTitle()}
                                </div>
                                <div className="form-group">
                                    <label htmlFor="body" >7. Nội dung <span className="text-danger">*</span>  &nbsp;  &nbsp; Note: Đặt tên biến theo cú pháp <span className="text-danger"> &#123;&#123;variable&#125;&#125; </span> </label>  
                                    <EditorContent
                                        onChangeContent={this.onChangeContent}
                                        uploadImageCallBack={this.uploadImageCallBack}  
                                        onImageListChange={this.onImageListChange}  
                                    >
                                    </EditorContent>
                                    <InputErrorMessage>{this.state.bodyError}</InputErrorMessage>
                                </div>  

                                <div className="form-group">
                                    <label htmlFor="body" >8. Chọn Thumbnail </label> <br></br>
                                    <ChoseThumbnail
                                        imageList={this.state.imageList}
                                        onChoseThumbnail={this.onChoseThumbnail}
                                    >
                                    </ChoseThumbnail>    
                                </div>
                                <div className="form-group">
                                    <label htmlFor="body" >9. Icon thông báo</label> <br></br>
                                    <a className="underline-text" href="http://upanh.vforum.vn/" target="_blank">Truy cập vào đây để upload ảnh và điền link vào ô bên dưới</a>
                                    <textarea rows="3" 
                                        type="text" 
                                        id="iconSentFrom" 
                                        value={this.state.iconSentFrom === null ? '' : this.state.iconSentFrom}
                                        className="form-control textarea-fixed-size"
                                        name = "iconSentFrom"
                                        onChange={this.onChange}
                                        />
                                </div>
                                
                                <div className="row">
                                    <div className="col-sm-4">
                                        <button className="btn btn-success" disabled={this.state.notificationType !== NotificationType.QUICKSEND} onClick = {() => this.onSend()}>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Gửi Ngay&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</button> 
                                       
                                    </div>
                                    <div className="col-sm-4">
                                        <button className="btn btn-success" disabled={this.state.notificationType !== NotificationType.PREPLAN && this.state.notificationType !== NotificationType.SCHEDULED } onClick = {() => this.onSend()}>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Lưu Thông Báo Lịch Trình &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</button>
                                    </div>
                                </div>
                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

const mapStateToProps = state => {
    return {
        files: state.importFileReducer.files,
        uploadedFiles: state.importFileReducer.uploadedFiles,
        uploadedFile: state.importFileReducer.uploadedFile,
        notificaitonPush: state.notifcationReducer.notificaitonPush
    }
}

const mapDispatchToProps = (dispatch, props) => {
    return {
        submitNotification: (params) => {
            dispatch(submitNotification(params));
        },
        quickSendNotification: (params) => {
            dispatch(quickSendNotification(params));
        },
        getSenderDetail: (senderId) => {
            dispatch(getSenderDetail(senderId))
        },
        onChangeTab: () => {
            dispatch(onChangeTab())
        },
        validateStudentInfo: (param, successCalback) => {
            validateStudentInfo(param, successCalback);
        },
        verifyToken: () => {
            verifyToken()
        }
    }
}

export default  connect(mapStateToProps, mapDispatchToProps)(NotificationPush);
