import React, { Component } from 'react';
import { connect } from 'react-redux';
import {loadAllAppManagers, 
        createNewNotificationApp, 
        closerAppModal, 
        showAppModal,
        saveNewAppManager,
        changeManagerStatusInApp,
        onChangeAppMangerModaShowing,
        onDeleteApp,
        removeManagerInApp,
        updateManager} from '../redux/actions/appManagerAction';
import '../style/index.css'
import NotificaitonAppModal from '../components/notificationappmanager/NotificaitonAppModal';
import NotificaitonAppMangerModal from '../components/notificationappmanager/NotificaitonAppMangerModal';
import { LogSystem } from '../log/index'
import CONSTANT from '../constants/Constant';
import NotificationAppBox from '../components/notificationappmanager/NotificationAppBox';

class NotificationAppManagerPage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isShowModal: false,
            isCreateMode: true,
            appIdFocusing: null,
            keyInAppsArrayFocusing: null
        }
    }

    onChangeModalShowing = (isShow) => {
        if(isShow === true) {
            this.props.showAppModal(null, CONSTANT.AppManager.AppModal.Mode.Create);
        } else {
            this.props.closerAppModal();
        }
    }

    componentDidMount  = ()  => {
        this.props.loadAllAppManagers();
        LogSystem.info("NotificationAppManagerPage::componentDidMount ---------------");
        LogSystem.info(this.props.mangerModal);
    }


    componentWillReceiveProps = (newProps) => {
        LogSystem.info('Portal::componentWillReceiveProps::newProps------------------------');
        LogSystem.info(newProps);
    }

    onSaveNewNotificationApp = (param) => {
        this.props.createNewNotificationApp(param);
    }

    onViewDetail = (appInfo) => {
        LogSystem.info('NotificationAppManagerPage::onViewDetail')
        LogSystem.info(appInfo)
        this.props.showAppModal(appInfo, CONSTANT.AppManager.AppModal.Mode.View);
    }

    // app manager
    onSaveNewAppManager = (username, studentTypeSupported) => {
        var appManager = {
            manager: {
                username: username 
            },
            app: {
                id: this.state.appIdFocusing
            },
            studentTypeSupported: studentTypeSupported,
            status: "ACTIVE"
        }
        this.props.saveNewAppManager(appManager, this.state.keyInAppsArrayFocusing);
    }

    onUpdateManager = (userId) => {

    } 

    onEditManger = (detail, appIndex, keyInUserSubcribeds) => {
        LogSystem.info('onEditManger-----------------------------');
        LogSystem.info(detail);
        LogSystem.info(appIndex);
        LogSystem.info(keyInUserSubcribeds);
        this.props.onChangeAppMangerModaShowing(true, CONSTANT.Modal.Mode.Update, detail, appIndex, keyInUserSubcribeds);
    }

    deleteApp = (index, appid) => {
        this.props.onDeleteApp(index, appid);
    } 

    addNewUserToApp = (appIdFocusing, keyInAppsArrayFocusing) => {
        LogSystem.info('Portal::NotificationAppManagerPage::addNewUserToApp----------')
        this.setState({
            appIdFocusing,
            keyInAppsArrayFocusing
        })
        this.props.onChangeAppMangerModaShowing(true, CONSTANT.Modal.Mode.Create);
    }

    onChangeAppMangerModaShowing = (isShowed) => {
        LogSystem.info('Portal::NotificationAppManagerPage::onChangeAppMangerModaShowing')
        this.props.onChangeAppMangerModaShowing(isShowed, CONSTANT.Modal.Mode.Create)
    }

    render() {
        return (
            <div>
                <div className="panel panel-flat">
                    <div className="panel-heading">
                        <h5 className="panel-title">Quản lý người dùng app</h5>
                        <div className="top_right_box">
                            <div className="row">
                                <div className="pull-right">
                                    {/* <button type="button" class="btn btn-primary">Thêm App Cho gửi Notification</button> */}
                                    <button class="btn btn-primary" onClick = {() => this.onChangeModalShowing(true)}>Thêm app</button>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div className="panel-body">
                        <NotificationAppBox
                            appMangerList = {this.props.appMangerList}
                            onViewDetail={this.onViewDetail}
                            addNewUserToApp = {this.addNewUserToApp}
                            removeManagerInApp={this.props.removeManagerInApp}
                            onEditManger={this.onEditManger}
                            deleteApp={this.deleteApp}
                            changeManagerStatusInApp = {this.props.changeManagerStatusInApp}
                        ></NotificationAppBox>
                    </div>
                </div>


                {this.props.modal.isModalShow ===  true ? 
                    <NotificaitonAppModal 
                        onChangeModalShowing = {this.onChangeModalShowing}
                        onSaveNewNotificationApp = {this.onSaveNewNotificationApp}
                        appInfo = {this.props.modal.appInfo}
                        mode={this.props.modal.mode}
                    /> : 
                    <div/>
                }
                {this.props.mangerModal.isShow === true ? 
                    <NotificaitonAppMangerModal
                        onSaveNewAppManager = {this.onSaveNewAppManager}
                        onChangeAppMangerModaShowing={this.onChangeAppMangerModaShowing}
                        detail={this.props.mangerModal.detail}
                        mode={this.props.mangerModal.mode}
                        updateManager={this.props.updateManager}
                        /> : 
                    <div/>    
                }
                
            </div>
        );
    }
}


const mapStateToProps = state => {
    return {
        appMangerList: state.appManagerReducer.appMangerList,
        modal: state.appManagerReducer.modal,
        mangerModal: state.appManagerReducer.managerModal
    }
}

const mapDispatchToProps = (dispatch, props) => {
    return {
        loadAllAppManagers: () => {
            dispatch(loadAllAppManagers())
        },
        createNewNotificationApp: (param) => {
            dispatch(createNewNotificationApp(param))
        },
        closerAppModal: () => {
            dispatch(closerAppModal())
        },
        showAppModal: (param, mode) => {
            dispatch(showAppModal(param, mode));
        },
        saveNewAppManager: (param, keyInAppsArray) => {
            dispatch(saveNewAppManager(param, keyInAppsArray))
        },
        changeManagerStatusInApp: (param, keyInAppsArray, keyInUserSubcribeds) => {
            dispatch(changeManagerStatusInApp(param, keyInAppsArray, keyInUserSubcribeds))
        },
        onChangeAppMangerModaShowing: (isShowed, mode, ...data) => {
            dispatch(onChangeAppMangerModaShowing(isShowed,  mode, ...data))
        },
        onDeleteApp: (index, appid) => {
            dispatch(onDeleteApp(index, appid))
        },
        removeManagerInApp: (userId, keyInAppsArray, keyInUserSubcribeds) => {
            dispatch(removeManagerInApp(userId, keyInAppsArray, keyInUserSubcribeds))
        },
        updateManager: (managerApp, keyInAppsArray, keyInUserSubcribeds) => {
            dispatch(updateManager(managerApp, keyInAppsArray, keyInUserSubcribeds))
        }
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(NotificationAppManagerPage);
