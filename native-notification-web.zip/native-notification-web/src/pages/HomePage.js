import React, { Component } from 'react';
import Header from '../components/common/Header';
import Footer from '../components/common/Footer';
import Siderbar from '../navigation/SiderBar';
import { connect } from 'react-redux';
import {logoutAction, verifyToken} from '../redux/actions/loginActions'
import { LogSystem } from '../log/index'

class HomePage extends Component {

    constructor(props) {
        super(props);
        this.state = {
            isShowAlert: false,
            isLogin: false
        }
    }

    componentDidMount() {
        this.props.verifyToken();
    }

    componentWillReceiveProps(nextProps){
        if(nextProps){
            var {isShowAlert} = nextProps;
            this.setState({
                isShowAlert: isShowAlert
            });
        }
    }

    onConfirm = () => {
        LogSystem.info('click confirm')
    }
    
    onLogout = () => {
        LogSystem.info('Portal::App::logout')
        this.props.logout()
    }

    render() {
        
        return (

                <div>
                    {/* <ToastContainer /> */}

                    
                    <Header user={this.props.user}
                            logout = {this.onLogout}
                    ></Header>

            
                    {/* Page container */}
                    <div className="page-container" style={{height:'100vh'}}>

                        {/* Page content */}
                        <div className="page-content">

                            {(this.props.isDisplaySliderBar === true) ? <Siderbar user={this.props.user}></Siderbar> : undefined}
                        
                            {/* Main content */}
                            <div className="content-wrapper">

                                {/* Page header */}
                                <div className="page-header">
                                    <div className="page-header-content">
                                        {(this.props.isDisplaySliderBar === true) ? <br/> : undefined}
                                    </div>
                                </div>
                                {/* /page header */}

                                {/* Content area */}
                                <div className="content">
                                    <div>
                                        {this.props.content}
                                    </div>
                                    <Footer></Footer>
                                </div>
                                {/* /content area */}

                            </div>
                            {/* /main content */}

                        </div>
                        {/* /page content */}

                    </div>
                    {/* /page container */}

                </div>    
        );
    }
}

const mapStateToProps = state => ({
    isShowAlert: state.alertReducer.isShowAlert,
    token: state.loginReducers.token,
    user: state.loginReducers.user
});

const mapDispatchToProps = (dispatch, props) => {
    return {
        logout: () => {
            dispatch(logoutAction())
        },
        verifyToken: () => {
            dispatch(verifyToken())
        }
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(HomePage);
