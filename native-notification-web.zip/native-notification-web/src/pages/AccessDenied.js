import React, { Component } from 'react';
import {TokenManager } from '../data/TokenManager'

class AccessDenied extends Component {

    componentDidMount() {
        TokenManager.clearAll();
    }

    render() {
        return (
            <div className="container">
                <div className="alert alert-warning">
                    {/* <button type="button" className="close" data-dismiss="alert" aria-hidden="true">&times;</button> */}
                    <strong>Tài khoản của bạn không được cấp quyền truy cập</strong>
                    <p>Về  <a href="/"> Trang Chủ </a></p>
                </div>
            </div>
        );
    }
}

export default AccessDenied;