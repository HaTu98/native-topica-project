import React, { Component } from 'react';

class SystemErrorPage extends Component {
    render() {
        return (
            <div className="container">
                <div className="alert alert-warning">
                    {/* <button type="button" className="close" data-dismiss="alert" aria-hidden="true">&times;</button> */}
                    <strong>Hệ thống dang bảo trì không thể truy cập</strong>
                    <p>Về  <a href="/"> Trang Chủ </a></p>
                </div>
            </div>
        );
    }
}

export default SystemErrorPage;