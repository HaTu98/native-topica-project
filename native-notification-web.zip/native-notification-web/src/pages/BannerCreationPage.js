import React, { Component } from 'react';
import { connect } from 'react-redux';
import {createNewBanner} from '../redux/actions/bannerAction'
import Datetime from 'react-datetime';
import '../style/react-datetime.css';
import InputErrorMessage from '../components/common/InputErrorMessage';
import swal from 'sweetalert2'
import CONSTANT from '../constants/Constant';
import {LogSystem } from  '../log/index'
// import { Editor } from 'react-draft-wysiwyg';
import 'react-draft-wysiwyg/dist/react-draft-wysiwyg.css';
// import { EditorState , convertToRaw  } from 'draft-js';

// import uploadImageCallBack from '../data/UploadImage'

import * as ALERT from '../redux/actions/alertActions'
import { toast } from 'react-toastify';
import EditorBanner from '../components/banner/EditorBanner';
import BannerInputReceiverTabs from '../components/banner/BannerInputReceiverTabs';
import XSSUtil from '../util/XSSUtil';
// import CKEditor from "react-ckeditor-component";



const NotificationDeepLinkType = {
    HOME: "HOME",
    NOTIFY_DETAIL: "NOTIFY_DETAIL",
    LIVE_STREAM: "LIVE_STREAM",
    WEB: "WEB",
} 



class BannerCreationPage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            timeStart: null,
            timeStartError: null,
            timeEnd: null,
            timeEndError: null,
            deepLinkType: '',
            additionalData: '',
            usernameReceivedList: [],
            studentTypeSendAll: null,
            name: '',
            bodyHtml: '',
            webLink: '',
            currentTab: 0,
            bodyLength: 0
        };
    }

    showValidateTitle = () => {
        if(this.state.titleError !== null) {
            return(<p className="text-danger">{this.state.titleError}</p>)
        }
    }

    showValidateBody = () => {
        if(this.state.bodyError !== null) {
            return(<p className="text-danger">{this.state.bodyError}</p>)
        }
    }

    onChangeTab = (tab) => {
        LogSystem.info('Portal::NotificationPush::onChangeTab::tab ' + tab);
        this.setState ({
            currentTab: tab,
            receiversTabError: null,
            studentTypeSendAll: null,
            usernameReceivedList: []
        })
    }

    onTitleChange = (e) => {
        LogSystem.info('e.target.value');
        var value = e.target.value;
        LogSystem.info(value.length);
        this.setState({
            titleError: null        
        })
        if(value !== null && value.trim().length > 250) {
            this.setState({
                titleError: 'Tên banner không vượt quá 250 ký tự',
                name: value.trim().substring(0, 250)
            })
            return;
        }
        this.setState({
            name: value
        });
    } 

    onBodyChange = (e) => {
    } 

    validateTitleBeforSending = (title) => {
        LogSystem.info('validateTitleBeforSending: ' + title);
        if(title === null || title.trim() === '') {
            this.setState({
                titleError: 'Không cho phép trống trường tên'
            })
            return false;
        } 
        return true;
    } 

    validateBodyBeforSending = (bodyHtml, bodyLength) => {
        LogSystem.info('bodyHtml:bodyHtml:bodyHtml: ' + bodyHtml +  '_');
        if(bodyHtml.trim() === '' || (!bodyHtml.includes('<img') && bodyLength < 1)) {
            this.setState({
                bodyError: 'Trường này là bắt buộc'
            })
            return false;
        }
        if(XSSUtil.isExistringScriptTag(bodyHtml)) {
            this.setState({
                bodyError: 'không cho phép chưa thẻ script'
            })
            return false;
        } 
        return true;
    } 

    validateTimeStart = (timeStart) => {
        LogSystem.info('validateTimeStart::timeStart: ' + timeStart);
        if(timeStart === null) {
            this.setState({
                timeStartError: 'Không cho phép trống trường thời gian bắt đầu'
            })
            return false;
        }
        return true;
    } 


    validateTimeEnd = (timeEnd) => {
        if(timeEnd === null) {
            this.setState({
                timeEndError: 'Không cho phép trống trường thời gian kết thúc'
            })
            return false;
        }
        return true;
    } 

    validateReceiversBeforSending = (receivers) => {
        LogSystem.info('validateReceiversBeforSending::receivers----------------------');
        LogSystem.info(receivers);
        if(receivers === undefined || receivers === null || receivers.length < 1) {
            this.setState({
                receiversTabError: 'Import file học viên hoặc chọn trong phần chọn loại học viên'
            })
            return false;
        } else {
            this.setState({
                receiversTabError: undefined
            })
            return true;
        }
    }

    validateStudentTypeBeforSending = (studentType) => {
        LogSystem.info('validateStudentTypeBeforSending::studentType: ' + studentType);
        if(studentType === null || studentType === undefined || studentType === "") {
            this.setState({
                receiversTabError: 'Import file học viên hoặc chọn trong phần chọn loại học viên'
            })
            return false;
        } else {
            this.setState({
                receiversTabError: undefined
            })
            return true;
        }
    }

    validateDeepLink = () => {
        if(this.state.deepLinkType === NotificationDeepLinkType.WEB 
            && (this.state.webLink === null || this.state.webLink.trim() === '')) {
                this.setState({
                    deepLinkTypeError: 'Điền link của trang web muốn tới ở đây khi chọn mở thông báo trên web'
                });
                return false;
            }
            return true;
    }

    onChange = (e) => {
        LogSystem.info('Portal::onChange ');
        LogSystem.info('Portal::onChange name: ' + e.target.name);
        LogSystem.info('Portal::onChange value: ' + ((e.target.type === 'checkbox') ?  e.target.checked : e.target.value));
        var target = e.target;
        var name = target.name;
        var value = target.type === 'checkbox' ? target.checked : target.value;
        this.setState({
            [name]: value
        });
    }

    onChangeWeblink = (e) => {
        var value = e.target.value;
        this.setState({
            webLink: (value === undefined || value === null) ? null : value.trim(),
            deepLinkTypeError: null
        });
    }

    onInput = (e) => {
        LogSystem.info('Portal::onInput ');
    }

    onSave = () => {
        LogSystem.info('send button from pager');
        LogSystem.info(this.state)
        const { timeStart, timeEnd, deepLinkType, additionalData ,usernameReceivedList,name , bodyHtml, currentTab, studentTypeSendAll, bodyLength} = this.state;
        let status = true;
        status = this.validateTitleBeforSending(name) && status;
        status = this.validateBodyBeforSending(bodyHtml, bodyLength) && status;
        status = this.validateDeepLink() && status;
        status = this.validateTimeStart(timeStart) && status;
        status = this.validateTimeEnd(timeEnd) && status;

        if(currentTab === 0) {
            status = this.validateReceiversBeforSending(usernameReceivedList) && status;
        } else {
            status = this.validateStudentTypeBeforSending(studentTypeSendAll) && status;
        }
        if(status === false) {
            return;
        } 
        var notificationData = {
            name: encodeURI((name === null) ? null : name.trim()),
            bodyHtml: encodeURI(bodyHtml),
            timeStart: this.state.timeStart * 1,
            timeEnd: this.state.timeEnd * 1,
            deepLinkType: (this.state.deepLinkType === null) ? 'NONE' : this.state.deepLinkType.trim(),
            additionalData: {"webLink": this.state.webLink},
            emailStudentList: this.state.usernameReceivedList,
            serviceTypeSendAll: (studentTypeSendAll == null) ? 'NORMAL' : studentTypeSendAll,
            deepLinkType:  (this.state.deepLinkType === null || this.state.deepLinkType === "") ? NotificationDeepLinkType.NOTIFY_DETAIL : this.state.deepLinkType,
        }
        swal({
            title: 'Warning',
            text: 'Bạn chắc chắn muốn tạo banner không ?',
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Chắc chắn',
			cancelButtonText: 'Hủy'
        }).then((result) => {
            if (result.value) {
                this.props.createNewBanner(notificationData);
            }
        })
        
    }


    onCancel = () => {
        swal({
            title: 'Warning',
            text: 'Bạn chắc chắn muốn hủy không ?',
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Chắc chắn',
			cancelButtonText: 'Hủy'
        }).then((result) => {
            if (result.value) {
                window.location.reload(false); 
            }
        })
    }

    onChangeReceivers = (receivers) => {
        LogSystem.info('Portal::onChangeReceivers receivers -------------------------------------')
        LogSystem.info(receivers)
        this.setState({
            usernameReceivedList: receivers,
            receiversTabError: null,
        })
    }

    onSelelctStudentType = (studentType) => {
        LogSystem.info('onSelelctStudentType::studentType: ' + studentType);
        this.setState({
            studentTypeSendAll: studentType,
            receiversTabError: null
        })
    }

 
    /*------ timeStart -----*/
    onChangeTimeStart = (date) => {
        LogSystem.info('Portal::onBlurOfPrePlan date: ' + date);
        this.setState({
            timeStart: (date === undefined) ? null : date,
            timeStartError: ''
        })
    }

    clearTimeStart = () => {
        this.setState({
            timeStart: null
        })
    }


    /*------ timeEnd -----*/
    onChangeTimeEnd = (date) => {
        LogSystem.info('Portal::onBlurOfPrePlan date: ' + date);
        this.setState({
            timeEnd: (date === undefined) ? null : date,
            timeEndError: ''
        })
    }

    clearTimeEnd = () => {
        this.setState({
            timeEnd: null
        })
    }
    /* ---------Deeplink-----------*/
    onSellectDeepLinkType = (e) => {
        LogSystem.info(e.target.value);  
        this.setState({
            deepLinkType: e.target.value
        });
        if(e.target.value !== NotificationDeepLinkType.WEB) {
            this.setState({
                webLink: null
            });
        }
    }

    onEditorChange(evt){
        LogSystem.info("onChange fired with event info: " + evt);
        var newContent = evt.editor.getData();
        LogSystem.info("newContent: " + newContent);    
        LogSystem.info("text: " + newContent.replace(/<\/?[^>]+>/ig, " "));
    }

    /*---------GronExpression------------ */
    // Onchange CKeditor
    onChangeContent = (bodyHtml, body)  => {
        LogSystem.info("onChangeContBannerCreationPageent::onChangeContent::bodyHtml ---------------------");
        LogSystem.info(bodyHtml);
        var bodyLength = (body == null || body == undefined) ? 0 : body.trim().length; 
        this.setState({
            bodyHtml,
            bodyError: null,
            bodyLength:  bodyLength
        });  
    }

    render() {
        return (
            <div>
                <div className="row">
                    <div className="col-md-6">
                        <div className="panel panel-flat" style={{minHeight: 2000}}>
                            <div className="panel-heading">
                                <h5 className="panel-title">Thông tin banner</h5>
                            </div>
                            <div className="panel-body">

                                <div className="form-group">
                                    <label htmlFor="pwd">1. Thời gian bắt đầu <span className="text-danger"> *</span></label>
                                    <div className="picker_wrapper" >
                                        <Datetime data-toggle="tooltip" data-placement="top" title="Tooltip on top"
                                            id="timeStart"
                                            value={this.state.timeStart}
                                            name="timeStart"
                                            onChange={this.onChangeTimeStart}
                                            inputProps={{readOnly: "true"}}
                                            dateFormat="DD-MM-YYYY"
                                            closeOnSelect={true}
                                        />
                                         {(this.state.timeStart === null) ? undefined : <button className="picker_clear_button" onClick={() => this.clearTimeStart()}><i className="icon-cross2"></i></button> } 
                                    </div>
                                    <InputErrorMessage>{this.state.timeStartError}</InputErrorMessage>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="pwd">2. Thời gian kết thúc <span className="text-danger"> *</span></label>
                                    <div className="picker_wrapper" >
                                        <Datetime data-toggle="tooltip" data-placement="top" title="Tooltip on top"
                                            id="timeEnd"
                                            value={this.state.timeEnd}
                                            name="timeEnd"
                                            onChange={this.onChangeTimeEnd}
                                            inputProps={{readOnly: "true"}}
                                            dateFormat="DD-MM-YYYY"
                                            closeOnSelect={true}
                                        />
                                         {(this.state.timeEnd === null) ? undefined : <button className="picker_clear_button" onClick={() => this.clearTimeEnd()}><i className="icon-cross2"></i></button> } 
                                    </div>
                                    <InputErrorMessage>{this.state.timeEndError}</InputErrorMessage>
                                </div>

                                <div className="form-group">
                                    <label htmlFor="sel1">3. DeepLink  <b className="text-primary"> [ Màn hình sẽ được mở khi click vào banner ]</b></label>
                                    <select className="form-control" id="sel1" onChange={this.onSellectDeepLinkType}>
                                        <option value=''>-- Chọn loại banner --</option>
                                        <option value={NotificationDeepLinkType.WEB}>Mở thông báo trên web</option>
                                    </select>
                                </div>
                                {this.state.deepLinkType == NotificationDeepLinkType.WEB ? 
                                 <div className="form-group">
                                    <label htmlFor="webLink">Link trang web muốn mở notification <span className="text-danger">*</span> </label>
                                    <textarea type="text" 
                                            className="form-control textarea-fixed-size" 
                                            id="webLink" 
                                            value={this.state.webLink ===  null  ? '' : this.state.webLink}
                                            name ="webLink"
                                            rows="2" 
                                            onChange={this.onChangeWeblink}></textarea>
                                    <InputErrorMessage>{this.state.deepLinkTypeError}</InputErrorMessage>
                                </div> : undefined }

                                <div className="form-group">   
                                    <label htmlFor="pwd" >4. Người nhận<span className="text-danger"> *</span> </label>
                                    <BannerInputReceiverTabs
                                        onChangeReceivers = {this.onChangeReceivers}
                                        onSelelctStudentType={this.onSelelctStudentType}
                                        tab = {this.state.currentTab}
                                        onChangeTab = {this.onChangeTab}
                                        currentTab = {this.state.currentTab}
                                        receiversTabError={this.state.receiversTabError}
                                        editMode={this.state.editMode}
                                        user={this.props.user}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-6" >
                        <div className="panel panel-flat" style={{minHeight: 2000}}>
                            <div className="panel-heading">
                                <h5 className="panel-title">Nội dung </h5>
                            </div>

                            <div className="panel-body">

                                <div className="form-group">
                                    <label htmlFor="pwd" >5. Tên banner <span className="text-danger">*</span></label>
                                    <textarea type="text" 
                                            className="form-control textarea-fixed-size" 
                                            id="pwd" 
                                            value={this.state.name ===  null  ? '' : this.state.name}
                                            name ="title"
                                            // maxLength="251"
                                            rows="2" 
                                            onChange={this.onTitleChange}></textarea>
                                    {this.showValidateTitle()}
                                </div>
                                <div className="form-group">
                                    <label htmlFor="body" >6. Nội dung <span className="text-danger"> *</span> <b className="text-primary"> [ Banner hiển thị đẹp nhất khi bạn chỉ up ảnh ]</b></label>  
                                    <EditorBanner
                                        onChangeContent={this.onChangeContent}
                                    >
                                    </EditorBanner>
                                    <InputErrorMessage>{this.state.bodyError}</InputErrorMessage>
                                </div>      
                                <div className="row">
                                    <div className="col-sm-6">
                                    </div>
                                    <div className="col-sm-3">
                                        <button className="btn btn-success" onClick = {() => this.onSave()}>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Lưu &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</button>    
                                    </div>
                                    <div className="col-sm-1">
                                    </div>
                                    <div className="col-sm-3">
                                        <button className="btn btn-success" onClick = {() => this.onCancel()}>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Hủy &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</button>
                                    </div>
                                </div>
                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}


const mapStateToProps = state => ({
    user: state.loginReducers.user
});



const mapDispatchToProps = (dispatch, props) => {
    return {
        createNewBanner: (params) => {
            dispatch(createNewBanner(params));
        }
    }
}

export default  connect(mapStateToProps, mapDispatchToProps)(BannerCreationPage);
