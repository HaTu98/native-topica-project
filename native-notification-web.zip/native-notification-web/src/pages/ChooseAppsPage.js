import React, { Component } from 'react';
import '../style/index.css'
import { connect } from 'react-redux';
import { chooseApp, renderAppsAssigned } from '../redux/actions/ChooseAppAction'
import AppsContainer from '../components/notificationappmanager/AppsContainer';

class ChooseAppsPage extends Component {

    componentDidMount() {
        this.props.renderAppsAssigned();
    }

    render() {
        return (
            <div className="container">
                <h2 className="text-center">Mời bạn chọn App</h2>
                <AppsContainer 
                    apps = {this.props.apps}
                    chooseApp={this.props.chooseApp}
                />
            </div>
        );
    }
}

const mapStateToProps = state => {
    return {
        apps: state.chooseAppReducer.apps
    }
}

const mapDispatchToProps = (dispatch, props) => {
    return {
        chooseApp: (app) => {
            chooseApp(app);
        },
        renderAppsAssigned: () => {
            dispatch(renderAppsAssigned());
        }
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(ChooseAppsPage);