import React, { Component } from 'react';
import '../style/Login.css';
import SocailAuthUrl from '../constants/SocailAuthUrl'
import { TokenManager } from '../data/TokenManager'


class LoginPage extends Component {

	componentDidMount() {
		TokenManager.clearAll();
	}

	render() {
		return (
			<div className="login-background-custom" style={{height:'100vh', padding: '100px'}}>
					<div className="login-form">
						<div className="login_box">
							<h2 className="text-center" style={{fontWeight: 'bold', fontFamily: 'Times New Roman', color: 'black'}}>Portal Notificaiton</h2>
							<div className="text-center social-btn">
								<a href="#" class="btn btn-danger btn-block" href={SocailAuthUrl.GOOGLE_AUTH_URL}>
									<i class="icon-google-plus2"></i> Sign in with <b>Google</b>
								</a>
							</div>
							<div style={{position: 'absolute', bottom: 2, left: '0', right: '0'}}>
								<div className="text-center text-light" style={{fontWeight: 'bold'}} >
									&copy; 2018. Portal by Topica Native
								</div>
							</div>
						</div>
					</div>	
			</div>
		);
	}
}


export default LoginPage;