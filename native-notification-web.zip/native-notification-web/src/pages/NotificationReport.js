import React, { Component } from 'react';
import { connect } from 'react-redux';
import SearchBox from '../components/notificaitonreport/SearchBox';
import DataRenderingBox from '../components/notificaitonreport/DataRenderingBox';
import { searhNotificationSenders, unscheduleNotificcation, restartNotificcation, cancelNotificationWating} from '../redux/actions/notificationActions';
import { BackupDataManager } from '../data/BackupDataManager';
import { LogSystem } from '../log/index'

const renderRow = {
    imgAttached: true
}

class NotificationReport extends Component {
    constructor(props) {
        super(props);
        this.state = {
            paginable: {
                orderBy: 'timeUpdated',
                direction: 'DESC',
                number: 1,
                size: 20
            },
            searchInfo: {
                usernameSender: null,
                statuses: null,
                types: null,
                sentFrom: null,
                sentTo: null,
                search: null
            },
            appId: null
        }
    }

    componentDidMount() {
        const chooseApp = BackupDataManager.getItem("choosenApp")
        if(chooseApp === undefined || chooseApp === null) {
            window.location.replace('/')
        }
        var app = JSON.parse(chooseApp);
        const appId = app.appId;
        this.setState({
            appId: appId
        }) 
        const {paginable, searchInfo } = this.state;
        LogSystem.info('searchInfo--------------------------------');
        LogSystem.info(searchInfo);
        this.props.searhNotificationSenders({...paginable ,...searchInfo, appId: appId})
    }

    onChangePaginale = (paginable) => {
       this.setState({paginable})
       const {searchInfo, appId } = this.state;
       this.props.searhNotificationSenders({ ...paginable, ...searchInfo,  appId: appId })
    }

    onSearch = (searchInfo) => {
        LogSystem.info('onSearch---------------');
        LogSystem.info(searchInfo);
        var {paginable, appId} = this.state;
        paginable.number = 1;
        paginable.size = 20;
        this.setState({
            searchInfo: searchInfo,
            paginable: paginable
        })
        this.props.searhNotificationSenders({...paginable, ...searchInfo, appId: appId})
    }

    createNewNotificationFromThis = (senderId) => {
        window.location.replace('/notification/push?id=' + senderId);
    }

    render() {
        return (
            <div>
                <SearchBox
                    searchInfo={this.state.searchInfo}
                    onSearch = {this.onSearch}
                />
                <DataRenderingBox 
                    sendersData={this.props.sendersData}
                    paginable={this.state.paginable}
                    content={this.props.sendersData.content}
                    number={this.props.sendersData.number}
                    size={this.props.sendersData.size}
                    totalElements={this.props.sendersData.totalElements}
                    totalPages={this.props.sendersData.totalPages}
                    onChangePaginale = {this.onChangePaginale}
                    unscheduleNotificcation={this.props.unscheduleNotificcation}
                    restartNotificcation={this.props.restartNotificcation}
                    cancelNotificationWating={this.props.cancelNotificationWating}
                    createNewNotificationFromThis={this.createNewNotificationFromThis}
                    renderRow = {renderRow}
                />
            </div>
        );
    }
}


const mapStateToProps = state => {
    return {
        sendersData: state.notifcationReducer.sendersData
    }
}

const mapDispatchToProps = (dispatch, props) => {
    return {
        searhNotificationSenders: (params) => {
            dispatch(searhNotificationSenders(params))
        },
        unscheduleNotificcation: (senderId, key) => {
            dispatch(unscheduleNotificcation(senderId, key))
        },
        restartNotificcation: (senderId, index) => {
            dispatch(restartNotificcation(senderId, index))
        },
        cancelNotificationWating: (senderId, key) => {
            dispatch(cancelNotificationWating(senderId, key))
        }
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(NotificationReport);
