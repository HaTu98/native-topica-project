import React, { Component } from 'react';
import {TokenManager } from '../data/TokenManager'
import {LogSystem } from  '../log/index'

class AppSubribedEmpty extends Component {

    getLinkForDirect = () => {
        const user = JSON.parse(TokenManager.getItem("user"));
        if(user !== null && user.role == 'ADMIN') {
            return <p>Về  <a href="/notification/app"> Quản lý App và User </a></p>
        } else {
            return <p>Về  <a href="/login"> Login </a></p>
        }
    }

    render() {
        return (
            <div className="container">
                <div className="alert alert-warning">
                    {/* <button type="button" className="close" data-dismiss="alert" aria-hidden="true">&times;</button> */}
                    <strong>Bạn đang không có quyền làm việc với bất cứ app Notifcation nào !</strong>
                    {this.getLinkForDirect()}
                </div>
            </div>
        );
    }
}

export default AppSubribedEmpty;