import React from 'react';
import { Editor } from 'react-draft-wysiwyg';
import 'react-draft-wysiwyg/dist/react-draft-wysiwyg.css';
import { EditorState , convertToRaw  } from 'draft-js';
import draftToHtml from 'draftjs-to-html';
import uploadImageCallBack from '../data/UploadImage'
import  EmailSending  from '../redux/actions/EmailSending'
import { connect } from 'react-redux';
import swal from 'sweetalert2'
import InputErrorMessage from '../components/common/InputErrorMessage';
import Datetime from 'react-datetime';
import '../style/react-datetime.css';
import {LogSystem } from  '../log/index'
import InputReceiverEmailTabs from '../components/emailpush/InputReceiverEmailTabs';
import '../style/emailstyle.css'
import XSSUtil from '../util/XSSUtil';
  
const NotificationType = {
    QUICKSEND: "QUICKSEND",
    PREPLAN: "PREPLAN",
    SCHEDULED: "SCHEDULED"
} 

class EmailSender extends React.Component {
    constructor(props){
        super(props);
        this.state = {
            toEmail:'',
            subject :'',
            body : '',
            bodyTest: '',
            attachments : '',
            notificationType: '',
            prePlanTime: '',
            prePlanTimeError: '',
            cronExpression: '',
            subjectError: '',
            cronExpressionError: '',
            bodyError: '',
            usernameReceivedList: [],
            editorState: EditorState.createEmpty(),
            receiversTab: {
                currentTab: 0
            }          
        };
    }


    onChangeTab = (tab) => {
        LogSystem.info('EmailSender::onChangeTab::tab ' + tab);
        this.setState ({
            receiversTab: {
                currentTab: tab
            },
            receiversTabError: null
        })
    }


    onEnteringReceivers = () => {
        this.setState({
            receiversTabError: undefined
        })
    }

    onChangeReceivers = (receivers) => {
        LogSystem.info('EmailSender::onChangeReceivers receivers')
        LogSystem.info(receivers)
        this.setState({
            usernameReceivedList: receivers,
        })
    }

    onSelectNotificationType = (e) => {
        LogSystem.info(e.target.value);  
        this.setState({
            notificationType: e.target.value,
            prePlanTime: '',
            cronExpression: '',
            prePlanTimeError: '',
            cronExpressionError: '',
        });
    }

    /*------ PrePlan -----*/
    onBlurOfPrePlan = (date) => {
        LogSystem.info('Portal::onBlurOfPrePlan date: ' + date);
        this.setState({
            prePlanTime: (date === undefined) ? '' : date,
            prePlanTimeError: ''
        })
    }


    /*---------GronExpression------------ */

    onCronExpressionChange = (e) => {
        if(e.target.value === undefined || e.target.value === null) {
            return;
        }
        var cron = e.target.value;
        LogSystem.info('cron --------------------------')
        LogSystem.info(cron)
        LogSystem.info('verify cron expression')
        this.setState({
            [e.target.name]: cron,
        });
        this.setState({
            [e.target.name]: cron,
            cronExpressionError: ''
        });
    }

  

    onEditorStateChange  = (editorState) => {
        var blocks = convertToRaw(editorState.getCurrentContent()).blocks;
        var bodyTest = blocks.map(block => (!block.text.trim() && '\n') || block.text.replace(/<img[^>]*>/g, '')).join('\n').trim();
        this.setState({
          editorState,
          body : draftToHtml(convertToRaw(editorState.getCurrentContent())) ,
          bodyTest,
          bodyError: ''
        });
    };

    onChange = (e) => {
        this.setState({ [e.target.name]: e.target.value });
    }

    onChangeTitle = (e) => {
        this.setState({
            subject: e.target.value,
            subjectError: ''
        });
    }

    handleEmailTabsTrigger = () => {
        this.setState({
            receiversTabError: ''
        })
    }

    validateReceiver() {
        if(this.state.usernameReceivedList === null || this.state.usernameReceivedList.length < 1) {
            this.setState({
                receiversTabError: "Nhập email học viên hoặc import file học viên"
            })
            return false;
        } 
        return true;
    }


    validateSubject() {
        LogSystem.info('validateSubject _' + this.state.title + '_')
        if(this.state.subject === undefined || this.state.subject === null || this.state.subject === '') {
            this.setState({
                subjectError: "Không được để trống trường này"
            })
            this.referTitle.focus();
            return false;
        } 
        return true;
    }

    validateBody() {
        LogSystem.info("validateBody:: " + this.state.bodyTest);
        if(this.state.bodyTest === undefined || this.state.bodyTest === null || this.state.bodyTest === '') {
            this.setState({
                bodyError: "Không được để trống trường này"
            })
            // this.referContent.focus();
            return false;
        } 
        if(XSSUtil.isExistringScriptTag(this.state.bodyTest)) {
            this.setState({
                bodyError: 'không cho phép chưa thẻ script'
            })
            return false;
        } 
        return true;
    }


    validateRePlanTime() {
        if(this.state.notificationType !== NotificationType.PREPLAN) return true;
        if(this.state.prePlanTime === undefined || this.state.prePlanTime === null || this.state.prePlanTime === '') {
            this.setState({
                prePlanTimeError: "Không được để trống trường này khi chọn gửi 1 lần với lịch"
            })
            // this.referTimeSent.focus();
            return false;
        } 
        return true;
    }

    validateReCronExpression() {
        if(this.state.notificationType !== NotificationType.SCHEDULED) return true;
        if(this.state.cronExpression === undefined || this.state.cronExpression === null || this.state.cronExpression === '') {
            this.setState({
                cronExpressionError: "Không được để trống trường này khi chọn gửi nhiều lần với lịch"
            })
            this.referCronExpression.focus();
            return false;
        } 
        return true;
    }

    validateAfterSending() {
        let status = this.validateReceiver(); 
        status = this.validateSubject() && status;
        status = this.validateBody() && status; 
        status = this.validateRePlanTime() && status;
        status = this.validateReCronExpression() && status;
        return status;
    }

    emailSenderClick = ()=> {
        console.log('email Sender');
        const subject = this.state.subject.trim();
        const body = this.state.body;
        var msgMail = new FormData();
        if(!this.validateAfterSending()) return;
        msgMail.append('receivers', this.state.usernameReceivedList);
        msgMail.append('title', encodeURI(subject));
        msgMail.append('bodyHtml', encodeURI(body))
        msgMail.append('timeSent', this.state.prePlanTime * 1)
        msgMail.append('cronExpression', (this.state.cronExpression === null) ? null : this.state.cronExpression.trim())
        msgMail.append('type', this.state.notificationType)
        var warningMessage = 'Bạn chắc chắn muốn gửi  không ?';
        swal({
            title: 'Warning',
            text: warningMessage,
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Chắc chắn',
			cancelButtonText: 'Hủy'
        }).then((result) => {
            if (result.value) {
                this.props.EmailSending(msgMail);
            }
        })
    }


    clearTimeSent = () => {
        this.setState({
            prePlanTime: null
        })
    }

    render() {
        const { editorState } = this.state;
        return (
            <div className="container-fluid">
                <div className="row">
                     {/* <div className="col-lg-12">
                        <div className="card">
                            <div className="card-body"> */}
                            <div className="form-group">
                                <label htmlFor="sel1">1. Loại gửi Email <span className="text-danger">*</span></label>
                                <select className="form-control" id="sel1" onChange={this.onSelectNotificationType}>
                                    <option value=''>--Chọn loại gửi email---</option>
                                    <option value="QUICKSEND">Gửi Ngay</option>
                                    <option value="PREPLAN">Gửi Một Lần Theo Lịch</option>
                                    <option value="SCHEDULED">Gửi Nhiều Lần Theo Lịch</option>
                                </select>
                                <InputErrorMessage>{this.state.notificationTypeError}</InputErrorMessage>
                            </div>

                            <div className="form-group">
                                <div class="row">
                                    <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                    <div className="form-group">
                                    <label htmlFor="pwd">2. Thời gian gửi <b className="text-primary"> </b></label>
                                    <div className="picker_wrapper" >
                                     <Datetime data-toggle="tooltip" data-placement="top" title="Tooltip on top"
                                            id="prePlanTime"
                                            value={this.state.prePlanTime}
                                            name="prePlanTime"
                                            onChange={this.onBlurOfPrePlan}
                                            inputProps={{readOnly: "true", disabled: this.state.notificationType !== NotificationType.PREPLAN}}
                                            dateFormat="DD-MM-YYYY"
                                            closeOnSelect={true}
                                            // ref={(input) => { this.referTimeSent = input; }} 
                                        />
                                    {(this.state.prePlanTime === null || this.state.prePlanTime === '') ? undefined : <button className="picker_clear_button" onClick={() => this.clearTimeSent()}><i className="icon-cross2"></i></button> } 
                                    </div>
                                    <InputErrorMessage>{this.state.prePlanTimeError}</InputErrorMessage>
                                </div>
                                    </div>
                                    <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                        <label htmlFor="pwd">3. Lịch trình Cron Expression <a className="underline-text" href="http://www.cronmaker.com/" target="_blank">Lấy Cron Expression ở đây</a></label>
                                        <br></br>                                    
                                        {/* <a className="underline-text" href="http://www.cronmaker.com/" target="_blank">Lấy Cron Expression ở đây</a> */}
                                                <input type="text" 
                                                className="form-control textarea-fixed-size" 
                                                id="cron-expression" 
                                                value={this.state.cronExpression}
                                                name ="cronExpression"
                                                disabled={this.state.notificationType !== NotificationType.SCHEDULED}
                                                onChange ={this.onCronExpressionChange}
                                                onBlur ={this.onCronExpressionBlur}
                                                ref={(input) => { this.referCronExpression = input; }} 
                                                ></input>
                                        <InputErrorMessage>{this.state.cronExpressionError}</InputErrorMessage>
                                    </div>
                                        
                                </div>
                                
                            </div>

                            <div className="form-group">   
                                    <label htmlFor="pwd" >1. Người nhận<span className="text-danger"> *</span> </label>
                                    <InputReceiverEmailTabs
                                        onChangeReceivers = {this.onChangeReceivers}
                                        tab = {this.state.receiversTab.currentTab}
                                        onChangeTab = {this.onChangeTab}
                                        currentTab = {this.state.receiversTab.currentTab}
                                        receiversTabError={this.state.receiversTabError}
                                        onEnteringReceivers = {this.onEnteringReceivers}
                                        uploadedFile = {this.state.uploadedFile}
                                        usernameReceivedList={this.state.usernameReceivedList}
                                        handleEmailTabsTrigger={this.handleEmailTabsTrigger}
                                        editMode={this.state.editMode}
                                    />
                                </div>    
                            <div className="form-group">
                                <label>5. Tiêu đề <span className="text-danger">*</span></label>
                                <input className="form-control"
                                    type="text" name ="subject" 
                                    value={this.state.subject ===  null  ? '' : this.state.subject}
                                    onChange={this.onChangeTitle}
                                    ref={(input) => { this.referTitle = input; }} 
                                    />
                                <InputErrorMessage>{this.state.subjectError}</InputErrorMessage>    
                            </div>
                            <div className="form-group">
                                <label>6. Nội dung <span className="text-danger">*</span></label>
                                <div className="" style={{border:'1px solid #ddd',height:'700px', background:'#fff', padding:'0 20px'}} >                       
                                    <Editor
                                        editorState={editorState}
                                        wrapperClassName="email-editor_wrapper"
                                        editorClassName="email-editor"
                                        name = "body"
                                        value={editorState === null ? '' : editorState}
                                        heigh="100"
                                        toolbar={{
                                            options: ['inline', 'blockType', 'fontSize', 'fontFamily', 'list', 'textAlign', 'colorPicker', 'link', 'image', 'remove', 'history'],
                                            inline: { inDropdown: true },
                                            list: { inDropdown: true ,
                                                options: ['unordered', 'ordered']
                                            },
                                            textAlign: { inDropdown: true },
                                            link: { inDropdown: true },
                                            history: { inDropdown: true },
                                            emoji: {},
                                            image: { uploadCallback: uploadImageCallBack, previewImage:true, alt: { present: true, mandatory: false }, alignmentEnabled: "RIGHT"},
                                            
                                        }}
                                        onEditorStateChange={this.onEditorStateChange}
                                    />
                                     
                                </div>
                                <InputErrorMessage>{this.state.bodyError}</InputErrorMessage>   
                            </div>

                            <div className="row">
                                
                                
                                <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
                                    
                                </div>
                                <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                    <div className="form-group" style={{marginTop:'20px'}}>
                                        <button  className="btn btn-info" 
                                                style={{width:'100%'}} 
                                                onClick = {() => this.emailSenderClick()}
                                                disabled={!(this.state.notificationType === NotificationType.QUICKSEND)}
                                                data-toggle="tooltip" data-placement="top" title="Chức năng chỉ cho phép khi chọn loại gửi là Gửi Ngay"
                                                >Gửi Ngay</button>
                                    </div>
                                </div>
                                <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
                                    
                                </div>
                                <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                    <div className="form-group" style={{marginTop:'20px'}}>
                                        <button className="btn btn-info" style={{width:'100%'}} 
                                        onClick = {() => this.emailSenderClick()}
                                        data-toggle="tooltip" data-placement="top" title="Chức năng chỉ cho phép khi chọn loại là gửi 1 lần theo lịch hoặc gửi nhiều lần theo lịch"
                                        disabled={!(this.state.notificationType === NotificationType.PREPLAN || this.state.notificationType === NotificationType.SCHEDULED)}
                                        >Tạo Thông Báo Lịch Trình</button>
                                    </div>
                                </div>
                                <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
                                </div>
                            </div>
                            </div>
                        </div>
                //      </div>
                // </div>
            // </div>
        );
    }

}


const mapDispatchToProps = (dispatch, props) => {
    return {
        EmailSending: (params) => {
            dispatch(EmailSending(params));
        }
    }
}

export default connect(null, mapDispatchToProps)(EmailSender);