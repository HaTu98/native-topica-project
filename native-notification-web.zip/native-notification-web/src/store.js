import rootReducers from './redux/reducers/rootReducers';
import thunk from 'redux-thunk';
import { applyMiddleware , createStore} from 'redux';

export const store = createStore(
    rootReducers,
    applyMiddleware(thunk)
);