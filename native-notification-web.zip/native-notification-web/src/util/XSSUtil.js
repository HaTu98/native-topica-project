// const SCRIPT_TAG_OPEN = "&lt;script&gt;";
// const SCRIPT_TAG_CLOSE = "&lt;/script&gt;";

const SCRIPT_TAG_OPEN = "<script>";
const SCRIPT_TAG_CLOSE = "</script>";

const XSSUtil = {
    isExistringScriptTag: (text) => {    
        if(text === null || text === undefined) return false;
        if(typeof(text) !== 'string') return false;
        if(text.toLowerCase().includes(SCRIPT_TAG_OPEN) || text.toLowerCase().includes(SCRIPT_TAG_CLOSE)) {
            return true;
        }
    }
}
export default XSSUtil;