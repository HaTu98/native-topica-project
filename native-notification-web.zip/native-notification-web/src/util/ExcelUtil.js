import LogSystem from '../log/LogSystem'
import XLSX from 'xlsx';
import * as ALERT from '../redux/actions/alertActions';
import { toast } from 'react-toastify';
import EmailValidation from './EmailValidation';
import swal from 'sweetalert2';
import { ExcelProvider } from '../redux/actions/ExcelProvider';
import CONSTANT from '../constants/Constant';
const MAX_SIZE = 1000000; // 1MB
const MAX_ROWS = 5000;

const ExcelUtil = {
    exportTemplate: (variables) => {    
        var exportData = [];
        exportData.push(Array.from(variables));
        LogSystem.info('exportData------------------------------------');
        LogSystem.info(exportData);
        const ws = XLSX.utils.aoa_to_sheet(exportData);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Sheet 1");
        /* generate XLSX file and send to client */
        XLSX.writeFile(wb, "student_template.xlsx")
    },
    validateFileSize: (file) => {
        if(file.size > MAX_SIZE) {
            ALERT.showToastAlter("Error", "File quá lớn, Chỉ cho phép upload với file nhỏ hơn 1MB", toast.TYPE.ERROR); 
                return false;
        }
        return true;
    },
    validateExtention: (fileName) => {
        if(fileName === undefined) return false;
        if(!(fileName.endsWith(".xlsx") || fileName.endsWith(".xls"))) {
            LogSystem.info("Chỉ hỗ trợ với định dạng .xlsx và .xls");
            ALERT.showToastAlter("Error", "Chỉ hỗ trợ với định dạng .xlsx và .xls", toast.TYPE.ERROR); 
            return false;
        }
        return true;
    },
    handleFile: (f) => {
        var reader = new FileReader();
        const rABS = !!reader.readAsBinaryString;
        return new Promise((resolve, reject) => {
            reader.onload = function(e) {
                const bstr = e.target.result;
                const wb = XLSX.read(bstr, {type:rABS ? 'binary' : 'array', raw: false, cellText: true, dateNF: 'dd/MM/yyyy'});
                LogSystem.info('wb::wb::wb::wb-------------------');
                LogSystem.info(wb);
                const wsname = wb.SheetNames[0];
                LogSystem.info('wb::wsname::wsname::wsname-------------------');
                LogSystem.info(wsname);
                const ws = wb.Sheets[wsname];
                LogSystem.info('ws::ws::ws::ws-------------------');
                LogSystem.info(ws);
                const data = XLSX.utils.sheet_to_json(ws, {header:1, raw: false});
                LogSystem.info('data::data::data::data-------------------');
                LogSystem.info(data);
                resolve(data);
            };
            if(rABS) reader.readAsBinaryString(f); else reader.readAsArrayBuffer(f);
        }) 
    },
    validateTemplte: (data, template) => {
        const headerRow = data[0];
        if(headerRow === undefined || headerRow.length !== template.length) {
            ALERT.showToastAlter("Error", "Template không hợp lệ. Xin vui lòng download lại template chuẩn.", toast.TYPE.ERROR); 
            return false;
        } 
        for(let i = 0; i < template.length; i++) {
            if(headerRow[i] == null || headerRow[i] == undefined || headerRow[i] == '' || template[i] == null || template[i] == undefined) {
                ALERT.showToastAlter("Error", "Template không hợp lệ. Xin vui lòng download lại template chuẩn.", toast.TYPE.ERROR); 
                return false;
            }
            if(template[i].trim() !== headerRow[i].trim()) { 
                ALERT.showToastAlter("Error", "Template không hợp lệ. Xin vui lòng download lại template chuẩn.", toast.TYPE.ERROR); 
                return false;
            }
        }
    
        return true;
    },
    validateLength: (data) => {
        if(data === undefined || data.length < 1) {
            ALERT.showToastAlter("Error", "Phải điền đầy đủ thông tin các cột trước khi upload file lên", toast.TYPE.ERROR);
            return false; 
        }
        if(data.length > MAX_ROWS) {
            ALERT.showToastAlter("Error", "Chỉ cho phép upload 1000 học viên", toast.TYPE.ERROR);
            return false; 
        }
        return true;
    },
    getStudent: (data) => {
        LogSystem.info('ExcelUtil::getStudent::data');
        LogSystem.info(data);
        var variables = data[0]
        var presonalInfos = new Array();
        var variablesLength = variables.length;
        var indexPersonalInfo = 1;
        for(let i = 1; i < data.length; i++) {
            let studentInfo = data[i]; 
            if(studentInfo ===  undefined || studentInfo.length < 1) continue;
            let personalInfo = mapPersonalInfoByVariable(studentInfo, variables, variablesLength);
            if(personalInfo === undefined) return undefined;
            if(studentInfo[0] != indexPersonalInfo) {
                if(studentInfo[0] === undefined || (typeof(studentInfo[0]) === 'string') && studentInfo[0].trim() === '') {
                    ALERT.showToastAlter("Error", "Phải điền đầy đủ thông tin các cột trước khi upload file lên", toast.TYPE.ERROR);
                }
                ALERT.showToastAlter("Error", "Số thứ tự (No) phải tăng dần từ 1 tới hết", toast.TYPE.ERROR);
                return undefined;
            }
            presonalInfos.push(personalInfo);
            indexPersonalInfo++;
        }
        LogSystem.info('ExcelUtil::getStudent::student::variables');
        LogSystem.info(variables);
        LogSystem.info('ExcelUtil::getStudent::student::presonalInfos');
        LogSystem.info(presonalInfos);
        return {
            variables,
            presonalInfos
        }
    },
    showErrorPopUp: (validStudents, inValidStudents, cb) => {
        swal({
            title: (validStudents.length > 0) ? 'Warning' : 'Error',
            type: (validStudents.length > 0) ? 'warning' : 'error',
            html:
                '<h4 class="text-warning">' + (validStudents.length > 0 ? CONSTANT.UploadFile_Modal.EXIST_STUDENT_INVALID : CONSTANT.UploadFile_Modal.All_STUDENT_INVALID) + '</h4> <br>' +
                '<a style="text-decoration: underline;" id="resume"><h4> Tải xuống Học Viên lỗi</h4></a>',
            onBeforeOpen: () => {
                const content = swal.getContent()
                const $ = content.querySelector.bind(content)
                const resume = $('#resume')
                resume.addEventListener('click', () => {
                    LogSystem.info('Click tai xuong HV loi')
                    exportStudentErrors(inValidStudents)
                })
    
                },    
            showCloseButton: true,
            showCancelButton: true,
            focusConfirm: false,
            confirmButtonText: 'Tiếp Tục',
            cancelButtonText: 'Hủy'
        }).then((result) => {
            if (result.value && validStudents.length > 0) {
                LogSystem.info('_uploadFileFail:: data ---------------------------');
                LogSystem.info(validStudents);
                cb();
            }
        })
    }
}

function exportStudentErrors(studentErrors) {
    LogSystem.info('exportStudentErrors::studentErrors -----------------------');
    LogSystem.info(studentErrors);

    var exportData = [];
    exportData.push(['No', 'Student Email', 'Error']);
    studentErrors.sort((a, b) => (Number(a.No) > Number(b.No)) ? 1 : -1);
    studentErrors.map((item) => {
        var studentDetail = [item.No, item.studentEmail, item.error];
        exportData.push(studentDetail);
    })

    LogSystem.info('exportData------------------------------------');
    LogSystem.info(exportData);

    const ws = XLSX.utils.aoa_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Student Error");
    /* generate XLSX file and send to client */
    XLSX.writeFile(wb, "Danh_sach_hoc_vien_loi.xlsx")
}

function mapPersonalInfoByVariable(studentInfo, variables, variablesLength, errorCallback) {
    var personalInfo = Object.create(null);
    for(let i = 0 ; i < variablesLength; i++) {
        LogSystem.info('studentInfo[i]: ' + studentInfo[i]);
        var temp2 = studentInfo[i];
        var temp = (typeof(temp2) === 'string' && temp2 !== null && temp2 !== undefined) ? temp2.trim() : temp2;
        if(temp === undefined || (typeof(temp) === 'string' && temp.length < 1)) {
            ALERT.showToastAlter("Error", "Phải điền đủ thông tin các cột trước khi upload file lên", toast.TYPE.ERROR);
            return undefined;
        }
        if(i === 0) {
            personalInfo["No"] = (temp);
            continue;
        }
        if(i === 1) {
            personalInfo["studentEmail"] = temp.toLowerCase();
            continue;
        }
        personalInfo[variables[i]] = temp;
    }
    return personalInfo;
}

export default ExcelUtil;