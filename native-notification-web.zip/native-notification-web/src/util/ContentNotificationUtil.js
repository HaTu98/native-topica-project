import CONSTANT from '../constants/Constant';

const firstMark = "{{";
const secondMark = "}}";

const ContentNotificationUtil = {
    getAllVariablesFromBody: (body) => {
        var firstIndex = -1;
        var secondIndex = -1;
        var variablesSet = new Set(); 
        firstIndex = body.indexOf(firstMark);
        if(firstIndex === -1) return variablesSet;
        secondIndex = body.indexOf(secondMark, firstIndex);
        if(secondIndex === -1) return variablesSet;
        var variable = body.substring(firstIndex + 2, secondIndex);
        variablesSet.add(variable);
        while(secondIndex !== -1) {
            firstIndex = body.indexOf(firstMark, secondIndex);
            if(firstIndex === -1) break;
            secondIndex = body.indexOf(secondMark, firstIndex);
            variable = body.substring(firstIndex + 2, secondIndex);
            variablesSet.add(variable);
        }
        return variablesSet;
    }
}

export default ContentNotificationUtil;