import CONSTANT from '../constants/Constant';

const EmailValidation = {
    isEmail: (param) => {
        return CONSTANT.Email_Regrex.test(param)
    },
    isTopicaEmail: (param) => {
        return CONSTANT.TopicaEmail_Regrex.test(param)
    },
    isTopicaUsername: (param) => {
        return CONSTANT.TopicaUsename_Regrex.test(param)
    }
}

export default EmailValidation;