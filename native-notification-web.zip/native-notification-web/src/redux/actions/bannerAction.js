import * as ActionType from './ActionType'
import API from '../../network/API';
import * as ALERT from './alertActions'
import { toast } from 'react-toastify';
// import { LogSystem } from '@logsystem';


export function createNewBanner(params) {
    return (dispatch) => {
        API.createNewBanner(params).then( 
            (res) => {
                if(res.data.code === 200) {
                    ALERT.showToastAlter('Success',  'Tạo banner mới thành công', toast.TYPE.SUCCESS);
                } else {
                    ALERT.showToastAlter('Error',  res.data.message, toast.TYPE.ERROR);
                }
            }, 
            (err) => {
                // window.location.replace('/systemerror');
            }
        )
    }
}

