import * as ActionType from './ActionType'
import API from '../../network/API';
import  { TokenManager } from '../../data/TokenManager'
import { compose } from 'redux';
import * as ALERT from './alertActions'
import { toast } from 'react-toastify';
import { LogSystem } from '../../log/index'

const ErrorsException = new Map();
ErrorsException.set(401, 'Username hoặc password không chính xác')
ErrorsException.set(403, 'Tài khoản không được cho phép truy cập')


//Add Action
export function loginAcitonSuccess(data) {
    // LogSystem.info('Portal::loginAcitonSuccess-----------------------------')
    // LogSystem.info(data)
    const {token, firstName, lastName, userName, serviceType, roleName} = data
    const user = {
        firstName,
        lastName,
        userName,
        serviceType,
        roleName
    }
    // TokenManager.setItem('token', data.token)
    // TokenManager.setItem('user', JSON.stringify(user))
    return {
        type: ActionType.Login_Success,
        token,
        user
    };
}

export function loginAcitonFailed(error) {
    return {
        type: ActionType.Login_Fail,
        error
    };
}

export function loginAction(params) {
    return (dispatch) => {
        API.login(params).then( 
            (res) => {
                // LogSystem.info('Portal::API::loginAction response: ' + JSON.stringify(res));
                if(res.data.code === 200) {
                    const roleName = res.data.data.roleName;
                    if(roleName === "ADMIN") {
                        window.location.replace("/notification/app");
                        dispatch(loginAcitonSuccess(res.data.data));
                    } else if(roleName === "MANAGER") {
                        window.location.replace("/");
                        dispatch(loginAcitonSuccess(res.data.data));
                    } else {
                        ALERT.showToastAlter('Error', 'Không được phép truy cập', toast.TYPE.ERROR);
                    }
                } else {
                    ALERT.showToastAlter('Error',  ErrorsException.get(res.data.code), toast.TYPE.ERROR);
                    dispatch(loginAcitonFailed(res.data));
                }
            }, 
            (err) => {
                ALERT.showToastAlter('Error', err, toast.TYPE.ERROR);
                dispatch(loginAcitonFailed(err));
                window.location.replace('/systemerror');
            }
        )
    }
};



export function logoutAction() {
    TokenManager.clearAll();
    return {
        type: ActionType.Log_Out
    }    
}

// export function verifyToken()  {
//     API.verifyToken().then( 
//         (res) => {
//             LogSystem.info('Portal::API::verifyToken verifyToken: ');
//             LogSystem.info(res.data.data)

//         }, 
//         (err) => {
//             window.location.replace('/login');
//         }
//     )
// }


function verifyTokenSuccess(data) {
    // LogSystem.info('Portal::verifyTokenSuccess-----------------------------')
    // LogSystem.info(data)
    const {username, role, avatarUrl, name} = data
    const user = {
        username,
        role,
        avatarUrl, 
        name
    }
    TokenManager.setItem('user', JSON.stringify(user))
    return {
        type: ActionType.Login_Success,
        user
    };
}


export function verifyToken()  {
    return (dispatch) => {
        API.verifyToken().then( 
            (res) => {
                LogSystem.info('Portal::API::loginAction response: ' + JSON.stringify(res));
                if(res.data.code === 200) {
                    LogSystem.info('Portal::API::verifyToken verifyToken: ');
                    LogSystem.info(res.data.data)
                    dispatch(verifyTokenSuccess(res.data.data));
                } else {
                    window.location.replace('/login');
                }
            }, 
            (err) => {
                window.location.replace('/login');
            }
        )
    }
}