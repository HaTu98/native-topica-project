import API from '../../network/API';
import * as ActionType from './ActionType'
import * as ALERT from './alertActions'
import { toast } from 'react-toastify';
import AppConfig from '../../constants/AppConfig'
import { LogSystem } from '../../log/index'

export default  function EmailSending(params) {
    return (dispatch) => {
        return API.EmailSending(params).then(
            (res) => {
                if (res.data.code === 200) {
                    ALERT.showToastAlter('Success', 'Yêu cầu gửi email đang trong quá trình xử lý', toast.TYPE.SUCCESS);   
                } else {
                    ALERT.showToastAlter('Error', res.data.message, toast.TYPE.ERROR);
                }
            },
            (err) => {
                ALERT.showToastAlter('Error', "Lỗi mạng", toast.TYPE.ERROR);
                //window.location.replace('/systemerror');
                //ALERT.showToastAlter('Error', err, toast.TYPE.ERROR);
            }
        )
    }
}

function searhEmailSenderSuccess(data) {
    LogSystem.info('Portal::handleSearchNotificaitonSuccess response');
    LogSystem.info(data);
    return {
        type: ActionType.EMAIL_SEARCH,
        sendersData: data
    }
}


export function searhEmailSender(params) {
    LogSystem.info('Portal::searhNotificationSenders params');
    LogSystem.info(params);
    return (dispatch) => {
        return API.emailSearch(params).then(
            (res) => {
                LogSystem.info('Portal::searhNotificationSender response');
                LogSystem.info(res);
                if (res.data.code === 200) {
                    LogSystem.info('Portal::searhNotificationSender data');
                    LogSystem.info(res.data.data);
                    ALERT.showToastAlter('Success', 'Dữ liệu được tìm thấy thành công', toast.TYPE.SUCCESS);
                    dispatch(searhEmailSenderSuccess(res.data.data));
                } else {
                    ALERT.showToastAlter('Error', res.data.message, toast.TYPE.ERROR);
                }
            },
            (err) => {
                //window.location.replace('/systemerror');
            }
        )
    }
}


function unscheduleEmailSuccess(sender, key) {
    return {
        type: ActionType.Unschedule_Email,
        sender: sender,
        key: key
    }
}

export function unscheduleEmail(senderId, key) {
    LogSystem.info('Portal::unscheduleEmail --------------------------senderId: ' + senderId + ' key: ' + key);
    return (dispatch) => {
        return API.unscheduleEmail(senderId).then(
            (res) => {
                if (res.data.code === 200) {
                    ALERT.showToastAlter('Success', 'Dừng lịch trình gửi email thành công', toast.TYPE.SUCCESS);
                    dispatch(unscheduleEmailSuccess(res.data.data, key));
                } else {
                    ALERT.showToastAlter('Error', res.data.message, toast.TYPE.ERROR);
                }
            },
            (err) => {
                window.location.replace('/systemerror');
            }
        )
    }
}

function restartEmailSuccess(sender, key) {
    return {
        type: ActionType.Restart_Email,
        sender: sender,
        key: key
    }
}

export function restartEmail(senderId, key) {
    LogSystem.info('Portal::restartEmail senderId: ' + senderId + ' - key: ' + key);
    return (dispatch) => {
        return API.restartEmail(senderId).then(
            (res) => {
                if (res.data.code === 200) {
                    ALERT.showToastAlter('Success', 'Lịch trình gửi email đã được chạy lại', toast.TYPE.SUCCESS);
                    dispatch(restartEmailSuccess(res.data.data, key));
                } else {
                    ALERT.showToastAlter('Error', res.data.message, toast.TYPE.ERROR);
                }
            },
            (err) => {
                window.location.replace('/systemerror');
            }
        )
    }
}

function cancelEmailWatingSuccess(sender, key) {
    return {
        type: ActionType.Cancel_Email,
        sender: sender,
        key: key
    }
}

export function cancelEmailWating(senderId, key) {
    LogSystem.info('Portal::cancelEmailWating senderId: ' + senderId + ' - key: ' + key);
    return (dispatch) => {
        return API.cancelEmailWating(senderId).then(
            (res) => {
                if (res.data.code === 200) {
                    ALERT.showToastAlter('Success', 'Lịch trình gửi Email đã được hủy', toast.TYPE.SUCCESS);
                    dispatch(cancelEmailWatingSuccess(res.data.data, key));
                } else {
                    ALERT.showToastAlter('Error', res.data.message, toast.TYPE.ERROR);
                }
            },
            (err) => {
                window.location.replace('/systemerror');
            }
        )
    }
}


