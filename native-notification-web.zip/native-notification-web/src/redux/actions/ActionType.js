export const Push_Notificaiton_Fail = 'Push_Notificaiton_Fail';
export const Push_Notificaiton = 'Push_Notificaiton_Fail';
export const Push_Notification_With_File = 'Push_Notification_With_File';
export const Submit_Notification = 'Submit_Notification'; 
export const Restart_Notification = 'Restart_Notification';
export const Unschedule_Notification = 'Unschedule_Notification';
export const Cancel_Notification = 'Cancel_Notification';
export const Create_New_Notificaiton_From_This = 'Create_New_Notificaiton_From_This';
export const On_Change_Tab = 'On_Change_Tab';


export const Show_Alert = 'Show_Alert';
export const Add_New_Import_File = 'Add_New_Import_File';
export const Clear_Uploaded_files = 'Clear_Uploaded_files';

export const Login = 'Login';
export const Login_Success = 'Login_Success';
export const Login_Fail = 'Login_Fail';
export const Log_Out = 'Log_Out';

export const Load_Senders = 'Load_Senders';
export const Search_Sender = 'Search_Sender';

export const LoadAll_AppManagers = 'LoadAll_AppManagers'; 
export const CREATE_NEW_APP = 'CREATE_NEW_APP'; 

export const SHOW_APP_MODAL = 'SHOW_APP_MODAL'; 
export const CLOSE_APP_MODAL = 'CLOSE_APP_MODAL'; 

export const CHANGE_APP_MANAGER_MODAL_SHOWING = 'CHANGE_APP_MANAGER_MODAL_SHOWING';
export const SAVE_NEW_APP_MANAGER = 'SAVE_NEW_APP_MANAGER';     
export const UPDATE_APP_MANAGER = 'UPDATE_APP_MANAGER';


export const ADD_NEW_APP_MANAGER_TO_APP = 'ADD_NEW_APP_MANAGER_TO_APP'; 
export const UPDATE_MANGER_STATUS_IN_APP = 'UPDATE_MANGER_STATUS_IN_APP';
export const LOAD_APPS_ASSIGNED = 'LOAD_APPS_ASSIGNED';
export const DELETE_APP = 'DELETE_APP';
export const REMOVE_MANAGER_IN_APP = 'REMOVE_MANAGER_IN_APP';
export const UPDATE_MANGER_IN_APP =  'UPDATE_MANGER_IN_APP';

export const EDIT_MANAGER_IN_APP = 'EDIT_MANAGER_IN_APP';

export const Restart_Email = 'Restart_Email';
export const Unschedule_Email = 'Unschedule_Email';
export const Cancel_Email = 'Cancel_Email';


export const UPLOAD_IMAGE = 'UPLOAD_IMAGE';


export const EMAIL_SEARCH = 'EMAIL_SEARCH';





