import * as ActionType from './ActionType'
import API from '../../network/API';
import * as ALERT from './alertActions'
import { toast } from 'react-toastify';
import { BackupDataManager } from '../../data/BackupDataManager';
import { LogSystem } from '../../log/index'
import { TokenManager } from '../../data/TokenManager'
import { __await } from 'tslib';

export function chooseApp(app) {
    LogSystem.info('chooseApp ------------------------------------------')
    LogSystem.info(app);
    BackupDataManager.setItem('choosenApp', JSON.stringify(app));
    window.location.replace('/notification/push');
}


function renderAppsAssignedSuccess(apps) {
    return {
        type: ActionType.LOAD_APPS_ASSIGNED,
        apps: apps
    }
}

function proceesWhenUserAssignedOnlyOneApp(appInput) {
    LogSystem.info('proceesWhenUserAssignedOnlyOneApp');
    LogSystem.info(appInput);
    const app = {
        "appId": appInput.app.id,
        "appName": appInput.app.appName,
        "iconUrl": appInput.app.iconUrl,
        "studentTypeSupported": appInput.studentTypeSupported
    }
    BackupDataManager.setItem('choosenApp', JSON.stringify(app));
    window.location.replace('/notification/push');
}

export function renderAppsAssigned() {
    const user = JSON.parse(TokenManager.getItem("user"));
    const role = (user === null) ? null : user.role;
    return (dispatch) => {
        API.getAppsAssigned().then( 
            (res) => {
                LogSystem.info('Portal::API::renderAppsAssigned------------------------------: ');
                LogSystem.info(res);
                if(res.data.code === 200) {
                    if(res.data.data === null || res.data.data.length < 1) {
                        window.location.replace('/appSubcribeEmpty');
                    }
                    else if(res.data.data !== null && res.data.data.length === 1) {
                        proceesWhenUserAssignedOnlyOneApp(res.data.data[0])
                    } else {
                        dispatch(renderAppsAssignedSuccess(res.data.data));
                    }
                } else {
                    ALERT.showToastAlter('Error',  res.data.message, toast.TYPE.ERROR);
                }
            }, 
            (err) => {
                window.location.replace('/systemerror');
            }
        )
        
    }
}