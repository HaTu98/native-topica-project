import { toast } from 'react-toastify';
import swal from 'sweetalert2'


export function showToastAlter(_title, _message, _type) {
    toast(_title + ': ' + _message, {type: _type})
}

export function showConfirmAlter(_title, _text , _callback) {
    swal({
        title: _title,
        text: _text,
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Chắc Chắn',
        cancelButtonText: 'Hủy',
        allowOutsideClick: false
      }).then((result) => {
        if (result.value) {
            _callback();
        }
      })
}