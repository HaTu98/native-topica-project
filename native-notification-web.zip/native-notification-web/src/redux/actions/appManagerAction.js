import * as ActionType from './ActionType'
import API from '../../network/API';
import * as ALERT from './alertActions'
import { toast } from 'react-toastify';
import { BackupDataManager } from '../../data/BackupDataManager';
import { LogSystem } from '../../log/index';
import CONSTANT from '../../constants/Constant';
// import { LogSystem } from '@logsystem';


function loadAllAppManagersSuccess(appMangerList) {
    return {
        type: ActionType.LoadAll_AppManagers,
        appMangerList: appMangerList
    }
}

export function loadAllAppManagers() {
    return (dispatch) => {
        API.loadAllAppMangers().then( 
            (res) => {
                if(res.data.code === 200) {
                    dispatch(loadAllAppManagersSuccess(res.data.data));
                } else if (res.data.codeStr !== undefined && res.data.codeStr === 305) {
                    window.location.replace('/')
                    ALERT.showToastAlter('Error',  'Không có quyền truy cập', toast.TYPE.ERROR);
                } else {
                    ALERT.showToastAlter('Error',  res.data.message, toast.TYPE.ERROR);
                }
            }, 
            (err) => {
                window.location.replace('/systemerror');
            }
        )
    }
}

function createNewNotificationAppSuccess(appInfo) {
    appInfo.subscribedManagers = [];
    return {
        type: ActionType.CREATE_NEW_APP,
        appInfo
    }
}

function randomString(length) {
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  
    for (var i = 0; i < length; i++)
      text += possible.charAt(Math.floor(Math.random() * possible.length));
  
    return text;
  }
  

export function showAppModal(appInfo, mode) {
    LogSystem.info('showAppModal::appInfo------------------------');
    LogSystem.info(appInfo);

    LogSystem.info('showAppModal------------------------');
    LogSystem.info(mode);
    return(dispatch) => {
        if(appInfo === null) {
            dispatch({
                    type: ActionType.SHOW_APP_MODAL,
                    appInfo: {
                        id: new Date().getTime(),
                        appName: null,
                        restApiKey: null,
                        onesignalAppId: null,
                        iconUrl: null,
                        privateKey: randomString(20)
                    },
                    mode
                }
            )
        } else {
            dispatch({
                    type: ActionType.SHOW_APP_MODAL,
                    appInfo,
                    mode
                }
            )
        }
    }
}

export function closerAppModal() {
    return {
        type: ActionType.CLOSE_APP_MODAL
    }
}

export function createNewNotificationApp(param) {
    LogSystem.info('Portal::API::createNewNotificationApp: input');
    LogSystem.info(param);
    
    return (dispatch) => {
        ALERT.showConfirmAlter(
            "Warning",
            "Bạn có chắc chắn muốn lưu ?",
            function ()  {
                API.createNewNotificationApp(param).then( 
                    (res) => {
                        LogSystem.info('Portal::API::createNewNotificationApp: ');
                        LogSystem.info(res);
                        if(res.data.code === 200) {
                            ALERT.showToastAlter('Success',  "Tao app mới thành công", toast.TYPE.SUCCESS);
                            dispatch(createNewNotificationAppSuccess(res.data.data));
                            // dispatch(closerAppModal());
                        } else {
                            ALERT.showToastAlter('Error',  res.data.message, toast.TYPE.ERROR);
                        }
                    }, 
                    (err) => {
                        console.error('Portal::API::loadAllAppManagers::e: ' + err);
                        window.location.replace('/systemerror');
                    }
                )
            }
        )
    }
}


function saveNewAppManagerSuccess(appManagerInfo, keyInAppsArray) {
    return({
        type: ActionType.ADD_NEW_APP_MANAGER_TO_APP,
        appManagerInfo,
        keyInAppsArray
    })
}

export function saveNewAppManager(param, keyInAppsArray) {
    LogSystem.info('Portal::saveNewAppManager -----------------')
    LogSystem.info(param);
    return (dispatch) => {

        ALERT.showConfirmAlter(
            "Warning",
            "Bạn có chắc chắn muốn lưu ?",
            function ()  {
                API.authorizeUserToApp(param).then( 
                    (res) => {
                        LogSystem.info('Portal::API::createNewNotificationApp: ');
                        LogSystem.info(res);
                        if(res.data.code === 200) {
                            ALERT.showToastAlter('Success',  "Thêm User mới thành công", toast.TYPE.SUCCESS);
                            dispatch(saveNewAppManagerSuccess(res.data.data, keyInAppsArray));
                            // dispatch(closerAppModal());
                        } else {
                            ALERT.showToastAlter('Error',  res.data.message, toast.TYPE.ERROR);
                        }
                    }, 
                    (err) => {
                        // console.error('Portal::API::saveNewAppManager::e: ' + err);
                        window.location.replace('/systemerror');
                    }
                )
            }
        )
    }
}

function changeManagerStatusInAppSuccess(appManager, indexInAppsArray, indexInUserSubcribeds) {
    LogSystem.info('changeManagerStatusInAppSuccess------------------');
    LogSystem.info(appManager);
    LogSystem.info('indexInAppsArray: '+ indexInAppsArray);
    LogSystem.info('indexInUserSubcribeds: '+ indexInUserSubcribeds);
    return ({
        type: ActionType.UPDATE_MANGER_STATUS_IN_APP,
        appManager,
        indexInAppsArray,
        indexInUserSubcribeds
    })
}

export function changeManagerStatusInApp(param, indexInAppsArray, indexInUserSubcribeds) {
    LogSystem.info('Portal::AppManagerAction::changeManagerStatusInApp -----------------')
    LogSystem.info(param);
    LogSystem.info('indexInAppsArray: ' + indexInAppsArray);
    LogSystem.info('indexInUserSubcribeds: ' + indexInUserSubcribeds);
    return (dispatch) => {
        ALERT.showConfirmAlter(
            "Warning",
            "Bạn có chắc chắn muốn thay đổi trạng thái ?",
            function ()  {
                API.updateManager(param).then( 
                    (res) => {
                        LogSystem.info('Portal::AppManagerAction::res -----------------')
                        LogSystem.info(res);
                        if(res.data.code === 200) {
                            ALERT.showToastAlter('Success',  "Thay đổi trạng thái thành công", toast.TYPE.SUCCESS);
                           //setTimeout(window.location.reload(), 3000);
                           dispatch(changeManagerStatusInAppSuccess(res.data.data, indexInAppsArray, indexInUserSubcribeds));
                            
                        } else {
                            ALERT.showToastAlter('Error',  res.data.message, toast.TYPE.ERROR);
                        }
                    }, 
                    (err) => {
                        window.location.replace('/systemerror');
                    }
                )
            }
        )
    }
}


export function onNewSaveAppManger(appManager) {

}

export function onChangeAppMangerModaShowing(isShowed, mode,...data) {
    LogSystem.info('onChangeAppMangerModaShowing::data:  ');
    LogSystem.info(data);
    var detail = {
        manager: {
            username: '' 
        },
        app: {
            id: ''
        },
        studentTypeSupported: '',
        status: "ACTIVE"
    };
    if(data !== null && data.length > 0) {
        detail = data[0]
    }
    return(dispatch) => {
        dispatch({
            type: ActionType.CHANGE_APP_MANAGER_MODAL_SHOWING,
            isAppMangerModalShowed: isShowed,
            detail,
            mode
        })
    }
}

function onDeleteAppSuccess(indexOfDeletedApp) {
    return ({
        type: ActionType.DELETE_APP,
        indexOfDeletedApp
    })
}

export function onDeleteApp(index, appId) {
    LogSystem.info('Portal::onDeleteApp::res index:' + index + ' - appId: ' + appId);
    return (dispatch) => {
        ALERT.showConfirmAlter(
            "Warning",
            "Bạn có chắc chắn muốn xóa App ?",
            function ()  {
                API.deleteApp(appId).then( 
                    (res) => {
                        LogSystem.info('Portal::AppManagerAction::res -----------------')
                        LogSystem.info(res);
                        if(res.data.code === 200) {
                            ALERT.showToastAlter('Success',  "Xóa app thành công", toast.TYPE.SUCCESS);
                            dispatch(onDeleteAppSuccess(index));
                        } else {
                            ALERT.showToastAlter('Error',  res.data.message, toast.TYPE.ERROR);
                        }
                    }, 
                    (err) => {
                        window.location.replace('/systemerror');
                    }
                )
            }
        )
    }
}

function removeManagerInAppSuccess(appIndex, indexInUserSubcribeds) {
    return ({
        type: ActionType.REMOVE_MANAGER_IN_APP,
        appIndex,
        indexInUserSubcribeds
    })
}

export function removeManagerInApp(id, appIndex, indexInUserSubcribeds) {
    LogSystem.info('Portal::removeManagerInApp::res id:' + id + ' - appIndex: ' + appIndex + ' - indexInUserSubcribeds: ' + indexInUserSubcribeds);
    return (dispatch) => {
        ALERT.showConfirmAlter(
            "Warning",
            "Bạn có chắc chắn muốn xóa user khỏi app ?",
            function ()  {
                API.deleteManager(id).then( 
                    (res) => {
                        LogSystem.info('Portal::AppManagerAction::res -----------------')
                        LogSystem.info(res);
                        if(res.data.code === 200) {
                            // window.location.reload();
                            ALERT.showToastAlter('Success',  "Xóa user thành công", toast.TYPE.SUCCESS);
                            setTimeout(() => window.location.reload(), 1500);
                            // dispatch(loadAllAppManagers())
                            // dispatch(removeManagerInAppSuccess(appIndex, indexInUserSubcribeds));
                        } else {
                            ALERT.showToastAlter('Error',  res.data.message, toast.TYPE.ERROR);
                        }
                    }, 
                    (err) => {
                        window.location.replace('/systemerror');
                    }
                )
            }
        )
    }
}

function updateManagerSuccess(appIndex, indexInUserSubcribeds) {
    return ({
        type: ActionType.UPDATE_MANGER_IN_APP,
        appIndex,
        indexInUserSubcribeds
    })
}

export function updateManager(param, indexInAppsArray, indexInUserSubcribeds) {
    LogSystem.info('Portal::AppManagerAction::changeManagerStatusInApp -----------------')
    LogSystem.info(param);
    LogSystem.info('indexInAppsArray: '+ indexInAppsArray);
    LogSystem.info('indexInUserSubcribeds: '+ indexInUserSubcribeds);
    return (dispatch) => {
        ALERT.showConfirmAlter(
            "Warning",
            "Bạn có chắc chắn muốn lưu ?",
            function ()  {
                API.updateManager(param).then( 
                    (res) => {
                        LogSystem.info('Portal::AppManagerAction::res -----------------')
                        LogSystem.info(res);
                        if(res.data.code === 200) {
                            ALERT.showToastAlter('Success',  "Sửa user thành công", toast.TYPE.SUCCESS);
                           dispatch(updateManagerSuccess(res.data.data, indexInAppsArray, indexInUserSubcribeds));
                            
                        } else {
                            ALERT.showToastAlter('Error',  res.data.message, toast.TYPE.ERROR);
                        }
                    }, 
                    (err) => {
                        // console.error('Portal::API::loadAllAppManagers::e: ' + err);
                        window.location.replace('/systemerror');
                    }
                )
            }
        )
    }
}

