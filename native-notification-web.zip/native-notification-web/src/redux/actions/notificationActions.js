import API from '../../network/API';
import * as ActionType from './ActionType'
import * as ALERT from './alertActions'
import { toast } from 'react-toastify';
import swal from 'sweetalert2'
import AppConfig from '../../constants/AppConfig'
import CONSTANT from '../../constants/Constant';
import XLSX from 'xlsx';
import { LogSystem } from '../../log/index'
import { TokenManager } from '../../data/TokenManager';

import {BackupDataManager} from '../../data/BackupDataManager';
import { from } from 'rxjs';


const cols = [{ name: "A", key: 0 }, { name: "B", key: 1 }, { name: "C", key: 2 }];
const  data = [
    [ "id",    "name", "value" ],
    [    1, "sheetjs",    7262 ],
    [    2, "js-xlsx",    6969 ]
  ]

const _uploadFileSuccess = (params, file) => {
    return {
        type: ActionType.Add_New_Import_File,
        uploadedFile: file
    }
}

const updateFileToPreview = (file) => {
    
    return {
        type: ActionType.Add_New_Import_File,
        uploadedFile: file
    }
}

const All_STUDENT_INVALID = 'Không có học viên nào chính xác';
const EXIST_STUDENT_INVALID = 'Có một số học viên không chính xác';

const exportStudentErrors = (studentErrors) => {
    LogSystem.info('exportStudentErrors::studentErrors');
    LogSystem.info(studentErrors);

    var exportData = [];
    exportData.push(['No *', 'Student Email *', 'Error']);
    studentErrors.map((item) => {
        var studentDetail = [item.id, item.username, item.error];
        exportData.push(studentDetail);
    })

    LogSystem.info('exportData------------------------------------');
    LogSystem.info(exportData);

    const ws = XLSX.utils.aoa_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Student Error");
    /* generate XLSX file and send to client */
    XLSX.writeFile(wb, "Danh_sach_hoc_vien_loi.xlsx")
} 

function uploadFileFail(params, dispatch, file) {
    LogSystem.info('uploadFileFail::params');
    LogSystem.info(params.data);
    swal({
        title: (params.data.successStudents > 0) ? 'warning' : 'error',
        type: (params.data.successStudents > 0) ? 'warning' : 'error',
        html:
            '<h4 class="text-warning">' + (params.data.successStudents > 0 ? EXIST_STUDENT_INVALID : All_STUDENT_INVALID) + '</h4> <br>' +
            '<a style="text-decoration: underline;" id="resume"><h4> Tải xuống Học Viên lỗi</h4></a>',
        onBeforeOpen: () => {
            const content = swal.getContent()
            const $ = content.querySelector.bind(content)
            const resume = $('#resume')
            resume.addEventListener('click', () => {
                LogSystem.info('Click tai xuong HV loi')
                exportStudentErrors(params.data.studentErrors)
                // Swal.resumeTimer()
                // toggleButtons()
            })

            },    
        showCloseButton: true,
        showCancelButton: true,
        focusConfirm: false,
        confirmButtonText: 'Tiếp Tục',
        cancelButtonText: 'Hủy'
    }).then((result) => {
        if (result.value && params.data.successStudents > 0) {
            LogSystem.info('_uploadFileFail:: data ---------------------------');
            LogSystem.info(params.data.studentErrors);
            
            dispatch(updateFileToPreview(file))
        }
    })
}

function getAppId() {
    const choosenApp = JSON.parse(BackupDataManager.getItem("choosenApp"));
    var appId = 1547767888688;
    if(choosenApp !== null) {
        appId = choosenApp.appId;
    }
    return appId;
}

export function uploadFile(file) {
    LogSystem.info('Portal::uploadFile fileName: ' + file.name);
    var appId = getAppId();
    return (dispatch) => {
        return API.uploadFile(file, appId).then(
            (res) => {
                LogSystem.info(res);
                if (res.data.code === 200) {
                    ALERT.showToastAlter('Success', 'Tất cả các học viên được import thành công', toast.TYPE.SUCCESS);
                    dispatch(_uploadFileSuccess(res.data, file));
                } else {
                    if(res.data.code === 134) {
                        uploadFileFail(res.data, dispatch, file)
                    } else {
                        ALERT.showToastAlter('Error', res.data.message, toast.TYPE.ERROR);
                    }
                }
            },
            (err) => {
                
                // window.location.replace('/systemerror');
            }
        )
    }
};

function handleClearUploadedFile() {
    return {
        type: ActionType.Clear_Uploaded_files
    }
}

export function clearUploadedFiles() {
    LogSystem.info('Portal::notificationAction::clearUploadedFiles ----------------')
    return (dispatch) => {
        swal({
            title: 'Warning',
            text: "Bạn có chắc chắn muốn xóa ?",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Xóa',
            cancelButtonText: 'Hủy',
        }).then((result) => {
            if(result.value) {
                dispatch(handleClearUploadedFile());
            }
        })
    }
}


export function submitNotification(params) {
    return (dispatch) => {
        return API.submitNotification(params).then(
            (res) => {
                if (res.data.code === 200) {
                    if(params.type === CONSTANT.NotificationType.QUICKSEND) {
                        ALERT.showToastAlter('Success', 'Gửi thông báo thành công', toast.TYPE.SUCCESS);    
                    } else {
                        ALERT.showToastAlter('Success', 'Tạo thông báo thành công', toast.TYPE.SUCCESS);
                    }
                } else {
                    ALERT.showToastAlter('Error', res.data.message, toast.TYPE.ERROR);
                }
            },
            (err) => {
                //window.location.replace('/systemerror');
                //ALERT.showToastAlter('Error', err, toast.TYPE.ERROR);
            }
        )
    }
}


function handleSearchNotificaitonSuccess(data) {
    LogSystem.info('Portal::handleSearchNotificaitonSuccess response');
    LogSystem.info(data);
    return {
        type: ActionType.Search_Sender,
        sendersData: data
    }
}

export function searhNotificationSenders(params) {
    LogSystem.info('Portal::searhNotificationSenders params');
    LogSystem.info(params);
    return (dispatch) => {
        return API.searchNotificationSenders(params).then(
            (res) => {
                // LogSystem.info('Portal::searhNotificationSender response');
                // LogSystem.info(res);
                if (res.data.code === 200) {
                    // LogSystem.info('Portal::searhNotificationSender data');
                    // LogSystem.info(res.data.data);
                    ALERT.showToastAlter('Success', 'Dữ liệu được tìm thấy thành công', toast.TYPE.SUCCESS);
                    dispatch(handleSearchNotificaitonSuccess(res.data.data));
                } else {
                    ALERT.showToastAlter('Error', res.data.message, toast.TYPE.ERROR);
                }
            },
            (err) => {
                window.location.replace('/systemerror');
            }
        )
    }
}

function unscheduleNotificcationSuccess(sender, key) {
    return {
        type: ActionType.Unschedule_Notification,
        sender: sender,
        key: key
    }
}

export function unscheduleNotificcation(senderId, key) {
    LogSystem.info('Portal::unscheduleNotificcation --------------------------senderId: ' + senderId + ' key: ' + key);
    return (dispatch) => {
        return API.unscheduleNotificcation(senderId).then(
            (res) => {
                if (res.data.code === 200) {
                    ALERT.showToastAlter('Success', 'Dừng thông báo thành công', toast.TYPE.SUCCESS);
                    dispatch(unscheduleNotificcationSuccess(res.data.data, key));
                } else {
                    ALERT.showToastAlter('Error', res.data.message, toast.TYPE.ERROR);
                }
            },
            (err) => {
                window.location.replace('/systemerror');
                //ALERT.showToastAlter('Error', err, toast.TYPE.ERROR);
            }
        )
    }
}

function restartNotificcationSuccess(sender, key) {
    return {
        type: ActionType.Restart_Notification,
        sender: sender,
        key: key
    }
}

export function restartNotificcation(senderId, key) {
    LogSystem.info('Portal::restartNotificcation senderId: ' + senderId + ' - key: ' + key);
    return (dispatch) => {
        return API.restartNotificcation(senderId).then(
            (res) => {
                if (res.data.code === 200) {
                    ALERT.showToastAlter('Success', 'Thông báo đã được chạy lại', toast.TYPE.SUCCESS);
                    dispatch(restartNotificcationSuccess(res.data.data, key));
                } else {
                    ALERT.showToastAlter('Error', res.data.message, toast.TYPE.ERROR);
                }
            },
            (err) => {
                window.location.replace('/systemerror');
            }
        )
    }
}


export function quickSendNotification(params) {
    return (dispatch) => {
        swal({
            title: 'Warning',
            text: "Bạn có chắc chắn muốn gửi ngay không?",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            cancelButtonText: 'Hủy',
            confirmButtonText: 'Chắc chắn'
        }).then((result) => {
            if (result.value) {
                return API.quickSendNotification(params).then(
                    (res) => {
                        if (res.data.code === 200) {
                            ALERT.showToastAlter('Success', 'Yêu cầu gửi thông báo đang trong quá trình xử lý', toast.TYPE.SUCCESS);
                        } else {
                            ALERT.showToastAlter('Error', res.data.message, toast.TYPE.ERROR);
                        }
                    },
                    (err) => {
                        window.location.replace('/systemerror');
                    }
                )
            }
        })

    }
}


function cancelNotificationWatingSuccess(sender, key) {
    return {
        type: ActionType.Cancel_Notification,
        sender: sender,
        key: key
    }
}


export function cancelNotificationWating(senderId, key) {
    LogSystem.info('Portal::cancelNotificationWating senderId: ' + senderId + ' - key: ' + key);
    return (dispatch) => {
        return API.cancelNotificationWating(senderId).then(
            (res) => {
                if (res.data.code === 200) {
                    ALERT.showToastAlter('Success', 'Thông báo đã được hủy không gửi nữa', toast.TYPE.SUCCESS);
                    dispatch(cancelNotificationWatingSuccess(res.data.data, key));
                } else {
                    ALERT.showToastAlter('Error', res.data.message, toast.TYPE.ERROR);
                }
            },
            (err) => {
                window.location.replace('/systemerror');
            }
        )
    }
}

function createNewNotificationFromThisSuccess(notificaitonPush) {
    return {
        type: ActionType.Create_New_Notificaiton_From_This,
        notificaitonPush
    }
}

export function getSenderDetail(senderId) {
    LogSystem.info('Portal::getSenderDetail senderId: ' + senderId);
    return (dispatch) => {
        return API.getDetail(senderId).then(
            (res) => {
                // LogSystem.info(res);
                if (res.data.code === 200) {
                    ALERT.showToastAlter('Success', 'Lấy thông báo thành công', toast.TYPE.SUCCESS);
                    dispatch(createNewNotificationFromThisSuccess(res.data.data))
                } else {
                    ALERT.showToastAlter('Error', res.data.message, toast.TYPE.ERROR);
                }
            },
            (err) => {
                window.location.replace('/systemerror');
            }
        )
    }
}

export function onChangeTab() {
    return {
        type: ActionType.On_Change_Tab
    }
}

// export function validateStudentInfo(params) {
//     var appId = getAppId();
//     return (dispatch) => {
//         return API.validateStudentInfo(appId, params).then(
//             (res) => {
//                 if (res.data.code === 200) {
//                     ALERT.showToastAlter('Success', 'Upload file thành công', toast.TYPE.SUCCESS);
//                     dispatch(createNewNotificationFromThisSuccess(res.data.data))
//                 } else {
//                     ALERT.showToastAlter('Error', res.data.message, toast.TYPE.ERROR);
//                 }
//             },
//             (err) => {
//                 // window.location.replace('/systemerror');
//             }
//         )
//     }
// }

export function validateStudentInfo(params, successCalback) {
    var appId = getAppId();
    return API.validateStudentInfo(appId, params).then (
        (res) => {
            if (res.data.code === 200) {
                // ALERT.showToastAlter('Success', 'Upload file thành công', toast.TYPE.SUCCESS);
                successCalback(res.data.data);
            } else {
                ALERT.showToastAlter('Error', res.data.message, toast.TYPE.ERROR);
            }
        },
        (err) => {
            window.location.replace('/systemerror');
        }
    )
    
}