
import LogSystem from '../../log/LogSystem'
import XLSX from 'xlsx';

export const ExcelProvider = {
    exportStudentErrors: (studentErrors) => {
        LogSystem.info('exportStudentErrors::studentErrors -----------------------');
        LogSystem.info(studentErrors);
    
        var exportData = [];
        exportData.push(['No *', 'Student Email *', 'Error']);
        studentErrors.map((item) => {
            var studentDetail = [item.id, item.username, item.error];
            exportData.push(studentDetail);
        })
    
        LogSystem.info('exportData------------------------------------');
        LogSystem.info(exportData);
    
        const ws = XLSX.utils.aoa_to_sheet(exportData);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Student Error");
        /* generate XLSX file and send to client */
        XLSX.writeFile(wb, "Danh_sach_hoc_vien_loi.xlsx")
    } 

}
