import * as ActionType from '../actions/ActionType'
import  { TokenManager } from '../../data/TokenManager'

var initialState = {
    token: TokenManager.getItem('token'),
    user: JSON.parse(TokenManager.getItem('user'))
};

const loginReducers = (state = initialState, action) => {
    // LogSystem.info('Portal::login::action ' + JSON.stringify(action));
    // LogSystem.info('Portal::login::state ' + JSON.stringify([state]));
    switch (action.type) {
        case ActionType.Login:
            return [...state];
        case ActionType.Login_Success:
            return {
                token: action.token,
                user: action.user
            } 
        case ActionType.Log_Out: 
            return {  
                token: null,
                user: null
            }       
        default: 
            return state;
    }
}


export default loginReducers;