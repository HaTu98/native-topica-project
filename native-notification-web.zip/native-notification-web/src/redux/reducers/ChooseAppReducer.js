import * as ActionType from '../actions/ActionType'
import { LogSystem } from '../../log/index'

var initialState = {
    apps: []
};

const chooseAppReducer = (state = initialState, action) => {
    LogSystem.info('Portal::chooseAppReducer------------------------')
    LogSystem.info(action);
    LogSystem.info('Portal::chooseAppReducer::state------------------------');
    LogSystem.info(state);
    switch (action.type) {
        case ActionType.LOAD_APPS_ASSIGNED:
            LogSystem.info('Debug ---- action.apps');
            LogSystem.info(action.apps)
            return {
                ...state,
                apps: action.apps
            };     
        default: 
            return state;
    }
}

export default chooseAppReducer;