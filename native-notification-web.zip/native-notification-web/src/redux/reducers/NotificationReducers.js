import * as ActionType from '../actions/ActionType'
var initialState = {
    sendersData: {
        content: undefined,
        size: null,
        number: null,
        totalElements: null,
        totalPages: null
    },
    notificaitonPush: {
            detailContent: {
                title: '',
                body: '',
                bodyHtml: '',     
            },
            usernameSender: [],
            currentTab: 0,
            notificationType: '',
            prePlanTime: '',
            cronExpression: '',
            sendAll: false
    }
}

const notifcationReducer = (state = initialState, action) => {
    // LogSystem.info('Portal::notificaitonReducer::action ');
    // LogSystem.info(action);
    switch (action.type) {
        case ActionType.Search_Sender: {
            return {
                ...state,
                sendersData: action.sendersData,
                content: action.content
            }
        }
        case ActionType.Restart_Notification: 
        case ActionType.Unschedule_Notification: 
        case ActionType.Cancel_Notification: {
            let content = state.sendersData.content;
            content[action.key]=action.sender;
            return {
                ...state,
                sendersData: {
                    content: content,
                    size: state.sendersData.size,
                    number: state.sendersData.number,
                    totalElements: state.sendersData.totalElements,
                    totalPages: state.sendersData.totalPages
                }
            }
        }
        case ActionType.Create_New_Notificaiton_From_This: {
            return {
                ...state,
                notificaitonPush: action.notificaitonPush
            }
        }
        default: 
            return state;
    }
}

export default notifcationReducer;