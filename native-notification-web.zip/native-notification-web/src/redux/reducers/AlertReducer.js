import * as ActionType from '../actions/ActionType';
var initialState = {
    isShowAlert: false
}

const alertReducer = (state = initialState, action) => {
    switch (action.type) {
        case ActionType.Show_Alert: 
            return {
                ...state,
                isShowAlert: true
            }
        default: 
            return state;
    }
}


export default alertReducer;