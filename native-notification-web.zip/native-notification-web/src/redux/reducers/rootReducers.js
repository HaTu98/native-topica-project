import { combineReducers } from 'redux';
import notifcationReducer from './NotificationReducers'
import alertReducer from './AlertReducer'
import importFileReducer from './ImportFileReducer'
import loginReducers from './LoginReducers'
import appManagerReducer from './AppManagerReducer'
import chooseAppReducer from './ChooseAppReducer'
import emailReducer from './EmailReducers'

const rootReducers = combineReducers({  
   notifcationReducer,
   alertReducer,
   importFileReducer,
   loginReducers,
   appManagerReducer,
   chooseAppReducer,
   emailReducer
});

export default rootReducers;