import * as ActionType from '../actions/ActionType'
var initialState = {
    uploadedFile: null
};

const importFileReducer = (state = initialState, action) => {
    // LogSystem.info('Portal::importFileReducer::action ' + JSON.stringify(action));
    switch (action.type) {
        case ActionType.Add_New_Import_File:
            return {
                ...state,
                uploadedFile: action.uploadedFile,
            }
        case ActionType.Clear_Uploaded_files: {
            return {
                ...state,
                uploadedFile: null
            }
        }
        case ActionType.On_Change_Tab:
            return {
                ...state,
                uploadedFile: null,
            }
        default: 
            return state;
    }
}


export default importFileReducer;