import * as ActionType from '../actions/ActionType'
import LogSystem from '../../log/LogSystem'

var initialState = {
    sendersData: {
        content: undefined,
        size: null,
        number: null,
        totalElements: null,
        totalPages: null
    },
    notificaitonPush: {
            detailContent: {
                title: '',
                body: '',
                bodyHtml: '',     
            },
            usernameSender: [],
            currentTab: 0,
            notificationType: '',
            prePlanTime: '',
            cronExpression: '',
            sendAll: false
    }
}

const emailReducers = (state = initialState, action) => {
    LogSystem.info('Portal::notificaitonReducer::action ');
    LogSystem.info(action);
    switch (action.type) {
        case ActionType.EMAIL_SEARCH: {
            return {
                ...state,
                sendersData: action.sendersData,
                content: action.content
            }
        }
        case ActionType.Restart_Email: 
        case ActionType.Unschedule_Email: 
        case ActionType.Cancel_Email: {
            let content = state.sendersData.content;
            content[action.key]=action.sender;
            return {
                ...state,
                sendersData: {
                    content: content,
                    size: state.sendersData.size,
                    number: state.sendersData.number,
                    totalElements: state.sendersData.totalElements,
                    totalPages: state.sendersData.totalPages
                }
            }
        }
        default: 
            return state;
    }
}

export default emailReducers;