import * as ActionType from '../actions/ActionType'
import { LogSystem } from '../../log/index'
import CONSTANT from '../../constants/Constant';

var initialState = {
    appMangerList: [],
    modal: {
        isModalShow: false,
        appInfo: {
            id: null,
            appName: null,
            restApiKey: null,
            onesignalAppId: null,
            iconUrl: null  
        },
        mode: CONSTANT.AppManager.AppModal.Mode.Create,
        isEditMode: false  
    },
    managerModal: {
        isShow: false,
        detail: {
            manager: {
                username: '' 
            },
            app: {
                id: ''
            },
            studentTypeSupported: '',
            status: "ACTIVE"
        },
        mode: CONSTANT.Modal.Mode.Create
    }
};

const appManagerReducer = (state = initialState, action) => {
    LogSystem.info('Portal::appManagerReducer------------------------')
    LogSystem.info(action);
    LogSystem.info('Portal::appManagerReducer::state------------------------');
    LogSystem.info(state);
    switch (action.type) {
        case ActionType.LoadAll_AppManagers:
            return {
                ...state,
                appMangerList: action.appMangerList
            };     

        case ActionType.CREATE_NEW_APP:
            var { appMangerList } = state;
            appMangerList.push(action.appInfo);
            return {
                ...state,
                appMangerList: appMangerList,
                modal: {
                    isModalShow: false,
                    appInfo: {
                        id: null,
                        appName: null,
                        restApiKey: null,
                        onesignalAppId: null,
                        iconUrl: null
                    },
                    mode: CONSTANT.AppManager.AppModal.Mode.Create,
                    isEditMode: false  
                },
            };  
        case ActionType.SHOW_APP_MODAL:
            return {
                ...state,
                modal: {
                    isModalShow: true,
                    appInfo: action.appInfo,
                    isEditMode: false, 
                    mode: action.mode 
                },
                
            };  
        case ActionType.CLOSE_APP_MODAL:
            return {
                ...state,
                modal: {
                    isModalShow: false  
                },
            };     
        case ActionType.CHANGE_APP_MANAGER_MODAL_SHOWING:
            return {
                ...state,
                managerModal: {
                    isShow: action.isAppMangerModalShowed,
                    detail: action.detail,
                    mode: action.mode
                }
            }        
        case ActionType.ADD_NEW_APP_MANAGER_TO_APP:
            var newAppMangerList  = state.appMangerList;
            newAppMangerList[action.keyInAppsArray].subscribedManagers.push(action.appManagerInfo);
            return {
                ...state,
                appMangerList: newAppMangerList,
                managerModal: {
                    ...state.managerModal,
                    isShow: false
                }
            }
        case ActionType.UPDATE_MANGER_IN_APP:
            return {
                ...state,
                managerModal: {
                    ...state.managerModal,
                    isShow: false
                }
            }    

        case ActionType.UPDATE_MANGER_STATUS_IN_APP: 
            var newAppMangers  = state.appMangerList;
            newAppMangers[action.indexInAppsArray].subscribedManagers[action.indexInUserSubcribeds] = action.appManager;
            LogSystem.info('-------------------------------UPDATE_MANGER_STATUS_IN_APP----------------------------------------------');
            LogSystem.info(newAppMangers);
            return {
                ...state,
                appMangerList: newAppMangers,
                modal: {...state.modal}
            };
        case ActionType.DELETE_APP:
            var { appMangerList } = state;
            appMangerList.splice(action.indexOfDeletedApp, 1);
            return {
                ...state,
                appMangerList: appMangerList,
                modal: {...state.modal}
            }


        case ActionType.REMOVE_MANAGER_IN_APP:
            var  appMangerList  = [...state.appMangerList];
            var subscribedManagers = appMangerList[action.appIndex].subscribedManagers;
            var managers = [...subscribedManagers];
            LogSystem.info('action.indexInUserSubcribeds::appMangerList: ');
            LogSystem.info(appMangerList);

            LogSystem.info('action.indexInUserSubcribeds::managers: ');
            LogSystem.info(managers);
        
            var managersOutput = managers.splice(action.indexInUserSubcribeds, 1);
            LogSystem.info('action.indexInUserSubcribeds::managers::managersOutput ');
            LogSystem.info(managers);

            appMangerList[action.appIndex].subscribedManagers = managers;

            // LogSystem.info(' appMangerList[action.appIndex].subscribedManagers: ------------------')
            // LogSystem.info(appMangerList[action.appIndex].subscribedManagers);

            // appMangerList[action.appIndex].subscribedManagers.splice(action.indexInUserSubcribeds, 1);
            // LogSystem.info(' appMangerList[action.appIndex].subscribedManagers: after------------------')
            // LogSystem.info(appMangerList[action.appIndex].subscribedManagers);
            // LogSystem.info('-------------appMangerList--------------------');
            // LogSystem.info(appMangerList);
            return {
                ...state,
                appMangerList: appMangerList,
                modal: {...state.modal}
            }   
        default: 
            return state;
    }
}

export default appManagerReducer;