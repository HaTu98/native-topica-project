import React, { Component } from 'react';
import { LogSystem } from '../../log/index'
import NotitificationApp from './NotitificationApp';

class NotificationAppBox extends Component {

    componentWillReceiveProps(newProps) {
        LogSystem.info('Portal::NotificationAppManagerBox::componentWillReceiveProps');
        LogSystem.info(newProps);
    } 

    showNotificationAppManagerList= ()  => {
        var { appMangerList } = this.props;
        LogSystem.info('Portal::NotificationAppManagerBox::showNotificationAppManagerList::appMangerList');
        LogSystem.info(appMangerList);
        var result = [];
        if(appMangerList !== undefined && appMangerList !== null && appMangerList.length > 0) {
            for(let i = appMangerList.length - 1; i >= 0; i--) {
                let _item = appMangerList[i];
                result.push(
                    <NotitificationApp
                    key = {i}
                    index = {i}
                    id = {_item.id} 
                    appName = {_item.appName}
                    privateKey={_item.privateKey}
                    onesignalAppId = {_item.onesignalAppId}
                    restApiKey = {_item.restApiKey}
                    iconUrl = {_item.iconUrl}
                    status = {_item.status}
                    subscribedManagers = {_item.subscribedManagers}
                    onViewDetail = {this.props.onViewDetail}
                    addNewUserToApp = {this.props.addNewUserToApp}
                    removeManagerInApp={this.props.removeManagerInApp}
                    onEditManger={this.props.onEditManger}
                    deleteApp={this.props.deleteApp}
                    changeManagerStatusInApp = {this.props.changeManagerStatusInApp} 
                    
                    />
                )
            }
            return result;
        }
        return <div></div>
    }

    render() {
        return (
            <div>
                {this.showNotificationAppManagerList()}
            </div>
        );
    }
}




export default NotificationAppBox;
