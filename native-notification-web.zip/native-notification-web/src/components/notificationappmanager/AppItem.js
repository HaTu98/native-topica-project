import React, { Component } from 'react';
import { LogSystem } from '../../log';

// const defaultIconUrl = "https://images-na.ssl-images-amazon.com/images/I/51FPJmcYaEL._SY355_.png"
const defaultIconUrl = "https://go.umaine.edu/wp-content/uploads/sites/10/2017/01/The-Common-Application-300x300.png"

class AppItem extends Component {

    // key={_index}
    // appId = {_item.id}
    // iconUrl = {_item.iconUrl}
    // appName={_item.appName}

    // constructor(props) {
    //     super(props);
    //     this.state = this.props;
    // }

    onClickChooseApp = () => {
        // LogSystem.info('AppItem::onClickChooseApp::onClickChooseApp::onClickChooseApp');
        // LogSystem.info(this.props);
        this.props.chooseApp(this.props)
    }


    render() {
        return (
            <div className="col-xs-4 col-sm-4 col-md-4 col-lg-4">
                <div className="img-app_container">
                    <div className="img-app_content">
                        <div className="img-app_inner">
                            <a onClick={() => this.onClickChooseApp()}>
                                <img src={(this.props.iconUrl !== null && this.props.iconUrl !== 'null') ? this.props.iconUrl : defaultIconUrl} className="img-responsive " alt="Image"></img>
                                <div className="img-app_title-inner">
                                    {( this.props.appName !== null && this.props.appName.length > 14 ) ? this.props.appName.substring(0, 10) + '...' :  this.props.appName}
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}



export default AppItem;