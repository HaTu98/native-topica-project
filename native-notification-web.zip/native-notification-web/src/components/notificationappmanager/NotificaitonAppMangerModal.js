import React, { Component } from 'react';
import InputErrorMessage from '../common/InputErrorMessage';
import '../../style/appModal.css'
import { LogSystem } from '../../log/index'
import EmailValidation from '../../util/EmailValidation'
import CONSTANT from '../../constants/Constant'

class NotificaitonAppMangerModal extends Component {
    constructor(props) {
        super(props);
        this.state = {
            userid: null,
            username: this.props.detail.manager.username,
            serviceType: null,
            studentTypeSupported: this.props.detail.studentTypeSupported,
            usernameError: null,
            studentTypeSupportedError: null
        }
    }

    componentDidMount() {
        this.emailInputRef.focus();
        LogSystem.info("NotificaitonAppMangerModal::componentDidMount---------vvv------------");
        LogSystem.info(this.props.detail);
        LogSystem.info("NotificaitonAppMangerModal::componentDidMount--------------mode-------");
    }

    onChangeModalShowing = (isShow) => {
        this.props.onChangeAppMangerModaShowing(isShow, CONSTANT.Modal.Mode.View);
    }

    componentWillReceiveProps(props) {
        LogSystem.info("NotificaitonAppMangerModal::componentWillReceiveProps---------------------");
        LogSystem.info(this.props.detail.studentTypeSupported);
    }


    onChange = (e) => {
        LogSystem.info('Portal::onChange ');
        LogSystem.info('Portal::onChange name: ' + e.target.name);
        LogSystem.info('Portal::onChange value: ' + ((e.target.type === 'checkbox') ?  e.target.checked : e.target.value));
        var target = e.target;
        var name = target.name;
        var value = target.type === 'checkbox' ? target.checked : target.value;
        this.setState({
            [name]: value
        });
        if(name === 'username') {
            this.setState({
                usernameError: null
            });
        }
        if(name === 'studentTypeSupported') {
            this.setState({
                studentTypeSupportedError: null
            });
        }
    }

    onChangeEmail = (e) => {
        let username = e.target.value;
        LogSystem.info('onChangeEmail -----------username.length-------------');
        LogSystem.info(username.length);
        if(username !== null && username.length > 50) {
            this.setState({
                usernameError: "Trường này không vượt quá 50 kí tự"
            });
        } else {
            this.setState({
                username: (username === null) ? '' : username.trim(),
                usernameError: null
            });
        }
    }

    getUsernameFromInput = (param) => {
        if(param === undefined || param === null || param === '') {
            this.setState({
                usernameError: 'Trường này là bắt buộc '
            })
            this.emailInputRef.focus();
            return null;
        }else if(EmailValidation.isTopicaUsername(param)) {
            return param + CONSTANT.Topica_Email_Extension;
        }else if(EmailValidation.isTopicaEmail(param)) {
            return param;
        }
        this.setState({
            usernameError: 'Email nhân viên không hợp lệ. Vui lòng kiểm tra lại'
        })
        this.emailInputRef.focus();
        return null;
    }

    getStudentTypeSupportedErrorFromInput = (param) => {
        if(param === undefined || param === null || param === "") {
            this.setState({
                studentTypeSupportedError: "Trường này là bắt buộc"
            })
            this.studentTypeSupported.focus();
            return null;
        }
        return param;
    }



    onClickSave = () => {
        var studentTypeSupported = this.getStudentTypeSupportedErrorFromInput(this.state.studentTypeSupported);
        let username  = this.getUsernameFromInput(this.state.username);
        if(username === null || studentTypeSupported === null) return;
        if(this.props.mode === CONSTANT.Modal.Mode.Update) {
            var  { detail } = this.props;
            detail.studentTypeSupported = this.state.studentTypeSupported
            this.props.updateManager(detail)
        } else {
            this.props.onSaveNewAppManager(username, studentTypeSupported);
        }
    }

    // .modal-dialog_add_user, .modal-content_add_user

    render() {
        // LogSystem.info("NotificaitonAppMangerModal::render--------------mode-------");
        console.log('-------------: ' + JSON.stringify(this.props.detail));
        return (
            <div className={"modal fade in modal_show"}>
                <div className="modal-dialog modal-dialog_add_user">
                    <div className="modal-content modal-content_add_user">
                        <div className="modal-header">
                            <button type="button" className="close"  style={{fontWeight: 'bold'}} onClick={() => this.onChangeModalShowing(false)}>X</button>
                            <h4 className="modal-title">Thông tin Người dùng</h4>
                        </div>
                        <div className="modal-body">
                            <div className="form-group">
                                <label htmlFor="username">Email nhân viên: <span className="text-danger">*</span></label>
                                <input type="text"
                                    className="form-control"
                                    id="username"
                                    maxLength={51}
                                    value={this.state.username === null ? "" : this.state.username}
                                    name="username"
                                    onChange = {this.onChangeEmail}
                                    ref={(input) => { this.emailInputRef = input; }} 
                                    readOnly={this.props.mode !== CONSTANT.Modal.Mode.Create}
                                    >
                                </input>
                                <InputErrorMessage>{this.state.usernameError}</InputErrorMessage>
                            </div>
                            <div className="form-group">
                                <label htmlFor="username">Loại Student cho phép: <span className="text-danger">*</span></label>
                                <select className="form-control"  
                                    name = "studentTypeSupported"
                                    value = {this.state.studentTypeSupported}
                                    onChange={this.onChange}	
                                    ref={(input) => { this.studentTypeSupported = input; }} 
                                    >
                                    <option value="">-- Chọn loại học viên cho phép gửi notification --</option>
                                    <option value="VIP">VIP</option>
                                    <option value="NORMAL">NORMAL</option>
                                    <option value="ALL">ALL</option>
                                </select>
                                <InputErrorMessage>{this.state.studentTypeSupportedError}</InputErrorMessage>	
                            </div>
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-default" onClick={() => this.onChangeModalShowing(false)} >&nbsp;&nbsp;&nbsp;Hủy&nbsp;&nbsp;&nbsp;</button>&nbsp;&nbsp;
                            <button type="button" className="btn btn-primary" onClick={() => this.onClickSave()}>&nbsp;&nbsp;&nbsp;Lưu&nbsp;&nbsp;&nbsp;</button>
                        </div> 
                    </div>
                </div>
            </div>

        );
    }
}

export default NotificaitonAppMangerModal;
