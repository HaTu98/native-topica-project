import React, { Component } from 'react';
import NotificationManagerItem from './NotificationManagerItem';
import '../../style/notificationMangermanerList.css'

class NotificaitonManagerList extends Component {

    render() {
        return (
            // <div>
            //     {this.props.children}
            // </div>
            // <div style={{width: "100%" }}>
            //     <div className="scroll_style">
            //     <ul class="list-group" style={{minWidth: "700px"}}>
            //         <li class="list-group-item">
            //             <div className="row mt-10">
            //                 <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2" style={{minWidth: "30px"}}>
            //                     <span className="label-style">ID</span>
            //                 </div>
            //                 <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4" style={{overflowWrap: "break-word", minWidth: "150px"}}>
            //                     <span className="label-style">Username</span>
            //                 </div>

            //                 <div class="col-xs-1 col-sm-1 col-md-1 col-lg-1" style={{minWidth: "100px"}}>
            //                     <span className="label-style">Role</span>
            //                 </div>

            //                 <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 text-center" style={{minWidth: "130px"}}>
            //                     <span className="label-style">Loại HV</span>
            //                 </div>

            //                 <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 text-center" style={{minWidth: "100px"}}>
            //                     <span className="label-style">Trạng thái</span>
            //                 </div>

            //                 <div class="col-xs-1 col-sm-1 col-md-1 col-lg-1" style={{minWidth: "40px"}}>
            //                     <span className="label-style pull-right">Actions</span>
            //                 </div>
                        
            //             </div>
            //             {/* one */}
            //             <hr></hr>
            //         </li>    

            //         {/* {this.props.children} */}
            //     </ul>
            //     </div>
            // </div>


            <div style={{width: "100%"}}>
            <div className="scroll_style" style={{paddingBottom: "150px"}}>
            <table className="table datatable-basic ">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Role</th>
                        <th>Loại HV</th>
                        <th>Trạng thái</th>
                        <th className="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {this.props.children}
                </tbody>
            </table>
            </div>
            </div>

        );
    }
}




export default NotificaitonManagerList;
