import React, { Component } from 'react';
import NotificaitonManagerList from './NotificaitonManagerList';
import NotificationManagerItem from './NotificationManagerItem';
import { LogSystem } from '../../log/index'
import CONSTANT from '../../constants/Constant';

class NotitificationApp extends Component {

    onChangeAppManagerStatus = (appManager, indexInUserSubscribed ) => {
        appManager.app = {
            id: this.props.id
        }
        const appIndex = this.props.index;
        this.props.changeManagerStatusInApp(appManager, appIndex, indexInUserSubscribed);
    }

    onRemoveManagerInApp = (id, indexInUserSubscribed ) => {
        const appIndex = this.props.index;
        this.props.removeManagerInApp(id, appIndex, indexInUserSubscribed)
    }


    onEditManger = (detail, indexInUserSubscribed) => {
        const appIndex = this.props.index;
        console.log('NotitificationApp::onEditManger --------------detail-----------------')
        LogSystem.info('detail: ' + JSON.stringify(detail));
        detail.app = {
            id: this.props.id
        }
        this.props.onEditManger(detail, appIndex, indexInUserSubscribed);
    }

    showMangerChildren = (subscribedManagers) => {
        LogSystem.info('Portal::showMangerChildren---------------------');
        LogSystem.info(subscribedManagers);
        if(subscribedManagers !== undefined && subscribedManagers !== null && subscribedManagers.length > 0) {
            var result = [];
            for(let  i = subscribedManagers.length - 1; i >= 0; i--) {
                var _item =  subscribedManagers[i];
                result.push(
                    <NotificationManagerItem
                        key = {i}
                        index = {i}
                        id = {_item.id}
                        userid = {_item.manager.userid}
                        username = {_item.manager.username}
                        serviceType = {_item.manager.serviceType}
                        role={_item.manager.role}
                        studentTypeSupported={_item.studentTypeSupported}
                        status = {_item.status}
                        onChangeAppManagerStatus = {this.onChangeAppManagerStatus}
                        onRemoveManagerInApp={this.onRemoveManagerInApp}
                        onEditManger={this.onEditManger}
                    />
                )
            }
            return result;
        } else {
            return undefined;
            // return <div>&nbsp;&nbsp;&nbsp; Không có người dùng nào được cấp quyền trong app này</div>
        }
    }
    
    showManagerTable = () => {
        let {subscribedManagers} = this.props;
        if(subscribedManagers !== undefined && subscribedManagers !== null && subscribedManagers.length > 0) {
            return <NotificaitonManagerList>
                        {this.showMangerChildren(subscribedManagers)}
                    </NotificaitonManagerList>;
        }
        return <div>&nbsp;&nbsp;&nbsp; Không có người dùng nào được cấp quyền trong app này</div>;
    }

    onViewDetail = () => {

        var appInfo = {
            id: this.props.id,
            appName: this.props.
            appName,
            onesignalAppId: this.props.onesignalAppId,
            restApiKey: this.props.restApiKey,
            iconUrl: this.props.iconUrl,
            privateKey: this.props.privateKey
        }
        this.props.onViewDetail(appInfo)
    }

    onAddNewUser = () => {
        LogSystem.info('NotitificationAppManager::onAddNewUser::keyInArray:: ' + this.props.index);
        this.props.addNewUserToApp(this.props.id, this.props.index);
    }

    onDeleteApp = () => {
        this.props.deleteApp( this.props.index, this.props.id)
    }

    onUpdateApp = () => {

    }

    render() {
        return (
            <div class="panel-group">
                <div class="row panel panel-default">
                    <div class="panel-heading header_inner">
                        <div className="row">
                        <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                            <h4 class="panel-title">
                                <a data-toggle="collapse" style={{textDecoration: "underline", overflowWrap: "break-word"}} href={'#' + this.props.index} >{this.props.appName}</a>
                            </h4>
                        </div>

                        <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
                        
                        </div>

                        <div class="col-xs-1 col-sm-1 col-md-1 col-lg-1">
                 
                            <ul className="icons-list header_button pull-right">
                                <li className="dropdown pull-right">
                                    <div href="#" className="dropdown-toggle" data-toggle="dropdown">
                                        <i className="icon-menu9"></i>
                                    </div>
                                    <ul className="dropdown-menu dropdown-menu-right">
                                        <li><a href={false}  onClick={() => this.onViewDetail()}><i class="icon-file-eye"></i>Xem chi tiết</a></li>
                                        <li><a href={false} onClick={() => this.onAddNewUser()}><i class="icon-user-plus"></i>Thêm User vào App</a></li>
                                        {/* <li><a href={false} onClick={() => this.onUpdateApp()}><i class="icon-wrench2"></i>Chỉnh sửa App</a></li> */}
                                        <li><a href={false} onClick={() => this.onDeleteApp()}><i class="icon-blocked"></i>Xóa</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        </div>
                        
                    </div>
                    <div id={this.props.index} class="panel-collapse collapse" style={{overflowY: "visible"}}>
                    {this.showManagerTable()}
                    </div>
                </div>
            </div>

        );
    }
}




export default NotitificationApp;
