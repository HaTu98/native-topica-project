import React, { Component } from 'react';
import { LogSystem } from '../../log';

class NotificationManagerItem extends Component {

    constructor(props) {
        super(props);
        this.state = {
            id: this.props.id,
            manager: {
                userid: this.props.userid,
                username: this.props.username,
                serviceType: this.props.serviceType,
                role: this.props.role
            },
            studentTypeSupported: this.props.studentTypeSupported,
            status: this.props.status
        }
    }

    onActivated = () => {
        let appManager = this.state;
        appManager.status = "ACTIVE";
        this.props.onChangeAppManagerStatus(appManager, this.props.index)
    }   

    onDeactivated = () => {
        let appManager = this.state;
        appManager.status = "INACTIVE";
        this.props.onChangeAppManagerStatus(appManager,  this.props.index)
    }
    
    onDeleted = () => {
        this.props.onRemoveManagerInApp(this.props.id, this.props.index);
    }

    onClickEditManger = () => {
        LogSystem.info('NotificationManagerItem::onClickEditManger -----------------------');
        this.props.onEditManger(this.state, this.props.index);
    }

    render() {
        return (
            // <li class="list-group-item">
            //     <div className="row mt-10">
            //         <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
            //             <span className="label-style">{this.state.manager.userid}</span>
            //         </div>
            //         <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4" style={{overflowWrap: "break-word"}}>
            //             <span className="label-style">{this.state.manager.username}</span>
            //         </div>

            //         <div class="col-xs-1 col-sm-1 col-md-1 col-lg-1">
            //             <span className="label-style">{this.state.manager.role}</span>
            //         </div>

            //         <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 text-center">
            //             <span className="label-style">{this.state.studentTypeSupported}</span>
            //         </div>

            //         <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 text-center">
            //             <span className="label-style">{this.state.status}</span>
            //         </div>

            //         <div class="col-xs-1 col-sm-1 col-md-1 col-lg-1">
            //             <ul className="icons-list pull-right">
            //                 <li className="dropdown">
            //                     <div href="#" className="dropdown-toggle" data-toggle="dropdown">
            //                         <i className="icon-menu9"></i>
            //                     </div>
            //                     <ul className="dropdown-menu dropdown-menu-right">
            //                         <li className={this.state.status === "ACTIVE" ? "disabled" : ""}><a href={false}  onClick={() => this.onActivated()}><i class="icon-checkmark"></i> Bật để cho phép gửi thông báo </a></li>
            //                         <li className={this.state.status !== "ACTIVE" ? "disabled" : ""}><a href={false} onClick={() => this.onDeactivated()}><i class="icon-blocked"></i> Khóa để không cho phép gửi thông báo </a></li>
            //                         <li ><a href={false} onClick={() => this.onClickEditManger()}><i class="icon-wrench2"></i> Chỉnh sửa tài khoản </a></li>
            //                         <li ><a href={false} onClick={() => this.onDeleted()}><i class="icon-blocked"></i> Xóa tài khoản </a></li>
            //                     </ul>
            //                 </li>
            //             </ul>
            //         </div>
                  
            //     </div>
            //     {/* one */}
            //     <hr></hr>
            // </li>    
              
            
            // <th>ID</th>
            // <th>Username</th>
            // <th>Role</th>
            // <th>Loại HV</th>
            // <th>Trạng thái</th>
            // <th className="text-center">Actions</th>

              <tr>
                <td>{this.state.manager.userid}</td>
                <td style={{overflowWrap: "break-word"}}>{this.state.manager.username}</td>

                <td>{this.state.manager.role}</td>
                <td>{this.state.studentTypeSupported}</td>
                <td>{this.state.status}</td>
                <td className="text-center">
                    <ul className="icons-list">
                        <li className="dropdown">
                            <div href="#" className="dropdown-toggle" data-toggle="dropdown">
                                <i className="icon-menu9"></i>
                            </div>
                            <ul className="dropdown-menu dropdown-menu-right">
                                <li className={this.state.status === "ACTIVE" ? "disabled" : ""}><a href={false}  onClick={() => this.onActivated()}><i class="icon-checkmark"></i> Bật để cho phép gửi thông báo </a></li>
                                <li className={this.state.status !== "ACTIVE" ? "disabled" : ""}><a href={false} onClick={() => this.onDeactivated()}><i class="icon-blocked"></i> Khóa để không cho phép gửi thông báo </a></li>
                                <li ><a href={false} onClick={() => this.onClickEditManger()}><i class="icon-wrench2"></i> Chỉnh sửa tài khoản </a></li>
                                <li ><a href={false} onClick={() => this.onDeleted()}><i class="icon-blocked"></i> Xóa tài khoản </a></li>
                            </ul>
                        </li>
                    </ul>
                </td>
          </tr>  
        );
    }
}




export default NotificationManagerItem;
