import React, { Component } from 'react';
import '../../style/appModal.css'
import { LogSystem } from '../../log/index'
import InputErrorMessage from '../common/InputErrorMessage';
import CONSTANT from '../../constants/Constant';

class NotificaitonAppModal extends Component {
    constructor(props) {
        super(props);
        this.state = {
            id: this.props.appInfo.id,
            appName: this.props.appInfo.appName,
            restApiKey: this.props.appInfo.restApiKey,
            onesignalAppId: this.props.appInfo.onesignalAppId,
            privateKey: this.props.appInfo.privateKey,
            iconUrl: this.props.appInfo.iconUrl,
            appNameError: '',
            restApiError: '',
            onesignalAppIdError: '',
            iconUrlError: '',
           
        }
    }

    onChangeModalShowing = (isShow) => {
        this.props.onChangeModalShowing(isShow);
    }

    componentDidMount() {
        this.appNameInput.focus(); 
        LogSystem.info('NotificaitonAppModal::componentDidMount ' + this.props.mode);
     }

    onChange = (e) => {
        var target = e.target;
        var name = target.name;
        var value = target.type === 'checkbox' ? target.checked : target.value;
        LogSystem.info('NotificaitonAppModal::onChange ');
        LogSystem.info('name: ' + name);
        LogSystem.info('value: _' + value + '_');
        switch(name) {
            case "appName":
                if(!this.isValidAppName(value)) return; 
                break;
            case "onesignalAppId":
                if(!this.isOneSignalAppId(value)) return;
                break;
            case "restApiKey":
                if(!this.isValidRestApiKey(value)) return;
                break;
            case "iconUrl":
                if(!this.isValidIconUrl(value)) return;
                break;
            default:
              break;
          }
        this.setState({
            [name]: value
        });
    }


    isValidIconUrl = (iconUrl) => {
        LogSystem.info("isValidImage::iconUrl " + iconUrl);
        if(iconUrl !== null && !(iconUrl.endsWith('.jpg') || iconUrl.endsWith('.png'))) {
            this.setState({
                    iconUrlError: 'Sai định dạng link ảnh. Bạn vui lòng nhập lại'
                })
            }
        this.setState({
            iconUrlError: ''
        }); 
        return true;
    }

    isValidAppName = (appName) => {
        LogSystem.info("isValidAppName::appName " + appName);
        if(appName.length > CONSTANT.AppManager.AppModal.AppName.MaxLength) {
            this.setState({
                appNameError: CONSTANT.AppManager.AppModal.AppName.errorMessage
            }); 
            return false;
        }
        this.setState({
            appNameError: ''
        }); 
        return true;
    }

    isOneSignalAppId = (param) => {
        if(param.length > CONSTANT.AppManager.AppModal.OneSignalAppId.MaxLength) {
            this.setState({
                onesignalAppIdError: CONSTANT.AppManager.AppModal.OneSignalAppId.errorMessage
            }); 
            return false;
        }
        this.setState({
            onesignalAppIdError: ''
        }); 
        return true;
    }

    isValidRestApiKey = (param) => {
        if(param.length > CONSTANT.AppManager.AppModal.RestApiKey.MaxLength) {
            this.setState({
                restApiError: CONSTANT.AppManager.AppModal.RestApiKey.errorMessage
            }); 
            return false;
        }
        this.setState({
            restApiError: ''
        }); 
        return true;
    }


    validateAppInfor() {
        let {appName, restApiKey, onesignalAppId, iconUrl} = this.state;
        LogSystem.info('AppName: ' + '_' + appName + '_');
        var isValid = true;
        LogSystem.info('iconUrl: ' + '_' + iconUrl + '_');
        if(iconUrl !== null && iconUrl.trim() !== '' && !(iconUrl.trim().endsWith('.jpg') || iconUrl.trim().endsWith('.png'))) {
        this.setState({
                iconUrlError: 'Sai định dạng link ảnh. Bạn vui lòng nhập lại'
            })
            this.restIconUrlInput.focus();
            isValid = false;
        }
        if(restApiKey === undefined || restApiKey === null || restApiKey.trim() === '') {
            this.setState({
                restApiError: 'Trường này là bắt buộc'
            })
            this.restApiKeyInput.focus();
            isValid = false;
        } 
        if(onesignalAppId === undefined || onesignalAppId === null || onesignalAppId.trim() === '') {
            this.setState({
                onesignalAppIdError: 'Trường này là bắt buộc'
            })
            this.oneSignalAppIdInput.focus();
            isValid = false;
        } 
        if(appName === undefined || appName === null || appName.trim() === '') {
            this.setState({
                appNameError: 'Trường này là bắt buộc'
            })
            this.appNameInput.focus();
            isValid = false;
        } 
        return isValid;
    }
    
    onClickSave = () => {
        const {id, appName, restApiKey, onesignalAppId, iconUrl, privateKey} = this.state;
        if(!this.validateAppInfor()) return;
        const appInfor = {
            id,
            appName: (appName === null) ? '' : appName.trim(),
            restApiKey: (restApiKey === null) ? '' :  restApiKey.trim(),
            onesignalAppId: (onesignalAppId === null) ? '' :   onesignalAppId.trim(),
            iconUrl: (iconUrl === null) ? '' :   iconUrl.trim(),
            privateKey:  (privateKey === null) ? '' :   privateKey.trim()
        }
        this.props.onSaveNewNotificationApp(appInfor);
    }

    showModalFooter  = () => {
        LogSystem.info('-----------------------------------------------------');
        LogSystem.info('showModalFooter-----------------------------------------------------');
        LogSystem.info(this.props.appInfo.appName)
        if(this.props.appInfo.appName == null) {
            return(
                <div className="modal-footer">
                    <button type="button" className="btn btn-default" onClick={() => this.onChangeModalShowing(false)} >&nbsp;&nbsp;&nbsp;Hủy&nbsp;&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <button type="button" className="btn btn-primary" onClick={() => this.onClickSave()}>&nbsp;&nbsp;&nbsp;Lưu&nbsp;&nbsp;&nbsp;</button>
                </div>
            )
        } 
    }

    render() {
        return (
            <div className={"modal fade in modal_show"} >
                <div className="modal-dialog ">
                    <div className="modal-content">
                        <div className="modal-header">
                            <button type="button" className="close" style={{fontWeight: 'bold'}}  onClick={() => this.onChangeModalShowing(false)}>X</button>
                            {/* <h4 className="modal-title">Thông tin App</h4> */}
                        </div>
                        <br></br>
                        <div className="modal-body" style={{width: '100%', height: '450px', paddingRight: '30px'}}>
                            <div className="modal-guts">
                                <div className="form-group">
                                    <label htmlFor="appId">App ID:</label>
                                    <input type="text"
                                        class="form-control"
                                        readOnly={true}
                                        id="appId"
                                        value={this.state.id === null ? "" : this.state.id} 
                                        name="id"
                                        ></input>
                                </div>

                                <div className="form-group">
                                    <label htmlFor="appId">Private key:</label>
                                    <input type="text"
                                        class="form-control"
                                        readOnly={true}
                                        id="appId"
                                        value={this.state.privateKey} 
                                        name="privateKey"
                                        ></input>
                                </div>

                                <div className="form-group">
                                    <label htmlFor="appName">Tên app: <span className="text-danger">*</span></label>
                                    <input type="text" 
                                        readOnly={this.props.mode === CONSTANT.AppManager.AppModal.Mode.View ? true : false}
                                        className="form-control"
                                        id="appName"
                                        value={this.state.appName === null ? "" : this.state.appName}
                                        name="appName"
                                        onChange = {this.onChange}
                                        maxLength={CONSTANT.AppManager.AppModal.AppName.maxLength}
                                        ref={(input) => { this.appNameInput = input; }} 
                                        >
                                    </input>
                                    <InputErrorMessage>{this.state.appNameError}</InputErrorMessage>
                                </div>

                                <div className="form-group">
                                    <label htmlFor="onesignalAppId">ONESIGNAL APP ID: <span className="text-danger">*</span></label>
                                    <input type="text"
                                        readOnly={this.props.mode === CONSTANT.AppManager.AppModal.Mode.View ? true : false}
                                        className="form-control"
                                        id="onesignalAppId"
                                        value={this.state.onesignalAppId === null ? "" : this.state.onesignalAppId}
                                        name="onesignalAppId"
                                        maxLength={CONSTANT.AppManager.AppModal.OneSignalAppId.maxLength}
                                        onChange = {this.onChange}
                                        ref={(input) => { this.oneSignalAppIdInput = input; }} 
                                        >
                                    </input>
                                    <InputErrorMessage>{this.state.onesignalAppIdError}</InputErrorMessage>
                                </div>

                                <div className="form-group">
                                    <label htmlFor="restApiKey">REST API KEY: <span className="text-danger">*</span></label>
                                    <input type="text"
                                        readOnly={this.props.mode === CONSTANT.AppManager.AppModal.Mode.View ? true : false}
                                        className="form-control"
                                        id="restApiKey"
                                        value={this.state.restApiKey === null ? "" : this.state.restApiKey }
                                        name="restApiKey"
                                        maxLength={CONSTANT.AppManager.AppModal.RestApiKey.maxLength}
                                        onChange = {this.onChange}
                                        ref={(input) => { this.restApiKeyInput = input; }} 
                                        >
                                    </input>
                                    <InputErrorMessage>{this.state.restApiError}</InputErrorMessage>
                                </div>

                                <div className="form-group">
                                    <label htmlFor="iconUrl">Link icon cho app: </label>
                                    <div class="row">
                                        <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                                        <textarea type="text "
                                            readOnly={this.props.mode === CONSTANT.AppManager.AppModal.Mode.View ? true : false}
                                            rows="6"
                                            className="form-control textarea-fixed-size"
                                            id="iconUrl"
                                            value={this.state.iconUrl === null ? "" : this.state.iconUrl}
                                            name="iconUrl"
                                            onChange = {this.onChange}
                                            ref={(input) => { this.restIconUrlInput = input; }} 
                                            >
                                        </textarea>
                                        
                                        </div>
                                        <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3" style={{marginTop: 0}}>
                                            <div className="preview-avata_inner pull-right">
                                                <img src={this.state.iconUrl === null ? "" : this.state.iconUrl} className="img-responsive"></img>
                                            </div>
                                        </div>
                                    </div>
                                    <InputErrorMessage>{this.state.iconUrlError}</InputErrorMessage>
                                </div>
                            </div>
                        </div>
                        {this.showModalFooter()}
                    </div>
                </div>
            </div>
        );
    }
}

export default NotificaitonAppModal;
