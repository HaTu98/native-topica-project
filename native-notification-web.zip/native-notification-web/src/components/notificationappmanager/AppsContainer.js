import React, { Component } from 'react';
import AppItem from './AppItem';
import { LogSystem } from '../../log/index'
import {Redirect } from 'react-router-dom';
class AppsContainer extends Component {

    renderAppItems = () => {
        var {apps} = this.props;
        LogSystem.info('AppsContainer::renderAppItems::apps-----------------------');
        LogSystem.info(apps);
        if(apps === null || apps.length < 1) {
            LogSystem.info('Console in here --------------------------------------');
            LogSystem.info(apps);
            // return <Redirect to={{ pathname: '/appSubcribeEmpty'}}/>
            return undefined;
        }
        return apps.map((_item, _index) => {
            return <AppItem
                        key={_index}
                        appId = {_item.app.id}
                        iconUrl = {_item.app.iconUrl}
                        appName={_item.app.appName}
                        studentTypeSupported={_item.studentTypeSupported}
                        chooseApp={this.props.chooseApp}
                    />
        })
    }

    render() {
        return (

            <div className="wrapper">
                <div className="wrapper_inner">
                    <div className="row">
                        {this.renderAppItems()}
                    </div>

                </div>

            </div>

        );
    }
}



export default AppsContainer;