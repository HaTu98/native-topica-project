import React, { Component } from 'react';
import swal from 'sweetalert2'
import { LogSystem } from '../../log/index'
import BannerImportReceiversFile from './BannerImportReceiversFile';
import TypeStudentSellection from './TypeStudentSellection';

class BannerInputReceiverTabs extends Component {
	constructor(props) {
		super(props);
		this.state = {
			importedFiles: [],
			tab: this.props.tab
		}
	}

	onTab = (tab) => {
		LogSystem.info('Portal::ontab::tab: ' + tab)
		if(tab === this.props.tab) return;
		swal({
            title: 'Warning',
            text: "Bạn có chắc chắn muốn chuyển cách nhập người nhận?",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Chắc chắn',
			cancelButtonText: 'Hủy'
          }).then((result) => {
			if (result.value) {
				this.props.onChangeTab(tab);
            }
          })
		
	}
	
	showContentOntab = () => {
		var {currentTab} = this.props;
		switch(currentTab) {
			case 0:
				return <BannerImportReceiversFile 
					onChangeReceivers = {this.props.onChangeReceivers}
				/>

            case 1: 
                return <TypeStudentSellection
					onSelelctStudentType={this.props.onSelelctStudentType}
					user={this.props.user}
                    />	
			default:
                return <BannerImportReceiversFile 
                    onChangeReceivers = {this.props.onChangeReceivers}
                />
		}
	}

	showErrorMessage = () => {
		return(<p className="text-danger">{this.props.receiversTabError}</p>)
	}

	render() {
		return (
			<div>
				<ul className="nav nav-tabs">
					{/* <li className={this.props.tab === 0 ? 'active' : ''}><a onClick={() => this.onTab(0)}><b className="text-info">Nhập tay</b></a></li> */}
					<li className={this.props.tab === 0 ? 'active' : ''}><a  onClick={() => this.onTab(0)}><b className="text-danger">Upload file</b></a></li>
					<li className={this.props.tab === 1 ? 'active' : ''}><a  onClick={() => this.onTab(1)}><b className="text-primary">Gửi theo loại học viên </b></a></li>
				</ul>
				<div>
					{this.showContentOntab()}

				</div>
				{this.showErrorMessage()}
			</div>
		);
	}
}

export default BannerInputReceiverTabs;

















