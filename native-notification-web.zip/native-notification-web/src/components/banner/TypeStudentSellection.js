import React, { Component } from 'react';
import { LogSystem } from '../../log';
import { BackupDataManager } from '../../data/BackupDataManager';
class TypeStudentSellection extends Component {

    constructor(props) {
        super(props);
        this.state = {
            studentTypeSupported: null,
        }
    }

    componentDidMount() {
        var studetnAppInfo = JSON.parse(BackupDataManager.getItem("choosenApp"));
        this.setState({
            studentTypeSupported: (studetnAppInfo === null) ? null : studetnAppInfo.studentTypeSupported
        });
    }

    onSelectNotificationType = (e) => {
        LogSystem.info('onSelectNotificationType::e.target.value: ' + e.target.value)
        this.props.onSelelctStudentType(e.target.value); 
    }

    render() {
        return (

                <div className="form-group">
                    <label htmlFor="sel1">Chọn loại học viên</label>
                    <select className="form-control" id="sel1" onChange={this.onSelectNotificationType}>
                        <option value="">-- Chọn loại học viên --</option>
                        {this.state.studentTypeSupported === 'NORMAL' ? undefined : <option value="LMS_VIP">Học viên VIP</option>} 
                        {this.state.studentTypeSupported === 'VIP' ? undefined : <option value="LMS">Học viên thường</option>}
                        <option value="ALL">Tất cả học viên</option>
                    </select>
                </div>

            );
        }
    }
            
            
export default TypeStudentSellection;