import React, { Component } from 'react';
import imageDefault from '../../img/upload-icon-3.png'
// import '../index.css'
import PreviewBox from '../notificationpush/PreviewBox';
import AppConfig from '../../constants/AppConfig'
import { LogSystem } from '../../log/index'
import CONSTANT from '../../constants/Constant';
import ExcelUtil from '../../util/ExcelUtil';
import swal from 'sweetalert2';
import * as ALERT from '../../redux/actions/alertActions'
import { toast } from 'react-toastify';
import EmailValidation from '../../util/EmailValidation';

const TEMPLATE = ["No *", "Student Email *"];
class BannerImportReceiversFile extends Component {

    constructor(props) {
        super(props)
        this.fileInput = React.createRef();
        this.state = {
            importedFiles: null,
            studentEmailList: null
        }
    }

    onRemoveFile = () => {
        swal({
            title: 'Warning',
            text: "Bạn có chắc chắn muốn xóa ?",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Xóa',
            cancelButtonText: 'Hủy',
        }).then((result) => {
            if(result.value) {
                this.setState({
                    importedFiles: null
                });
                this.props.onChangeReceivers(null);
            }
        })
    }

    validateStudentInfo(studentList, cb) {
        var validaStudetnList = new Array();
        var inValidaPersonalInfoList = new Array();
        studentList.map((item) => {
            if(EmailValidation.isEmail(item.studentEmail)) {
                validaStudetnList.push(item.studentEmail);
            } else {
                var errorItem = {
                    ...item, 
                    error: "Không đúng định dạng Email "}
                inValidaPersonalInfoList.push(errorItem);    
            }
        });
        LogSystem.info('validateStudentInfo::validaStudetnList');
        LogSystem.info(validaStudetnList);

        LogSystem.info('validateStudentInfo::inValidaPersonalInfoList');
        LogSystem.info(inValidaPersonalInfoList);
        cb(validaStudetnList, inValidaPersonalInfoList);
    }

    onChange = (e) => {
        e.preventDefault();
        var file = this.fileInput.current.files[0];
        e.target.value = null; 
        if(!ExcelUtil.validateFileSize(file)) return;
        LogSystem.info('onChange::file');
        LogSystem.info(file);
        LogSystem.info('Portal::onChange value: ' + file.name);
        if(!ExcelUtil.validateExtention(file.name)) return;
        ExcelUtil.handleFile(file)
            .then(data => {
                LogSystem.info('handleFile::then');
                LogSystem.info(data);          
                if(!ExcelUtil.validateTemplte(data, TEMPLATE)) return;
                var variablesAndPersonalInfo = ExcelUtil.getStudent(data);
                if(variablesAndPersonalInfo === undefined) return;
                LogSystem.info("variablesAndPersonalInfo ");
                LogSystem.info(variablesAndPersonalInfo.presonalInfos);
                if(!ExcelUtil.validateLength(variablesAndPersonalInfo.presonalInfos)) return;
                //TODO
                this.validateStudentInfo(variablesAndPersonalInfo.presonalInfos, (validaStudetnList, inValidaPersonalInfoList) =>{
                    LogSystem.info('validateStudentInfo::calback');
                    LogSystem.info(data);
                    LogSystem.info('print something in here');
                    this.proccesAfterUploadFile(validaStudetnList, inValidaPersonalInfoList, file.name);
                });
            })
    }

    proccesAfterUploadFile = (validaPersonalInfoList, inValidaPersonalInfoList, fileName) => {
        if(inValidaPersonalInfoList === null || inValidaPersonalInfoList.length < 1) {
            ALERT.showToastAlter("Success", "Tất cả học viên được import thành công", toast.TYPE.SUCCESS);
            this.setState({
                importedFiles: fileName,
                studentEmailList: validaPersonalInfoList
            })
            this.props.onChangeReceivers(validaPersonalInfoList);
            return;
        }
        ExcelUtil.showErrorPopUp(validaPersonalInfoList, inValidaPersonalInfoList, () => {
            LogSystem.info(`showErrorPopUp::Calback::file.name ${fileName}`)
            this.setState({
                importedFiles: fileName,
                studentEmailList: validaPersonalInfoList
            })
            this.props.onChangeReceivers(validaPersonalInfoList);
        })
    }

    dowloadTemlate = () => {
        ExcelUtil.exportTemplate(TEMPLATE);
    }

    render() {
        return (
            <div className="file-field">
                <div className="row">
                    <div className="col-md-6 ">
                        <div className="img-select-block margin-bottom-15 margin-15">
                            <img id="preview-product-img" src={imageDefault} ></img>
                            <input type='file' id="input-select-img-product" ref={this.fileInput} name="file" onChange={this.onChange}/>
                        </div>
                    </div>
                    <div className="col-md-6">
                        <a onClick={() => this.dowloadTemlate()}>
                            <span className="label label-success font-30">&nbsp;&nbsp;&nbsp;&nbsp;dowload template&nbsp;&nbsp;&nbsp;&nbsp;</span>
                        </a>
                    </div>
                </div>
                
                <PreviewBox
                    onRemoveFile = {this.onRemoveFile}
                    importedFiles = {this.state.importedFiles}
                />
            </div>
            );
        }
    }
            
            
export default BannerImportReceiversFile;