import React, { Component } from 'react';
import { LogSystem } from '../../log/index'

class Paginator extends Component {

    constructor(props) {
        super(props);
        LogSystem.info("TotalPage: " + this.props.totalPages);
         LogSystem.info("pageNumber: " + this.props.pageNumber);
    }

    onClickPaginator = (_index) => {
        this.props.onPage(_index);
    }

    renderPaginatorItems = () => {
        LogSystem.info("pageNumber" + this.props.pageNumber);
        let { pageNumber, totalPages } = this.props;
        let paginatorList = [];
        
        var i = 1;
        let startPage = (pageNumber > 5) ? (pageNumber - 2) : 1;
        let endPage = (pageNumber + 2 < totalPages) ? pageNumber + 2 : totalPages;
        if(startPage < 2) {
            paginatorList.push(<li key={0} className="page-item disabled"><span aria-hidden="true">&laquo;</span></li>);    
        } else {
            paginatorList.push(<li key={0} className="page-item" onClick={() => { if(startPage > 1) this.onClickPaginator(startPage - 1)}}><span aria-hidden="true">&laquo;</span></li>);
        }
        for(i = startPage; i <= endPage; i++) {
            const id = i;
            paginatorList.push((this.props.pageNumber === i) ? (<li key={i} className="page-item active"><span className="page-link">{i}</span></li>) : 
                (<li key={i} onClick={() => this.onClickPaginator(id)} className="page-item"><span className="page-link">{i}</span></li>));
        }

        if(endPage === totalPages) {
            paginatorList.push(<li key={i} className="page-item disabled"><span aria-hidden="true">&raquo;</span></li>);
        } else {
            paginatorList.push(<li key={i} className="page-item" onClick={() => this.onClickPaginator(endPage + 1)}><span aria-hidden="true">&raquo;</span></li>);
        }
        return paginatorList;
    };


    render() {
    
        return (                
           <ul className="pagination">
                {this.renderPaginatorItems()}
            </ul> 
        );
    }
}

export default Paginator;
