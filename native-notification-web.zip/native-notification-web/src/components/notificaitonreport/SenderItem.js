import React, { Component } from 'react';
import CONSTANT from '../../constants/Constant';
import { LogSystem } from '../../log/index'

class SenderItem extends Component {

    onClickPlay = (senderId, key) => {
        this.props.restartNotificcation(senderId, key)
    }

    onClickUnschedule = (senderId, key) => {
        this.props.unscheduleNotificcation(senderId, key);
    }

    onClickEdit = (senderId) => {
        LogSystem.info('onClickEdit----ffff------------------------');
        this.props.createNewNotificationFromThis(senderId);
    }

    onClickCancelNotificationWating = (senderId, key)  => {
        LogSystem.info('onClickCancelNotificationWating----------------------------');
        this.props.cancelNotificationWating(senderId, key);
    }

    render() {
        return (
            <tr>
                <td>{this.props.id}</td>
                {(this.props.showField.isShowTitle) ? <td>{this.props.title}</td> : undefined}
                {(this.props.showField.isShowBody) ? <td>{this.props.body}</td> : undefined}
                {(this.props.showField.isShowImgUrl) ? <td>{this.props.imgUrl}</td> : undefined}
                {(this.props.showField.isShowUsernameSender) ? <th>{this.props.usernameSender}</th> : undefined}
                {(this.props.showField.isShowTimeCreated) ? <th>{this.props.timeCreated}</th> : undefined}
                {(this.props.showField.isShowTimeSent) ? <th>{this.props.timeSent}</th> : undefined}
                {(this.props.showField.isShowCronExpression) ? <th>{this.props.cronExpression}</th> : undefined}
                {(this.props.showField.isShowLastFiredTime) ? <th>{this.props.lastFiredTime}</th> : undefined}
                {(this.props.showField.isShowNextFireTime) ? <th>{this.props.nextFireTime}</th> : undefined}
                {(this.props.showField.isShowType) ? <th>{CONSTANT.NotificationType.get(this.props.type)}</th> : undefined}
                {(this.props.showField.isShowStatus) ? <th>{CONSTANT.StatusType.get(this.props.status)}</th> : undefined}
                {(this.props.showField.isShowTimeUpdated) ? <th>{this.props.timeUpdated}</th> : undefined}
                <td className="text-center">
                    <ul className="icons-list" >
                        <li className={this.props.index === 0 || this.props.index === 1 ? "dropdown" : "dropdown dropup" }>
                            <div href="#" className="dropdown-toggle" data-toggle="dropdown">
                                <i className="icon-menu9"></i>
                            </div>
                            <ul className="dropdown-menu dropdown-menu-right" style={{zIndex: 9999}}>
                                    <li className={this.props.type !== "SCHEDULED" ? "disabled" : ""}><a href="#" onClick={() => this.onClickPlay(this.props.id, this.props.index)}><i className="icon-play4"></i> Chaỵ Lịch Trình Gửi</a></li>
                                    <li className={this.props.type !== "SCHEDULED" ? "disabled" : ""}><a href="#" onClick={() => this.onClickUnschedule(this.props.id, this.props.index)}><i className="icon-pause2"></i> Dừng Lịch Trình Gửi</a></li>
                                    <li className={this.props.type !== "PREPLAN" ? "disabled" : ""}><a href="#" onClick={() => this.onClickCancelNotificationWating(this.props.id, this.props.index)}><i className="icon-cancel-circle2"></i> Hủy Gửi Thông Báo Đang Chờ Gửi</a></li>                                  
                            </ul>
                        </li>
                    </ul>
                </td>
            </tr>
        );
    }
}

export default SenderItem;
