import React, { Component } from 'react';
import CONSTANT from '../../constants/Constant';

const defaultTitle = '- - - - - -   Chọn loại thông báo   - - - - - -';

class NotificationTypeSelect extends Component {

    constructor(props) {
        super(props);
        let selectedItemsMap = new Map();
        selectedItemsMap.set('QUICKSEND', false);
        selectedItemsMap.set('PREPLAN', false);
        selectedItemsMap.set('SCHEDULED', false);
        this.state = {
            QUICKSEND: false,
            PREPLAN: false,
            SCHEDULED: false,
            selectedItemsMap: selectedItemsMap
        }
    }

    onChecked = (e) => {
        const { name, checked } = e.target; 
        this.setState({
            [name]: checked
        });
        let selectedItems = [];
        let selectedItemsMap = this.state.selectedItemsMap;
        selectedItemsMap.set(name, checked);
        selectedItemsMap.forEach((value, key, map) => {
            if(value === true) selectedItems.push(key);
        });
        this.props.onChangeNotificaitonType((selectedItems.length === 0) ? null : selectedItems);
    }

    getContentButton = () => {
        let selectedItemsDisplay = '';
        if(this.state.QUICKSEND) { 
            selectedItemsDisplay += ' ' + CONSTANT.NotificationType.get('QUICKSEND') + ' ';
        }
        if(this.state.PREPLAN) {
            selectedItemsDisplay += ((selectedItemsDisplay === '') ? '' : ' - ') + CONSTANT.NotificationType.get('PREPLAN') + ' ';
        }
        if(this.state.SCHEDULED) {
            selectedItemsDisplay += ((selectedItemsDisplay === '') ? '' : ' - ') + CONSTANT.NotificationType.get('SCHEDULED') + ' ';
        }
        return (selectedItemsDisplay === '') ? defaultTitle : selectedItemsDisplay;
    }

    render() {
        return (
            <div className="icons-list">
                <div className="dropdown">
                    <div type="button" className="btn btn-default select-button dropdown-toggle" data-toggle="dropdown">{this.getContentButton()}</div>

                    <div className="dropdown-menu dropdown-menu-left select-box">
                        <form className="select-from">
                            <div className="checkbox">
                                <label><input type="checkbox"
                                    checked={this.state.QUICKSEND}
                                    name="QUICKSEND"
                                    onChange={this.onChecked}
                                />{CONSTANT.NotificationType.get('QUICKSEND')}</label>
                            </div>
                            <div className="checkbox">
                                <label><input type="checkbox"
                                    checked={this.state.PREPLAN}
                                    name="PREPLAN"
                                    onChange={this.onChecked}
                                />{CONSTANT.NotificationType.get('PREPLAN')}</label>
                            </div>
                            <div className="checkbox">
                                <label><input type="checkbox"
                                    checked={this.state.SCHEDULED}
                                    name="SCHEDULED"
                                    onChange={this.onChecked}
                                />{CONSTANT.NotificationType.get('SCHEDULED')}</label>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        );
    }
}

export default NotificationTypeSelect;
