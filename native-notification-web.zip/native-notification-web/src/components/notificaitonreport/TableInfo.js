import React, { Component } from 'react';

class TableInfo extends Component {

    // constructor(props) {
    //     super(props);
    // };

    // render() {
    //     return (                
    //         (this.props.totalRow > 0) ? <span>&nbsp;&nbsp;&nbsp;&nbsp;Show {this.props.fromRow} to {this.props.toRow}  of {this.props.totalRow} entries</span> : ""           
    //     );
    // }

    render() {
        return (                
            (this.props.totalRow > 0) ? <span>&nbsp;&nbsp;&nbsp;&nbsp; There are {this.props.totalRow} entries</span> : ""           
        );
    }
}

export default TableInfo;