import React, { Component } from 'react';
import SenderItem from './SenderItem';
import '../../style/notificationReport.css'

class TableRender extends Component {

  

    render() {
        return (
            <div style={{width: "100%"}}>
                <div className="scroll_style">
                <table className="table datatable-basic ">
                    <thead>
                        <tr>
                            <th>ID</th>
                            {(this.props.showField.isShowTitle) ? <th className="col-xs-3 col-sm-3 col-md-3 col-lg-3">Tiêu đề</th> : undefined}
                            {(this.props.showField.isShowBody) ? <th className="col-xs-3 col-sm-3 col-md-3 col-lg-3">Nội dung</th> : undefined}
                            {(this.props.showField.isShowImgUrl) ? <th>Ảnh đính kèm</th> : undefined}
                            {(this.props.showField.isShowUsernameSender) ? <th>Người gửi</th> : undefined}
                            {(this.props.showField.isShowTimeCreated) ? <th>Ngày tạo</th> : undefined}
                            {(this.props.showField.isShowTimeSent) ? <th>Thời gian gửi</th> : undefined}
                            {(this.props.showField.isShowCronExpression) ? <th>Cron Expression</th> : undefined}
                            {(this.props.showField.isShowLastFiredTime) ? <th>Thời gian gửi gần nhất</th> : undefined}
                            {(this.props.showField.isShowNextFireTime) ? <th>Thời gian gửi tiếp theo</th> : undefined}
                            {(this.props.showField.isShowType) ? <th>Loại thông báo</th> : undefined}
                            {(this.props.showField.isShowStatus) ? <th>Trạng thái</th> : undefined}
                            {(this.props.showField.isShowTimeUpdated) ? <th>Ngày cập nhật</th> : undefined}
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.props.children}
                    </tbody>
                </table>
                </div>
            </div>
        );
    }
}

export default TableRender;
