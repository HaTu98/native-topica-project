import React, { Component } from 'react';
import TableRender from './TableRender';
import TableInfo from './TableInfo';
import Paginator from './Paginator';
import SenderItem from './SenderItem';
import TableFieldsShowing from './TableFieldsShowing';
import { LogSystem } from '../../log/index'
import '../../style/notificationReport.css'

class DataRenderingBox extends Component {

    constructor(props) {
        super(props);
        this.state = {
            orderBy: this.props.paginable.orderBy,
            direction: this.props.paginable.direction,
            number: this.props.paginable.number,
            size: this.props.paginable.size,
            showField: {
                isShowUsernameSender: true,
                isShowTimeSent: false,
                isShowTimeCreated: false,
                isShowTimeUpdated: false,
                isShowTitle: true,
                isShowBody: false,
                isShowImgUrl: false,
                isShowCronExpression: false,
                isShowStatus: true,
                isShowType: true,  
                isShowLastFiredTime: false,
                isShowNextFireTime: false
            }
        }
    }


    componentDidMount() {
        // LogSystem.info('Portall::DataRenderingBox::componentDidMount-------------------------------------------')
        // this.props.searhNotificationSenders(this.state);
    }

    onChangeShowingFeilds = (showField) => {
        this.setState({
            showField
        })
    }

    getBeginRow = () => {
        return this.props.dataTable.pageSize * (this.props.dataTable.pageNumber - 1) + 1;
    }


    getLastRow = () => {
        return Math.min((this.props.dataTable.pageSize * this.props.dataTable.pageNumber),
            this.props.dataTable.total);

    }

    getTotalPages = () => {
        let value = Math.ceil(this.props.dataTable.total / this.props.dataTable.pageSize);
        LogSystem.info("totalPage: " + value);
        return value;
    }

    getTotalRow = () => {
        LogSystem.info("JobDetailTable totalRow: " + this.props.dataTable.total);
        return this.props.dataTable.total;
    }

    getData = () => {
        LogSystem.info("getData " + this.props.dataTable.data);
        return this.props.dataTable.data;
    }

    onHandleTestData = () => {
        this.props.onTestButton();
    }

    onPage = (number) => {
        LogSystem.info('number: ' + number);
        this.setState({
            number: number,
        })
        this.props.onChangePaginale({
            orderBy: this.state.orderBy,
            direction: this.state.direction,
            number: number,
            size: this.state.size
        });
    }


    onSelectSize = (e) => {
        LogSystem.info(e.target.name);
        LogSystem.info(e.target.value);
        this.setState({
            size: e.target.value,
            number: 1
        })
        this.props.onChangePaginale({
            orderBy: this.state.orderBy,
            direction: this.state.direction,
            number: 1,
            size: e.target.value
        });
    }

    renderDataItems = () => {
        LogSystem.info('Portal::renderDateItems------vvv----------------')
        LogSystem.info('sendersData:');
        LogSystem.info(this.props.sendersData)
        // LogSystem.info(this.props.content);
        var result;
        var { content } = this.props;
        if (content !== undefined && content.length > 0) {
            result = content.map((_item, _index) => {
                return (
                    <SenderItem
                        key={_index}
                        index = {_index}
                        id={_item.id}
                        title={(_item.content !== null) ? _item.content.title : ''}
                        body={(_item.content !== null) ? _item.content.body : ''}
                        imgUrl={(_item.content !== null && _item.content.imgUrl !== null && _item.content.imgUrl !== 'null') ? <a className="underline-text" href={_item.content.imgUrl} target="_blank">link ảnh đính kèm</a> : ''}
                        timeCreated={_item.timeCreated}
                        timeSent={_item.timeSent}
                        cronExpression={_item.cronExpression}
                        type={_item.type}
                        status={_item.status}
                        usernameSender={_item.usernameSender}
                        lastFiredTime={_item.lastFiredTime}
                        nextFireTime={_item.nextFireTime}
                        timeUpdated={_item.timeUpdated}
                        showField={this.state.showField}
                        unscheduleNotificcation={this.props.unscheduleNotificcation}
                        restartNotificcation={this.props.restartNotificcation}
                        cancelNotificationWating={this.props.cancelNotificationWating}
                        createNewNotificationFromThis={this.props.createNewNotificationFromThis}
                    />
                )
            });
            return result;
        }
        return <h3 className="text-danger">Không có kết quả nào phù hợp</h3>
    }


    render() {

        return (

            <div className="panel panel-flat">
                <div className="panel-heading">
                    <h5 className="panel-title">Danh Sách Thông Báo</h5>
                    <div className="top_right_box">   
                        <div className="row">
                            <div className="pull-right">
                                <TableFieldsShowing 
                                    showField = {this.state.showField}
                                    renderRow={this.props.renderRow}
                                    onChangeShowingFeilds = {this.onChangeShowingFeilds}
                                />
                            </div>   
                            <div className="pull-left">
                                <select className="form-control" id="sel1" 
                                        value={this.props.paginable.size}
                                        name="size" onChange={this.onSelectSize}>
                                    <option value="20">20</option>
                                    <option value="50">50</option>
                                    <option value="100">100</option>
                                </select>
                            </div> 
                        </div>
                    </div>
                </div>
        
                <TableRender 
                    showField = {this.state.showField}>
                    
                    {this.renderDataItems()}
                </TableRender>
                <div className="row">
                    <div className="pull-left margin-25">
                        <TableInfo fromRow={1}
                            toRow={3}
                            totalRow={this.props.totalElements} />
                    </div>
                    <div className="pull-right paginator-margin">
                        <Paginator pageNumber={this.props.number + 1}
                            totalPages={this.props.totalPages}
                            onPage={this.onPage} />
                    </div>
                </div>
                 
                </div>
             
                );
            }
        }
        

export default  DataRenderingBox;