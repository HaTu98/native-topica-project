import React, { Component} from 'react';
    import Datetime from 'react-datetime';
import NotificationTypeSelect from './NotificationTypeSelect';
import NotificaitonStatusSelect from './NotificaitonStatusSelect';
import InputErrorMessage from '../common/InputErrorMessage';
import { constants } from 'os';
import CONSTANT from '../../constants/Constant';
import { LogSystem } from '../../log/index'
import NotiDateTimePicker from '../common/NotiDateTimePicker';

var minSentTo = null;
var validSentTo = function( current ){
    if(minSentTo === null) return true;
    return current.isAfter( minSentTo );
};

var maxSentFrom = Datetime.moment();
var validSentFrom = function( current ){
    if(maxSentFrom === null) current.isBefore( Datetime.moment() );
    return current.isBefore( maxSentFrom );
};


class SearchBox extends Component {

    constructor(props) {
        super(props);
        this.state = {
            usernameSender: null,
            statuses: null,
            types: null,
            sentFrom: null,
            sentTo: null,
            search: null,
            usernameSenderError: null,
            validSentFrom: null,
        }
    }

    onChangeUsernameSender = (e) => {
        this.setState({
            usernameSenderError: ''
        })
        LogSystem.info('Portal::onBlurUsernameSentFrom ');
        LogSystem.info('Portal::onBlurUsernameSentFrom name: ' + e.target.value.trim());
        let sender = e.target.value.trim();
        if(CONSTANT.TopicaUsename_Regrex.test(sender)) {
            this.setState({
                usernameSender: sender + '@topica.edu.vn'
            })
        } else if(sender.search(/@/i) !== -1  &&  CONSTANT.TopicaEmail_Regrex.test(sender)) {
            this.setState({
                usernameSender: sender
            })
        } else if(sender === null || sender === '') {
            this.setState({
                usernameSender: null
            })
        } else {
            this.setState({
                usernameSenderError: 'Không phải định dạng usename hoặc email của topica'
            })
        }
    }

    onBlur = (e) => {
        LogSystem.info('Portal::onBlur ');
        LogSystem.info('Portal::onBlur name: ' + e.target.name);
        LogSystem.info('Portal::onBlur value: ' + ((e.target.type === 'checkbox') ? e.target.checked : e.target.value));
        var target = e.target;
        var name = target.name;
        var value = target.type === 'checkbox' ? target.checked : target.value;
        this.setState({
            [name]: (value === '') ? null : value
        });
    }

    onChangeSelect = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        });
    }

    onPressSeach = () => {
        const seachInfo = {
            usernameSender: this.state.usernameSender,
            statuses: this.state.statuses,
            types: this.state.types,
            sentFrom: this.state.sentFrom,
            sentTo: this.state.sentTo,
            search: this.state.search,
        }
        this.props.onSearch(seachInfo);
    }

    onChangeNotificaitonType = (types) => {
        this.setState({
            types
        })
    }

    onBlurOfDateTime = (e) => {
        LogSystem.info('Portal::onBlurOfPrePlan date: ');
        LogSystem.info(e);
    }

    validSentoFunc = function( current ){
        if(this !== undefined && this.state !== undefined) {
            if(this.state.sentFrom !== null) {
                return current.isAfter(new Date(this.state.sentFrom));
            } 
        }
        return null;
    };

    

    onChangeSentFrom = (date) => {
        LogSystem.info('Portal::onChangeSentFrom date: ' + date * 1);
        this.setState({
            sentFrom: (date === undefined) ? null : date * 1,
            validSentFrom:  date
        })
        if(date !== undefined && date !== null && date !== "") {
            minSentTo = date.subtract(1, 'day' );
        } else {
            minSentTo = null;
        }
    }

    onChangeSentTo = (date) => {
        LogSystem.info('Portal::onChangeSentTo date: ' + date);
        
        this.setState({
            sentTo:  (date === undefined || date === null || date === "") ? null : date * 1 + 86400000,
        })

        if(date !== undefined && date !== null && date !== "") {
            maxSentFrom = date.add(1, 'day');
        } else {
            maxSentFrom = Datetime.moment();
        }
        
    }

    clearSentTo = () => {
        this.setState({
            sentTo: null
        })
    }

    clearSentFrom = () => {
        this.setState({
            sentFrom: null
        })
    }

    render() {
        return (
            <div className="panel panel-flat">
                <div className="panel-heading">
                    <h5 className="panel-title">Tìm kiếm</h5>
                </div>
              
                <div className="panel-body">
                    <div className="row form-group">
                        <div className="col-md-6 col-xs-12">
                            <span>Loại thông báo </span>
                            <NotificationTypeSelect
                                onChangeNotificaitonType = {this.onChangeNotificaitonType}
                            />
                        </div>

                        <div className="col-md-6 col-xs-12">
                            <span>Trạng thái </span>
                            <NotificaitonStatusSelect
                                onBlur={this.onBlur}
                            />
                        </div>
                    </div>
                    <div className="row form-group">
                        <div className="col-md-3 col-xs-12">
                            <span>Người gửi: </span>
                            <input id="search_input_student" type="text" className="form-control"
                                autoFocus={true}
                                name="usernameSender"
                                onChange={this.onChangeUsernameSender}
                                placeholder="Nhập username hoặc email người gửi" />
                                 <InputErrorMessage>{this.state.usernameSenderError}</InputErrorMessage>
                        </div>
                       

                        <div className="col-md-3 col-xs-12">
                            <span>Tìm kiếm: </span>
                            <input id="search_input_student" type="text" className="form-control"
                                name="search"
                                onBlur={this.onBlur}
                                placeholder="Tìm kiếm theo ID, Tiêu đề, Nội dung" />
                        </div>

                        <div className="col-md-3 col-xs-12">
                            <span>Ngày tạo từ: </span>
                            <div className="picker_wrapper" >
                            <Datetime
                                id="sentFrom"
                                name="sentFrom"
                                value={this.state.sentFrom}
                                onChange={this.onChangeSentFrom}
                                dateFormat="DD-MM-YYYY"
                                closeOnSelect={true}
                                timeFormat={false}
                                isValidDate={validSentFrom}
                                inputProps={{readOnly: "true"}}
                            />
                            {(this.state.sentFrom === null) ? undefined : <button className="picker_clear_button" onClick={() => this.clearSentFrom()}><i className="icon-cross2"></i></button> } 
                            </div>
                            {/* <NotiDateTimePicker/> */}
                        </div>

                        <div className="col-md-3 col-xs-12">
                            <span>Ngày tạo đến </span>
                            <div className="picker_wrapper" >
                            <Datetime
                                id="sendTo"
                                name="sendTo"
                                dateFormat="DD-MM-YYYY"
                                onChange={this.onChangeSentTo}
                                closeOnSelect={true}
                                isValidDate={validSentTo}
                                value={this.state.sentTo}
                                timeFormat={false}
                                inputProps={{readOnly: "true"}}
                            />
                            {(this.state.sentTo === null) ? undefined : <button className="picker_clear_button" onClick={() => this.clearSentTo()}><i className="icon-cross2"></i></button> } 
                            </div>

                        </div>
                    </div>

                    <div className="row text-right">
                        <button id="btn-filter" type="submit"
                            className="btn btn-primary btn-filter"
                            onClick={() => this.onPressSeach()}
                        >Search <i
                            className="icon-arrow-right14 position-right"></i></button>
                    </div>

                </div>
            </div>
        );
    }
}

export default SearchBox;
