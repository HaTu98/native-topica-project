import React, { Component } from 'react';
import CONSTANT from '../../constants/Constant';

const defaultTitle = '- - - - - -   Chọn trạng thái   - - - - - -';

class NotificaitonStatusSelect extends Component {

    constructor(props) {
        super(props);
        let selectedItemsMap = new Map();
        selectedItemsMap.set('SUCCESS', false);
        selectedItemsMap.set('FAIL', false);
        selectedItemsMap.set('SCHEDULED', false);
        selectedItemsMap.set('UNSCHEDULED', false);
        selectedItemsMap.set('WAITE_SENDING', false);
        selectedItemsMap.set('CANCEL', false);
        this.state = {
            SUCCESS: false,
            FAIL: false,
            SCHEDULED: false,
            UNSCHEDULED: false,
            WAITE_SENDING: false,
            CANCEL: false,
            selectedItemsMap: selectedItemsMap
        }
    }

    onChecked = (e) => {
        const { name, checked } = e.target; 
        this.setState({
            [name]: checked
        });
        let selectedItems = [];
        let selectedItemsMap = this.state.selectedItemsMap;
        selectedItemsMap.set(name, checked);
        selectedItemsMap.forEach((value, key, map) => {
            if(value === true) selectedItems.push(key);
        });
        this.props.onBlur( {
            target: {   
                name: 'statuses', 
                value: (selectedItems.length === 0) ? null : selectedItems
            }
        });
    }

    getContentButton = () => {
        let selectedItemsDisplay = '';
        if(this.state.SUCCESS) { 
            selectedItemsDisplay += CONSTANT.StatusType.get('SUCCESS') + ' ';
        }
        if(this.state.FAIL) {
            selectedItemsDisplay += ((selectedItemsDisplay === '') ? '' : ' - ') + CONSTANT.StatusType.get('FAIL') + ' ';
        }
        if(this.state.SCHEDULED) {
            selectedItemsDisplay += ((selectedItemsDisplay === '') ? '' : ' - ') + CONSTANT.StatusType.get('SCHEDULED') + ' ';
        }
        if(this.state.UNSCHEDULED) {
            selectedItemsDisplay += ((selectedItemsDisplay === '') ? '' : ' - ') + CONSTANT.StatusType.get('UNSCHEDULED') + ' ';
        }
        if(this.state.WAITE_SENDING) {
            selectedItemsDisplay += ((selectedItemsDisplay === '') ? '' : ' - ') + CONSTANT.StatusType.get('WAITE_SENDING') + ' ';
        }
        if(this.state.CANCEL) {
            selectedItemsDisplay += ((selectedItemsDisplay === '') ? '' : ' - ') + CONSTANT.StatusType.get('CANCEL') + ' ';
        }
        // this.props.onChangeNotificaitonType((selectedItems.length < 1) ? null : selectedItems);
        return (selectedItemsDisplay === '') ? defaultTitle : selectedItemsDisplay;
    }

    render() {
        return (
            <div className="icons-list">
                <div className="dropdown">
                    <div type="button" className="btn btn-default select-button dropdown-toggle" data-toggle="dropdown">{this.getContentButton()}</div>

                    <div className="dropdown-menu dropdown-menu-left select-box">
                        <form className="select-from">
                            <div className="checkbox">
                                <label><input type="checkbox"
                                    checked={this.state.SUCCESS}
                                    name="SUCCESS"
                                    onChange={this.onChecked}
                                />{CONSTANT.StatusType.get('SUCCESS')}</label>
                            </div>
                            <div className="checkbox">
                                <label><input type="checkbox"
                                    checked={this.state.FAIL}
                                    name="FAIL"
                                    onChange={this.onChecked}
                                />{CONSTANT.StatusType.get('FAIL')}</label>
                            </div>
                            <div className="checkbox">
                                <label><input type="checkbox"
                                    checked={this.state.SCHEDULED}
                                    name="SCHEDULED"
                                    onChange={this.onChecked}
                                />{CONSTANT.StatusType.get('SCHEDULED')}</label>
                            </div>
                            <div className="checkbox">
                                <label><input type="checkbox"
                                    checked={this.state.UNSCHEDULED}
                                    name="UNSCHEDULED"
                                    onChange={this.onChecked}
                                />{CONSTANT.StatusType.get('UNSCHEDULED')}</label>
                            </div>
                            <div className="checkbox">
                                <label><input type="checkbox"
                                    checked={this.state.WAITE_SENDING}
                                    name="WAITE_SENDING"
                                    onChange={this.onChecked}
                                />{CONSTANT.StatusType.get('WAITE_SENDING')}</label>
                            </div>
                            <div className="checkbox">
                                <label><input type="checkbox"
                                    checked={this.state.CANCEL}
                                    name="CANCEL"
                                    onChange={this.onChecked}
                                />{CONSTANT.StatusType.get('CANCEL')}</label>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        );
    }
}

export default NotificaitonStatusSelect;
