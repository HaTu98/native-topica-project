import React, { Component } from 'react';
import { LogSystem } from '../../log/index'


class TableFieldsShowing extends Component {
    
    constructor(props) {
        super(props);
        this.state = this.props.showField;
    }

    // componentWillUnmount() {
        
    // }
    onClickShowingFields = () => {
        this.props.onChangeShowingFeilds(this.state);
    }

    onChecked = (e) => {
        const { name, checked } = e.target; 
        LogSystem.info('Portal::onChange ');
        LogSystem.info('Portal::onChange name: ' + e.target.name);
        LogSystem.info('Portal::onChange value: ' +  e.target.checked);     
        this.setState({
            [name]: checked
        });
    }
    
    render() {
        return (
            <ul className="icons-list">
                <li className="dropdown">
                    <button type="button" className="btn btn-primary dropdown-toggle" data-toggle="dropdown">Chọn các trường cho bảng</button>

                    <ul className="dropdown-menu dropdown-menu-right">
                        <form className="select-from">
                            <div className="checkbox">
                                <label><input type="checkbox" 
                                                checked={this.state.isShowTitle}
                                                name="isShowTitle" 
                                                onChange = {this.onChecked}
                                />Tiêu đề</label>
                            </div>
                            <div className="checkbox">
                                <label><input type="checkbox" 
                                                checked={this.state.isShowBody} 
                                                name="isShowBody"
                                                onChange = {this.onChecked}
                                                />Nội dung</label>
                            </div>
                            {this.props.renderRow.imgAttached === true ? 
                            <div className="checkbox">
                                <label><input type="checkbox" 
                                                checked={this.state.isShowImgUrl} 
                                                name="isShowImgUrl"
                                                onChange = {this.onChecked}
                                                />Ảnh đính kèm</label>
                                
                            </div>
                            : undefined }
                            <div className="checkbox">
                                <label><input type="checkbox" 
                                                checked={this.state.isShowUsernameSender}
                                                name="isShowUsernameSender" 
                                                onChange = {this.onChecked}
                                                />Người gửi</label>
                            </div>
                            <div className="checkbox">
                                <label><input type="checkbox" 
                                                checked={this.state.isShowTimeCreated}
                                                name="isShowTimeCreated" 
                                                onChange = {this.onChecked}
                                                />Ngày tạo</label>
                            </div>
                            <div className="checkbox">
                                <label><input type="checkbox" 
                                                checked={this.state.isShowTimeSent}
                                                name="isShowTimeSent" 
                                                onChange = {this.onChecked}
                                                />Ngày gửi</label>
                            </div>
                            <div className="checkbox">
                                <label><input type="checkbox" 
                                                checked={this.state.isShowCronExpression}
                                                name="isShowCronExpression"
                                                onChange = {this.onChecked}
                                                />Cron Expression</label>
                            </div>
                            <div className="checkbox">
                                <label><input type="checkbox" 
                                                checked={this.state.isShowLastFiredTime} 
                                                name="isShowLastFiredTime"
                                                onChange = {this.onChecked}
                                                />Thời gian gửi gần nhất</label>
                            </div>
                            <div className="checkbox">
                                <label><input type="checkbox" 
                                                checked={this.state.isShowNextFireTime}
                                                name="isShowNextFireTime"
                                                onChange = {this.onChecked}
                                                />Thời gian gửi tiếp theo</label>
                            </div>
                            <div className="checkbox">
                                <label><input type="checkbox" 
                                              checked={this.state.isShowType} 
                                              name="isShowType"
                                              onChange = {this.onChecked}
                                              />Loại thông báo</label>
                            </div>
                            <div className="checkbox">
                                <label><input type="checkbox" 
                                              checked={this.state.isShowStatus}
                                              name="isShowStatus"
                                              onChange = {this.onChecked}
                                              />Trạng thái</label>
                            </div>
                            <div className="checkbox">
                                <label><input type="checkbox" 
                                                checked={this.state.isShowTimeUpdated}
                                                name="isShowTimeUpdated" 
                                                onChange = {this.onChecked}
                                                />Ngày cập nhật</label>
                            </div>
                            {/* <div className="checkbox disabled">
                                <label><input type="checkbox" 
                                                disabled={true}
                                                checked="" 
                                                onChange = {this.onChecked}
                                                />Tất cả</label>
                            </div> */}

                        </form>
                        <div className="text-center">
                            <button type="button" className="btn btn-primary"
                                onClick = {() => this.onClickShowingFields()}
                                >Apply</button>
                        </div>
                    </ul>
                </li>

                
                
                

            </ul> 
        );
    }
}



export default TableFieldsShowing;
