import React, { Component } from 'react';
import '../../style/inputag.css'
import { WithContext as ReactTags } from 'react-tag-input';
import CONSTANT from '../../constants/Constant';
import { LogSystem } from '../../log/index'

class InputReceivers extends Component {
    constructor(props) {
        super(props);

        this.state = {
            receivers: [],
            error: undefined
        };
        this.handleDelete = this.handleDelete.bind(this);
        this.handleAddition = this.handleAddition.bind(this);
    }

    handleDelete(i) {
        const { receivers } = this.state;
        const newReceivers = receivers.filter((receiver, index) => index !== i);
        this.setState({
            receivers: newReceivers
        });
        this.props.onChangeReceivers(newReceivers.map((item) => {
            return item.text;
        }))
    }

    componentDidMount() {
        let usernameReceivedList = this.props.usernameReceivedList;
        LogSystem.info('Chay vao day xem nao')
        LogSystem.info(usernameReceivedList);
        var receivers = [];
        if(usernameReceivedList !== undefined && usernameReceivedList  !== null 
                && usernameReceivedList.size > 0) {
            usernameReceivedList.map((_item, _index) => {
                receivers.push({
                    id: _index + 1,
                    text: _item
                })
            })
            this.setState({ receivers })
        }
        
    }

    componentWillReceiveProps(newPorp) {
        if(this.props.editMode === true) {
            let usernameReceivedList = newPorp.usernameReceivedList;
            LogSystem.info('Chay vao day xem nao')
            LogSystem.info(usernameReceivedList);
            var receivers = [];
            usernameReceivedList.map((_item, _index) => {
                receivers.push({
                    id: _index + 1,
                    text: _item
                })
            })
            this.setState({ receivers })
        }
    }

    _validateReceiver = (_receiver) => {
        if (!CONSTANT.Email_Regrex.test(_receiver)) {
            this.setState({
                error: 'không đúng định dạng email'
            })
            //showToastAlter('Error', 'Username: ' + _receiver + ' không đúng định dạng emmail', toast.TYPE.ERROR);
            return false;
        }
        this.setState({
            error: undefined
        })
        return true;
    }

    _showValidateMessage = () => {
        if (this.state.error !== undefined) {
            return (<p className="text-danger">{this.state.error}</p>)
        }
    }

    handleInputChange = (receiver) => {
        this.setState({
            error: undefined
        })
        this.props.onEnteringReceivers()
    }

    handleAddition(receiver) {
        LogSystem.info('receiver: ' + receiver);
        if (!this._validateReceiver(receiver.text)) {
            return;
        }
        var receiverInstead = {
            id: receiver.id,
            text: receiver.text.toLowerCase()
        }
        const newReceivers = [...this.state.receivers, receiverInstead];
        this.setState({
            receivers: newReceivers
        });
        this.props.onChangeReceivers(newReceivers.map((item) => {
            return item.text;
        }))
        LogSystem.info('receivers:')
        LogSystem.info(newReceivers)
    }

    handleInputBlur = (receiver) => {
        LogSystem.info('handleInputBlur --------------------')
        LogSystem.info(receiver)
        // receiver = receiver.toLowerCase();
        // if (!this._validateReceiver(receiver)) {
        //     return;
        // }
        // // if(this.state.receivers === undefined || this.state.receivers === null) {  
        // //     receiverItem = {
        // //         id: '0',
        // //         text: receiver
        // //     }
        // // }
        // LogSystem.info('this.state.receivers.length :' + this.state.receivers.length);
        // var receiverItem = {
        //     id: receiver,
        //     text: receiver
        // }
        // const newReceivers = [...this.state.receivers, receiverItem];
        // this.setState({
        //     receivers: newReceivers
        // });
        // this.props.onChangeReceivers(newReceivers.map((item) => {
        //     return item.text;
        // }))
        
    }

    render() {
        const { receivers, suggestions } = this.state;
        return (
            <div>
                <ReactTags
                    tags={receivers}
                    handleDelete={this.handleDelete}
                    handleAddition={this.handleAddition}
                    handleInputChange={this.handleInputChange}
                    handleInputBlur={this.handleInputBlur}
                    placeholder="Nhập HV kết thúc bằng Enter"
                // handleDrag={this.handleDrag}
                // handleTagClick={this.handleTagClick}
                />
                {this._showValidateMessage()}
            </div>
        );
    }
}

export default InputReceivers;