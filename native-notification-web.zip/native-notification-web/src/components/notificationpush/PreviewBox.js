import React, { Component } from 'react';
import PreviewItem from './PreviewItem';
import { LogSystem } from '../../log/index'

class PreviewBox extends Component {

   
    onRemove = (_index) => {
        this.props.onRemoveFile();
    }

    showPreviewItems = (fileName) => {
        LogSystem.info('showPreviewItems');
        LogSystem.info(fileName);    
        if(fileName === undefined || fileName === null) return null;
        return <PreviewItem
                    fileName = {fileName}
                    onRemove = {this.onRemove}
                />
         
        }

    render() {
        return ( 
            <ol>
                {this.showPreviewItems(this.props.importedFiles)}
            </ol>
        );
    }
}
                        
export default PreviewBox;