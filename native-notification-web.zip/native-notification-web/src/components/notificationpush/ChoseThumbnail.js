import React, { Component } from 'react';
import LogSystem  from '../../log/LogSystem';
import  '../../style/thumbnail.css'


class ChoseThumbnail extends Component {
  
    constructor(props) {
        super(props);
        this.state = {
            thumbnail: ''
        }
    }

    // componentWillReceiveProps(newProps) {
    //     console.log('componentWillReceiveProps');
    //     console.log(newProps);
    // }

   generateImageOptionList = () => {
        var {imageList} = this.props;
        if(imageList === null || imageList.length < 1) { 
            return result;
        }
        var result = imageList.map((item, index) => {
            return <option value={item}>{`Bức ảnh thứ ${index + 1}`}</option>
        })
        return result;
   }


    onSelectThumbnail = (e) => {
        LogSystem.info('onSelectThumbnail: ' + e.target.value);  
        this.setState({
            thumbnail: e.target.value
        });
        this.props.onChoseThumbnail(e.target.value);
    }

    render() {

        return (
            <div className="thumbnail_container">
                <select className="form-control"
                    onChange={this.onSelectThumbnail}
                    name="thumbnail">
                    <option value=''>--Chọn Thumbnail ---</option>
                    {this.generateImageOptionList()}
                </select>

                <div className="thumbnail_inner">
                    <img className="img-responsive" src={this.state.thumbnail}></img>
                </div>
            </div>
            
        )
    }
      
}

           
export default ChoseThumbnail;