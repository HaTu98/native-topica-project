import React, { Component } from 'react';
// import CKEditor from "react-ckeditor-component";

import { Editor } from 'react-draft-wysiwyg';
import 'react-draft-wysiwyg/dist/react-draft-wysiwyg.css';
import { EditorState , convertToRaw  } from 'draft-js';
import draftToHtml from 'draftjs-to-html';
import '../../style/editor.css';
import LogSystem  from '../../log/LogSystem';

const xhr = new XMLHttpRequest();
var parser = new DOMParser();
var doc = parser.parseFromString('', "text/html");


class EditorContent extends Component {
  
    constructor(props) {
        super(props);
        this.state = {
            editorState: EditorState.createEmpty(),
            imageList: []
        };
    }

    uploadImageCallBack = (file) => {
        return new Promise(
          (resolve, reject) => {
            xhr.open('POST', 'https://api.imgur.com/3/image');
            xhr.setRequestHeader('Authorization', 'Bearer 1db50e52745884d924b695cf33b73b133b4f9fe5');
            const data = new FormData();
            data.append('image', file);
            xhr.send(data);
            xhr.addEventListener('load', () => {
              const response = JSON.parse(xhr.responseText);
              resolve(response);
              console.log('uploadImageCallBack::response------------------------');
              console.log(response);
            });
            xhr.addEventListener('error', () => {
              const error = JSON.parse(xhr.responseText);
              reject(error);
            });
          }
        );
      }
    getImgUrlsInBodyHtml = (bodyHtml) => {
      return new Promise((resolve, reject) => {
        doc = parser.parseFromString(bodyHtml, "text/html");
        var elements = doc.getElementsByTagName('img');
        var imageList = new Array();
        for(var i = 0; i < elements.length; i++) {
          imageList.push(elements[i].getAttribute('src'));
        }
        resolve(imageList);  
      });
    }

    onEditorStateChange  = (editorState) => {
        var blocks = convertToRaw(editorState.getCurrentContent()).blocks;
        LogSystem.info("--------------editorState ------------------------");
        LogSystem.info(editorState);
        var bodyText = blocks.map(block => (!block.text.trim() && '\n') || block.text.replace(/<img[^>]*>/g, '')).join('\n');
        // if(bodyText.length > 250) {
        //   bodyText = bodyText.substring(0, 250);
        // }
        LogSystem.info("----------onEditorStateChange---------------");
        var bodyHtml = ' ' + draftToHtml(convertToRaw(editorState.getCurrentContent())) + ' ';
        LogSystem.info(bodyHtml);
        this.setState({
          editorState,
        });
        this.getImgUrlsInBodyHtml(bodyHtml)
          .then(imageList => {
            this.setState({
              imageList,
            });
            this.props.onImageListChange(imageList);
          });
        this.props.onChangeContent(bodyText, bodyHtml);
      };

    render() {

        return (
            <div className="rdw-editor-main content-editor_inner" 
                style={{border:'1px solid #ddd'}} >
                <Editor
                    editorState={this.state.editorState}
                    wrapperClassName="demo-wrapper"
                    editorClassName="demo-editor"
                    name = "body"
                    value={this.state.editorState === null ? '' : this.state.editorState}
                    toolbar={{
                        image: { 
                            uploadCallback: this.uploadImageCallBack, 
                            previewImage:true, 
                            alt: { present: true, mandatory: false },  
                            alignmentEnabled: "RIGHT",
                            defaultSize: {
                                height: 'auto',
                                width: '100%',
                            },
                        },
                        options: ['inline', 'image', 'blockType', 'fontSize', 'fontFamily', 'list', 'textAlign', 'colorPicker', 'link', 'emoji','remove', 'history'],
                        inline: { inDropdown: true },
                        list: { inDropdown: true,
                          options: ['unordered', 'ordered'],
                        },
                        textAlign: { inDropdown: true },
                        link: { inDropdown: true },
                        history: { inDropdown: true },
                        fontFamily: {
                          options: ['Arial', 'Georgia', 'Tahoma', 'Times New Roman', 'Verdana']
                        }
                    }}
                    onEditorStateChange={this.onEditorStateChange}
                />
            </div>
            
        )
    }
      
}

           
export default EditorContent;