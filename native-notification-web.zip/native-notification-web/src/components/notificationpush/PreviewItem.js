import React, { Component } from 'react';
// import '../index.css'
import { LogSystem } from '../../log/index'
class PreviewItem extends Component {

    onRemove = () => {
        LogSystem.info('onRemove --------------index: ' + this.props.index);
        this.props.onRemove(this.props.index);
    }

    render() {
        return ( 
                <li> 
                    <span> {this.props.fileName} </span> 
                    <button type="button" className="btn-remove" onClick={() => this.onRemove()}>
                        <span aria-hidden="true">&times;</span>
                    </button> 
                </li>
            );
        }
    }
            
            
export default PreviewItem;