import React, { Component } from 'react';
import Datetime from 'react-datetime';
import '../../style/notiDateTimePicker.css'
import { LogSystem } from '../../log/index'

var minSentTo = null;
var validSentTo = function( current ){
    if(minSentTo === null) return true;
    return current.isAfter( minSentTo );
};

var maxSentFrom = Datetime.moment();
var validSentFrom = function( current ){
    if(maxSentFrom === null) current.isBefore( Datetime.moment() );
    return current.isBefore( maxSentFrom );
};


class NotiDateTimePicker extends Component {

    constructor(props) {
        super(props);
        this.state = {
            dateTime: 0,
        }
    }

    validateTime = (current) => {

    }


    onChangeSentFrom = (date) => {
        LogSystem.info('Portal::NotiDateTimePicker date: ' + date * 1);
        this.setState({
            dateTime: (date === undefined) ? null : date * 1
        })
    }

    renderInput = ( props, openCalendar, closeCalendar ) => {
        function clear(){
            props.onChange({target: {value: ''}});
        }

        return (
            <div className="picker_wrapper" >
                <div>
                    <input {...props}/>    
                </div>
                <button className="picker_clear_button" onClick={clear}><i className="icon-cross2"></i></button>  
            </div>
        );
    }

    render() {
        return (
            <Datetime renderInput={ this.renderInput }
            name="dateTime"
            onChange={this.onChangeSentFrom}
            dateFormat="DD-MM-YYYY"
            closeOnSelect={true}
            timeFormat={false}
            inputProps={{readOnly: "true"}}
            />
        );
    }
}

export default NotiDateTimePicker;
