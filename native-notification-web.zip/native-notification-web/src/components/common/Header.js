import React, { Component } from 'react';
import swal from 'sweetalert2'
import { LogSystem } from '../../log/index'


class Header extends Component {

    logout = () => {
        LogSystem.info('Header::logout -----------------')
        swal({
            title: 'Warning',
            text: "Bạn có chắc chắn muốn logout ?",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Tiếp tục',
            cancelButtonText: 'Hủy'
        }).then((result) => {
            if (result.value) {
                this.props.logout()
            }
        })
    }

    goToChangingAppPage = () => {
        LogSystem.info('Header::logout -----------------')
        swal({
            title: 'Warning',
            text: "Bạn có chắc chắn muốn chọn App khác ?",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Tiếp tục',
            cancelButtonText: 'Hủy'
        }).then((result) => {
            if (result.value) {
                window.location.replace('/')
            }
        })
    }

    render() {
        return (
            <div className="navbar navbar-default header-highlight">
                {/* <div className="navbar-header">
                    <a className="navbar-brand" href="index.html"><img src="assets/images/logo_light.png" alt=""></img></a>
                </div> */}

                <div className="navbar-collapse collapse" id="navbar-mobile">
                    <ul className="nav navbar-nav navbar-right">
                      
                        <li className="dropdown dropdown-user">
                            <a className="dropdown-toggle" data-toggle="dropdown">
                                <img src="assets/images/placeholder.jpg" alt=""></img>
                                <span>{(this.props.user !== null) ? this.props.user.username: ''}</span>
                                <i className="caret"></i>
                            </a>

                            <ul className="dropdown-menu dropdown-menu-right">
                                <li ><a onClick={() => this.goToChangingAppPage()}><i className="icon-cog4"></i>Chuyển sang App khác</a></li>
                                <li ><a onClick={() => this.logout()}><i className="icon-switch2"></i>Logout</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        );
    }
}

export default Header;
