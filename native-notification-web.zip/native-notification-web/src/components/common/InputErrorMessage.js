import React, { Component } from 'react';

class InputErrorMessage extends Component {

    render() {
        return (
            <p className="text-danger">{this.props.children}</p>
        );
    }
}

export default InputErrorMessage;
