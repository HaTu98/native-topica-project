import React, { Component } from 'react';
import InputReceivers from '../notificationpush/InputReceivers';
import swal from 'sweetalert2'
import { LogSystem } from '../../log/index'
import ImportEmailFile from './ImportEmailFile';

class InputReceiverEmailTabs extends Component {
	constructor(props) {
		super(props);
		this.state = {
            usernameReceivedList: [],
			importedFiles: [],
			tab: this.props.tab
		}
	}

	onTab = (tab) => {
		LogSystem.info('Portal::ontab::tab: ' + tab)
		if(tab === this.props.tab) return;
		swal({
            title: 'Warning',
            text: "Bạn có chắc chắn muốn chuyển cách nhập người nhận?",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Chắc chắn',
			cancelButtonText: 'Hủy'
		}).then((result) => {
		if (result.value) {
			this.props.onChangeTab(tab);
		}
		})	
	}
	
    onEnteringReceivers = () => {
        this.setState({
            receiversTabError: undefined
		})
		this.props.handleEmailTabsTrigger();
    }

	showContentOntab = () => {
		var {currentTab} = this.props;
		switch(currentTab) {
			case 0:
				return <InputReceivers onChangeReceivers = {this.props.onChangeReceivers}
									onEnteringReceivers = {this.onEnteringReceivers} 
									usernameReceivedList={this.props.usernameReceivedList}
									editMode={this.props.editMode}
					/>
			case 1:
				return <ImportEmailFile 
					onChangeReceivers = {this.props.onChangeReceivers}
				/>
			default:
				return <InputReceivers onChangeReceivers = {this.props.onChangeReceivers}
						onEnteringReceivers = {this.onEnteringReceivers} 
						usernameReceivedList={this.props.usernameReceivedList}
						editMode={this.props.editMode}
						/>
		}
	}

	showErrorMessage = () => {
		return(<p className="text-danger">{this.props.receiversTabError}</p>)
	}

	render() {
		return (
			<div>
				<ul className="nav nav-tabs">
					<li className={this.props.tab === 0 ? 'active' : ''}><a onClick={() => this.onTab(0)}><b className="text-info">Nhập tay</b></a></li>
					<li className={this.props.tab === 1 ? 'active' : ''}><a  onClick={() => this.onTab(1)}><b className="text-danger">Upload file</b></a></li>
				</ul>
				<div>
					{this.showContentOntab()}

				</div>
				{this.showErrorMessage()}
			</div>
		);
	}
}

export default InputReceiverEmailTabs;

















