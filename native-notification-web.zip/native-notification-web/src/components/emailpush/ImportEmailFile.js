import React, { Component } from 'react';
import imageDefault from '../../img/upload-icon-3.png'
// import '../index.css'
import AppConfig from '../../constants/AppConfig'
import { LogSystem } from '../../log/index'
import CONSTANT from '../../constants/Constant';
import PreviewBox from '../notificationpush/PreviewBox';
import XLSX from 'xlsx';
import swal from 'sweetalert2'
import * as ALERT from '../../redux/actions/alertActions';
import { toast } from 'react-toastify';
import { ExcelProvider } from '../../redux/actions/ExcelProvider';
import ExcelUtil from '../../util/ExcelUtil';

const StudentUploadConfig = {
    MAX_SIZE: 1000000, // 1MB
    MAX_ROWS: 1000
}



function showErrorPopUp(validStudents, inValidStudents, cb) {
    swal({
        title: (validStudents.length > 0) ? 'warning' : 'error',
        type: (validStudents.length > 0) ? 'warning' : 'error',
        html:
            '<h4 class="text-warning">' + (validStudents.length > 0 ? CONSTANT.UploadFile_Modal.EXIST_STUDENT_INVALID : CONSTANT.UploadFile_Modal.All_STUDENT_INVALID) + '</h4> <br>' +
            '<a style="text-decoration: underline;" id="resume"><h4> Tải xuống Học Viên lỗi</h4></a>',
        onBeforeOpen: () => {
            const content = swal.getContent()
            const $ = content.querySelector.bind(content)
            const resume = $('#resume')
            resume.addEventListener('click', () => {
                LogSystem.info('Click tai xuong HV loi')
                ExcelProvider.exportStudentErrors(inValidStudents)
            })

            },    
        showCloseButton: true,
        showCancelButton: true,
        focusConfirm: false,
        confirmButtonText: 'Tiếp Tục',
        cancelButtonText: 'Hủy'
    }).then((result) => {
        if (result.value && validStudents.length > 0) {
            LogSystem.info('_uploadFileFail:: data ---------------------------');
            LogSystem.info(validStudents);
            cb();
        }
    })
}




function handleFile(f) {
    var reader = new FileReader();
    const rABS = !!reader.readAsBinaryString;
    return new Promise((resolve, reject) => {
        reader.onload = function(e) {
            const bstr = e.target.result;
            const wb = XLSX.read(bstr, {type:rABS ? 'binary' : 'array'});
            const wsname = wb.SheetNames[0];
            const ws = wb.Sheets[wsname];
            const data = XLSX.utils.sheet_to_json(ws, {header:1});
            resolve(data);
        };
        if(rABS) reader.readAsBinaryString(f); else reader.readAsArrayBuffer(f);
    }) 
}

function validateExtention(fileName) {
    if(fileName === undefined) return false;
    if(!(fileName.endsWith(".xlsx") || fileName.endsWith(".xls"))) {
        LogSystem.info("Chỉ hỗ trợ với định dạng .xlsx và .xls");
        ALERT.showToastAlter("Error ", "Chỉ hỗ trợ với định dạng .xlsx và .xls", toast.TYPE.ERROR); 
        return false;
    }
    return true;
}

function validateTemplte(data, template) {
    const headerRow = data[0];
    if(headerRow === undefined || headerRow.length !== TemplateInput.length) {
        ALERT.showToastAlter("Error ", "Không dứng template, Xin vui lòng download template trước", toast.TYPE.ERROR); 
        return false;
    } 
    for(let i = 0; i < template.length; i++) {
        if(template[i] !== headerRow[i]) { 
            ALERT.showToastAlter("Error ", "Không đúng template, Xin vui lòng download template trước", toast.TYPE.ERROR); 
            return false;
        }
    }

    return true;
}

function validateFileSize(file) {
    if(file.size > StudentUploadConfig.MAX_SIZE) {
        ALERT.showToastAlter("Error ", "File quá lớn, Chỉ cho phép upload với file nhỏ hơn 1MB", toast.TYPE.ERROR); 
            return false;
    }
    return true;
}

function validateLength(data) {
    if(data.length > StudentUploadConfig.MAX_ROWS + 1) {
        ALERT.showToastAlter("Error ", "Chỉ cho phép upload 1000 học viên", toast.TYPE.ERROR);
        return false; 
    }
    return true;
}

function isValidateEmail(email) {
    return CONSTANT.Email_Regrex.test(email);   
}

function getStudent(data) {
    let validStudents = [];
    let inValidStudents = [];
    for(let i = 1; i < data.length; i++) {
        let email = data[i][1];
        if(isValidateEmail(email)) {
            validStudents.push(email);
        } else {
            let studentErrorInfo = {
                id: data[i][0],
                username: data[i][1], 
                error: "Không đúng định dạng email"

            };
            inValidStudents.push(studentErrorInfo);
        }
    }
    if(validStudents.size < 1) {
        ALERT.showToastAlter("Error: ", "Không có học viên nào cả", toast.TYPE.ERROR)
        return null;
    }
    return{
        validStudents,
        inValidStudents
    }
}

const TemplateInput = ["No *", "Student Email *"];

class ImportEmailFile extends Component {

    constructor(props) {
        super(props)
        this.fileInput = React.createRef();
        this.state = {
            validStudents: [],
            importedFiles: null,
        }
    }

    onChange = (e) => {
        e.preventDefault();
        var file = this.fileInput.current.files[0];
        e.target.value = null; 
        if(!validateFileSize(file)) return;
        LogSystem.info('onChange::file');
        LogSystem.info(file);
        LogSystem.info('Portal::onChange value: ' + file.name);
        if(!validateExtention(file.name)) return;
        handleFile(file)
            .then(data => {
                LogSystem.info('handleFile::then');
                LogSystem.info(data);          
                if(!validateTemplte(data, TemplateInput)) return;
                if(!validateLength(data)) return;
                var student = getStudent(data);
                if(student === null) return;
                if(student.inValidStudents.length > 0) {
                    showErrorPopUp(student.validStudents, student.inValidStudents, () => {
                        this.addValidstudentsAndSuccessFile(student.validStudents, file.name)
                    });
                } else {
                    ALERT.showToastAlter("Success ", "Tất cả học viên được import thành công", toast.TYPE.SUCCESS);
                    this.addValidstudentsAndSuccessFile(student.validStudents, file.name)
                }
            })
    }


    addValidstudentsAndSuccessFile(validStudents, fileName) {
        this.setState({
            importedFiles: fileName
        });
        LogSystem.info("ImportEmailFile::addValidstudentsAndSuccessFile ");
        LogSystem.info(validStudents);
        this.props.onChangeReceivers(validStudents);
    }

    onRemoveFile = () => {
        swal({
            title: 'Warning',
            text: "Bạn có chắc chắn muốn xóa ?",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Xóa',
            cancelButtonText: 'Hủy',
        }).then((result) => {
            if(result.value) {
                this.setState({
                    importedFiles: null
                });
                this.props.onChangeReceivers(null);
            }
        })
    }

    dowloadTemlate = () => {
        ExcelUtil.exportTemplate(TemplateInput);
    }


    render() {
        return (
            <div className="file-field">
                <div className="row">
                    <div className="col-md-6 ">
                        <div className="img-select-block margin-bottom-15 margin-15">
                            <img id="preview-product-img" src={imageDefault} ></img>
                            <input type='file' id="input-select-img-product" ref={this.fileInput} name="file" onChange={this.onChange}/>
                        </div>
                    </div>
                    <div className="col-md-6">
                        <a onClick={() => this.dowloadTemlate()}>
                            <span className="label label-success font-30">&nbsp;&nbsp;&nbsp;&nbsp;dowload template&nbsp;&nbsp;&nbsp;&nbsp;</span>
                        </a>
                    </div>
                </div>
                
                <PreviewBox
                    onRemoveFile = {this.onRemoveFile}
                    importedFiles = {this.state.importedFiles}
                />
            </div>
            );
        }
    }
            
            
export default ImportEmailFile;