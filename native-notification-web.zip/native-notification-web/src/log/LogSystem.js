import AppConfig  from '../constants/AppConfig'
const LogSystem = {
    info: (_log) => {
        if(AppConfig.DEBUG === '__DEV__') {
            console.log(_log)
        }
    },
    error: (_log) => {
        if(AppConfig.DEBUG === '__DEV__') {
            console.error(_log)
        }
    },
}

export default LogSystem;
