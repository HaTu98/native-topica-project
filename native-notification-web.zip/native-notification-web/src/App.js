import React, { Component } from 'react';
import { Switch, Route, BrowserRouter as Router } from 'react-router-dom';
import { ROUTES } from './navigation/routes';
import { ToastContainer } from 'react-toastify';
import './style/index.css'
import { connect } from 'react-redux';
import LoginPage from './pages/LoginPage';
import {logoutAction} from './redux/actions/loginActions'
import { HomeRoute } from './navigation/HomeRoute';
import NotFoundPage from './pages/NotFoundPage';
import SystemErrorPage from './pages/SystemErrorPage';
import { LogSystem } from '../src/log/index'
import OAuth2RedirectHandler from './pages/OAuth2RedirectHandler';
import AccessDenied from './pages/AccessDenied';
import AppSubribedEmpty from './pages/AppSubribedEmpty';


class App extends Component {

    constructor(props) {
        super(props);
        this.state = {
            isShowAlert: false,
            isLogin: false
        }
    }

    componentWillReceiveProps(nextProps){
        if(nextProps){
            var {isShowAlert} = nextProps;
            this.setState({
                isShowAlert: isShowAlert
            });
        }
    }

    onConfirm = () => {
        LogSystem.info('click confirm')
    }
    
    onLogout = () => {
        LogSystem.info('Portal::App::logout')
        this.props.logout()
    }

    render() {
        return (
            <Router>
                    <div>
                        <ToastContainer/>    
                        <Switch>                                      
                            {
                                this.showContentMenus(ROUTES.ADMIN)
                            }
                            <Route exact={false} path='/login' component={LoginPage}/>
                            <Route path="/oauth2/redirect" component={OAuth2RedirectHandler} />
                            <Route exact={true} path='/systemerror' component={SystemErrorPage}/>
                            <Route exact={true} path='/accessdenied' component={AccessDenied}/>
                            <Route exact={true} path='/appSubcribeEmpty' component={AppSubribedEmpty}/>
                            <Route path='' exact={false} component={NotFoundPage} />
                        </Switch>
                    </div>                  
            </Router>
        );
    }

    
    showContentMenus = (routes) => {
        var result = [];
        if (routes.length > 0) {
            routes.map((route, index) => {
                (
                    result.push(<HomeRoute
                        key={index}
                        path={route.path}
                        exact={true}
                        isDisplaySliderBar = {route.isDisplaySliderBar}
                        content={route.main}
                    />
                    )
                );
            });
        }
        return result;
    }
}

const mapStateToProps = state => ({
    isShowAlert: state.alertReducer.isShowAlert,
    token: state.loginReducers.token,
    user: state.loginReducers.user
});

const mapDispatchToProps = (dispatch, props) => {
    return {
        logout: () => {
            dispatch(logoutAction());
        }
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(App);
