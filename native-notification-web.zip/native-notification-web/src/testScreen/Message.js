const URL  = 'server';
export default URL; 