import LogSystem  from '../log/LogSystem'
import { store } from '../store.js'
import * as ActionType from '../redux/actions/ActionType'


export default function uploadImageCallBack(file) {
    return new Promise(
      (resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'https://api.imgur.com/3/image');
        xhr.setRequestHeader('Authorization', 'Bearer 1db50e52745884d924b695cf33b73b133b4f9fe5');
        const data = new FormData();
        data.append('image', file);
        xhr.send(data);
        xhr.addEventListener('load', () => {
          const response = JSON.parse(xhr.responseText);
          resolve(response);
          console.log(response);
          // exportImageUrl(response.data.link);
        });
        xhr.addEventListener('error', () => {
          const error = JSON.parse(xhr.responseText);
          reject(error);
        });
      }
    );
  }


  // function exportImageUrl(imgUrl) {
  //   LogSystem.info("exportImageUrl: " + imgUrl);
  //   store.dispatch({
  //     type: ActionType.UPLOAD_IMAGE,
      
  //   })
  // }
