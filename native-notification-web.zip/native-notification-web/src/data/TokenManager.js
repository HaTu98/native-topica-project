export const TokenManager = {
    setItem: (_key, _value) => {
        localStorage.setItem(_key, _value);
    },
    getItem: (_key) => {
        return localStorage.getItem(_key);
    },
    removeItem: (_key) => {
        localStorage.removeItem(_key);
    },
    clearAll: () => {
        localStorage.clear();
    }
}
