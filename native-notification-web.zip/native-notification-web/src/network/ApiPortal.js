import axios from 'axios';


// const API_BASE_PORTAL = 'http://localhost:8082/api/portal/setting';
// const API_BASE_PORTAL = 'http://portalstaging.topicanative.edu.vn/api/portal/setting';
const API_BASE_PORTAL = 'http://portalit.topicanative.edu.vn/api/portal/setting';


const getInstance = () => {
  const instance = axios.create({
    baseURL: API_BASE_PORTAL,
    timeout: 30000,
    headers: {
      'key': "bMch6ARfMNlADVTn",
      'Content-Type': 'application/json'
    }
  });

  return instance;
}

const ApiPortal = { instance: getInstance() };

ApiPortal.getVcrType = (params) => {
  return ApiPortal.instance.get('/vcrType/get', params);
}

ApiPortal.updateVcrType = (params) => {
  return ApiPortal.instance.post('/vcrType', params)
}

ApiPortal.getDeepLinkStatus = (params) => {
  return ApiPortal.instance.get('/adobe/deeplink/get', params);
}

ApiPortal.setDeepLinkStatus = (params) => {
  return ApiPortal.instance.get('/adobe/deeplink/set/'+params);
}

ApiPortal.getMixListStatus = (params) => {
  return ApiPortal.instance.get('/list/mix/get', params);
}

ApiPortal.setMixListStatus = (params) => {
  return ApiPortal.instance.get('/list/mix/set/'+ params);
}

ApiPortal.getNumberEmpty = (params) => {
  return ApiPortal.instance.get('/list/empty/get', params);
}

ApiPortal.setNumberEmpty = (params) => {
  return ApiPortal.instance.get('/list/empty/set/' + params);
}

ApiPortal.getNumberStudent = (params) => {
  return ApiPortal.instance.get('/maxUser/get', params);
}

ApiPortal.setNumberStudent = (params) => {
  return ApiPortal.instance.post('/maxUser/set', params);
}


/* Export Component ==================================================================== */
export default ApiPortal;
