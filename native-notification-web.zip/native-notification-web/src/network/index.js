/**
 * Networking Manager
 */

import API from './API';
import ApiPortal from './ApiPortal';

export { API, ApiPortal };