import axios from 'axios';

import * as UnauthorizeInterceptor from './interceptors/unauthorize.js';
import * as LogInterceptor from './interceptors/log';
import * as AccessTokenInterceptor from './interceptors/accessToken';
// import { LocalStorage } from '@data';
import AppConfig from '../constants/AppConfig'
import { LogSystem } from '../log/index'

const getInstance = () => {
    const instance = axios.create({
        baseURL: AppConfig.API_BASE_URL,
        timeout: 30000,
    });

    instance.interceptors.response.use(
        UnauthorizeInterceptor.onFullfilled,
        UnauthorizeInterceptor.onRejected,
    );

    instance.interceptors.request.use(
        LogInterceptor.requestLog,
        LogInterceptor.requestError,
    );

    instance.interceptors.response.use(
        LogInterceptor.responseLog,
        LogInterceptor.responseError,
    );

    instance.interceptors.request.use(
        AccessTokenInterceptor.addAccessToken,
        AccessTokenInterceptor.onRejected
    );
    return instance;
}

const API = { instance: getInstance() };
/**
 *  API xample
 */
API.xample = () => {
    return API.instance.get('https://api.github.com/users/defunkt')
}

// API.login = (params) => {
//     return API.instance.post('/api/portal/notify/manager/login', params)
// }

API.verifyToken = () => {
    return API.instance.get('/api/notify/manager/verify')
}

API.downloadLink = (params) => {
    return API.instance.get(params)
}

API.uploadFile = (params, appId) => {
    LogSystem.info('Portal::API::uploadFile: ');
    LogSystem.info(params);
    var formData = new FormData();
    formData.append('file', params);
    LogSystem.info('uploadFile------------------------------')
    return API.instance.post('/api/notify/manager/upload_excel/upLoad/students/appid/' + appId, formData)
}

API.submitNotification = (params) => {
    return API.instance.post('/api/notify/manager/send', params)
}



API.cancelNotificationWating = (senderId) => {
    return API.instance.post('/api/notify/manager/cancel?senderId=' + senderId)
}

API.searchNotificationSenders = (params) => {
    return API.instance.post('/api/notify/manager/sender/search', params)
}

API.unscheduleNotificcation = (senderId) => {
    return API.instance.post('/api/notify/manager/unschedule?senderId=' + senderId)
}

API.restartNotificcation = (senderId) => {
    return API.instance.post('/api/notify/manager/restart?senderId=' + senderId)
}

API.updateNotificcation = (senderId) => {
    return API.instance.post('/api/notify/manager/update?senderId=' + senderId)
}

API.getDetail = (senderId) => {
    return API.instance.get('/api/notify/manager/sender/' + senderId)
}

/*  -- App manager --*/ 
API.loadAllAppMangers = () => {
    return API.instance.get('/api/notify/admin/apps')
}

API.createNewNotificationApp = (params) => {
    return API.instance.post('/api/notify/admin/app', params)
}

API.authorizeUserToApp = (params) => {
    return API.instance.post('/api/notify/manager/authorizeUserToApp', params)
}

API.updateManager = (params) => {
    return API.instance.post('/api/notify/manager/changeStatus', params)
}

API.getAppsAssigned = (params) => {
    return API.instance.get('/api/notify/manager/apps', params)
}

API.deleteApp = (appId) => {
    return API.instance.post('/api/notify/admin/delete/app?id=' + appId);
}

API.updateManager= (params) => {
    return API.instance.post('/api/notify/manager/update', params);
}

API.deleteManager = (id) => {
    return API.instance.post('/api/notify/manager/delete/id/' + id);
}

// email

API.EmailSending = (params) => {
    return API.instance.post('/api/email/manager/send', params)
}

API.emailSearch = (params) => {
    return API.instance.post('/api/email/manager/sender/search', params)
}

API.unscheduleEmail = (params) => {
    return API.instance.post('/api/email/manager/unschedule?senderId=' + params)
}

API.restartEmail = (senderId) => {
    return API.instance.post('/api/email/manager/restart?senderId=' + senderId)
}

API.cancelEmailWating = (senderId) => {
    return API.instance.post('/api/email/manager/cancel?senderId=' + senderId)
}

API.validateStudentInfo = (appId, params) => {
    return API.instance.post('/api/notify/manager/validate/studentInfo/appid/' + appId, params)
}

API.createNewBanner = (params) => {
    return API.instance.post('/api/portal/banner/save', params)
}

API.createNewBanner = (params) => {
  return API.instance.post('/api/portal/banner/save', params)
}


/* Export Component ==================================================================== */
export default API;


