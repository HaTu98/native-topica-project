import { LogSystem } from '../../log/index'
const DEBUG = '__DEV__';
export function requestLog(config) {
  if (DEBUG) {
    LogSystem.info(`>>> ${config.method}: ${config.url}`);
    LogSystem.info(config.data);
    LogSystem.info(config.headers);
  }
  return config;
}

export function requestError(error) {
  if (DEBUG) {
    LogSystem.info(error);
  }
  return Promise.reject(error);
}

export function responseLog(response) {
  if (DEBUG) {
    const config = response.config;
    LogSystem.info(`<<< ${response.status} ${config.method}: ${config.url}`);
    LogSystem.info(response);
  }
  return response;
}

export function responseError(error) {
  if (DEBUG) {
    const config = error.config;
    const response = error.response;
    if (response) {
      LogSystem.info(`<<< ${response.status} ${config.method}: ${config.url}`);
      LogSystem.info(response);
    } else {
      LogSystem.info(`<<< ${config.method}: ${config.url}`);
      LogSystem.info('network log error', error);
    }
  }
  return Promise.reject(error);
}