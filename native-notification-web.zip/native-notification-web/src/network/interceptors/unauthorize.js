
const UnauthorizeStatusCode = 401;


export function onFullfilled(response) {
  return Promise.resolve(response);
}

export function onRejected(error) {
  if (error) {
    const response = error.response;
    if (UnauthorizeStatusCode == response.status) {
      window.location.reload();
    }
    return Promise.reject(error);
  }
}