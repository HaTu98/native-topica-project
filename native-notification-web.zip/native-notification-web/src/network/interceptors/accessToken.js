import {TokenManager} from '../../data/TokenManager'
import {LogSystem} from '../../log/index'

export function addAccessToken(config) {
  const accessToken = TokenManager.getItem('token');
  if (accessToken) {
    const headers = { ...config.headers, 'Authorization': accessToken};
    config.headers = headers;
  }
  return config;
}

export function onRejected(error) {
  return Promise.reject(error);
}