import React from 'react';
import { Route, Redirect } from 'react-router-dom';
import HomePage from '../pages/HomePage'
import {TokenManager} from '../data/TokenManager'

export const HomeRoute = ({ match, isDisplaySliderBar, content, ...rest }) => (
    <Route {...rest} render={props => (
        TokenManager.getItem('token')
            ? <HomePage isDisplaySliderBar = {isDisplaySliderBar} content={content}></HomePage>
            : <Redirect to={{ pathname: '/login', state: { from: props.location } }} />
    )} />
)