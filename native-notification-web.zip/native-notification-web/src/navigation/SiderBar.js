import React, { Component } from 'react';
import { Route, Link } from 'react-router-dom';
import { ROUTES  } from './routes';
import { BackupDataManager } from '../data/BackupDataManager';
import { LogSystem } from '../log/index'

class MenuLink extends Component {

    render() {
        return(
            <li key={this.props.index}  className={this.props.currentPath === this.props.path ? 'active' : ''}>
                <Link to={this.props.path}>
                    <i className={this.props.classNameIcon}></i>
                    <span className="pull-left">{this.props.label}</span>
                </Link>  
            </li>
        )
    }
}

class Siderbar extends Component {

    constructor(props) {
        super(props);
        this.state = {
            activeItem: 0,
            currentPath: window.location.pathname,
            appName: null,
        }
    } 

    componentDidMount() {
        // LogSystem.info(this.)
        var choosenApp = BackupDataManager.getItem("choosenApp");
        var app = JSON.parse(choosenApp);
        LogSystem.info('choosenApp --------------------------------')
        LogSystem.info(app)
        if(app !== null && app.appName !== undefined ) {
            this.setState({
                appName: app.appName
            })
        }
        LogSystem.info(app)
    }
    
    render() {
        return (
            <div className="sidebar sidebar-main">
                <div className="sidebar-content">
                    {/* User menu */}
                    <div className="sidebar-user">
                        <div className="category-content">
                            <div className="avatar-img_inner center">
                                <img src={(this.props.user !== null) ? this.props.user.avatarUrl : ''} className="avatar-img img-circle" alt=""></img>
                            </div>
                            <div className="media">
                               
                                <div className="media-body text-center">
                                    <h4 className="media-heading text-semibold">{(this.props.user !== null) ? this.props.user.name : ''}</h4>
                                    <div className="text-size-mini text-muted">
                                        <p className = "appNameAndRoleName"><span>{this.state.appName}</span> - <span>{this.props.user !== null ? this.props.user.role : ''}</span></p>
                                    </div>
                                </div>

                                <div className="media-right media-middle">
                                    {/* <ul className="icons-list">
                                        <li>
                                            <a ><i className="icon-cog3"></i></a>
                                        </li>
                                    </ul> */}
                                </div>
                            </div>
                        </div>
                    </div>
                    {/* /user menu */}


                    {/* Main navigation */}
                    <div className="sidebar-category sidebar-category-visible">
                        <div className="category-content no-padding">
                            <ul className="navigation navigation-main navigation-accordion">              
                                {  (this.props.user !== null && this.props.user.role === 'ADMIN') ?
                                    this.showMenus(ROUTES.ADMIN) : this.showMenus(ROUTES.MANAGER) } 
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    showMenus = (menus) => {
        var result = null;
        if (menus.length > 0) {
            result = menus.map((menu, index) => {
                if(menu.isAddedInSliderBar === false) return null;
                return (
                     <MenuLink
                        key={index}
                        index = {index}
                        label={menu.name}
                        path={menu.path}
                        currentPath={this.state.currentPath}
                        classNameIcon={menu.classNameIcon}
                    />
                );
            });
        }
        return result;
    }
}

export default Siderbar;
