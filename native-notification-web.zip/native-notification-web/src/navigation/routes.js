import React from 'react';
import NotificationPush from '../pages/NotificationPush';
import EmailSender from '../pages/EmailSender';
import NotificationReport from '../pages/NotificationReport';
import NotificationAppManagerPage from '../pages/NotificationAppManagerPage';
import ChooseAppsPage from '../pages/ChooseAppsPage';
import EmailReport from '../pages/EmailReport';
import BannerCreationPage from '../pages/BannerCreationPage';
import SystemConfigPage from '../pages/SystemConfigPage';

export const ROUTES = {
    ADMIN: [
        {
            path: "/",
            exact: true,
            name: 'Gửi thông báo',
            classNameIcon: 'icon-bubble-notification',
            isDisplaySliderBar: false,
            isAddedInSliderBar: false,
            main: <ChooseAppsPage />,
        },
        {
            path: "/notification/push",
            exact: true,
            name: 'Gửi thông báo',
            classNameIcon: 'icon-bubble-notification',
            isDisplaySliderBar: true,
            isAddedInSliderBar: true,
            main: <NotificationPush />,
        },
       
        {
            path: '/notification/report',
            exact: true,
            name: 'Báo cáo thông báo',
            classNameIcon: 'icon-list2',
            isDisplaySliderBar: true,
            isAddedInSliderBar: true,
            main: <NotificationReport />,
        },
        {
            path: "/emailSender",
            exact: true,
            name: 'Gửi Mail',
            classNameIcon: 'icon-bubble-notification',
            isDisplaySliderBar: true,
            isAddedInSliderBar: true,
            main: <EmailSender />,
        },
        {
            path: '/email/report',
            exact: true,
            name: 'Báo cáo Email',
            classNameIcon: 'icon-list2',
            isDisplaySliderBar: true,
            isAddedInSliderBar: true,
            main: <EmailReport />,
        },
        {
            path: '/banner/create',
            exact: true,
            name: 'Tạo banner',
            classNameIcon: 'icon-list2',
            isDisplaySliderBar: true,
            isAddedInSliderBar: true,
            main: <BannerCreationPage />,
        },
        {
            path: '/notification/app',
            exact: true,
            name: 'Quản lý App và User',
            classNameIcon: 'icon-users4',
            isDisplaySliderBar: true,
            isAddedInSliderBar: true,
            main: <NotificationAppManagerPage />,
        },
        {
            path: '/system/config',
            exact: true,
            name: 'Thiết lập hệ thống',
            classNameIcon: 'icon-users4',
            isDisplaySliderBar: true,
            isAddedInSliderBar: true,
            main: <SystemConfigPage />,
        }
    ],
    MANAGER: [
        {
            path: "/",
            exact: true,
            name: 'Gửi thông báo',
            classNameIcon: 'icon-bubble-notification',
            isDisplaySliderBar: false,
            isAddedInSliderBar: false,
            main: <ChooseAppsPage />,
        },
        {
            path: "/notification/push",
            exact: true,
            name: 'Gửi thông báo',
            classNameIcon: 'icon-bubble-notification',
            isDisplaySliderBar: true,
            isAddedInSliderBar: true,
            main: <NotificationPush />,
        },
        {
            path: '/notification/report',
            exact: true,
            name: 'Báo cáo thông báo',
            classNameIcon: 'icon-list2',
            isDisplaySliderBar: true,
            isAddedInSliderBar: true,
            main: <NotificationReport />,
        },
        {
            path: "/emailSender",
            exact: true,
            name: 'Gửi Mail',
            classNameIcon: 'icon-bubble-notification',
            isDisplaySliderBar: true,
            isAddedInSliderBar: true,
            main: <EmailSender />,
        },
        {
            path: '/banner/create',
            exact: true,
            name: 'Tạo banner',
            classNameIcon: 'icon-list2',
            isDisplaySliderBar: true,
            isAddedInSliderBar: true,
            main: <BannerCreationPage />,
        },
        {
            path: '/email/report',
            exact: true,
            name: 'Báo cáo Email',
            classNameIcon: 'icon-list2',
            isDisplaySliderBar: true,
            isAddedInSliderBar: true,
            main: <EmailReport />,
        },
        {
            path: '/system/config',
            exact: true,
            name: 'Thiết lập hệ thống',
            classNameIcon: 'icon-users4',
            isDisplaySliderBar: true,
            isAddedInSliderBar: true,
            main: <SystemConfigPage />,
        }
    ]
}





// export default routes;