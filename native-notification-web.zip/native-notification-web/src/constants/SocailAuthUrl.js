import AppConfig  from './AppConfig'

const SocailAuthUrl = {
    GOOGLE_AUTH_URL: AppConfig.API_BASE_URL + '/api/oauth2/authorize/google?redirect_uri=' + AppConfig.DOMAIN + '/oauth2/redirect'
}

export default SocailAuthUrl;