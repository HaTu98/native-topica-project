const AppConfig = {
    // App Details
    appName: 'Native  Portal',
    // API_BASE_URL: 'http://127.0.0.1:8082',
    // API_BASE_URL: 'http://notifystg.topicanative.edu.vn',
    API_BASE_URL: 'http://notify.topicanative.edu.vn',
    DOMAIN: 'http://admin.notify.topicanative.edu.vn',
    // DOMAIN: 'http://admin.portalstaging.topicanative.edu.vn',
    // DOMAIN: 'http://admin.portalstaging.topicanative.edu.vn',
    // DOMAIN: 'http://localhost:3000',
    DEBUG: '__DEV__'
    // DEBUG: '__PRO__'

}

export default AppConfig;