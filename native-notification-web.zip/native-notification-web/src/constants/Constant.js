import  AppConfig from './AppConfig' 

const CONSTANT = {
    Email_Regrex: /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/,
    TopicaEmail_Regrex: /^([a-zA-Z0-9_\.\-])+\@(topica.edu.vn)+$/,
    TopicaUsename_Regrex: /^([a-zA-Z0-9_\.\-])+$/,
    Cron_Regex: /^(\*|([0-9]|1[0-9]|2[0-9]|3[0-9]|4[0-9]|5[0-9])|\*\/([0-9]|1[0-9]|2[0-9]|3[0-9]|4[0-9]|5[0-9])) (\*|([0-9]|1[0-9]|2[0-3])|\*\/([0-9]|1[0-9]|2[0-3])) (\*|([1-9]|1[0-9]|2[0-9]|3[0-1])|\*\/([1-9]|1[0-9]|2[0-9]|3[0-1])) (\*|([1-9]|1[0-2])|\*\/([1-9]|1[0-2])) (\*|([0-6])|\*\/([0-6]))$/,
    NotificationType: new Map([
        ['QUICKSEND', 'Gửi Ngay'],
        ['PREPLAN', 'Gửi Một Lần Theo Lịch'],
        ['SCHEDULED', 'Gửi Nhiều Lần Theo Lịch']
    ]),     
    StatusType: new Map([
        ['INPROGRESS', 'Đang xử lý'],
        ['SUCCESS', 'Thành Công'],
        ['FAIL', 'Lỗi'],
        ['SCHEDULED', 'Đang Trong Lịch Trình Gửi'],
        ['UNSCHEDULED', 'Đang Không Trong Lịch Trình Gửi'],
        ['WAITE_SENDING', 'Đang Chờ Gửi'],
        ['CANCEL', 'Huỷ']
    ]),
    Topica_Email_Extension: '@topica.edu.vn',
    DowLoad_Form_URL: AppConfig.API_BASE_URL + '/api/notify/manager/download/excel_form',
    AppManager: {
        AppModal: {
            AppName: {
                MaxLength: 80,
                errorMessage: 'Tên app không vượt quá 80 ký tự'
            },
            OneSignalAppId: {
                MaxLength: 100,
                errorMessage: 'ONESIGNAL APP ID Không vượt quá 100 kí tự'

            },
            RestApiKey: {
                MaxLength: 100,
                errorMessage: ' REST API KEY không vượt quá 100 ký tự'
            },
            Mode: {
                View: 'VIEW',
                Create: 'CREATE',
                Update: 'UPDATE'
            }
        }
    },
    Modal: {
        Mode: {
            View: 'VIEW',
            Create: 'CREATE',
            Update: 'UPDATE'
        }
    },
    UploadFile_Modal: {
         All_STUDENT_INVALID: 'Không có học viên nào chính xác',
         EXIST_STUDENT_INVALID:'Có một số học viên không chính xác'
    },
    SERVICE_LMS: 'LMS',
    SERVICE_LMS_VIP: 'LMS_VIP',
    VCR_TYPE_VCRX: 'VCRX',
    VCR_TYPE_BBB: 'BBB',
    VCR_TYPE_ADB: 'ADB',
    ADMIN_TYPE_ALL: 'ALL',
    ADMIN_TYPE_NORMAL: 'NORMAL',
    ADMIN_TYPE_VIP: 'VIP',
    MESSAGE_UPDATE_SUCCESS: 'Update thành công!',
    MESSAGE_UPDATE_ERROR: 'Update lỗi!',
}



export default CONSTANT;