package com.topica.lms.model.lms;

import com.topica.adapter.common.dto.RoomDTO;
import lombok.Data;
import org.springframework.util.StringUtils;

import static com.topica.adapter.common.constant.RoleInClass.NORMAL;
import static com.topica.adapter.common.constant.ServiceType.LMS;
import static com.topica.adapter.common.dto.RoomDTO.VCRX;

@Data
public class RoomResult {
    private MdlTpeBBBSimple bbb;
    private MdlTpeCanlendarTeach calendar;
    private MdlVCRXRoom vcrxRoom;
    private long totalUserNormal;
    private long totalUserAudit;
    private LmsMdlUserData teacher;
    private LmsMdlLogsserviceMoveUser logMove;

    public RoomResult() {
    }

    public RoomDTO toRoomDTO() {
        return new RoomDTO().builder()
                .packageType(LMS.name())
                .id(bbb.getId())
                .name(bbb.getName())
                .levelClass(calendar.getLevelClass())
                .timeAvailable(bbb.getTimeavailable())
                .typeClass(calendar.getTypeClass())
                .classIdVcrx(vcrxRoom != null ? vcrxRoom.getVcrxId() : null)
                .isVCRX(bbb.getIsVCRX() == 1? true : false)
                .vcrClassId(bbb.getVcrClassId())
                .vcrType(bbb.getIsVCRX() == 1? VCRX : bbb.getVcrType())
                .totalJoin(totalUserNormal)
                .totalAuditJoin(totalUserAudit)
                .isOpened(true)
                .teacherFirstName(teacher != null ? teacher.getFirstName() : "")
                .teacherLastName(teacher != null ? teacher.getLastName() : "")
                .teacherAvatar(teacher != null ? teacher.getImageAlt() : "")
                .teacherId(calendar.getTeacherId())
                .teacherType(calendar.getTeacherType())
                .status(calendar.getStatus())
                .role(logMove != null && !StringUtils.isEmpty(logMove.getRole()) ? logMove.getRole() : NORMAL.name())
                .build();
    }

    private boolean isOpened() {
        if(totalUserNormal > 0) {
            return true;
        }
        if(RoomDTO.ADB.equalsIgnoreCase(bbb.getVcrType()) && bbb.getVcrClassId() != null) {
            return true;
        }
        if(bbb.getIsVCRX() == 1) {
            return vcrxRoom != null && vcrxRoom.getVcrxId() != null;
        }
        if(RoomDTO.BBB.equalsIgnoreCase(bbb.getVcrType()) && bbb.getVcrClassId() != null) {
            return true;
        }
        return false;
    }

    public static RoomDTO toRoomDTO(Object[] records) {
        RoomResult result = new RoomResult();
        result.setBbb((MdlTpeBBBSimple) records[0]);
        result.setCalendar((MdlTpeCanlendarTeach) records[1]);
        result.setVcrxRoom((MdlVCRXRoom) records[2]);
        result.setTotalUserNormal((Long) records[3]);
        result.setTotalUserAudit((Long) records[4]);
        result.setTeacher((LmsMdlUserData) records[5]);
        return result.toRoomDTO();
    }

    public static RoomDTO toRoomDTOJoined(Object[] records) {
        RoomResult result = new RoomResult();
        result.setBbb((MdlTpeBBBSimple) records[0]);
        result.setLogMove((LmsMdlLogsserviceMoveUser) records[1]);
        result.setVcrxRoom((MdlVCRXRoom) records[2]);
        result.setCalendar((MdlTpeCanlendarTeach) records[3]);
        result.setTeacher((LmsMdlUserData) records[4]);

        RoomDTO room = result.toRoomDTO();
        room.setOpened(true);
        room.setJoined(true);
        return room;
    }

    public static RoomDTO toPureRoom(Object[] records) {
        RoomResult result = new RoomResult();
        result.setBbb((MdlTpeBBBSimple) records[0]);
        result.setCalendar((MdlTpeCanlendarTeach) records[1]);
        result.setVcrxRoom((MdlVCRXRoom) records[2]);
        return result.toRoomDTO();
    }
}