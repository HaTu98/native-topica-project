package com.topica.lms.repository.lms;

import com.topica.lms.model.lms.LmsMdlLogsserviceInOut;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface LmsMdlLogsserviceInOutRepository extends JpaRepository<LmsMdlLogsserviceInOut, Long> {

  @Query(value = "SELECT NEW com.topica.adapter.common.dto.LogInOutDTO(log.roomid, role.roleId) "
      + "FROM LmsMdlLogsserviceInOut log "
      + "JOIN LmsMdlRoleAssignments role "
      + " ON role.userid = log.userid "
      + "WHERE role.roleId = 9 "
      + " AND log.roomid = :roomId "
      + "GROUP BY log.roomid ")
  Object getPoJoinRoom(@Param("roomId") Long roomId);

  @Query(value = "SELECT log.userid FROM LmsMdlLogsserviceInOut log "
          + " LEFT JOIN LmsMdlRoleAssignments role ON log.userid = role.userid "
          + " LEFT JOIN LmsMdlUserInfoData user ON log.userid = user.userid "
          + " WHERE log.roomid = :roomId "
          + "   AND role.roleId IN (3, 10, 11, 12) "
          + "   AND log.timeIn IS NOT NULL "
          + "   AND log.timeOut IS NOT NULL "
          + "   AND user.fieldid = 93 "
          + "   AND user.data = 'VN' "
          + " GROUP BY log.userid "
          + " ORDER BY SUM(log.timeOut) - SUM(log.timeIn) DESC ")
  List<Long> getRealTeacherVNOfRoom(@Param("roomId") Long roomId, Pageable pageable);


  @Query(value = "SELECT log.userid FROM LmsMdlLogsserviceInOut log "
          + " LEFT JOIN LmsMdlRoleAssignments role ON log.userid = role.userid "
          + " LEFT JOIN LmsMdlUserInfoData user ON log.userid = user.userid "
          + " WHERE log.roomid = :roomId "
          + "   AND role.roleId IN (3, 10, 11, 12) "
          + "   AND log.timeIn IS NOT NULL "
          + "   AND log.timeOut IS NOT NULL "
          + "   AND user.fieldid = 93 "
          + "   AND user.data <> 'VN' "
          + " GROUP BY log.userid "
          + " ORDER BY SUM(log.timeOut) - SUM(log.timeIn) DESC ")
  List<Long> getRealTeacherOfRoom(@Param("roomId") Long roomId, Pageable pageable);


  @Query(value = "SELECT SUM(log.timeOut) - SUM(log.timeIn) FROM LmsMdlLogsserviceInOut log "
          + "WHERE log.roomid = :roomId "
          + " AND log.userid = :userId "
          + " AND log.timeIn IS NOT NULL "
          + " AND log.timeOut IS NOT NULL ")
  Long getTotalTimeLearnInClass(@Param("roomId") Long roomId,@Param("userId") Long userId);

  @Query(value = "SELECT log.timeIn FROM LmsMdlLogsserviceInOut log " +
          "WHERE log.userid = ?1 " +
          "AND log.action = 'in' " +
          "ORDER BY log.timeIn DESC ")
  List<Long> getTimeInJoinRoomLatestByUserId(Long userId, Pageable pageable);
}
