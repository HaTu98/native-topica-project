package com.topica.lms.service.lms.impl.course;

import com.topica.adapter.common.dto.response.TransactionHistory;
import com.topica.adapter.common.dto.response.TransactionHistoryResponse;
import com.topica.adapter.common.service.BaseUserSessionService;
import com.topica.adapter.common.service.course.ActivePackageService;
import com.topica.adapter.common.service.course.TransactionHistoryService;
import com.topica.lms.model.lms.LmsMdlUserInfoData;
import com.topica.lms.service.lms.room.LmsMdlUserInfoDataService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service("transactionHistoryServiceSimple")
@Slf4j
public class TransactionHistoryServiceSimpleImpl extends BaseUserSessionService implements TransactionHistoryService {

  @Autowired
  private ActivePackageService packageService;

  @Autowired
  private LmsMdlUserInfoDataService infoDataService;

  @Override
  public Optional<List<TransactionHistory>> getTransactionHistory() {
    Long userId = this.getUserSession().getMdlUser().getId();
    LmsMdlUserInfoData userInfo = infoDataService.findByUseridAndFieldid(userId, 88);
    if (userInfo == null) {
      return Optional.empty();
    }
    String contactId = userInfo.getData();
    TransactionHistoryResponse transactionHistory = packageService.getTransactionHistory(contactId);
    return Optional.of(transactionHistory.getData());
  }
}
