package com.topica.lms.model.lms;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "mdl_vcrx_user")
public class MdlVCRXUser {
    @Id
    private Long id;
    private Long userId;
    private Long participantid;
    private Long timecreated;
}
