package com.topica.lms.repository.lms;

import com.topica.lms.model.lms.LmsMdlUserInfoData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface LmsMdlUserInfoDataRepository extends JpaRepository<LmsMdlUserInfoData,Long> {

  LmsMdlUserInfoData findByUseridAndFieldid(Long userId, Integer fieldId);

  @Query("UPDATE LmsMdlUserInfoData obj SET obj.data = :packageName WHERE obj.userid=:userId AND obj.fieldid = 91")
  void updatePackage(@Param("packageName") String packageName, @Param("userId") String userId);

  @Query("UPDATE LmsMdlUserInfoData obj SET obj.data = :packageParent WHERE obj.userid=:userId AND obj.fieldid = 92")
  void updatePackageParent(@Param("packageParent") String packageParent, @Param("userId") String userId);


}
