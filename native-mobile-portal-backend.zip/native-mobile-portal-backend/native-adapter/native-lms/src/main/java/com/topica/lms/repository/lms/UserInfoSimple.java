package com.topica.lms.repository.lms;

import com.topica.adapter.common.dto.PersonalInfoDTO;
import com.topica.adapter.common.dto.UserInfoDTO;
import com.topica.lms.model.lms.LmsMdlRole;
import com.topica.lms.model.lms.LmsMdlUserData;
import com.topica.lms.model.lms.LmsMdlUserInfoData;
import com.topica.lms.model.lms.MdlVCRXUser;
import lombok.Data;
import org.springframework.util.CollectionUtils;

import java.util.List;

@Data
public class UserInfoSimple extends PersonalInfoDTO {

    public UserInfoSimple(LmsMdlUserData user, LmsMdlRole role, MdlVCRXUser vcrxUser) {
        this.setId(user.getId());
        this.setUserName(user.getUsername());
        this.setRoleName(role.getShortname());
        this.setFirstName(user.getFirstName());
        this.setLastName(user.getLastName());
        this.setPhone1(user.getPhone1());
        this.setPhone2(user.getPhone2());
        this.setEmail(user.getEmail());

        UserInfoDTO userInfo = UserInfoDTO.builder()
                .userID(this.getId())
                .firstName(this.getFirstName())
                .lastName(this.getLastName())
                .phone1(this.getPhone1())
                .email(this.getEmail())
                .vcrxuserid(vcrxUser != null ? vcrxUser.getParticipantid() : null)
                .build();
        this.setUserInfo(userInfo);
    }

    public void setInfoData(List<LmsMdlUserInfoData> info) {
        if(CollectionUtils.isEmpty(info)) return;
        info.parallelStream().forEach(i -> {
            switch (i.getFieldid()) {
                case CONTACT_ID:
                    this.setContactId(i.getData());
                    break;
                case LEVEL:
                    this.setLevel(i.getData());
                    break;
                case PACKAGE_PARENT:
                    this.setPackageParent(i.getData());
                    break;
                case PACKAGE_CODE:
                    this.setPackageCode(i.getData());
                    break;
                case GENDER:
                    this.setGender(i.getData());
                    break;
                case BIRTHDAY:
                    this.setBirthday(i.getData());
                    break;
            }
        });
    }
}
