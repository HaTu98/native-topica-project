package com.topica.lms.model.lms;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@AllArgsConstructor
@Data
@Entity
@EqualsAndHashCode(of = "id")
@NoArgsConstructor
@Table(name = "mdl_materialservice")
public class MdlMaterialService {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "course_id")
    private Long courseId;

    @Column(nullable = false)
    private String code;

    @Column(nullable = false)
    private String subject;

    @Column(name = "subject_code")
    private String subjectCode;

    @Column(name = "subject_type")
    private String subjectType;

    @Column(name = "teacher_type")
    private String teacherType;

    @Column(name = "student_type")
    private String studentType;

    @Column(name = "level_outline")
    private String levelOutline;

    @Column()
    private String topic;

    @Column()
    private String objective;

    @Column(name = "class_outline")
    private String classOutline;

    @Column()
    private String background;

    @Column(name = "video_warmup")
    private String videoWarmUp;

    @Column(name = "lesson_plan")
    private String lessonPlan;

    @Column(name = "related_subject")
    private String relatedSubject;

    @Column(name = "time_begin")
    private Long timeBegin;

    @Column(name = "timecreated")
    private Long timeCreated;

    @Column(name = "timemodified")
    private Long timeModified;

    @Column()
    private Long status;

    @Column(name = "fileurl")
    private String fileUrl;

    @Column(name = "origin_code")
    private String originCode;

    @Column(name = "outline_vn")
    private String outlineVn;

    @Column(name = "outline_homework")
    private String outlineHomework;

    @Column(name = "link_video_warmup")
    private String linkVideoWarmUp;

}

