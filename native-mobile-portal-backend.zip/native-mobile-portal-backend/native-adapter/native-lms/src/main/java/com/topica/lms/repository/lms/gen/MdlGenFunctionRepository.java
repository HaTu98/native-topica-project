package com.topica.lms.repository.lms.gen;

import com.topica.lms.model.lms.MdlGenFunction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MdlGenFunctionRepository extends JpaRepository<MdlGenFunction, Long> {
}
