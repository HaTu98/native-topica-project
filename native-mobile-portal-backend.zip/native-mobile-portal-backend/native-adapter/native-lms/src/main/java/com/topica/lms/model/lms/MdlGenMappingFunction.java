package com.topica.lms.model.lms;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Data
@EqualsAndHashCode(of = "id")
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "mdl_gen_mapping_function")
public class MdlGenMappingFunction {

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Long id;

  @Column(name = "gen_code")
  private String genCode;

  @Column(name = "function_code")
  private String functionCode;
}
