package com.topica.lms.service.lms.gen;

import com.topica.adapter.common.exception.BusinessException;
import com.topica.lms.model.lms.MdlGenMappingFunction;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

public interface MdlGenMappingFunctionService {
    List<String> getUserGen() throws BusinessException;
    List<MdlGenMappingFunction> findByGenCode(String genCode);
}
