package com.topica.lms.service.lms;

import com.topica.adapter.common.dto.PersonalInfoDTO;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.service.BaseService;
import com.topica.adapter.common.service.user.UserServicePortal;
import com.topica.lms.model.lms.LmsMdlUserData;

import java.util.Optional;

public interface UserSimpleService extends BaseService<LmsMdlUserData, Long>, UserServicePortal {

  LmsMdlUserData findByUsername(String userName);

  PersonalInfoDTO findPersonalInfo(Long studentId) throws BusinessException;

  String getUserCountry(Long userId);

  Optional<Long> getIdVCRX(Long userId);
}
