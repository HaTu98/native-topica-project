package com.topica.lms.model.lms;

import lombok.*;

import javax.persistence.*;

@AllArgsConstructor
@Data
@Entity
@EqualsAndHashCode(of = "id")
@NoArgsConstructor
@Table(name = "mdl_role")
@Builder
public class LmsMdlRole {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "name", nullable = false)
    private String name;
    
    @Column(name = "shortname", nullable = false)
    private String shortname;

    @Column(name = "description", nullable = false)
    private String description;
    
    @Column(name = "sortorder", nullable = false)
    private Long sortorder;
    
    @Column(name = "archetype", nullable = false)
    private String archetype;

}
