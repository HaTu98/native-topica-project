package com.topica.lms.service.lms.impl;

import com.topica.adapter.common.dto.request.KibanaLogDTO;
import com.topica.adapter.common.model.portal.SigninHistory;
import com.topica.adapter.common.service.log.ExternalLogService;
import com.topica.adapter.common.service.room.TraceLogBlackBoxService;
import com.topica.lms.service.lms.room.LmsMdlLogsserviceInOutService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.HashMap;

@Service("traceLogBlackBoxServiceImpl")
@Slf4j
public class TraceLogBlackBoxServiceImpl implements TraceLogBlackBoxService {

    private final static String SOURCE = "portal_nvn";

    @Value("${portal.warning-last-join-room-day}")
    protected int warningLastJoinRoomDay;

    @Autowired
    private LmsMdlLogsserviceInOutService logsserviceInOutService;

    @Autowired
    private ExternalLogService externalLogService;

    @Override
    public void traceLogLogin(SigninHistory model) {
        KibanaLogDTO log = KibanaLogDTO.builder()
                .objectType("Student")
                .objectId(model.getUserid().toString())
                .objectName(model.getUsername())
                .objectAttribute("username=" + model.getUsername())
                .actionType("login_portal")
                .actionTime(model.getTime().getTime())
                .targetType("client_portal_" + model.getServiceType())
                .targetId(model.getDeviceId())
                .targetKey("deviceId")
                .targetName(model.getOs())
                .targetAttribute("device=" + model.getDevice() + ";appversion=" + model.getAppVersion())
                .source(SOURCE)
                .build();
        externalLogService.save(log);

    }

    @Override
    public long calTimeComeBackFromLast(Long userId, boolean isFromCurrentTime) {
        Long time = logsserviceInOutService.getTimeBetweenTwoTimeJoinClassLatest(userId, isFromCurrentTime);
        int warningLastJoinRoomTime = warningLastJoinRoomDay * 24 * 60 * 60;

        return Math.abs(time) - Math.abs(warningLastJoinRoomTime);
    }

    @Override
    public void traceLogWarningReJoinRoom(Long userId, String serviceType, Long roomId, Long timeBack) {
        KibanaLogDTO log = KibanaLogDTO.builder()
                .objectType("Student")
                .objectId(String.valueOf(userId))
                .actionType("warning_last_time_join_room_too_long")
                .actionTime(System.currentTimeMillis())
                .source(SOURCE)
                .targetType("client_portal_" + serviceType)
                .targetId(roomId.toString())
                .targetKey("roomId")
                .customAttribute(new HashMap<String, Object>() {{
                    put("comeBackTime", timeBack);
                }})
                .build();
        externalLogService.save(log);
    }
}
