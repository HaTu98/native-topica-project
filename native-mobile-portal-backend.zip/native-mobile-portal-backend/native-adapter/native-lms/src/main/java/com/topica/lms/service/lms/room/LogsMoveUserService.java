package com.topica.lms.service.lms.room;


import com.topica.adapter.common.dto.RoomUserCountDTO;
import com.topica.lms.model.lms.LmsMdlLogsserviceMoveUser;

import java.util.Optional;

public interface LogsMoveUserService {
  RoomUserCountDTO getUserCountWithRoleNormal(Long roomId);
  boolean checkTeacherJoin(Long roomId);
  Optional<LmsMdlLogsserviceMoveUser> getLastRoomId(Long userId);
}