package com.topica.lms.service.lms.impl;


import com.topica.adapter.common.constant.PageUtil;
import com.topica.adapter.common.dto.RoomUserCountDTO;
import com.topica.lms.model.lms.LmsMdlLogsserviceMoveUser;
import com.topica.lms.repository.lms.LogsMoveUserRepository;
import com.topica.lms.service.lms.room.LogsMoveUserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class LogsMoveUserServiceImpl implements LogsMoveUserService {

  public static final long ROLE_ID_TEACHER = 3;
  public static final long ROLE_ID_STUDENT = 5;

  @Autowired
  private LogsMoveUserRepository moveUserRepository;

  @Override
  public RoomUserCountDTO getUserCountWithRoleNormal(Long roomId) {
    return moveUserRepository.getUserCountWithRoleNormal(roomId, ROLE_ID_STUDENT);
  }

  @Override
  public boolean checkTeacherJoin(Long roomId) {
    long countTeacher = moveUserRepository.existsTeacherInRoom(roomId, ROLE_ID_TEACHER);
    return countTeacher >= 1 ? true : false;
  }

    @Override
    public Optional<LmsMdlLogsserviceMoveUser> getLastRoomId(Long userId) {
        List<LmsMdlLogsserviceMoveUser> lastRoomId = this.moveUserRepository.getLastRoomId(userId, PageUtil.FIRST_RESULT);
        if(CollectionUtils.isEmpty(lastRoomId)) {
            return Optional.empty();
        }
        return Optional.of(lastRoomId.get(0));
    }
}