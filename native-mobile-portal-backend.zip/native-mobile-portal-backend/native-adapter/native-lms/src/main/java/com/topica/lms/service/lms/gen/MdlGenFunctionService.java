package com.topica.lms.service.lms.gen;

public interface MdlGenFunctionService {
}
