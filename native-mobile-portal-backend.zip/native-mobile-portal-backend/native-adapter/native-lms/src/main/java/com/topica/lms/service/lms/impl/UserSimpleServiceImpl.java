package com.topica.lms.service.lms.impl;

import com.google.common.base.Strings;
import com.topica.adapter.common.config.room.ErrorMessageConfig;
import com.topica.adapter.common.constant.ServiceType;
import com.topica.adapter.common.dto.PersonalInfoDTO;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.exception.ExceptionCode;
import com.topica.adapter.common.model.PortalUser;
import com.topica.adapter.common.request.LoginRequest;
import com.topica.adapter.common.request.UpdateInfoRequest;
import com.topica.adapter.common.service.invoker.InvokerService;
import com.topica.adapter.common.service.market.MarketService;
import com.topica.lms.model.lms.LmsMdlUserData;
import com.topica.lms.model.lms.LmsMdlUserInfoData;
import com.topica.lms.repository.lms.LmsMdlUserDataRepository;
import com.topica.lms.repository.lms.UserInfoSimple;
import com.topica.lms.response.LoginVCRXResponse;
import com.topica.lms.service.lms.UserSimpleService;
import com.topica.lms.service.lms.room.LmsMdlUserInfoDataService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Optional;

import static com.topica.adapter.common.config.room.ErrorMessageConfig.*;
import static com.topica.adapter.common.constant.ServiceType.LMS;

@Slf4j
@Service("UserSimpleService")
@Transactional
public class UserSimpleServiceImpl implements UserSimpleService {

    @Autowired
    private LmsMdlUserDataRepository userDataRepository;

    @Autowired
    private LmsMdlUserDataRepository userRepository;

    @Autowired
    private LmsMdlUserInfoDataService lmsMdlUserInfoDataService;

    @Autowired
    private MarketService marketService;

    @Value("${domain.lms.student}")
    private String lmsURL;

    @Value("${lms.key.join.room.vcrx}")
    private String lmsKeyJoinRoom;

    @Autowired
    private InvokerService invokerService;

    @Autowired
    private ErrorMessageConfig errorMessageConfig;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Value("${function.mobile.vn}")
    private String functionMobileVN;

    @Value("${function.livestream}")
    private String functionMobileLive;

    @Value("${portal.user.update.require-password}")
    private Boolean requirePassword;

    @Override
    public String getUserCountry(Long userId) {
        return userDataRepository.getUserCountry(userId);
    }

    @Override
    public LmsMdlUserData findByUsername(String userName) {
        return userDataRepository.findByUsername(userName);
    }

    @Override
    public LmsMdlUserData save(LmsMdlUserData model) {
        return model;
    }

    @Override
    public LmsMdlUserData get(Long id) {
        return userDataRepository.getOne(id);
    }

    @Override
    public LmsMdlUserData update(LmsMdlUserData model) {
        return model;
    }

    @Override
    public void delete(Long id) {
    }

    @Override
    public Optional<? extends PortalUser> findUser(String userName, ServiceType type) {
        return userDataRepository.findFirstByUsername(userName);
    }

    @Override
    public PersonalInfoDTO findPersonalInfo(Long userId) throws BusinessException {
        UserInfoSimple info = userDataRepository.findPersonalInfo(userId);
        if (info == null) {
            throw new BusinessException(ExceptionCode.User.USER_NOT_FOUND, "user not found !");
        }
        info.setInfoData(this.userDataRepository.getInfoByUserid(info.getId(), PersonalInfoDTO.listField));
        info.setServiceType(LMS);
        info = marketService.setPackages(info, LMS);
        return info;
    }

    @Override
    public void checkValidGen(PersonalInfoDTO info, ServiceType serviceType) throws BusinessException {
        List<String> listGenCode = this.getListGenCode(info);
        if(!CollectionUtils.isEmpty(listGenCode)) {
            boolean anyValidGen = listGenCode.parallelStream().anyMatch(p -> isValidFunctionGen(p));
            if (anyValidGen) return;
        }
        throw new BusinessException(ExceptionCode.Authentication.AUTHENTICATION_GEN_INVALID, this.getMsgForInvalidGEN());
    }

    @Override
    public boolean changePassword(ServiceType serviceType, Long userId, String oldPassword, String newPassword) throws BusinessException {
        LmsMdlUserData userData = userDataRepository.findOne(userId);
        if (userData == null) {
            throw new BusinessException(ExceptionCode.User.USER_NOT_FOUND, "user not found !");
        }
        if (!this.passwordEncoder.matches(oldPassword, userData.getPassword())) {
            throw new BusinessException(ExceptionCode.User.INCORRECT_PASSWORD, "Old Password incorrect");
        }
        userData.setPassword(this.passwordEncoder.encode(newPassword));
        userDataRepository.save(userData);
        return true;
    }

    @Override
    public Optional<? extends PortalUser> update(Long userId, ServiceType type, UpdateInfoRequest updateInfoRequest) throws BusinessException {
        LmsMdlUserData userData = userDataRepository.findOne(userId);
        if (userData == null) {
            throw new BusinessException(ExceptionCode.User.USER_NOT_FOUND, "user not found !");
        }
        if (requirePassword && !this.passwordEncoder.matches(updateInfoRequest.getPassword(), userData.getPassword())) {
            throw new BusinessException(ExceptionCode.User.INCORRECT_PASSWORD, "Old Password incorrect");
        }
        this.updateUserInfoData(userId, updateInfoRequest);
        userData.setFirstName(updateInfoRequest.getFirstName());
        userData.setLastName(updateInfoRequest.getLastName());
        userData.setPhone1(updateInfoRequest.getPhone());
        userData.setEmail(updateInfoRequest.getEmail());
        return Optional.of(userDataRepository.save(userData));
    }

    private void updateUserInfoData(Long userId, UpdateInfoRequest updateInfoRequest) {
        if (!Strings.isNullOrEmpty(updateInfoRequest.getGender())) {
            lmsMdlUserInfoDataService.insert(LmsMdlUserInfoData.builder()
              .userid(userId).fieldid(PersonalInfoDTO.GENDER).data(updateInfoRequest.getGender()).build());
        }
        if (!Strings.isNullOrEmpty(updateInfoRequest.getBirthday())) {
            lmsMdlUserInfoDataService.insert(LmsMdlUserInfoData.builder()
              .userid(userId).fieldid(PersonalInfoDTO.BIRTHDAY).data(updateInfoRequest.getBirthday()).build());
        }
    }

    private boolean isValidFunctionGen(String genCode) {
        List<String> allowFuncs = this.userDataRepository.getListFunction(genCode);
        return allowFuncs.parallelStream()
                .anyMatch(f -> f.contains(functionMobileVN) || f.contains(functionMobileLive));
    }

    @Override
    public Optional<Long> registerVCRXUser(LoginRequest request) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Basic", lmsKeyJoinRoom);
        headers.set("Accept", "application/json");
        HttpEntity data = new HttpEntity(request, headers);

        String url = lmsURL + "/vcrx/portal/login";
        Optional<LoginVCRXResponse> response = invokerService.postHeader(url, data, LoginVCRXResponse.class);
        if (!response.isPresent()) {
            log.error("CALL REGISTER VCRX USER FROM LMS40 FAIL: " + request.getUsername());
        }

        LoginVCRXResponse.Response vcrxLoginRes = response.get().getResult();
        if (!response.get().getSuccess() || !vcrxLoginRes.getStatus() || vcrxLoginRes.getData() == null || vcrxLoginRes.getData().getParticipantid() == null) {
            log.error("REGISTER VCRX USER FROM LMS40 FAIL: " + request.getUsername());
            return Optional.empty();
        }
        return Optional.ofNullable(vcrxLoginRes.getData().getParticipantid());
    }

    @Override
    public PersonalInfoDTO findPersonalInfo(Long userId, ServiceType type) throws BusinessException {
        return this.findPersonalInfo(userId);
    }

    public String getMsgForExpiredPackage() {
        String msg = this.errorMessageConfig.getByKey(PACKAGE_EXPIRED);
        if(StringUtils.isEmpty(msg)) msg = DEFAULT_PACKAGE_EXPIRED;
        return msg;
    }

    @Override
    public String getMsgForDeactivedPackage() {
        String msg = this.errorMessageConfig.getByKey(PACKAGE_DEACTIVED);
        if(StringUtils.isEmpty(msg)) msg = DEFAULT_PACKAGE_DEACTIVED;
        return msg;
    }

    @Override
    public String getMsgForInvalidGEN() {
        String msg = this.errorMessageConfig.getByKey(INVALID_GEN);
        if(StringUtils.isEmpty(msg)) msg = DEFAULT_INVALID_GEN;
        return msg;
    }

    @Override
    public Optional<Long> getIdVCRX(Long userId) {
        try {
            return userRepository.getVCRXUserId(userId);
        } catch (Exception e) {
            log.error("getIdVCRX ERROR: {}", e.getMessage());
            return Optional.empty();
        }
    }
}