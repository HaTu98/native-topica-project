package com.topica.lms.service.lms.room.impl;

import com.topica.adapter.common.config.room.AcceptVCR;
import com.topica.adapter.common.constant.SubjectType;
import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.dto.response.JoinRoomResponse;
import com.topica.adapter.common.dto.response.RoomPresentResponse;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.exception.RoomError;
import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.request.ListRoomRequest;
import com.topica.adapter.common.service.room.JoinRoomMaker;
import com.topica.adapter.common.service.room.RoomServicePortal;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service("roomServiceSimple")
public class RoomServiceSimpleImpl extends BaseRoomServiceSimple implements RoomServicePortal {

    @Value("${domain.lms.student}")
    private String domainLms40;

    @Autowired
    @Qualifier("joinRoomSimple56Maker")
    private JoinRoomMaker joinRoomMaker;

    @Autowired
    @Qualifier("joinRoomAuditSimpleMaker")
    private JoinRoomMaker joinRoomAuditMaker;

    private @Autowired AcceptVCR acceptVCR;

    @Override
    public RoomPresentResponse presentRoom() {
        ListRoomRequest request = this.getListRoomRequest(null);
        return this.presentRoom(request);
    }

    @Override
    public ListRoomRequest getListRoomRequest(String classType) {
        PortalMdlUser user = this.getUserSession();
        ListRoomRequest request = this.getAbstractListRoomRequest(classType, user);
        List<String> acceptVCR = this.acceptVCR.getForSimple();
        Collection<String> queryVCRs = this.acceptVCR.changeBBBToVCRX(acceptVCR);
        request.setAcceptVCRTypes(acceptVCR);
        request.setQueryVCRTypes(queryVCRs);
        return request;
    }

    @Override
    public JoinRoomResponse joinRoom(Long classId) throws BusinessException {
        log.info("JOIN ROOM: user SIMPLE :{} - roomID: {}", this.getUserSession().getMdlUser().getUsername(), classId);
        Optional<RoomDTO> targetRoom = this.getRoom(classId);
        if (!targetRoom.isPresent()) {
            throw new BusinessException(RoomError.NOT_FOUND_ROOM, "Not found room ID: " + classId);
        }
        return joinRoomMaker.join(targetRoom.get());
    }

    @Override
    public JoinRoomResponse reJoinRoom(RoomDTO joinedRoom) throws BusinessException {
        log.info("REJOIN ROOM: user SIMPLE :{} - roomID: {}", this.getUserSession().getMdlUser().getUsername(), joinedRoom.getId());
        return joinRoomMaker.reJoin(joinedRoom);
    }

    @Override
    public JoinRoomResponse quickJoinRoom(SubjectType subjectType) throws BusinessException {
        log.info("QUICK JOIN ROOM: user SIMPLE: {} - type: {}", this.getUserSession().getMdlUser().getUsername(), subjectType);
        return this.joinRoomMaker.quickJoin(subjectType);
}

    @Override
    public JoinRoomResponse quickJoinRoomAudit(SubjectType subjectType) throws BusinessException {
        log.info("QUICK JOIN ROOM AUDIT: user SIMPLE: {} - type: {}", this.getUserSession().getMdlUser().getUsername(), subjectType);
        return this.joinRoomAuditMaker.quickJoin(subjectType);
    }
}