package com.topica.lms.repository.lms.gen;

import com.topica.lms.model.lms.MdlGenMappingFunction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MdlGenMappingFunctionRepository extends JpaRepository<MdlGenMappingFunction, Long> {
    List<MdlGenMappingFunction> findByGenCode(String genCode);
}
