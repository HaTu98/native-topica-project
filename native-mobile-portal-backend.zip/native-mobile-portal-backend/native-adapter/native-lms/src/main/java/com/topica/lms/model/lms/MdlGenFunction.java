package com.topica.lms.model.lms;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Data
@EqualsAndHashCode(of = "id")
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "mdl_gen_function")
public class MdlGenFunction {
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Long id;

  @Column(name = "function_code", nullable = false)
  private String functionCode;

  @Column(name = "description")
  private String description;

  @Column(name = "status")
  private String status;

  @Column(name = "created_at")
  private Long createdAt;

  @Column(name = "created_by")
  private String createdBy;

  @Column(name = "updated_at")
  private String updatedAt;

  @Column(name = "updated_by")
  private String updatedBy;
}
