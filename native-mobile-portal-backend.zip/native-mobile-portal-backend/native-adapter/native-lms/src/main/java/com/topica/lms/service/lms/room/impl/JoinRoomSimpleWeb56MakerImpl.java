package com.topica.lms.service.lms.room.impl;

import com.topica.adapter.common.config.room.AcceptVCR;
import com.topica.adapter.common.constant.SubjectType;
import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.dto.response.JoinRoomResponse;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.exception.RoomError;
import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.service.room.JoinRoomMaker;
import com.topica.adapter.common.service.room.RoomServicePortal;
import com.topica.adapter.common.util.RoomUtil;
import com.topica.booking.request.TicketRequest;
import com.topica.booking.service.BookingRoomService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

import static com.topica.adapter.common.constant.RoleInClass.NORMAL;
import static com.topica.adapter.common.constant.ServiceType.LMS;
import static com.topica.adapter.common.dto.RoomDTO.*;

@Slf4j
@Service("joinRoomSimpleWeb56MakerImpl")
public class JoinRoomSimpleWeb56MakerImpl extends BaseJoinRoomSimple implements JoinRoomMaker {

    @Value("${lms.key.get.vcr.link}")
    private String keyGetVCRLink;

    @Autowired
    private AcceptVCR acceptVCR;

    @Autowired
    private BookingRoomService bookingRoomService;

    @Autowired
    @Qualifier("roomServiceWebSimple")
    private RoomServicePortal roomService;

    @Override
    public boolean isFailJoinVCRX(JoinRoomResponse response) {
        return StringUtils.isEmpty(response.getLink());
    }

    @Override
    public JoinRoomResponse joinInto(RoomDTO targetRoom) throws BusinessException {
        JoinRoomResponse response;
        boolean isJoinFail;
        switch (targetRoom.getVcrType()) {
            case ADB:
                response = this.joinADOBE(targetRoom, false);
                isJoinFail = this.isFailJoinADOBE(response);
                break;
            case VCRX:
                response = this.joinVCRX(targetRoom);
                isJoinFail = this.isFailJoinVCRX(response);
                if(!isJoinFail) {
                    this.checkVCRXClassId(response);
                }
                break;
            case BBB:
                response = this.joinBBB(targetRoom);
                isJoinFail = this.isFailJoinBBB(response);
                break;
            default:
                throw new BusinessException(RoomError.NOT_SUPPORT_VCR, "Not support VCR");
        }
        if (isJoinFail) {
            this.bookingRoomService.returnTicket(targetRoom.getTicketId());
        }
        return response;
    }

    @Override
    public TicketRequest buildTicketRequest(SubjectType type) {
        String typeClass = RoomUtil.checkTypeClass(type.name());
        List<String> acceptVCRs = this.acceptVCR.getForSimpleWeb();
        PortalMdlUser user = this.getUserSession();
        String level = this.checkLevel(user.getLevel(), typeClass, user.getPackageParent());
        return TicketRequest
                .builder()
                .level(level)
                .roomType(typeClass)
                .teacherType(RoomUtil.getTeacherType(user.getPackageParent(), typeClass))
                .timeAvailable(RoomUtil.getTimeAvailableToSeconds())
                .role(NORMAL.name())
                .serviceType(LMS.name())
                .acceptVCRType(acceptVCRs)
                .userId(user.getMdlUser().getId())
                .userName(user.getMdlUser().getUsername())
                .build();
    }

    @Override
    public List<RoomDTO> getRefreshListRoom(String classType) throws BusinessException {
        return this.roomService.listRoom(classType);
    }

    @Override
    public String getSource() {
        return WEB_SOURCE;
    }
}