package com.topica.lms.service.lms.impl.course;

import com.topica.adapter.common.constant.ServiceType;
import com.topica.adapter.common.dto.MarketPackage;
import com.topica.adapter.common.dto.request.ActiveRequest;
import com.topica.adapter.common.dto.response.GetPackageResponse;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.service.BaseUserSessionService;
import com.topica.adapter.common.service.course.ActivePackageService;
import com.topica.adapter.common.service.course.PackageServicePortal;
import com.topica.adapter.common.service.invoker.InvokerService;
import com.topica.lms.model.lms.LmsMdlUserInfoData;
import com.topica.lms.service.lms.room.LmsMdlUserInfoDataService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service("packageServiceSimple")
@Slf4j
public class PackageServiceSimpleImpl extends BaseUserSessionService implements
    PackageServicePortal {

  @Autowired
  private ActivePackageService packageService;

  @Autowired
  private LmsMdlUserInfoDataService infoDataService;

  @Autowired
  InvokerService invokerService;

  @Override
  public Optional<GetPackageResponse> getListPackage() {
    Long userId = this.getUserSession().getMdlUser().getId();
    LmsMdlUserInfoData userInfo = infoDataService.findByUseridAndFieldid(userId, 88);
    String contactId = userInfo.getData();
    GetPackageResponse response = packageService.getListPackage(contactId);
    return Optional.of(response);
  }

  @Override
  public Optional<Boolean> activePackage(ActiveRequest activeRequest) {
    List<MarketPackage> deactivedPackage = Collections.emptyList();
    try {
      deactivedPackage = isCanActive();
    } catch (BusinessException e) {
      return Optional.of(false);
    }
    Optional<MarketPackage> targetPackage = deactivedPackage.stream()
            .filter(p -> activeRequest.getProductId().equals(p.getProductId()))
            .findFirst();
    if(!targetPackage.isPresent()) {
      log.error("not found deactive package on request!");
      return Optional.of(false);
    }
    activeRequest.setGenCode(targetPackage.get().getGenCode());
    activeRequest.setUserId(this.getUserSession().getMdlUser().getId());
    return packageService.activePackage(activeRequest, ServiceType.LMS);
  }

  @Override
  public List<MarketPackage> isCanActive() throws BusinessException {
    List<MarketPackage> listPackage = getListPackage().get().getData();
    return packageService.isCanActive(listPackage);
  }
}