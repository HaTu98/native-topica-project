package com.topica.lms.service.lms.room.impl;

import com.topica.adapter.common.config.room.AcceptVCR;
import com.topica.adapter.common.constant.SubjectType;
import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.dto.response.JoinRoomResponse;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.exception.RoomError;
import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.service.room.JoinRoomMaker;
import com.topica.adapter.common.service.room.RoomServicePortal;
import com.topica.adapter.common.util.RoomUtil;
import com.topica.booking.request.TicketRequest;
import com.topica.booking.service.BookingRoomService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.topica.adapter.common.constant.RoleInClass.NORMAL;
import static com.topica.adapter.common.constant.ServiceType.LMS;
import static com.topica.adapter.common.dto.RoomDTO.ADB;
import static com.topica.adapter.common.dto.RoomDTO.VCRX;

@Slf4j
@Service("joinRoomSimple56Maker")
public class JoinRoomSimple56MakerImpl extends BaseJoinRoomSimple implements JoinRoomMaker {

    @Autowired
    private AcceptVCR acceptVCR;

    @Autowired
    private BookingRoomService bookingRoomService;

    @Autowired
    @Qualifier("roomServiceSimple")
    private RoomServicePortal roomServiceSimple;

    @Override
    public JoinRoomResponse joinInto(RoomDTO targetRoom) throws BusinessException {
        JoinRoomResponse response;
        boolean isJoinFail;
        switch (targetRoom.getVcrType()) {
            case ADB:
                response = this.joinADOBE(targetRoom, true);
                isJoinFail = this.isFailJoinADOBE(response);
                break;
            case VCRX:
                response = this.joinVCRX(targetRoom);
                isJoinFail = this.isFailJoinVCRX(response);
                if(!isJoinFail) {
                    response.setLink("");
                    this.checkVCRXClassId(response);
                }
                break;
            default: throw new BusinessException(RoomError.NOT_SUPPORT_VCR, "Not support VCR");
        }
        if(isJoinFail) {
            this.bookingRoomService.returnTicket(targetRoom.getTicketId());
        }
        return response;
    }

    @Override
    public TicketRequest buildTicketRequest(SubjectType type) {
        String typeClass = RoomUtil.checkTypeClass(type.name());
        List<String> acceptVCRs = this.acceptVCR.getForSimple();
        PortalMdlUser user = this.getUserSession();
        String level = this.checkLevel(user.getLevel(), typeClass, user.getPackageParent());
        return TicketRequest
                .builder()
                .level(level)
                .roomType(typeClass)
                .teacherType(RoomUtil.getTeacherType(user.getPackageParent(), typeClass))
                .timeAvailable(RoomUtil.getTimeAvailableToSeconds())
                .role(NORMAL.name())
                .serviceType(LMS.name())
                .acceptVCRType(acceptVCRs)
                .userId(user.getMdlUser().getId())
                .userName(user.getMdlUser().getUsername())
                .build();
    }

    @Override
    public List<RoomDTO> getRefreshListRoom(String classType) throws BusinessException {
        return this.roomServiceSimple.listRoom(classType);
    }

    @Override
    public String getSource() {
        return MOBILE_SOURCE;
    }
}