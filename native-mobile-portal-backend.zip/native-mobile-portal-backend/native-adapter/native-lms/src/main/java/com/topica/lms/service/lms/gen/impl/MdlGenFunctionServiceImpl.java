package com.topica.lms.service.lms.gen.impl;

import com.topica.lms.service.lms.gen.MdlGenFunctionService;
import org.springframework.stereotype.Service;

@Service
public class MdlGenFunctionServiceImpl implements MdlGenFunctionService {
}
