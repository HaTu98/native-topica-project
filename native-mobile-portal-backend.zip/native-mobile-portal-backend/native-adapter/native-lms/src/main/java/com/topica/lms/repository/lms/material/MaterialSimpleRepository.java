package com.topica.lms.repository.lms.material;

import com.topica.lms.model.lms.SimpleMdlMaterialservice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MaterialSimpleRepository extends JpaRepository<SimpleMdlMaterialservice, Long>{

    @Query("SELECT m FROM SimpleMdlMaterialservice m " +
            "WHERE m.teacherType in :teacherType " +
            "AND m.timeBegin >= :startTime " +
            "AND m.timeBegin <= :endTime " +
            "AND m.status = 1" +
            "AND m.studentType = :studentType " +
            "AND ((m.subjectType = 'LS' AND m.levelOutline = :levelLS ) OR (m.subjectType = 'SC' AND m.levelOutline = :levelSC)) " +
            "ORDER BY m.timeBegin ASC")
    List<SimpleMdlMaterialservice> findByTime(@Param("startTime") long startTime,
                                              @Param("endTime") long endTime,
                                              @Param("teacherType") List<String> teacherType,
                                              @Param("levelLS") String levelLS,
                                              @Param("levelSC") String levelSC,
                                              @Param("studentType") String studentType);

}
