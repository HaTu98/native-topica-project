package com.topica.lms.service.lms.rate;

import com.topica.adapter.common.constant.CaraRateType;
import com.topica.adapter.common.constant.RoleInClass;
import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.model.cara.CaraResponse;
import com.topica.adapter.common.model.cara.RateInfo;
import com.topica.adapter.common.model.cara.RateProperties;
import com.topica.adapter.common.request.CaraRequest;
import com.topica.adapter.common.service.invoker.InvokerService;
import com.topica.adapter.common.service.rating.BasePortalCaraService;
import com.topica.adapter.common.service.rating.RatingServicePortal;
import com.topica.adapter.common.service.room.RoomServicePortal;
import com.topica.lms.model.lms.LmsMdlLogsserviceMoveUser;
import com.topica.lms.repository.lms.room.RoomSimpleRepository;
import com.topica.lms.request.CaraRatingLMS;
import com.topica.lms.service.lms.room.LmsMdlLogsserviceInOutService;
import com.topica.lms.service.lms.room.LogsMoveUserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

import static com.topica.adapter.common.constant.CaraRateType.TEACHER;

@Slf4j
@Service("ratingServiceSimple")
public class RatingServiceSimpleImpl extends BasePortalCaraService implements RatingServicePortal {

    @Value("${cara.rate.id.lms}")
    private Long rateId;

    @Value("${cara.rate.id.lms.audit:6}")
    private Long rateIdAudit;

    @Value("${cara.rate.type.lms}")
    private String rateTypeLMS;

    @Autowired
    @Qualifier("roomServiceSimple")
    protected RoomServicePortal roomSimpleService;

    @Value("${api.lmsservice.cara.username}")
    private String caraUsername;

    @Value("${api.lmsservice.cara.password}")
    private String caraPassword;

    @Value("${api.lmsservice.cara.key}")
    private String caraKeyLMS;

    @Value("${api.lmsservice.url}")
    private String urlLMSService;

    @Autowired
    private InvokerService invokerService;
    @Autowired
    private LmsMdlLogsserviceInOutService inOutService;
    @Autowired
    private RoomSimpleRepository roomSimpleRepository;
    @Autowired
    private LogsMoveUserService logsMoveUserService;

    @Override
    public Optional<CaraResponse> canRate() {
        String token = this.getCaraToken();
        if(StringUtils.isEmpty(token)){
            return Optional.empty();
        }
        return this.isCanRate(token);
    }

    private Optional<CaraResponse> isCanRate(String token) {
        Long userId = this.getUserSession().getMdlUser().getId();

        Optional<LmsMdlLogsserviceMoveUser> lastLogStudy = this.getLastLogStudy(userId);
        if(!lastLogStudy.isPresent()) {
            return Optional.empty();
        }

        Optional<RoomDTO> room = this.getLastRoomLearned(lastLogStudy.get().getRoomidto());
        if(!room.isPresent() || this.isCurrentTime(room.get().getTimeAvailable())){
            return Optional.empty();
        }

        if(this.isRated(userId, room.get().getId(), token)){
            return Optional.empty();
        }

        CaraResponse caraResponse;
        try {
            String role = lastLogStudy.get().getRole();
            caraResponse = this.getCaraResponse(room.get(), this.getRateId(role), token, role);
            caraResponse.getData().setRate_type(rateTypeLMS);
        } catch (BusinessException e) {
            return Optional.empty();
        }
        return Optional.of(caraResponse);
    }

    @Override
    public Optional<CaraResponse> rating(CaraRequest request) {
        String token = this.getCaraToken();
        if(StringUtils.isEmpty(token)){
            return Optional.empty();
        }
        Optional<CaraResponse> validRequest = this.isValidRequest(request, token);
        if(!validRequest.isPresent()) {
            return Optional.empty();
        }

        this.completeRequest(request, validRequest);
        Long rateId = this.getRateId(validRequest.get().getData().getClass_info().getRole());
        RateInfo rateInfo = this.getRateInfo(request, token, rateId);

        this.ratingToLMSCara(request);
        return this.sendRateToCara(rateInfo, token);
    }

    private Optional sendRateToCara(RateInfo rateInfo, String token) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization",token);
        HttpEntity httpEntity = new HttpEntity(rateInfo, headers);

        String url = domainCaraServer.concat(uriCreateRate);
        Optional<ApiDataResponse> response = invokerService.postHeader(url, httpEntity, ApiDataResponse.class);

        if(!response.isPresent() || response.get().getCode() != 200){
            return Optional.empty();
        }
        return Optional.of(new CaraResponse(true));
    }

    private long getRateId(String roleInClass) {
        RoleInClass role = RoleInClass.ofString(roleInClass);
        switch (role) {
            case AUDIT: return rateIdAudit;
            case NORMAL:
                default: return rateId;
        }
    }

    private void completeRequest(CaraRequest request, Optional<CaraResponse> validRequest) {
        Long userId = this.getUserSession().getMdlUser().getId();
        request.setStudent_id(userId);
        request.setTeacher_id(validRequest.get().getData().getClass_info().getTeacher_id());
        request.setRoom_id(validRequest.get().getData().getClass_info().getRoom_id());
    }

    private Optional<CaraResponse> isValidRequest(CaraRequest request, String token) {
        if(CaraRateType.NONE == request.getVote()) {
            return Optional.empty();
        }
        return this.isCanRate(token);
    }

    private RateInfo getRateInfo(CaraRequest request, String token, Long rateId) {
        RateInfo rateInfo = new RateInfo(request);
        rateInfo.setRateId(rateId);
        rateInfo.setStudyTime(request.getTimeAvailable());
        Long timeConfig = getTimeConfig(token);
        rateInfo.setStatus(this.getStatusRate(request.getTimeAvailable(), timeConfig));

        if(!CollectionUtils.isEmpty(request.getOptions())) {
            List<RateProperties> rateProperties = this.getRateProperties(request);
            rateInfo.setExtraInfos(rateProperties);
            return rateInfo;
        }

        int optionId = CaraRateType.getCode(request.getVote());
        Long teacherId = TEACHER == request.getVote() ? request.getTeacher_id() : null;
        RateProperties properties = new RateProperties(optionId, teacherId);

        List<RateProperties> rateProperties = Arrays.asList(properties);
        rateInfo.setExtraInfos(rateProperties);
        return rateInfo;
    }

    private Optional<LmsMdlLogsserviceMoveUser> getLastLogStudy(Long userId) {
        return logsMoveUserService.getLastRoomId(userId);
    }

    private Optional<RoomDTO> getLastRoomLearned(Long roomId) {
        try {
            return roomSimpleService.getRoom(roomId);
        } catch (Exception e) {
            log.error("getLastRoomLearned error roomId:{}", roomId);
        }
        return Optional.empty();
    }

    @Override
    public Long getTeacherIdByRoomId(Long roomId){
        String teacherType = roomSimpleRepository.getTeacherTypeByRoomId(roomId);
        Long realTeacherOfRoom = inOutService.getRealTeacherOfRoom(roomId, teacherType);
        if(realTeacherOfRoom == 0) {
            log.error("getTeacherIdByRoomId: {} NULL", roomId);
        }
        return realTeacherOfRoom;
    }


    private String getBasicAuthToken() {
        String auth = caraUsername + ":" + caraPassword;
        String authEncode = Base64.getEncoder().encodeToString(auth.getBytes());
        return "Basic " + authEncode;
    }

    private void ratingToLMSCara(CaraRequest request) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Authorization", this.getBasicAuthToken());
        headers.add("X-API-KEY", caraKeyLMS);
        CaraRatingLMS data = CaraRatingLMS.from(request);
        HttpEntity requestCara = new HttpEntity(data, headers);
        log.info("ratingToLMSCara: {}", data);

        String url = urlLMSService.concat("/api/rating_class/rating");
        Optional<CaraResponse> response = invokerService.postHeader(url, requestCara, CaraResponse.class);
        boolean result = response.isPresent() && response.get().getStatus();
        if(!result) {
            log.error("ratingToLMSCara error: userName: {}", this.getUserSession().getMdlUser().getUsername());
        }
    }
}