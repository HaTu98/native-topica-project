package com.topica.lms.repository.lms;

import com.topica.lms.model.lms.LmsMdlUserData;
import com.topica.lms.model.lms.LmsMdlUserInfoData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface LmsMdlUserDataRepository extends JpaRepository<LmsMdlUserData, Long> {

  LmsMdlUserData findByUsername(String userName);
  Optional<LmsMdlUserData> findFirstByUsername(String userName);

  @Query(value = "SELECT NEW com.topica.lms.repository.lms.UserInfoSimple (u, r, vcrxUser) " +
          "FROM LmsMdlUserData u " +
          "left join LmsMdlRoleAssignments a on u.id = a.userid " +
          "left join LmsMdlRole r on a.roleId = r.id " +
          "left join MdlVCRXUser vcrxUser on u.id = vcrxUser.userId " +
          "WHERE u.id = :studentId")
  UserInfoSimple findPersonalInfo(@Param("studentId") Long studentId);

  @Query(value = "SELECT vcrxUser.participantid FROM MdlVCRXUser vcrxUser WHERE vcrxUser.userId = :userId")
  Optional<Long> getVCRXUserId(@Param("userId") Long userId);

  @Query(value = "SELECT info.data "
      + "FROM LmsMdlUserData user "
      + "JOIN LmsMdlUserInfoData info "
      + " ON info.userid = user.id "
      + "WHERE info.fieldid = 90 "
      + " AND user.id = :userId")
  String getUserCountry(@Param("userId") Long userId);

  @Query(value = "SELECT info FROM LmsMdlUserInfoData info WHERE info.userid = :userId and info.fieldid in :fieldIds")
  List<LmsMdlUserInfoData> getInfoByUserid(@Param("userId") Long userId, @Param("fieldIds") List<Integer> fieldIds);

  @Query(value = "SELECT map.functionCode " +
          "FROM MdlGenMappingFunction map "
          + "INNER JOIN MdlGenFunction func ON func.status = 'ACTIVE' AND func.functionCode = map.functionCode "
          + "WHERE map.genCode = :genCode")
  List<String> getListFunction(@Param("genCode") String genCode);
}