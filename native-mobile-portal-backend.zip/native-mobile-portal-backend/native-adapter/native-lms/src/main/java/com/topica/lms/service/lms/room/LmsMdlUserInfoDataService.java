package com.topica.lms.service.lms.room;

import com.topica.lms.model.lms.LmsMdlUserInfoData;

public interface LmsMdlUserInfoDataService {
  LmsMdlUserInfoData findByUseridAndFieldid(Long userId, Integer fieldId);

  void updatePackage(String packageName, String userId);

  void updatePackageParent(String packageParent, String userId);

  void save(LmsMdlUserInfoData userInfoData);

  void insert(LmsMdlUserInfoData userInfoData);
}
