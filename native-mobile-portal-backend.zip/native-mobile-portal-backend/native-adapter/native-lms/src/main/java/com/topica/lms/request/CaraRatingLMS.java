package com.topica.lms.request;

import com.topica.adapter.common.constant.CaraRateType;
import com.topica.adapter.common.request.CaraRequest;
import lombok.Builder;
import lombok.Data;
import org.springframework.util.CollectionUtils;

@Data
@Builder
public class CaraRatingLMS {
    private int points;
    private int vote;
    private String room_id;
    private String teacher_id;
    private String student_id;
    private String opinion;

    public static CaraRatingLMS from(CaraRequest request) {
        String optionStr = "";
        if(!CollectionUtils.isEmpty(request.getOptions())) {
            optionStr = request.getOptions().get(0).getName();
        } else {
            optionStr = request.getVote().name();
        }
        int optionId = CaraRateType.getCode(CaraRateType.fromString(optionStr));
        return CaraRatingLMS.builder()
                .opinion(request.getOpinion())
                .student_id(request.getStudent_id().toString())
                .teacher_id(request.getTeacher_id() == null ? "" : request.getTeacher_id().toString())
                .room_id(request.getRoom_id().toString())
                .vote(optionId)
                .points(request.getPoints())
                .build();
    }

//    @Data
//    @AllArgsConstructor
//    public static class Option {
//        private Integer id;
//        private Long teacher_id;
//    }
}

