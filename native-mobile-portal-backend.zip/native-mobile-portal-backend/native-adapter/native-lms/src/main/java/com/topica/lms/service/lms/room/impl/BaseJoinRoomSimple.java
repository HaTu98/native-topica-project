package com.topica.lms.service.lms.room.impl;

import com.topica.adapter.common.config.room.UseDeeplinkAdobe;
import com.topica.adapter.common.constant.SubjectType;
import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.dto.response.JoinRoomResponse;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.exception.RoomError;
import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.request.alert.AlertSimpleRequest;
import com.topica.adapter.common.service.BaseUserSessionService;
import com.topica.adapter.common.service.alert.AlertService;
import com.topica.adapter.common.service.invoker.InvokerService;
import com.topica.adapter.common.service.room.RoomServicePortal;
import com.topica.adapter.common.service.room.TraceLogBlackBoxService;
import com.topica.adapter.common.util.RoomUtil;
import com.topica.adapter.common.util.TimeUtil;
import com.topica.booking.model.Ticket;
import com.topica.booking.request.TicketRequest;
import com.topica.booking.service.BookingRoomService;
import com.topica.lms.request.JoinRoomLMS;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static com.topica.adapter.common.constant.RoleInClass.NORMAL;
import static com.topica.adapter.common.constant.ServiceType.LMS;
import static com.topica.adapter.common.exception.RoomError.*;
import static com.topica.adapter.common.util.TimeUtil.DATE_FORMAT_ALERT_POCO_LMS;

@Slf4j
@Component
public abstract class BaseJoinRoomSimple extends BaseUserSessionService {

    public static final String WEB_SOURCE = "WEB";
    public static final String MOBILE_SOURCE = "MOBILE";

    private static final String PATH_JOIN_ADB = "/adobe/link/student";
    private static final String PATH_JOIN_BBB = "/bbb/link/student";
    public static final String PATH_JOIN_VCRX = "/vcrx/link/student";

    @Value("${lms.key.get.vcr.link}")
    private String keyGetVCRLink;

    @Value("${domain.lms.student}")
    protected String urlLMS;

    @Value("${alert.status}")
    protected Boolean alertStatus;

    @Autowired
    private InvokerService invokerService;

    @Autowired
    private UseDeeplinkAdobe useDeeplinkAdobe;

    @Autowired
    private BookingRoomService bookingRoomService;

    @Autowired
    @Qualifier("roomServiceSimple")
    private RoomServicePortal roomServiceSimple;

    @Autowired
    private AlertService alertService;

    @Autowired
    @Qualifier("traceLogBlackBoxServiceImpl")
    private TraceLogBlackBoxService traceLogJoinRoomService;

    @Autowired
    private RoomUtil roomUtil;

    protected JoinRoomResponse joinVCRX(RoomDTO targetRoom) {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", keyGetVCRLink);
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        JoinRoomLMS requestGetLink = this.createRequestGetLink(targetRoom);
        HttpEntity<Object> entity = new HttpEntity<>(requestGetLink, headers);

        String url = this.getURL(PATH_JOIN_VCRX);
        Optional<JoinRoomResponse.JoinRoomDataRes> res = invokerService.postHeader(url, entity, JoinRoomResponse.JoinRoomDataRes.class);

        if(!res.isPresent()) {
            return JoinRoomResponse.empty;
        }
        traceLogJoinRoomService.traceReJoinRoomAfterLongTime(this.getUserSession().getMdlUser().getId(),
                this.getUserSession().getServiceType().name(), targetRoom.getId(), false);
        return res.get().getData().toVCRX(targetRoom);

    }

    protected void checkVCRXClassId(JoinRoomResponse response) throws BusinessException {
        if(response.getData().getClassIdVcrx() == null) {
            Optional<RoomDTO> room = this.roomServiceSimple.getRoom(response.getRoomId());
            if(room.isPresent()) {
                response.getData().setClassIdVcrx(room.get().getClassIdVcrx());
            }
        }
    }

    protected JoinRoomResponse joinADOBE(RoomDTO targetRoom, boolean buildDeepLink) {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", keyGetVCRLink);
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        JoinRoomLMS requestGetLink = this.createRequestGetLink(targetRoom);
        HttpEntity<Object> httpEntity = new HttpEntity<>(requestGetLink, headers);

        String url = this.getURL(PATH_JOIN_ADB);
        Optional<JoinRoomResponse.JoinRoomDataRes> res = invokerService.postHeader(url, httpEntity, JoinRoomResponse.JoinRoomDataRes.class);

        if(!res.isPresent()) {
            return JoinRoomResponse.empty;
        }
        boolean useDeeplink = buildDeepLink && useDeeplinkAdobe.get();
        traceLogJoinRoomService.traceReJoinRoomAfterLongTime(this.getUserSession().getMdlUser().getId(),
                this.getUserSession().getServiceType().name(), targetRoom.getId(), false);
        return res.get().getData().toAdobe(targetRoom, useDeeplink);
    }

    protected JoinRoomResponse joinBBB(RoomDTO targetRoom) {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", keyGetVCRLink);
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        JoinRoomLMS requestGetLink = this.createRequestGetLink(targetRoom);
        HttpEntity<Object> entity = new HttpEntity<>(requestGetLink, headers);

        String url = this.getURL(PATH_JOIN_BBB);
        Optional<JoinRoomResponse.JoinRoomDataRes> res = invokerService.postHeader(url, entity, JoinRoomResponse.JoinRoomDataRes.class);

        if(!res.isPresent()) {
            return JoinRoomResponse.empty;
        }
        traceLogJoinRoomService.traceReJoinRoomAfterLongTime(this.getUserSession().getMdlUser().getId(),
                this.getUserSession().getServiceType().name(), targetRoom.getId(), true);
        return res.get().getData().toBBB(targetRoom);
    }

    public Optional<RoomDTO> findTargetRoom(SubjectType type) throws BusinessException {
        boolean roomError;
        TicketRequest ticketRequest = this.buildTicketRequest(type);
        do {
            Optional<Ticket> ticket = this.orderTicket(ticketRequest);
            if (!ticket.isPresent()) {
                this.alertFullUser(type);
                throw new BusinessException(FULL_USER_IN_ROOM, "FULL USER");
            }
            try {
                RoomDTO targetRoom = this.checkRoomToJoin(ticket.get(), ticketRequest.getAcceptVCRType());
                targetRoom.setTicketId(ticket.get().getId());
                targetRoom.setRole(NORMAL.name());
                log.info("QUICK JOIN FOUND ROOM ID: {} - ticketId: {}", targetRoom.getId(), ticket.get().getId());
                return Optional.ofNullable(targetRoom);
            } catch (BusinessException e) {
                roomError = true;
            }
        } while (roomError);
        return Optional.empty();
    }

    public boolean validRoom(RoomDTO room) throws BusinessException {
        try {
            Optional<Ticket> ticket = this.bookingRoomService.buyTicket(room.getId(), NORMAL.name(), LMS);
            if(ticket.isPresent()) {
                this.checkTicketToJoin(ticket.get(), room);
                log.info("JOIN ROOM: {} - TICKET: {}", room.getId(), ticket.get().getId());
                room.setTicketId(ticket.get().getId());
            }
        } catch (BusinessException e) {
            if(e.getCode() == RoomError.OUT_OF_TICKET) {
                throw new BusinessException(FULL_USER_IN_ROOM, "Full user in room !");
            }
        }
        return true;
    }

    protected String getURL(String path) {
       return urlLMS + path;
    }

    protected Optional<Ticket> orderTicket(TicketRequest ticketRequest) throws BusinessException {
        Optional<Ticket> ticket = this.bookingRoomService.order(ticketRequest);
        if(!ticket.isPresent()) {
            List<RoomDTO> listRefreshRoom = this.getRefreshListRoom(ticketRequest.getRoomType());
            ticket = this.bookingRoomService.refreshAndRetryOrder(ticketRequest, listRefreshRoom);
        }
        return ticket;
    }

    protected RoomDTO checkRoomToJoin(Ticket ticket, List<String> acceptVCRtype) throws BusinessException {
        Long roomId = ticket.getRoomId();
        Optional<RoomDTO> room = this.roomServiceSimple.getRoom(roomId);
        if (!room.isPresent()) {
            this.bookingRoomService.cancelRoom(roomId);
            throw new BusinessException(ROOM_DELETED, "ROOM DELETED: " + roomId);
        }
        this.checkValidVCR(room.get(), ticket, acceptVCRtype);
        return room.get();
    }

    private void checkTicketToJoin(Ticket ticket, RoomDTO targetRoom) {
        if(this.vcrTypeChanged(targetRoom, ticket)) {
            this.bookingRoomService.reportChangeVCR(ticket.getRoomId(), targetRoom.getVcrType());
        }
    }

    private JoinRoomLMS createRequestGetLink(RoomDTO targetRoom) {
        PortalMdlUser user = this.getUserSession();
        JoinRoomLMS.UserJoinRoom userJoinRoom = JoinRoomLMS.UserJoinRoom.builder()
                .id(user.getMdlUser().getId())
                .build();
        return new JoinRoomLMS(targetRoom.getId(), userJoinRoom, this.getSource(), targetRoom.getRole());
    }


    private void checkValidVCR(RoomDTO room, Ticket ticket, List<String> acceptVCRType) throws BusinessException {
        if(this.vcrTypeChanged(room, ticket)) {
            this.bookingRoomService.reportChangeVCR(room.getId(), room.getVcrType());
        }
        if(!acceptVCRType.contains(room.getVcrType())) {
            log.info("Room : {} - vcr: {} --- accept: {}", room.getId(), room.getVcrType(), acceptVCRType);
            this.bookingRoomService.returnTicket(ticket.getId());
            throw new BusinessException(VCR_CHANGED, "VCR TYPE CHANGED AND NOT SUPPORT");
        }
    }

    private boolean vcrTypeChanged(RoomDTO room, Ticket ticket) {
        return !room.getVcrType().equalsIgnoreCase(ticket.getVcrType());
    }

    public boolean isFailJoinADOBE(JoinRoomResponse response) {
        return StringUtils.isEmpty(response.getLink());
    }

    public boolean isFailJoinBBB(JoinRoomResponse response) {
        return StringUtils.isEmpty(response.getLink());
    }

    public boolean isFailJoinVCRX(JoinRoomResponse response) {
        return response.getData() == null || !response.getData().getStatus();
    }

    public void alertFullUser(SubjectType subjectType) {
        if(!this.alertStatus) return;
        PortalMdlUser user = this.getUserSession();
        AlertSimpleRequest request = AlertSimpleRequest.builder()
                .userId(user.getMdlUser().getId())
                .lastName(user.getLastName())
                .levelStudent(user.getLevel())
                .subjectType(subjectType.name())
                .time(TimeUtil.toString(DATE_FORMAT_ALERT_POCO_LMS))
                .build();
        this.alertService.sendToLMS(request);
    }

    public String checkLevel(String level, String classType, String packageParent) {
        return roomUtil.getLevelClass(packageParent, classType, level);
    }

    public abstract TicketRequest buildTicketRequest(SubjectType type);
    public abstract List<RoomDTO> getRefreshListRoom(String classType) throws BusinessException;
    public abstract String getSource();
}