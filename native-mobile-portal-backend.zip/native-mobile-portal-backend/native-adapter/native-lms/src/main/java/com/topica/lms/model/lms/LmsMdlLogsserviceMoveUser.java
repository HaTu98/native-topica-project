package com.topica.lms.model.lms;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@AllArgsConstructor
@Data
@Entity
@EqualsAndHashCode(of = "id")
@NoArgsConstructor
@Table(name = "mdl_logsservice_move_user")
public class LmsMdlLogsserviceMoveUser {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "userid")
    private Long userid;

    @Column(name = "povhid")
    @Transient
    private Long povhid;

    @Column(name = "roomidfrom")
    @Transient
    private Long roomidfrom;

    @Column(name = "roomidto")
    private Long roomidto;

    @Column(name = "moveauto")
    @Transient
    private int moveauto;

    @Column(name= "status")
    private String status;

    @Column(name= "device_type")
    private String device;

    @Column(name="role_in_class")
    private String role;

    @Column(name="timecreated")
    @Transient
    private Long timeCreated;
}