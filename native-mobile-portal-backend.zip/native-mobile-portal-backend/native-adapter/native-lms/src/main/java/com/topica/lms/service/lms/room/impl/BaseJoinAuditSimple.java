package com.topica.lms.service.lms.room.impl;

import com.topica.adapter.common.config.room.AcceptVCR;
import com.topica.adapter.common.constant.SubjectType;
import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.dto.response.JoinRoomResponse;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.exception.RoomError;
import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.util.RoomUtil;
import com.topica.booking.model.Ticket;
import com.topica.booking.request.TicketRequest;
import com.topica.booking.service.BookingRoomService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

import static com.topica.adapter.common.constant.RoleInClass.AUDIT;
import static com.topica.adapter.common.constant.ServiceType.LMS;
import static com.topica.adapter.common.dto.RoomDTO.VCRX;

@Slf4j
@Component
public abstract class BaseJoinAuditSimple extends BaseJoinRoomSimple {

    @Autowired
    private AcceptVCR acceptVCR;

    @Autowired
    private BookingRoomService bookingRoomService;

    @Override
    public Optional<RoomDTO> findTargetRoom(SubjectType type) throws BusinessException {
        TicketRequest ticketRequest = this.buildTicketRequest(type);
        boolean roomError;
        do {
            Optional<Ticket> ticket = this.orderTicket(ticketRequest);
            if (!ticket.isPresent()) {
                break;
            }
            try {
                RoomDTO targetRoom = this.checkRoomToJoin(ticket.get(), ticketRequest.getAcceptVCRType());
                targetRoom.setTicketId(ticket.get().getId());
                targetRoom.setRole(AUDIT.name());
                log.info("QUICK JOIN AUDIT FOUND ROOM ID: {} - ticketId: {}", targetRoom.getId(), ticket.get().getId());
                return Optional.of(targetRoom);
            } catch (BusinessException e) {
                roomError = true;
            }
        } while (roomError);

        if(this.isOutOfTicketAudit(ticketRequest)) {
            throw new BusinessException(RoomError.FULL_USER_IN_ROOM_AUDIT, "Full user audit");
        }
        throw new BusinessException(RoomError.NOT_FOUND_ROOM_AUDIT, "Not Found any Room");
    }

    private boolean isOutOfTicketAudit(TicketRequest ticketRequest) {
        long totalTicketReady = this.bookingRoomService.countTicketReady(ticketRequest);
        return totalTicketReady == 0;
    }

    public JoinRoomResponse joinIntoAudit(RoomDTO targetRoom) throws BusinessException {
        JoinRoomResponse response;
        boolean isJoinFail;
        switch (targetRoom.getVcrType()) {
            case VCRX:
                response = this.joinVCRX(targetRoom);
                isJoinFail = this.isFailJoinVCRX(response);
                if(!isJoinFail) {
                    this.checkVCRXClassId(response);
                }
                break;
            default: throw new BusinessException(RoomError.NOT_SUPPORT_VCR, "Not support VCR");
        }
        if(isJoinFail) {
            this.bookingRoomService.returnTicket(targetRoom.getTicketId());
        }
        return response;
    }

    public TicketRequest buildTicketRequest(SubjectType type) {
        String typeClass = RoomUtil.checkTypeClass(type.name());
        List<String> acceptVCRs = this.acceptVCR.getForSimpleAudit();
        PortalMdlUser user = this.getUserSession();
        String packageParent = user.getPackageParent();
        String level = this.checkLevel(user.getLevel(), typeClass, packageParent);
        return TicketRequest
                .builder()
                .level(level)
                .roomType(typeClass)
                .teacherType(RoomUtil.getTeacherType(user.getPackageParent(), typeClass))
                .timeAvailable(RoomUtil.getTimeAvailableToSeconds())
                .role(AUDIT.name())
                .serviceType(LMS.name())
                .acceptVCRType(acceptVCRs)
                .userId(user.getMdlUser().getId())
                .userName(user.getMdlUser().getUsername())
                .build();
    }
}