package com.topica.lms.service.lms.room.impl;

import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.dto.response.JoinRoomResponse;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.service.room.JoinRoomMaker;
import com.topica.adapter.common.service.room.RoomServicePortal;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service("joinRoomAuditSimpleMaker")
public class JoinRoomAuditSimpleMakerImpl extends BaseJoinAuditSimple implements JoinRoomMaker {

    @Autowired
    @Qualifier("roomServiceSimple")
    private RoomServicePortal roomService;

    @Override
    public JoinRoomResponse joinInto(RoomDTO targetRoom) throws BusinessException {
        JoinRoomResponse response = this.joinIntoAudit(targetRoom);
        response.setLink("");
        return response;
    }

    @Override
    public List<RoomDTO> getRefreshListRoom(String classType) throws BusinessException {
        return this.roomService.listRoom(classType);
    }

    @Override
    public String getSource() {
        return MOBILE_SOURCE;
    }
}