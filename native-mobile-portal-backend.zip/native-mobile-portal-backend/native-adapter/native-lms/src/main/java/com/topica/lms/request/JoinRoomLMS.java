package com.topica.lms.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
public class JoinRoomLMS {
    private Long classId;
    private UserJoinRoom user;
    private String source;
    private String role;

    @Data
    @Builder
    public static class UserJoinRoom {
        private long id;
        private String username;
        private String email;
        private String firstname;
        private String lastname;
    }

}
