package com.topica.lms.repository.lms.room;


import com.topica.adapter.common.dto.RoomPresentDTO;
import com.topica.adapter.common.request.ListRoomRequest;
import com.topica.lms.model.lms.MdlTpeBBBSimple;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface RoomSimpleRepository extends JpaRepository<MdlTpeBBBSimple, Long> {

    @Query(value =
            "SELECT NEW com.topica.adapter.common.dto.RoomPresentDTO( b.id, b.name, h.hourStart, m.topic, b.vcrType, b.timedue , " +
                    "b.timeavailable, c.levelClass, c.typeClass,m.objective, m.background, m.fileUrl, b.isVCRX) " +
                    "FROM MdlTpeBBBSimple  b " +
                    "JOIN MdlTpeCanlendarTeach c ON  b.calendarCode= c.calendarCode " +
                    "JOIN MdlHourTeach h ON c.hourId = h.id " +
                    "LEFT JOIN MdlMaterialService m ON c.subjectCode = m.subjectCode " +
                    "WHERE b.roomType = 'ROOM' " +
                    " AND b.vcrType in :#{#request.queryVCRTypes} " +
                    " AND b.timeavailable = :#{#request.timeAvailable} " +
                    " AND ( (c.levelClass = :#{#levelLS} AND c.typeClass = 'LS') OR (c.levelClass = :#{#levelSC} AND c.typeClass = 'SC') )" +
                    " AND c.status > 0")
    List<RoomPresentDTO> getRoomPresent(@Param("request") ListRoomRequest request,
                                        @Param("levelLS") String levelLS,
                                        @Param("levelSC") String levelSC);

    @Query(value = "SELECT b, c, vcrxRoom, count(distinct ra.userid), 0L, teacher "
            + "FROM MdlTpeBBBSimple b "
            + "JOIN MdlTpeCanlendarTeach c ON b.calendarCode = c.calendarCode "
            + "LEFT JOIN MdlVCRXRoom vcrxRoom  ON b.vcrClassId = vcrxRoom.id "
            + "LEFT JOIN LmsMdlLogsserviceMoveUser log ON log.roomidto = b.id AND (log.role = 'NORMAL' OR log.role is null) "
            + "LEFT JOIN LmsMdlRoleAssignments ra ON log.userid = ra.userid AND ra.roleId = 5 "
            + "LEFT JOIN LmsMdlUserData teacher ON teacher.id = c.teacherId "
            + "WHERE b.roomType = 'ROOM' "
            + " AND b.vcrType in :#{#request.queryVCRTypes} "
            + " AND b.timeavailable = :#{#request.timeAvailable} "
            + " AND c.typeClass = :#{#request.classType} "
            + " AND c.levelClass = :#{#request.level} "
            + " AND c.teacherType = :#{#request.teacherType} "
            + " AND c.status > 0 "
            + " GROUP BY b.id ")
    List<Object[]> getListRoom(@Param("request") ListRoomRequest request);

    @Query(value = " SELECT b, mv, vcrxRoom, t, teacher " +
            "FROM LmsMdlLogsserviceMoveUser mv " +
            "JOIN MdlTpeBBBSimple b ON mv.roomidto = b.id " +
            "LEFT JOIN MdlVCRXRoom vcrxRoom ON b.vcrClassId = vcrxRoom.id " +
            "LEFT JOIN MdlTpeCanlendarTeach t ON t.calendarCode = b.calendarCode " +
            "LEFT JOIN LmsMdlUserData teacher ON teacher.id = t.teacherId " +
            "WHERE b.roomType = 'ROOM' " +
            "AND b.timeavailable = :timeAvailable " +
            "AND mv.userid = :userId " +
            "ORDER BY mv.id DESC ")
    List<Object[]> getJoinedRoom(@Param("userId") Long userId, @Param("timeAvailable") Long timeAvailable);

    @Query(value = "SELECT b, c, vcrxRoom "
            + "FROM MdlTpeBBBSimple b "
            + "JOIN MdlTpeCanlendarTeach c ON b.calendarCode = c.calendarCode "
            + "LEFT JOIN MdlVCRXRoom vcrxRoom ON b.vcrClassId = vcrxRoom.id "
            + "WHERE b.id = :roomId "
            + "AND b.roomType = 'ROOM' "
            + "AND c.status > 0 ")
    List<Object[]> findPureRoom(@Param("roomId") Long roomId);

    @Query(value = "SELECT teach.teacherType "
            + "FROM MdlTpeBBBSimple room "
            + "LEFT JOIN MdlTpeCanlendarTeach teach  ON room.calendarCode = teach.calendarCode "
            + " WHERE room.id = :roomId ")
    String getTeacherTypeByRoomId(@Param("roomId") Long roomId);

    @Query(value = "SELECT b.timeavailable "
            + "FROM MdlTpeBBBSimple b "
                    + "JOIN MdlTpeCanlendarTeach c ON b.calendarCode = c.calendarCode "
                    + "WHERE b.roomType = 'ROOM' "
                    + " AND b.vcrType in :#{#request.queryVCRTypes} "
                    + " AND b.timeavailable >= :#{#request.timeAvailable} "
                    + " AND c.levelClass = :#{#request.level}"
                    + " AND c.status > 0 "
            + " order by b.timeavailable ASC ")
    List<Long> getClosestRoom(@Param("request") ListRoomRequest request, Pageable firstResult);

    @Query(value = "SELECT b, c, vcrxRoom, 0L, 0L, teacher "
            + "FROM MdlTpeBBBSimple b "
            + "JOIN MdlTpeCanlendarTeach c ON b.calendarCode = c.calendarCode "
            + "LEFT JOIN MdlVCRXRoom vcrxRoom  ON b.vcrClassId = vcrxRoom.id "
            + "LEFT JOIN LmsMdlUserData teacher ON teacher.id = c.teacherId "
            + "WHERE b.roomType = 'ROOM' "
            + " AND b.timeavailable = :timeAvailable "
            + " AND c.status > 0 "
            + " GROUP BY b.id ")
    List<Object[]> getAllRoomByTime(@Param("timeAvailable") Long timeAvailable);
}