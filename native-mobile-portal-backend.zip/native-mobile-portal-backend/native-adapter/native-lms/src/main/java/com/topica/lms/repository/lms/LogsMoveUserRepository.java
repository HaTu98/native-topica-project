package com.topica.lms.repository.lms;


import com.topica.adapter.common.dto.RoomUserCountDTO;
import com.topica.lms.model.lms.LmsMdlLogsserviceMoveUser;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface LogsMoveUserRepository extends JpaRepository<LmsMdlLogsserviceMoveUser, Long> {

  @Query(value = "SELECT NEW com.topica.adapter.common.dto.RoomUserCountDTO(m.roomidto, COUNT(DISTINCT ra.userid)) "
      + "FROM LmsMdlLogsserviceMoveUser m "
      + "LEFT JOIN LmsMdlRoleAssignments ra ON m.userid = ra.userid "
      + "WHERE ra.roleId = :roleId "
      + " AND m.roomidto = :roomId "
      + " AND ( m.role = 'NORMAL' OR m.role is null)")
  RoomUserCountDTO getUserCountWithRoleNormal(@Param("roomId") Long roomId, @Param("roleId") long roleIdStudent);

  @Query(value = "SELECT count(m) "
          + "FROM LmsMdlLogsserviceMoveUser m "
          + "JOIN LmsMdlRoleAssignments ra ON m.userid = ra.userid "
          + "WHERE ra.roleId = :roleId "
          + " AND m.roomidto = :roomId ")
  long existsTeacherInRoom(@Param("roomId") Long roomId, @Param("roleId") long roleIdTeacher);

  @Query(value = "SELECT log FROM LmsMdlLogsserviceMoveUser log "
          + "LEFT JOIN MdlTpeBBBSimple room ON log.roomidto = room.id "
          + "LEFT JOIN MdlTpeCanlendarTeach teach ON room.calendarCode = teach.calendarCode "
          + "WHERE log.userid = :userId "
          + " AND teach.teacherType NOT IN ('TRAINING','ORIENTATION') "
          + " AND room.roomType = 'room' "
          + " AND teach.status <> -1 "
          + "ORDER BY log.id DESC ")
  List<LmsMdlLogsserviceMoveUser> getLastRoomId(@Param("userId")Long userId, Pageable firstResult);
}