package com.topica.lms.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class LoginVCRXResponse {
    private Boolean success;
    private Response result;

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Response {
        private Boolean status;
        private UserVCRX data;
    }
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class UserVCRX {
        private Long id;
        private Long participantid;
    }
}
