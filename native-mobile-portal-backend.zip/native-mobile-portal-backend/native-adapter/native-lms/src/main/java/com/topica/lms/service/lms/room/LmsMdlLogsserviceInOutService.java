package com.topica.lms.service.lms.room;

public interface LmsMdlLogsserviceInOutService {
    Long getRealTeacherOfRoom(Long roomId, String teacherType);

    Long getTimeBetweenTwoTimeJoinClassLatest(Long userId, boolean isFromCurrentTime);
}