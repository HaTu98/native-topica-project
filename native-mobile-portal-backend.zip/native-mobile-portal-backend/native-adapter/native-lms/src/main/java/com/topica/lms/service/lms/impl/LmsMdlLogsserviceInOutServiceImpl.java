package com.topica.lms.service.lms.impl;

import com.topica.adapter.common.constant.PageUtil;
import com.topica.lms.repository.lms.LmsMdlLogsserviceInOutRepository;
import com.topica.lms.service.lms.room.LmsMdlLogsserviceInOutService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;

@Slf4j
@Service
public class LmsMdlLogsserviceInOutServiceImpl implements LmsMdlLogsserviceInOutService {

  @Autowired
  private LmsMdlLogsserviceInOutRepository inOutRepository;

  @Override
  public Long getRealTeacherOfRoom(Long roomId, String teacherType) {
    List<Long> teacherIds;
    if(teacherType.equalsIgnoreCase("VN")){
      teacherIds = inOutRepository.getRealTeacherVNOfRoom(roomId, PageUtil.FIRST_RESULT);
    } else {
      teacherIds = inOutRepository.getRealTeacherOfRoom(roomId, PageUtil.FIRST_RESULT);
    }

    if(!CollectionUtils.isEmpty(teacherIds)) {
      return teacherIds.get(0);
    }
    return 0L;
    }

    @Override
    public Long getTimeBetweenTwoTimeJoinClassLatest(Long userId, boolean isFromCurrentTime) {
        List<Long> times = inOutRepository.getTimeInJoinRoomLatestByUserId(userId, new PageRequest(0, isFromCurrentTime ? 1 : 2));
        if (isFromCurrentTime) times.add(0, System.currentTimeMillis() / 1000);
        if (times.size() < 2) return 0L;
        return times.get(0) - times.get(1);
    }
}
