package com.topica.lms.service.lms.gen.impl;

import com.topica.adapter.common.constant.ServiceType;
import com.topica.adapter.common.dto.PersonalInfoDTO;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.service.BaseUserSessionService;
import com.topica.adapter.common.service.user.UserServicePortal;
import com.topica.lms.model.lms.MdlGenMappingFunction;
import com.topica.lms.repository.lms.gen.MdlGenMappingFunctionRepository;
import com.topica.lms.service.lms.gen.MdlGenMappingFunctionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class MdlGenMappingFunctionServiceImpl extends BaseUserSessionService implements MdlGenMappingFunctionService {
    @Autowired
    private MdlGenMappingFunctionRepository mdlGenMappingFunctionRepository;

    @Autowired
    @Qualifier("UserServicePortal")
    private UserServicePortal userServicePortal;

    @Override
    public List<String> getUserGen() throws BusinessException {
        Long userId = getUserSession().getMdlUser().getId();
        ServiceType serviceType = getUserSession().getServiceType();
        PersonalInfoDTO infoData = this.userServicePortal.findPersonalInfo(userId, serviceType);
        String genCode = infoData.getPackageList().get(0).getGenCode();
        List<MdlGenMappingFunction> gens = this.findByGenCode(genCode);
        List<String> listGen = new ArrayList<>();
        for (MdlGenMappingFunction gen : gens) {
            listGen.add(gen.getFunctionCode());
        }
        return listGen;
    }

    @Override
    public List<MdlGenMappingFunction> findByGenCode(String genCode) {
        return mdlGenMappingFunctionRepository.findByGenCode(genCode);
    }
}
