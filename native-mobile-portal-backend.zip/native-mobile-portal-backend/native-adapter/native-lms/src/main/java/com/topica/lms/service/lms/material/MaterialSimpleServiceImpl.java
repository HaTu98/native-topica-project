package com.topica.lms.service.lms.material;


import com.topica.adapter.common.constant.LevelClass;
import com.topica.adapter.common.constant.SubjectType;
import com.topica.adapter.common.dto.material.MaterialDTO;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.service.material.MaterialService;
import com.topica.adapter.common.util.RoomUtil;
import com.topica.lms.model.lms.SimpleMdlMaterialservice;
import com.topica.lms.repository.lms.material.MaterialSimpleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.topica.adapter.common.constant.PackageParent.VIP;
import static com.topica.adapter.common.constant.SubjectType.LS;

@Service("materialSimpleServiceImpl")
public class MaterialSimpleServiceImpl implements MaterialService {

    private @Autowired MaterialSimpleRepository repository;

    @Autowired
    private RoomUtil roomUtil;

    @Override
    public Map<SubjectType, List<MaterialDTO>> get(long start, long end, String levelClass, String packageCode) throws BusinessException {
        List<String> teacherTypes = this.getTeacherType(packageCode);
        String studentType = this.getStudentType(packageCode);

        String levelClassSC = LevelClass.levelOf(levelClass).name();
        String levelClassLS = this.getLevelLS(levelClass, packageCode);

        return repository.findByTime(start, end, teacherTypes, levelClassLS, levelClassSC, studentType)
                .parallelStream()
                .map(e -> this.of(e))
                .collect(Collectors.groupingBy(MaterialDTO::getSubjectType));
    }

    private String getLevelLS(String levelUser, String packageCode) throws BusinessException {
        String levelLS = roomUtil.getLevelClass(packageCode, LS.name(), levelUser);
        return LevelClass.levelOf(levelLS).name();
    }

    private String getStudentType(String packageCode) {
        if (packageCode.contains(VIP.name())) {
            return VIP.name();
        }
        return "VN";
    }

    public MaterialDTO of (SimpleMdlMaterialservice simple) {
        return MaterialDTO.builder()
                .id(simple.getId())
                .subjectType(SubjectType.valueOf(simple.getSubjectType()))
                .objective(simple.getObjective())
                .topic(simple.getTopic())
                .subject(simple.getSubject())
                .classOutline(simple.getClassOutline())
                .fileurl(simple.getFileurl())
                .outlineHomework(simple.getOutlineHomework())
                .lessonPlan(simple.getLessonPlan())
                .videoWarmup(simple.getVideoWarmup() != null ? simple.getVideoWarmup() : simple.getLinkVideoWarmup())
                .background(simple.getBackground())
                .timeBegin(simple.getTimeBegin())
                .teacherType(simple.getTeacherType())
                .levelOutline(simple.getLevelOutline())
                .code(simple.getCode())
                .build();
    }
}
