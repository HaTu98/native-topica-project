package com.topica.lms.service.lms.impl;

import com.topica.lms.model.lms.LmsMdlUserInfoData;
import com.topica.lms.repository.lms.LmsMdlUserInfoDataRepository;
import com.topica.lms.service.lms.room.LmsMdlUserInfoDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LmsMdlUserInfoDataServiceImpl implements LmsMdlUserInfoDataService {

  @Autowired
  private LmsMdlUserInfoDataRepository dataRepository;

  @Override
  public LmsMdlUserInfoData findByUseridAndFieldid(Long userId, Integer fieldId) {
    return dataRepository.findByUseridAndFieldid(userId, fieldId);
  }

  @Override
  public void updatePackage(String packageName, String userId) {
    dataRepository.updatePackage(packageName, userId);
  }

  @Override
  public void updatePackageParent(String packageParent, String userId) {
    dataRepository.updatePackageParent(packageParent, userId);
  }

  @Override
  public void save(LmsMdlUserInfoData userInfoData) {
    dataRepository.save(userInfoData);
  }

  @Override
  public void insert(LmsMdlUserInfoData userInfoData) {
    LmsMdlUserInfoData mdlUserInfoData = dataRepository.findByUseridAndFieldid(userInfoData.getUserid(), userInfoData.getFieldid());
    if (mdlUserInfoData != null) {
      mdlUserInfoData.setData(userInfoData.getData());
      dataRepository.save(mdlUserInfoData);
      return;
    }
    dataRepository.save(userInfoData);
  }
}
