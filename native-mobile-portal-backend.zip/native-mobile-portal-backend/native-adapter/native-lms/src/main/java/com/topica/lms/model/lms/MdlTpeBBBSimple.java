package com.topica.lms.model.lms;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@AllArgsConstructor
@Data
@Entity
@EqualsAndHashCode(of = "id")
@NoArgsConstructor
@Table(name = "mdl_tpebbb")
public class MdlTpeBBBSimple {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "description")
    private String description;

    @Column(name = "timedue" )
    private Long timedue;

    @Column(name = "timeavailable")
    private Long timeavailable;

    @Column(name = "roomtype")
    private String roomType;
    
    @Column(name = "calendar_code")
    private String calendarCode;
    
    @Column(name = "subject_code")
    private String subjectCode;    
    
    @Column(name = "delete_status")
    private Byte deleteStatus;

    @Column(name = "vcr_type")
    private String vcrType;
    
    @Column(name = "vcr_class_id")
    private Long vcrClassId;

    @Column(name = "is_vcrx")
    private int isVCRX;
}