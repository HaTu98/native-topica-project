package com.topica.lms.model.lms;

import lombok.*;

import javax.persistence.*;

/**
 * Created by Hope on 2/5/2018.
 */
@AllArgsConstructor
@Data
@Entity
@EqualsAndHashCode(of = "id")
@NoArgsConstructor
@Table(name = "mdl_user_info_data")
@Builder
public class LmsMdlUserInfoData {

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Long id;

  @Column(name = "userid", nullable = false)
  private Long userid;

  @Column(name = "fieldid", nullable = false)
  private Integer fieldid;

  @Column(name = "data", nullable = false)
  private String data;

  @Column(name = "dataformat", nullable = false)
  private int dataformat;
}