package com.topica.lms.service.lms.room.impl;

import com.topica.adapter.common.config.room.MaxUserInRoom;
import com.topica.adapter.common.constant.LevelStudent;
import com.topica.adapter.common.constant.PageUtil;
import com.topica.adapter.common.constant.SubjectType;
import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.dto.RoomPresentDTO;
import com.topica.adapter.common.dto.RoomUserCountDTO;
import com.topica.adapter.common.dto.response.RoomPresentResponse;
import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.request.ListRoomRequest;
import com.topica.adapter.common.service.BaseUserSessionService;
import com.topica.adapter.common.util.RoomUtil;
import com.topica.lms.model.lms.RoomResult;
import com.topica.lms.repository.lms.LmsMdlUserDataRepository;
import com.topica.lms.repository.lms.room.RoomSimpleRepository;
import com.topica.lms.service.lms.UserSimpleService;
import com.topica.lms.service.lms.room.LogsMoveUserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.topica.adapter.common.constant.LevelStudent.sbasic;
import static com.topica.adapter.common.constant.SubjectType.SC;
import static com.topica.adapter.common.constant.SubjectType.SN;
import static com.topica.adapter.common.dto.RoomDTO.BBB;
import static com.topica.adapter.common.util.RoomUtil.isRoomSN;

@Slf4j
@Component
public abstract class BaseRoomServiceSimple extends BaseUserSessionService {

    @Value("${domain.lms.student}")
    private String domainLMS40;

    private @Autowired
    MaxUserInRoom maxUserInRoom;
    private @Autowired
    UserSimpleService userSimpleService;
    private @Autowired
    LogsMoveUserService moveUserService;
    private @Autowired
    RoomSimpleRepository roomSimpleRepository;

    @Autowired
    private RoomUtil roomUtil;


    public Optional<RoomDTO> getRoom(Long classId) {
        List<Object[]> result = roomSimpleRepository.findPureRoom(classId);
        if (CollectionUtils.isEmpty(result)) {
            return Optional.empty();
        }
        RoomDTO room = RoomResult.toPureRoom(result.get(0));
        return Optional.of(room);
    }

    public RoomDTO getJoinedRoom() {
        PortalMdlUser user = this.getUserSession();
        Long timeAvailable = RoomUtil.getTimeAvailableToSeconds();
        log.info("(getJoinedRoom)-user Simple {}, time:{}", user.getMdlUser().getUsername(), timeAvailable);
        List<Object[]> recentRoomDTOs = roomSimpleRepository.getJoinedRoom(user.getMdlUser().getId(), timeAvailable);
        if (CollectionUtils.isEmpty(recentRoomDTOs)) {
            return null;
        }
        RoomDTO joined = RoomResult.toRoomDTOJoined(recentRoomDTOs.get(0));
        this.updateRoomInfo(joined);
        this.setCountUserNormal(joined);
        return joined;
    }

    public List<RoomDTO> listRoom(String classType) {
        ListRoomRequest listRoomRequest = this.getListRoomRequest(classType);
        log.info("GetListRoom: {}", listRoomRequest);
//        //todo
//        RoomDTO roomDTO = new RoomDTO();
//        roomDTO.setPackageType("LMS_VIP");
//            roomDTO.setTypeClass("SC");
//        roomDTO.setLevelClass("sbasic");
//        this.updateRoomInfo(roomDTO);
        List<Object[]> roomResults = roomSimpleRepository.getListRoom(listRoomRequest);
        return roomResults.parallelStream()
                .map(r -> RoomResult.toRoomDTO(r))
                .filter(this.cleanResultNotInVCR(listRoomRequest.getAcceptVCRTypes()))
                .map(room -> this.updateRoomInfo(room))
                .collect(Collectors.toList());
    }

    public RoomPresentResponse  presentRoom(ListRoomRequest request) {
        PortalMdlUser user = this.getUserSession();
        String levelLS = roomUtil.getLevelClass(user.getPackageParent(), SubjectType.LS.name(), user.getLevel());
        String levelSC = roomUtil.getLevelClass(user.getPackageParent(), SubjectType.SC.name(), user.getLevel());

        List<RoomPresentDTO> roomPresent = roomSimpleRepository.getRoomPresent(request, levelLS, levelSC);
        if (CollectionUtils.isEmpty(roomPresent)) {
            Optional<Long> closestTimes = this.getClosestTimeRoom();
            if (!closestTimes.isPresent()) {
                return RoomPresentResponse.empty;
            }
            request.setTimeAvailable(closestTimes.get());
            roomPresent = roomSimpleRepository.getRoomPresent(request, levelLS, levelSC);
        }
        roomPresent = roomPresent
                .parallelStream()
                .filter(room -> {
                    if (!request.getAcceptVCRTypes().contains(BBB)) {
                        return RoomUtil.isNotBBBRoom(room);
                    }
                    return true;
                }).collect(Collectors.toList());

        return RoomUtil.convertToRoomPresent(roomPresent, this.getJoinedRoom());
    }

    public List<RoomDTO> getAllRoomByTime(Long timeAvailable) {
        log.info("GetAllRoomByTime: time = {}", timeAvailable);
        List<Object[]> roomResults = roomSimpleRepository.getAllRoomByTime(timeAvailable);
        return roomResults.parallelStream().map(r -> RoomResult.toRoomDTO(r))
                .collect(Collectors.toList());
    }

    protected int getMaxUserAllow(String userLevel, String classType) {
        if (sbasic == LevelStudent.of(userLevel)) {
            SubjectType type = SubjectType.valueOf(classType);
            if (type == SN || type == SC) {
                return this.maxUserInRoom.getMaxSimpleForRoomSN();
            }
        }
        return this.maxUserInRoom.getMaxSimple();
    }

    protected RoomDTO updateRoomInfo(RoomDTO room) {
        this.setMaxUser(room);
        this.setTeacherInfo(room);
        this.changeTypeSC(room);
        return room;
    }

    private void changeTypeSC(RoomDTO room) {
        if (isRoomSN(room.getLevelClass(), room.getTypeClass())) {
            room.setTypeClass(SN.name());
        }
    }

    public void setCountUserNormal(RoomDTO room) {
        if (room.isOpened()) {
            RoomUserCountDTO userCount = moveUserService.getUserCountWithRoleNormal(room.getId());
            if (userCount != null) {
                room.setTotalJoin(userCount.getTotalJoin());
            }
        }
    }

    protected void setTeacherInfo(RoomDTO room) {
        room.setHasTeacher(this.moveUserService.checkTeacherJoin(room.getId()));
        if (room.getTeacherId() != null && room.getTeacherId() != 0) {
            room.setTeacherCountry(userSimpleService.getUserCountry(room.getTeacherId()));
        }
        if (room.getTeacherAvatar() != null) {
            room.setTeacherAvatar(domainLMS40.concat(room.getTeacherAvatar()));
        }
    }

    protected RoomDTO setMaxUser(RoomDTO room) {
        int maxUserForRoom = this.maxUserInRoom.getMaxUserForRoom(room);
        room.setMaxJoin(maxUserForRoom);
        return room;
    }

    protected Predicate<RoomDTO> cleanResultNotInVCR(Collection<String> acceptVCR) {
        return roomDTO -> {
            if (!acceptVCR.contains(BBB)) {
                return RoomUtil.isNotBBBRoom(roomDTO);
            }
            return true;
        };
    }

    protected Optional<Long> getClosestTimeRoom() {
        ListRoomRequest request = this.getListRoomRequest(null);
        List<Long> closestRoom = this.roomSimpleRepository.getClosestRoom(request, PageUtil.FIRST_RESULT);
        if (CollectionUtils.isEmpty(closestRoom)) {
            return Optional.empty();
        }
        return Optional.of(closestRoom.get(0));
    }

    protected ListRoomRequest getAbstractListRoomRequest(String classType, PortalMdlUser user) {
        classType = RoomUtil.checkTypeClass(classType);
        String packageCode = user.getPackageParent();
        String levelClass = roomUtil.getLevelClass(packageCode, classType, user.getLevel());
        String teacherType = roomUtil.getTeacherType(packageCode, classType);
        Long timeAvailable = roomUtil.getTimeAvailableToSeconds();
        return ListRoomRequest.builder()
                .classType(classType)
                .level(levelClass)
                .teacherType(teacherType)
                .timeAvailable(timeAvailable)
                .build();
    }

    public abstract ListRoomRequest getListRoomRequest(String classType);
}