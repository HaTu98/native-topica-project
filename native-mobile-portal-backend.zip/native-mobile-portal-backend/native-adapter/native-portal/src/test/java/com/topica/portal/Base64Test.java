package com.topica.portal;

import org.junit.Assert;

import java.util.Base64;

public class Base64Test {
//    @Test
    public void base64 () {

        String username = "portal_admin";
        String password = "portal_admin.";
        String auth = username + ":" + password;
        String base64 = Base64.getEncoder().encodeToString(auth.getBytes());
        Assert.assertEquals(base64, "cG9ydGFsX2FkbWluOnBvcnRhbF9hZG1pbi4=");
    }
}
