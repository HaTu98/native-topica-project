package com.topica.portal;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.adapter.common.request.LoginRequest;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import static com.topica.adapter.common.constant.ServiceType.LMS;

@Slf4j
public class JoinTest {
    private static String DOMAIN = "http://localhost:8082";
    private static String LOGIN = DOMAIN + "/api/portal/login/lms";
    private static String QUICK_JOIN = DOMAIN + "/api/portal/room/quickJoin?typeClass=";
    private static String JOIN = DOMAIN + "/api/portal/room/join?classId=";
    private static String LS = "LS";
    private static String SC = "SC";
    private static String SN = "SN";
    private static Integer roomId = 4641844;
    private List<String> users = Arrays.asList(
            //inter
            "tei_testviet500",
            "tei_testviet501",
            "tei_testviet502",
            "tei_testviet503",
            "tei_testviet504",
            "tei_testviet505",
            "tei_testviet506"

            // sbasic
//            "tei_testviet650",
//            "tei_testviet648",
//            "tei_testviet647",
//            "tei_testviet646",
//            "tei_testviet645"

            // basic23
//            "tei_testviet550",
//            "tei_testviet551",
//            "tei_testviet552",
//            "tei_testviet553",
//            "tei_testviet554",
//            "tei_testviet555"
            //basic1
//            "tei_testviet023",
//            "tei_testviet024",
//            "tei_testviet025",
//            "tei_testviet026",
//            "tei_testviet027"

    );
    private RestTemplate restTemplate = new RestTemplate();
    private Executor executor = Executors.newFixedThreadPool(10);

//    @Test
    public void loginAndJoin() throws InterruptedException {
        users.parallelStream().forEach(u -> {
            executor.execute(() -> {
                LoginRequest req = new LoginRequest();
                req.setUsername(u + "@topica.edu.vn");
                req.setPassword("topica123");
                req.setServiceType(LMS);
                String res = restTemplate.postForEntity(LOGIN, req, String.class).getBody();
                try {
                    ApiDataResponse response = new ObjectMapper().readValue(res, ApiDataResponse.class);
                    LinkedHashMap info = (LinkedHashMap)response.getData();
                    this.quickjoin((String)info.get("token"));
//                    this.join((String)info.get("token"), roomId);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        });
        Thread.sleep(10000);
    }

    private void quickjoin(String token) {
        String res = restTemplate.exchange(QUICK_JOIN + LS, HttpMethod.GET, this.getHeader(token), String.class).getBody();
        log.info(res);
    }
    private void join(String token, Integer roomId) {
        String res = restTemplate.exchange(JOIN + roomId, HttpMethod.GET, this.getHeader(token), String.class).getBody();
        log.info(res);
    }

    private HttpEntity getHeader(String token) {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", token);
        HttpEntity<String> entity = new HttpEntity<>("parameters", headers);
        return entity;
    }
}