package com.topica.portal;

import com.topica.adapter.common.config.room.AcceptVCR;
import com.topica.adapter.common.config.room.TotalEmptyRoomDisplay;
import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.util.ListRoomDisplay;
import com.topica.portal.redis.service.config.ConfigService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Arrays;
import java.util.List;

import static com.topica.adapter.common.constant.SubjectType.LS;
import static com.topica.adapter.common.dto.RoomDTO.*;
import static com.topica.portal.redis.constant.KeyConfig.LMS_WEB_VCR_KEY;
import static org.junit.Assert.assertEquals;

//@RunWith(SpringRunner.class)
public class ListRoomDisplayTest {

    private int maxJoin = 6;

    @TestConfiguration
    static class ContextConfiguration {

        @Bean
        public ListRoomDisplay getListRoomFilter() {
            return new ListRoomDisplay();
        }

        @Bean
        public AcceptVCR getAcceptVCR() {
            return new AcceptVCR();
        }
    }

    @Autowired
    private ListRoomDisplay listRoomDisplay;

    @Autowired
    private AcceptVCR acceptVCR;

    @MockBean
    private TotalEmptyRoomDisplay totalEmptyRoomDisplay;

    @MockBean
    private ConfigService configService;

    @Before
    public void setUp() {
        float percentEmptyShow = 20;
        int maxEmptyShow = 2;
        Mockito.when(totalEmptyRoomDisplay.get()).thenReturn(percentEmptyShow);
        Mockito.when(totalEmptyRoomDisplay.getMax()).thenReturn(maxEmptyShow);
        Mockito.when(configService.get(LMS_WEB_VCR_KEY)).thenReturn("ADB,VCRX,BBB");
    }

    private RoomDTO createRoom(long totalJoin) {
        return RoomDTO.builder()
                .id(0L)
                .maxJoin(maxJoin)
                .totalJoin(totalJoin)
                .typeClass(LS.name())
                .vcrType(BBB)
                .build();
    }

    private RoomDTO createRoom(long totalJoin, String vcr) {
        RoomDTO room = this.createRoom(totalJoin);
        room.setVcrType(vcr);
        return room;
    }

//    @Test
    public void test() {
        List<RoomDTO> rooms = Arrays.asList(
                this.createRoom(1),
                this.createRoom(0),
                this.createRoom(0),
                this.createRoom(0),
                this.createRoom(0),
                this.createRoom(0)
        );
        List<RoomDTO> listResult = listRoomDisplay.show(rooms, acceptVCR.sortLMSWeb());

        listResult.forEach(r -> System.out.println(r.getTotalJoin() +" - "+ r.getVcrType()));
//        assertEquals(7, listResult.size());
//        assertEquals(RoomDTO.EXTEND, listResult.get(listResult.size() - 1).getVcrType());
    }

//    @Test
    public void testSort() {
        List<RoomDTO> rooms = Arrays.asList(
                this.createRoom(1, BBB),
                this.createRoom(0, ADB),
                this.createRoom(0, BBB),
                this.createRoom(0, ADB),
                this.createRoom(0, VCRX),
                this.createRoom(0, ADB),
                this.createRoom(0, VCRX)
        );
        List<RoomDTO> listResult = listRoomDisplay.show(rooms, acceptVCR.sortLMSWeb());

        listResult.forEach(r -> System.out.println(r));
//        assertEquals(RoomDTO.ADB, listResult.get(0).getVcrType());
//        assertEquals(RoomDTO.BBB, listResult.get(listResult.size() - 2).getVcrType());
//        assertEquals(RoomDTO.EXTEND, listResult.get(listResult.size() - 1).getVcrType());
    }
}
