package com.topica.portal;

import lombok.extern.slf4j.Slf4j;
import org.apache.http.HeaderElement;
import org.apache.http.HeaderElementIterator;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.ConnectionKeepAliveStrategy;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeaderElementIterator;
import org.apache.http.protocol.HTTP;
import org.apache.http.protocol.HttpContext;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.web.client.RestTemplate;

import java.net.UnknownHostException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

@Slf4j
//@RunWith(SpringRunner.class)
public class InvokerTest {

//    @TestConfiguration
    static class RestTemplateContextConfiguration {


        // Determines the timeout in milliseconds until a connection is established.
        private static final int CONNECT_TIMEOUT = 30000;

        // The timeout when requesting a connection from the connection manager.
        private static final int REQUEST_TIMEOUT = 30000;

        // The timeout for waiting for data
        private static final int SOCKET_TIMEOUT = 60000;

        private static final int MAX_TOTAL_CONNECTIONS = 50;
        private static final int DEFAULT_KEEP_ALIVE_TIME_MILLIS = 20 * 1000;
        private static final int CLOSE_IDLE_CONNECTION_WAIT_TIME_SECS = 30;

        @Bean
        public PoolingHttpClientConnectionManager poolingConnectionManager() {
            SSLContextBuilder builder = new SSLContextBuilder();
            try {
                builder.loadTrustMaterial(null, new TrustSelfSignedStrategy());
            } catch (NoSuchAlgorithmException | KeyStoreException e) {
            }

            SSLConnectionSocketFactory sslsf = null;
            try {
                sslsf = new SSLConnectionSocketFactory(builder.build());
            } catch (KeyManagementException | NoSuchAlgorithmException e) {
            }

            Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder
                    .<ConnectionSocketFactory>create()
                    .register("https", sslsf)
                    .register("http", new PlainConnectionSocketFactory())
                    .build();

            PoolingHttpClientConnectionManager poolingConnectionManager = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
            poolingConnectionManager.setMaxTotal(MAX_TOTAL_CONNECTIONS);
            return poolingConnectionManager;
        }

        @Bean
        public ConnectionKeepAliveStrategy connectionKeepAliveStrategy() {
            return new ConnectionKeepAliveStrategy() {
                @Override
                public long getKeepAliveDuration(HttpResponse response, HttpContext context) {
                    HeaderElementIterator it = new BasicHeaderElementIterator
                            (response.headerIterator(HTTP.CONN_KEEP_ALIVE));
                    while (it.hasNext()) {
                        HeaderElement he = it.nextElement();
                        String param = he.getName();
                        String value = he.getValue();

                        if (value != null && param.equalsIgnoreCase("timeout")) {
                            return Long.parseLong(value) * 1000;
                        }
                    }
                    return DEFAULT_KEEP_ALIVE_TIME_MILLIS;
                }
            };
        }

        @Bean
        public CloseableHttpClient httpClient() {
            RequestConfig requestConfig = RequestConfig.custom()
                    .setConnectionRequestTimeout(REQUEST_TIMEOUT)
                    .setConnectTimeout(CONNECT_TIMEOUT)
                    .setSocketTimeout(SOCKET_TIMEOUT).build();

            return HttpClients.custom()
                    .setDefaultRequestConfig(requestConfig)
                    .setConnectionManager(poolingConnectionManager())
                    .setKeepAliveStrategy(connectionKeepAliveStrategy())
                    .build();
        }

        @Bean
        public Runnable idleConnectionMonitor(final PoolingHttpClientConnectionManager connectionManager) {
            return new Runnable() {
                @Override
                @Scheduled(fixedDelay = 10000)
                public void run() {
                    try {
                        if (connectionManager != null) {
                            connectionManager.closeExpiredConnections();
                            connectionManager.closeIdleConnections(CLOSE_IDLE_CONNECTION_WAIT_TIME_SECS, TimeUnit.SECONDS);
                        } else {
                        }
                    } catch (Exception e) {
                    }
                }
            };
        }

        @Autowired
        CloseableHttpClient httpClient;

        @Bean("restPoolTemplate")
        public RestTemplate restTemplate() {
            RestTemplate restTemplate = new RestTemplate(clientHttpRequestFactory());
            return restTemplate;
        }

        @Bean
        public HttpComponentsClientHttpRequestFactory clientHttpRequestFactory() {
            HttpComponentsClientHttpRequestFactory clientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory();
            clientHttpRequestFactory.setHttpClient(httpClient);
            return clientHttpRequestFactory;
        }

        @Bean
        public TaskScheduler taskScheduler() {
            ThreadPoolTaskScheduler scheduler = new ThreadPoolTaskScheduler();
            scheduler.setThreadNamePrefix("poolScheduler");
            scheduler.setPoolSize(50);
            return scheduler;
        }

    }

    @Autowired
    @Qualifier("restPoolTemplate")
    private RestTemplate restTemplate;

//    @Test
    public void test_unknownHost() {
        try {
            String url = "http://marketst.topicanative.edu.vn";
            ResponseEntity responseEntity = this.restTemplate.postForEntity(url, "TEST", String.class);
            System.out.println(responseEntity.getStatusCode());
        } catch (Exception e) {
            if (e.getCause() != null && e.getCause() instanceof UnknownHostException) {
                System.out.println("UnknownHostException");
                return;
            }
            System.out.println(e.getMessage());
        }
    }

//    @Test
    public void testMultiple() {
        Executor executor = Executors.newFixedThreadPool(5);

        int i = 0;
        do {
            executor.execute(() -> {
                log.info("execute --->>>");
                this.invoke_get();
            });
            executor.execute(() -> {
                log.info("execute post --->>>");
                this.invoke_post();
            });
            i++;
        } while (i < 5);

        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


//    @Test
    public void testPoolConnection_ParseDepplink() {
        String url = "https://topicaedtech.adobeconnect.com/adb4712178?session=apac1breezis674frcx9spabh4";
        Executor executor = Executors.newFixedThreadPool(3);
        int i = 0;
        do{
            executor.execute(() -> {
                long start = System.currentTimeMillis();
                String html = this.restTemplate.getForEntity(url, String.class).getBody();
                System.out.println("==>"+ Thread.currentThread().getName()+":" +(System.currentTimeMillis() - start));
//                GetDeeplinkAdobeTest.test(url);
            });
            i++;
        }while (i < 15);

        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void invoke_get() {
        String url = "http://slowwly.robertomurray.co.uk/delay/3000/url/http://www.google.co.uk";
        String res = this.restTemplate.getForEntity(url, String.class).getBody();
        log.info("======>" + res);
    }
    public void invoke_post() {
        String url = "http://slowwly.robertomurray.co.uk/delay/3000/url/http://www.google.co.uk";
        String res = this.restTemplate.postForEntity(url, "Nothing", String.class).getBody();
        log.info("POST ====>" + res);
    }
}
