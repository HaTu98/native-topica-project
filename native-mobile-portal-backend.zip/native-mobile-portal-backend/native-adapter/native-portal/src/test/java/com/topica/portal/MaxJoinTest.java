package com.topica.portal;

import com.topica.adapter.common.config.room.MaxUserInRoom;
import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.service.maxJoin.MaxJoinService;
import com.topica.portal.redis.service.config.ConfigService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import static com.topica.portal.redis.constant.KeyConfig.LMS_WEB_VCR_KEY;
import static org.junit.Assert.assertEquals;

//@SpringBootTest
//@RunWith(SpringRunner.class)
public class MaxJoinTest {
    @TestConfiguration
    static class ContextConfiguration {
        @Bean
        public MaxUserInRoom getMaxUserInRoom() {
            return new MaxUserInRoom();
        }
    }
    @MockBean
    private MaxJoinService maxJoinService;

    @MockBean
    private ConfigService configService;

    @Autowired
    private MaxUserInRoom maxUserInRoom;

//    @Before
//    public void setUp() {
//        Mockito.when(maxJoinService.getMaxUser("LMS_VIP","AA","BB")).thenReturn(null);
//        Mockito.when(configService.get(LMS_WEB_VCR_KEY)).thenReturn("ADB,VCRX,BBB");
//    }

//    @Test
//    public void testMaxJoin() {
//        RoomDTO roomDTO = new RoomDTO();
//        roomDTO.setPackageType("LMS_VIP");
//        roomDTO.setLevelClass("AA");
//        roomDTO.setTypeClass("BB");
//        assertEquals(5,maxUserInRoom.getMaxUserForRoomDB(roomDTO));
//        assertEquals(5,1+4);
//    }
}