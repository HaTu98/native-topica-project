package com.topica.portal;

import lombok.extern.slf4j.Slf4j;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.junit.Test;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@Slf4j
public class GetDeeplinkAdobeTest {
    public static final String scheme = "connectpro://";
    public static final String swfURL = "swfUrl%3Dhttps%253A%252F%252Ftopicaedtech.adobeconnect.com%252Fcommon%252FmeetingAS3%252Fshell%252Fshell.swf%253F";
    public static final String url = "https://topicaedtech.adobeconnect.com/adb4712178?session=apac1breezis674frcx9spabh4";

    //@Test
    public static void test(String uri) {
        long start = System.currentTimeMillis();
        Document doc;
//        doc = Jsoup.parse(html);
        try {
            doc = Jsoup.connect(uri).get();
        } catch (IOException e) {
            log.error("Get DeepLink Adobe error: " + e.getMessage());
            return;
        }
        Elements scripts = doc.select("body > script");

        String deepLink;

        for (Element script : scripts) {

            if (script.html().contains("swfParam")) {
                int startParam = script.html().indexOf("internalTracking");
                int endParam = script.html().indexOf("launcher%");
                String params = script.html().substring(startParam, endParam);
                try {
                    params = URLDecoder.decode(params, StandardCharsets.UTF_8.name());
                    params = URLDecoder.decode(params, StandardCharsets.UTF_8.name());
                    params = URLEncoder.encode(params, StandardCharsets.UTF_8.name());
                    params = URLEncoder.encode(params, StandardCharsets.UTF_8.name());
                } catch (UnsupportedEncodingException e) {
                    params = "";
                }
                deepLink = scheme + swfURL + params;
                System.out.println(deepLink);
                System.out.println("=> parse in:"+(System.currentTimeMillis() - start));
                break;
            }

        }
        ;
    }

}
