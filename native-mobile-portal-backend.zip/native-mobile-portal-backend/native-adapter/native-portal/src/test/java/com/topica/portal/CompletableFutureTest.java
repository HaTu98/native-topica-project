package com.topica.portal;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import static junit.framework.TestCase.assertTrue;

public class CompletableFutureTest {

//    @Test
    public void test() throws ExecutionException, InterruptedException {
        long task1Time = 200;
        long task2Time = 400;
        long startTime = System.currentTimeMillis();

        System.out.println("task1...");
        CompletableFuture<String> task1 = CompletableFuture.supplyAsync(() -> {
            System.out.println("Starting task1...");
            try {
                Thread.sleep(task1Time);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return "Result task1";
        });

        System.out.println("task2...");
        CompletableFuture<String> task2 = CompletableFuture.supplyAsync(() -> {
            System.out.println("Starting task2...");
            try {
                Thread.sleep(task2Time);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return "Result task2";
        });

        System.out.println("CombineFuture...");
        CompletableFuture<String> CombineFuture = task1.thenCombine(task2,
                (task1Res, task2Res) -> {
                    System.out.println("String CombineFuture...");
                    return task1Res +" - "+ task2Res;
                });
        System.out.println("CombineFuture result: ..." + CombineFuture.get());

        long totalTime = System.currentTimeMillis() - startTime;
        System.out.println("totalTime ==>: "+totalTime);
        assertTrue(totalTime < task1Time + task2Time);
    }
}
