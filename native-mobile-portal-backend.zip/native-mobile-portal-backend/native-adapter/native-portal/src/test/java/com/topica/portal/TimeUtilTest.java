package com.topica.portal;

import com.topica.adapter.common.exception.RoomError;
import com.topica.adapter.common.util.RoomUtil;
import com.topica.adapter.common.util.TimeUtil;

import java.util.Calendar;


public class TimeUtilTest {
//    @Test
    public void test() {
        this.getTimeAvailableToSeconds();
    }
    private void getTimeAvailableToSeconds() {
        Long result = RoomUtil.getTimeAvailableToSeconds();
        System.out.println(result);
    }

//    @Test
    public void checkTimeToJoinClass() {
        if(!TimeUtil.isEnableJoinClass() && !TimeUtil.isTimeToQuickJoinClass()) {
            System.out.println(RoomError.INVALID_TIME_JOIN);
        }
        if(TimeUtil.isTimeToQuickJoinClass()) {
            System.out.println(RoomError.INVALID_TIME_QUICK_JOIN);
        }
    }

//    @Test
    public void showTime() {
        Calendar cal = Calendar.getInstance();
        int minute = cal.get(Calendar.MINUTE);
        System.out.println(minute);
    }

//    @Test
    public void toHour() {
        long timeAvailable = 1565262000;
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(timeAvailable * 1000);
        System.out.println(cal.get(Calendar.HOUR_OF_DAY));
    }
}
