package com.topica.portal.service.portal.engineeringtest;

import com.topica.adapter.common.exception.BusinessException;
import com.topica.portal.model.portal.EngineeringTest;
import com.topica.adapter.common.service.BaseService;

public interface EngineeringTestService extends BaseService<EngineeringTest, Long> {
    EngineeringTest getEngieeringTestOnDay(String deviceid) throws BusinessException;
}
