package com.topica.portal.controller.setting;

import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.lms.model.lms.MdlHourTeach;
import com.topica.portal.errorcode.Errors;
import com.topica.portal.model.dto.notification.input.ClientNotiReceiverInputDTO;
import com.topica.portal.model.portal.SettingEngineeringTest;
import com.topica.portal.request.HourTeachListRequest;
import com.topica.portal.request.SettingEngineeringTestRequest;
import com.topica.portal.service.portal.notification.NotiConnectionService;
import com.topica.portal.service.portal.setting.SettingEngineeringTestService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

@Slf4j
@RestController
@RequestMapping("/api/portal/setting")
public class SettingController {

    @Autowired
    private SettingEngineeringTestService settingEngineeringTestService;

    @Autowired
    private NotiConnectionService notiConnectionService;

    @RequestMapping(value = "/enginerringtest", method = RequestMethod.POST)
    public ApiDataResponse enginerringTest(@RequestBody SettingEngineeringTestRequest request) throws BusinessException {
        SettingEngineeringTest engineeringTest = new SettingEngineeringTest();
        engineeringTest.setIsRequestTesting(request.getIsRequestTesting());
        return ApiDataResponse.ok(settingEngineeringTestService.save(engineeringTest));
    }


    @RequestMapping(value = "/remind/online/register", method = RequestMethod.POST)
    public ApiDataResponse registerRemind(@RequestBody HourTeachListRequest mdlHourTeach) throws BusinessException {
        List<Long> mdHourTeachList = new ArrayList<>();
        for(Long hourTeach : mdlHourTeach.getMdlHourTeachIds()) {
            if(hourTeach < 8 || hourTeach > 23) {
                return ApiDataResponse.error(HttpStatus.BAD_REQUEST.value(), "mdlHourTeachId just supported from 8 to 23");
            }
            mdHourTeachList.add(hourTeach);
        }
        notiConnectionService.onlineRemindRegister(mdHourTeachList);
        return ApiDataResponse.ok("Success");
    }

    @RequestMapping(value = "/get/values", method = RequestMethod.GET)
    public ApiDataResponse registerRemind() throws BusinessException {
        return ApiDataResponse.ok(settingEngineeringTestService.getSettingValues());
    }
}

