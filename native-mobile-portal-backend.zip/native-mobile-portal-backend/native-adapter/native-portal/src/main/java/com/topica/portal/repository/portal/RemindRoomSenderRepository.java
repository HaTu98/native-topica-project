package com.topica.portal.repository.portal;

import com.topica.portal.model.portal.RemindRoomSender;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RemindRoomSenderRepository extends JpaRepository<RemindRoomSender, Long> {
}
