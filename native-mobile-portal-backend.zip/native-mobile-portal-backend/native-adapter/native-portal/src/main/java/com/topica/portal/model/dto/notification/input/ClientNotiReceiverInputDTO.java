package com.topica.portal.model.dto.notification.input;

import com.topica.portal.model.dto.BasePagerDTO;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString(callSuper = true)
@NoArgsConstructor
public class ClientNotiReceiverInputDTO extends BasePagerDTO {
}
