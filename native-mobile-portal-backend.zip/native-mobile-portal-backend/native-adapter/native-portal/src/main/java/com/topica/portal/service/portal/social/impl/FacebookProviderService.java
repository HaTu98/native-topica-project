package com.topica.portal.service.portal.social.impl;

import com.topica.adapter.common.constant.ErrorCode;
import com.topica.adapter.common.constant.ServiceType;
import com.topica.adapter.common.dto.PersonalInfoDTO;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.util.SocialType;
import com.topica.adapter.common.model.portal.SocialMapping;
import com.topica.portal.service.portal.social.ProviderPortalService;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.social.facebook.api.Facebook;
import org.springframework.social.facebook.api.User;
import org.springframework.social.facebook.api.impl.FacebookTemplate;
import org.springframework.social.facebook.connect.FacebookConnectionFactory;
import org.springframework.social.oauth2.GrantType;
import org.springframework.social.oauth2.OAuth2Operations;
import org.springframework.social.oauth2.OAuth2Parameters;
import org.springframework.stereotype.Service;

@Service("facebookProviderService")
@Getter
public class FacebookProviderService extends ProviderPortalService<Facebook> {

    public static final String DEFAULT_PERMISSION = "public_profile, email";
    private static final GrantType DEFAULT_GRANT_TYPE = GrantType.AUTHORIZATION_CODE;
    private static String DEFAULT_REDIRECT_URI;
    private OAuth2Operations oAuth2Operations;



    public FacebookProviderService(@Value("${spring.social.facebook.appId}") String facebookAppId,
                                   @Value("${spring.social.facebook.appSecret}") String facebookSecret,
                                   @Value("${spring.social.facebook.redirectURI}") String facebookRedirectURI) {
        this.oAuth2Operations = new FacebookConnectionFactory(facebookAppId, facebookSecret).getOAuthOperations();
        DEFAULT_REDIRECT_URI = facebookRedirectURI;
    }

    @Override
    public String createAuthorizationURL() throws BusinessException {
        return createAuthorizationURL(DEFAULT_GRANT_TYPE, DEFAULT_REDIRECT_URI);
    }

    @Override
    public String createAuthorizationURL(GrantType grantType, String url) throws BusinessException {
        OAuth2Parameters params = new OAuth2Parameters();
        params.setRedirectUri(url);
        params.setScope(DEFAULT_PERMISSION);
        return getOAuth2Operations().buildAuthorizeUrl(grantType, params);
    }

    @Override
    public String getAccessToken(String code) {
        return getAccessToken(code, DEFAULT_REDIRECT_URI);
    }

    @Override
    public String getAccessToken(String code, String uri) {
        return getOAuth2Operations().exchangeForAccess(code, uri, null).getAccessToken();
    }

    @Override
    public PersonalInfoDTO getUserProfile(Facebook providerObject) throws BusinessException {
        return getUserFromProvider(providerObject);
    }

    @Override
    public PersonalInfoDTO getUserProfile(String accessToken, String accessTokenSecret) throws BusinessException {
        return getUserFromProvider(new FacebookTemplate(accessToken));
    }

    @Override
    public boolean supports(String providerName) {
        return SocialType.FACEBOOK.getSnsCode().equals(providerName);
    }

    @Override
    public User getSnsProfile(String accessToken, String accessTokenSecret) throws BusinessException {
        return getSnsProfile(new FacebookTemplate(accessToken));
    }

    @Override
    public User getSnsProfile(Facebook providerObject) throws BusinessException {
        return providerObject.fetchObject("me", User.class);
    }

    @Override
    public SocialMapping mappingSns(String code, String urlRedirect) throws BusinessException {
        String accessToken = this.getAccessToken(code, urlRedirect);
        return mappingSns(accessToken);
    }

    @Override
    @Deprecated
    public SocialMapping mappingSns(String accessToken) throws BusinessException {
        User user = this.getSnsProfile(accessToken, "");
        SocialMapping socialMapping = socialMappingService.findBySocialIdAndSocialType(user.getId(), SocialType.FACEBOOK.getSnsCode());
        if (socialMapping == null) {
            return socialMappingService.mappingSocialId(user.getId(), SocialType.FACEBOOK.getSnsCode());
        }
        return null;
    }

    @Override
    public PersonalInfoDTO getUserProfile(String snsId) throws BusinessException {
        return this.getUserProfile(snsId, SocialType.FACEBOOK);
    }

    @Override
    public SocialMapping mappingSnsSocialId(String socialId) throws BusinessException {
        return mappingSnsSocialId(socialId, SocialType.FACEBOOK);
    }

    @Override
    @Deprecated
    public void unlinkMapping() throws BusinessException {
        SocialMapping socialMapping = socialMappingService.findByUserIdAndSocialTypeAndServiceType(SocialType.FACEBOOK.getSnsCode());
        if (socialMapping == null) {
            throw new BusinessException(ErrorCode.ACCOUNT_IS_NOT_LINKED.getCode(),ErrorCode.ACCOUNT_IS_NOT_LINKED.getMessage());
        }
        socialMapping.setStatus("inactive");
        socialMappingService.save(socialMapping);
    }

    private PersonalInfoDTO getUserFromProvider(Facebook providerObject) throws BusinessException {
        try {
            User user = providerObject.fetchObject("me", User.class);
            return getUserProfile(user.getId());
        } catch (Exception ex) {
            throw new BusinessException(ErrorCode.INVALID_SOCIAL_ACCESS_TOKEN.getCode(), ErrorCode.INVALID_SOCIAL_ACCESS_TOKEN.getMessage());
        }
    }
}
