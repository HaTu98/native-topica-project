package com.topica.portal.service.portal.setting;
import com.topica.adapter.common.service.BaseService;
import com.topica.portal.model.dto.setting.SettingOuputDTO;
import com.topica.portal.model.portal.SettingEngineeringTest;

public interface SettingEngineeringTestService extends BaseService<SettingEngineeringTest, Long> {
    Boolean isIgnoreTestingByCurrentSession();
    Boolean isIgnoreTestingByUserId(Long userId);
    SettingOuputDTO getSettingValues();
}
