package com.topica.portal.model.dto.job;

import lombok.Builder;
import lombok.Data;

import java.util.Date;

@Data
@Builder
public class JobOutputDTO {
    private String jobName;
    private String groupName;
    private String jobStatus;
    private Date scheduleTime;
    private Date lastFiredTime;
    private Date nextFireTime;
}
