package com.topica.portal.controller.social;

import com.topica.adapter.common.constant.ErrorCode;
import com.topica.adapter.common.constant.ServiceType;
import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.adapter.common.dto.PersonalInfoDTO;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.model.PortalUser;
import com.topica.adapter.common.model.portal.SigninHistory;
import com.topica.adapter.common.request.LoginRequest;
import com.topica.adapter.common.request.LoginSocialRequest;
import com.topica.adapter.common.service.social.SnsServiceFactory;
import com.topica.adapter.common.service.user.UserServicePortal;
import com.topica.lms.service.lms.UserSimpleService;
import com.topica.portal.constant.LmsRoleType;
import com.topica.portal.controller.BaseController;
import com.topica.portal.redis.redis.service.PilotUserService;
import com.topica.portal.redis.service.config.ConfigService;
import com.topica.portal.service.portal.notification.NotiConnectionService;
import com.topica.portal.service.portal.user.SigninHistoryService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.view.RedirectView;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static com.topica.adapter.common.constant.ServiceType.LMS;
import static com.topica.adapter.common.constant.ServiceType.LMS_WEB;

@Slf4j
@RestController
@RequestMapping("/api/portal")
public class LoginSocialController extends BaseController {

    @Autowired
    private SnsServiceFactory snsServiceFactory;

    @Autowired
    private SigninHistoryService signinHistoryService;

    @Autowired
    private UserSimpleService userServiceSimple;

    @Autowired
    private NotiConnectionService notiConnectionService;

    @Autowired
    private PilotUserService pilotUserService;

    public static String MODE_PILOT_PORTAL = "MODE_PILOT_PORTAL";

    @Autowired
    @Qualifier("UserServicePortal")
    private UserServicePortal userServicePortal;

    @Autowired
    private ConfigService configService;

    @Value("${stream.live.socket.url}")
    private String streamBaseUrl;

    @Value("${stream.live.socket.url.https}")
    private String streamBaseUrlHttps;

    @GetMapping(value = "/login/{sns_code}")
    public RedirectView googleConnectionStatus(@PathVariable("sns_code") String snsCode) throws BusinessException {
        String redirectLogin = "";
        try {
            redirectLogin = snsServiceFactory.get(snsCode).createAuthorizationURL();
        } catch (Exception e) {
            throw new BusinessException(HttpStatus.NOT_FOUND.value(), "NOT FOUND");
        }
        return new RedirectView(redirectLogin);
    }

    @GetMapping(value = "login/{sns_code}", params = "code")
    public ApiDataResponse oauth2Callback(@PathVariable("sns_code") String snsCode, @RequestParam(value = "code") String code) throws BusinessException {
        String accessToken = snsServiceFactory.get(snsCode).getAccessToken(code);
        //PersonalInfoDTO infoData = this.login(accessToken,snsCode);
        return ApiDataResponse.ok(accessToken);
    }

    @PostMapping(value = "login/{sns_code}")
    public ApiDataResponse loginAppSocial(@PathVariable("sns_code") String snsCode, @RequestBody LoginSocialRequest loginSocialRequest) throws BusinessException {
        log.info("(loginAppSocial) {} {}", snsCode, loginSocialRequest);
        PersonalInfoDTO infoData = this.login(loginSocialRequest.getAccessToken(),snsCode);
        this.checkGen(infoData, loginSocialRequest.getServiceType());
        return ApiDataResponse.ok(infoData);
    }

    private PersonalInfoDTO loginSocial(LoginRequest loginRequest, PersonalInfoDTO infoData) throws BusinessException {
        String userName = loginRequest.getUsername();
        ServiceType serviceType = loginRequest.getServiceType();

        if(!this.isValidUserInPilotMode(userName)){
            throw new BusinessException(HttpStatus.FORBIDDEN.value(),"User do not in pilot list!");
        }

        if(!infoData.getRoleName().equals(LmsRoleType.Student.getRole())) {
            throw new BusinessException(HttpStatus.FORBIDDEN.value(), "Role is invalid !");
        }

        Optional<? extends PortalUser> optUser = userServicePortal.findUser(userName, serviceType);
        if(optUser.get().delete().intValue() == 1 || optUser.get().suspended().intValue() == 1) {
            throw new BusinessException(HttpStatus.FORBIDDEN.value(), "Status is invalid !");
        }
        this.checkUserVCRXRegisted(infoData, loginRequest);
        this.logSignin(loginRequest, infoData, SigninHistory.LOG_IN);
        this.saveUserDeviceToken(loginRequest);

        infoData.buildToken(loginRequest);
        this.setUrlStream(infoData);
        return infoData;
    }

    private LoginRequest setLoginRequest(ServiceType serviceType, String username){
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setServiceType(serviceType);
        loginRequest.setUsername(username);
        return loginRequest;
    }

    private void logSignin(LoginRequest loginRequest, PersonalInfoDTO infoData, String action) {
        SigninHistory signin = SigninHistory.from(loginRequest, infoData, action);
        portalExecutorService.submit(() -> signinHistoryService.save(signin));
    }

    private void checkUserVCRXRegisted(PersonalInfoDTO userInfo, LoginRequest loginRequest) throws BusinessException {
        ServiceType serviceType = loginRequest.getServiceType();
        Long vcrxUserId = userInfo.getUserInfo().getVcrxuserid();
        if((LMS == serviceType || LMS_WEB == serviceType) && vcrxUserId == null) {
            this.userServiceSimple.registerVCRXUser(loginRequest);
            Optional<Long> userVCRXId = userServiceSimple.getIdVCRX(userInfo.getId());
            userInfo.getUserInfo().setVcrxuserid(userVCRXId.orElse(null));
        }
    }

    private void saveUserDeviceToken(LoginRequest loginRequest) {
        if(!StringUtils.isEmpty(loginRequest.getDeviceToken())) {
            portalExecutorService.submit(() -> notiConnectionService.registerUserAndDeviceToken(loginRequest));
        }
    }

    private void setUrlStream(PersonalInfoDTO info) {
        info.setStreamSocketBaseUrl(streamBaseUrl);
        info.setStreamSocketBaseUrlHttps(streamBaseUrlHttps);
    }

    private boolean isValidUserInPilotMode(String userName) {
        try {
            String isPilot = this.configService.getFromRemote(MODE_PILOT_PORTAL);
            if (org.springframework.util.StringUtils.isEmpty(isPilot)) {
                return true;
            }

            if (!Boolean.valueOf(isPilot)) {
                return true;
            }

            Optional<Object> pilotUsers = pilotUserService.get();

            if (!pilotUsers.isPresent()) {
                return false;
            }

            List<String> listUser = Arrays.asList(pilotUsers.get().toString().split(","));
            return listUser.parallelStream().anyMatch(user -> user.toUpperCase().contains(userName.toUpperCase()));

        } catch (Exception e) {
            return true;
        }
    }

    private PersonalInfoDTO login(String accessToken,String snsCode) throws BusinessException {
        PersonalInfoDTO infoData = snsServiceFactory.get(snsCode).getUserProfile(accessToken, "");
        if (infoData == null) {
            throw new BusinessException(ErrorCode.ACCOUNT_IS_NOT_LINKED.getCode(),ErrorCode.ACCOUNT_IS_NOT_LINKED.getMessage()) ;
        }

        LoginRequest loginRequest = this.setLoginRequest(infoData.getServiceType(), infoData.getUserName());
        PersonalInfoDTO info = this.loginSocial(loginRequest, infoData);
        if (info.getServiceType().equals(LMS_WEB)) {
            info.buildTokenForStarter();
        }
        return info;
    }

    private void checkGen(PersonalInfoDTO info, ServiceType serviceType) throws BusinessException {
        switch (serviceType) {
            case LMS_VIP:
            case LMS:
                this.userServicePortal.checkValidGen(info, info.getServiceType());
                break;
            case LMS_WEB:
            case LMS_VIP_WEB:
        }
    }
}
