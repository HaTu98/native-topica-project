package com.topica.portal.constant;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

public interface Constants {

    int NO_OF_ROWS_DEFAULT_VALUE = 20;
    int CURRENT_PAGE_DEFAULT_VALUE = 1;

    String PASS = "PASS";
    String FAIL = "FAIL";

    // Authorization
    String PRE_MANAGE = "hasAuthority('MANAGER') or hasAuthority('ADMIN')";
    String PRE_ADMIN = "hasAuthority('ADMIN')";

    String[] LIST_COLUMN_STUDENT_TEMPLATE = {
            "No *",
            "Student Email *",
            "Error"
    };

    Integer MAXIMUM_STUDENT_ROWS_IN_EXCEL_FILE = 1001;
    Integer MAXIMUM_TILE_NOTIFICATION = 200;
    Integer MAXIMUM_BODY_NOTIFICATION = 5000;
    Integer MAXIMUM_SHOTCUT_BODY = 300;

    String USENAME_ISNOT_EMAIL = "username không phải là email";
    String STUDENT_ID_INVALID = "Id is invalid";
    String NOT_REIGSTERED_DEVICE_TOKEN = "Chưa đăng kí thiết bị";

    ArrayList<String> MANAGER_ROLE_LIST = new ArrayList<String>() {{
        add(LmsRoleType.Manager.getRole());
        add(LmsRoleType.POHC.getRole());
        add(LmsRoleType.POHT.getRole());
        add(LmsRoleType.POVH.getRole());
    }};

    SimpleDateFormat DATE_TIME_FORMAT = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
//    String[] ALL_STATUS = {ResultType.SUCCESS.getResult(),
//                            ResultType.FAIL.getResult(),
//                            ResultType.InProgress.getResult(),
//                            ResultType.SCHEDULED.getResult(),
//                            ResultType.UNSCHEDULED.getResult(),
//                            ResultType.WAITE_SENDING.getResult(),
//                            ResultType.CANCEL.getResult(),
//                            null
//                            };
//
//    String[] ALL_TYPES = { NotificationType.QUICKSEND.name(),
//                            NotificationType.SCHEDULED.name(),
//                            NotificationType.PREPLAN.name(),
//                            NotificationType.NORMAL.name(),
//                            null,
//    };

    String LiveStreamNotifyTitle="Nhắc vào học lớp LiveStream";
    String LiveStreamNotifyBody="Chỉ còn 15 phút nữa sẽ tới giờ vào lớp livestream ";


    String ONLINE_REMIND_REGISTER_URI = "/api/notify/online/remind/register";
    String ONLINE_REMIND_GET_URI = "/api/notify/online/remind/getOnlineClassReminded";

    String NOTIFICATION_LIST_V2_URI = "/api/notify/client/list_v2";

    String BANNER_URI = "/api/portal/banner/get";
}
