package com.topica.portal.model.portal;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;


@Data
@Entity
@Table(name = "engineering_test")
@NoArgsConstructor
public class EngineeringTest {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String username;

    private String os;

    private String appversion;

    private String deviceid;

    @Column(name = "pass_date")
    private Date passDate;

    private String status;
}
