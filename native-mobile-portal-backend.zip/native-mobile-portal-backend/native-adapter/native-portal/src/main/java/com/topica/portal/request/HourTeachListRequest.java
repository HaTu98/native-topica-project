package com.topica.portal.request;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@Data
@NoArgsConstructor
public class HourTeachListRequest {
    private Set<Long> mdlHourTeachIds;
}
