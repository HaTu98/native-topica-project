package com.topica.portal.service.portal.market;

import com.topica.adapter.common.constant.ServiceType;
import com.topica.adapter.common.dto.PackageDTO;
import com.topica.adapter.common.dto.PackageDetailDTO;
import com.topica.adapter.common.dto.PersonalInfoDTO;
import com.topica.adapter.common.service.invoker.InvokerService;
import com.topica.adapter.common.service.market.MarketService;
import com.topica.lmsvip.common.PackageStatus;
import com.topica.lmsvip.dto.MarketResponseDTO;
import com.topica.lmsvip.dto.PackageAttrsDTO;
import com.topica.lmsvip.dto.PackageResponse;
import lombok.Builder;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static com.topica.adapter.common.constant.PackageParent.TENUP;

@Slf4j
@Service("marketService")
public class MarketServiceImpl implements MarketService {

    public static final String PATH_USE_PACKAGE = "/api/useProductAPI/usePackages";

    @Autowired
    private InvokerService invokerService;

    @Value("${api.market.url}")
    private String marketUrl;

    @Value("${api.market.key}")
    private String marketKey;

    @Value("${api.market.username}")
    private String marketUsername;

    @Value("${api.market.password}")
    private String marketPass;

    @Value("${api.market.vip.url:}")
    private String marketVipUrl;

    @Value("${api.market.vip.key:}")
    private String marketVipKey;

    @Value("${api.market.vip.username:}")
    private String marketVipUsername;

    @Value("${api.market.vip.password:}")
    private String marketVipPass;

    @Override
    public <P extends PersonalInfoDTO> P setPackages(P info, ServiceType type) {
        if(info == null) return null;

        String packageStatus = PackageStatus.DEACTIVATED;
        boolean isTenupPackage = false;

        if(!StringUtils.isEmpty(info.getContactId())) {
            List<PackageDTO> packageList = this.getPackageByContactId(info.getContactId(), type);

            if (!CollectionUtils.isEmpty(packageList)) {
                for (PackageDTO item : packageList) {
                    if (item.getStatus().equals(PackageStatus.ACTIVED)) {
                        packageStatus = PackageStatus.ACTIVED;
                    }
                    if (item.getStatus().equals(PackageStatus.ACTIVED) && item.getPackageDetail().getPackageName().contains(TENUP.name())) {
                        packageStatus = PackageStatus.ACTIVED;
                        isTenupPackage = true;
                        break;
                    }
                }
            }
            info.setPackageList(packageList);
            info.setPackageStatus(packageStatus);
            info.setTenupPackage(isTenupPackage);
        }
        return info;
    }

    @Override
    public List<PackageDTO> getPackageByContactId(String contactId, ServiceType type) {
        HttpHeaders headers = new HttpHeaders();
        MarketResponseDTO response = null;
        try {
            MarketRequest marketRequest = this.getRequest(type);
            headers.add("Authorization", marketRequest.getTokenBasic());
            headers.setContentType(MediaType.APPLICATION_JSON);
            JSONObject request1 = new JSONObject();
            request1.put("contact_id", contactId);
            request1.put("key", marketRequest.getKey());

            HttpEntity entity = new HttpEntity<>(request1.toString(), headers);
            Optional<MarketResponseDTO> responseOpt = invokerService.postHeader(marketRequest.getUrl(), entity, MarketResponseDTO.class);
            if(responseOpt.isPresent()) {
                response = responseOpt.get();
            }
        } catch (Exception e) {
            log.error("Portal::market:: " + e.getMessage());
            return Collections.emptyList();
        }
        List<PackageDTO> list = new ArrayList<>();
        if(response!= null && response.isStatus() == true) {
            for(PackageResponse r : response.getData()) {
                list.add(this.toDTO(r));
            }
        }
        return list;
    }

    private MarketRequest getRequest(ServiceType type) {
        switch (type) {
            case LMS:
            case LMS_WEB:
                return this.getDefaultRequest();
            case LMS_VIP:
                if(StringUtils.isEmpty(marketVipUrl)) {
                    return this.getDefaultRequest();
                }
                return MarketRequest.builder()
                        .url(marketVipUrl + PATH_USE_PACKAGE)
                        .tokenBasic(invokerService.toBase64Token(marketVipUsername, marketVipPass))
                        .key(marketVipKey)
                        .build();
            default: return null;
        }
    }

    private MarketRequest getDefaultRequest() {
        return MarketRequest.builder()
                .url(marketUrl + PATH_USE_PACKAGE)
                .tokenBasic(invokerService.toBase64Token(marketUsername, marketPass))
                .key(marketKey)
                .build();
    }

    private PackageDTO toDTO(PackageResponse r) {
        PackageDTO packageDTO = new PackageDTO();
        packageDTO.setContactId(r.getContact_id());
        packageDTO.setStatus(r.getStatus());
        packageDTO.setCatCode(r.getCat_code());
        packageDTO.setStarttime(r.getStarttime());
        packageDTO.setTimecreated(r.getTimecreated());
        packageDTO.setTimemodified(r.getTimemodified());
        PackageAttrsDTO packageAttrs = r.getPackage_attrs();
        packageDTO.setPackageDetail(PackageDetailDTO.builder()
                .packageCode(packageAttrs.getPackage_code())
                .catCode(packageAttrs.getCat_code())
                .packageName(packageAttrs.getPackage_name())
                .packageParent(packageAttrs.getPackage_parent())
                .imgLink(packageAttrs.getLink_img())
                .build());
        packageDTO.setGenCode(r.getGen_code());
        return packageDTO;
    }

    @Data
    @Builder
    public static class MarketRequest {
        private String url;
        private String tokenBasic;
        private String key;
    }
}