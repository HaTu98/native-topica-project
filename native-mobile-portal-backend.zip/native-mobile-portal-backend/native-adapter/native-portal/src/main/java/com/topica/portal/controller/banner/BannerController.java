package com.topica.portal.controller.banner;

import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.portal.controller.BaseController;
import com.topica.portal.service.portal.notification.NotiConnectionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/api/portal/banner")
public class BannerController extends BaseController {


    @Autowired
    private NotiConnectionService notiConnectionService;

    @RequestMapping(value = "/get", method = RequestMethod.GET)
    public ApiDataResponse getAll() throws BusinessException {
        return ApiDataResponse.ok(notiConnectionService.getAllBannerBySession());
    }
}
