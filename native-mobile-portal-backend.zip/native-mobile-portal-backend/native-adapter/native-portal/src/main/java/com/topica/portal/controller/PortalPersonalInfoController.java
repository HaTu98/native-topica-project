package com.topica.portal.controller;

import com.topica.adapter.common.constant.ServiceType;
import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.model.MdlUser;
import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.dto.PersonalInfoDTO;
import com.topica.adapter.common.model.PortalUser;
import com.topica.adapter.common.request.ChangePasswordRequest;
import com.topica.adapter.common.request.UpdateInfoRequest;
import com.topica.adapter.common.service.user.UserServicePortal;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import sun.misc.Request;

import java.util.Optional;

@Slf4j
@RestController
@RequestMapping("/api/portal")
@Api(value = "PersonalInformation", description = "Personal Information", produces = MediaType.APPLICATION_JSON_VALUE)
public class PortalPersonalInfoController {

	private @Autowired @Qualifier("UserServicePortal")
	UserServicePortal userServicePortal;

	@RequestMapping(value = "/user/info", method = RequestMethod.GET)
	public ApiDataResponse getInfo(Authentication auth) throws BusinessException {
		log.info("Begin get info user: ");
		PortalMdlUser portalMdlUser = (PortalMdlUser) auth.getPrincipal();
		MdlUser mdlUser = portalMdlUser.getMdlUser();
		ServiceType serviceType = portalMdlUser.getServiceType();
		PersonalInfoDTO infoData = this.userServicePortal.findPersonalInfo(mdlUser.getId(), serviceType);
		return ApiDataResponse.ok(infoData);
	}

	@RequestMapping(value = "/user/change-password", method = RequestMethod.POST)
	public ApiDataResponse changePassword(@RequestBody ChangePasswordRequest changePasswordRequest,
																																							Authentication auth) throws BusinessException {
		log.info("Begin change password: ");
		PortalMdlUser portalMdlUser = (PortalMdlUser) auth.getPrincipal();
		MdlUser mdlUser = portalMdlUser.getMdlUser();
		ServiceType serviceType = portalMdlUser.getServiceType();
		return ApiDataResponse.ok(this.userServicePortal.changePassword(serviceType, mdlUser.getId(),
			changePasswordRequest.getOldPassword(), changePasswordRequest.getNewPassword()));
	}

	@RequestMapping(value = "/user/update-info", method = RequestMethod.POST)
	public ApiDataResponse updateInfo(@RequestBody UpdateInfoRequest updateInfoRequest,
																																			Authentication auth) throws BusinessException {
		log.info("Begin update user info: ");
		PortalMdlUser portalMdlUser = (PortalMdlUser) auth.getPrincipal();
		MdlUser mdlUser = portalMdlUser.getMdlUser();
		ServiceType serviceType = portalMdlUser.getServiceType();
		Optional<? extends PortalUser> update = this.userServicePortal.update(mdlUser.getId(), serviceType, updateInfoRequest);
		if (update.isPresent()) {
			return ApiDataResponse.ok(true);
		} else {
			return ApiDataResponse.error(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Error update user");
		}
	}
}

