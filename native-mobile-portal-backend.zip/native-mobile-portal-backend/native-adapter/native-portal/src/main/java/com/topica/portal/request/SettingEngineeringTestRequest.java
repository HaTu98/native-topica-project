package com.topica.portal.request;

import lombok.Builder;
import lombok.Data;

import javax.persistence.Column;

@Data
@Builder
public class SettingEngineeringTestRequest {
    private Boolean isRequestTesting;
}
