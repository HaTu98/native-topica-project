package com.topica.portal.service.portal.room.impl;

import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.service.BaseUserSessionService;
import com.topica.portal.errorcode.Errors;
import com.topica.portal.model.portal.RemindRoom;
import com.topica.portal.model.portal.RemindRoomSender;
import com.topica.portal.repository.portal.RemindRoomRepository;
import com.topica.portal.request.RemindRoomRequest;
import com.topica.portal.service.portal.notification.NotiConnectionService;
import com.topica.portal.service.portal.notification.RemindRoomSenderService;
import com.topica.portal.service.portal.room.RemindRoomService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.concurrent.CompletableFuture;

@Slf4j
@Service
public class RemindRoomImpl extends BaseUserSessionService implements RemindRoomService {

    @Autowired
    private RemindRoomRepository repository;

    @Autowired
    private RemindRoomSenderService remindRoomSenderService;

    @Autowired
    private NotiConnectionService notiConnectionService;

    @Override
    public void remind(RemindRoomRequest request) throws BusinessException {
        log.info("RemindRoomImpl: remind roomID: {} - type: {} - time: {}", request.getRoomId(), request.getRoomType(), request.getTimeAvailable());
        this.verify(request);
        PortalMdlUser user = this.getUserSession();
        List<RemindRoom> remindRoomList = this.repository.findByUserIdAndRoomIdAndRoomType(user.getMdlUser().getId(),
                request.getRoomId(), request.getRoomType().toString());
        if(!CollectionUtils.isEmpty(remindRoomList)) return;

        RemindRoom remind = RemindRoom.builder()
                .roomId(request.getRoomId())
                .roomName(request.getSubject())
                .roomType(request.getRoomType().toString())
                .timeAvailable(request.getTimeAvailable())
                .userId(user.getMdlUser().getId())
                .userName(user.getMdlUser().getUsername())
                .serviceType(this.getUserSession().getServiceType())
                .build();
        repository.save(remind);
        this.registerRemindingForLiveStream(request);
    }

    private void registerRemindingForLiveStream(RemindRoomRequest request) {
        RemindRoomSender roomSender = remindRoomSenderService.getByRoomId(request.getRoomId());
        String username = this.getUserSession().getMdlUser().getUsername();
        if(roomSender != null) {
            log.info("RemindRoomService::registerRemindingForLiveStream roomSender != null ----------------------");
            log.info("RemindRoomService::registerRemindingForLiveStream username: " + username + " - senderId: " + roomSender.getSenderId());
            CompletableFuture.supplyAsync(() ->
                notiConnectionService.addNewUserToSender(username, roomSender.getSenderId())
            );
            return;
        }
        CompletableFuture.supplyAsync(() -> {
            log.info("RemindRoomService::registerRemindingForLiveStream roomSender != null ----------------------");
            return notiConnectionService.initializeRemind(request, username);
        }).thenAccept((senderId) -> {
            log.info("RemindRoomService::registerRemindingForLiveStream roomSender thenAccept  -----------------------");
            if(senderId == null) return;
            RemindRoomSender remindRoomSender = RemindRoomSender.builder()
                    .roomId(request.getRoomId())
                    .senderId(senderId)
                    .isActive(true)
                    .build();
            try {
                remindRoomSenderService.save(remindRoomSender);
            } catch (BusinessException e) {
                log.info("RemindRoomService::registerRemindingForLiveStream " + e.getMessage());
            }
        });
        return;
    }

    @Override
    public void unRemind(RemindRoomRequest request) throws BusinessException {
        log.info("RemindRoomImpl: Un Remind roomID: {} - type: {} - time: {}", request.getRoomId(), request.getRoomType(), request.getTimeAvailable());
        this.verify(request);
        PortalMdlUser user = this.getUserSession();

        List<RemindRoom> remindRoomList = this.repository.findByUserIdAndRoomIdAndRoomType(user.getMdlUser().getId(),
                request.getRoomId(), request.getRoomType().toString());
//        if(CollectionUtils.isEmpty(remindRoomList)) return;

        for(RemindRoom remind: remindRoomList) {
            this.repository.delete(remind.getId());
        }
        RemindRoomSender roomSender = remindRoomSenderService.getByRoomId(request.getRoomId());
        if(roomSender == null || roomSender.getSenderId() == null) return;
        String username = this.getUserSession().getMdlUser().getUsername();
        CompletableFuture.supplyAsync(() ->
                notiConnectionService.removeUserInSender(username, roomSender.getSenderId())
        );
    }

    @Override
    public List<Long> getListRemindRoomId(List<Long> roomIds) {
        PortalMdlUser user = this.getUserSession();
        return repository.getListRemindRoomId(user.getMdlUser().getId() , user.getServiceType(), roomIds);
    }

    private void verify(RemindRoomRequest request) throws BusinessException {
        if(request.getTimeAvailable() == null) {
            throw new BusinessException(HttpStatus.BAD_REQUEST.value(), "RemindRoom: Time Available Empty");
        }

        long currentTime = System.currentTimeMillis()/ 1000;

        log.info("currentTime: " + currentTime);
        log.info("request.getTimeAvailable(): " + request.getTimeAvailable());

        long minute15 = 15 * 60;
        if((request.getTimeAvailable() - currentTime) <= minute15) {
            throw new BusinessException(Errors.TIME_SENT_BEFORE_CURRENT.getCode(), "RemindRoom: cannot be done at this time");
        }

        if(request.getRoomId() == null) {
            throw new BusinessException(HttpStatus.BAD_REQUEST.value(), "RemindRoom: Room ID Empty");
        }
        if(request.getRoomType() == null) {
            throw new BusinessException(HttpStatus.BAD_REQUEST.value(), "RemindRoom: Room type Empty");
        }
    }
}
