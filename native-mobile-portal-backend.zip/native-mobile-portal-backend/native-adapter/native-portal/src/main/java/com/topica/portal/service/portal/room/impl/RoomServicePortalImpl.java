package com.topica.portal.service.portal.room.impl;

import com.topica.adapter.common.config.room.AcceptVCR;
import com.topica.adapter.common.constant.ServiceType;
import com.topica.adapter.common.constant.SubjectType;
import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.dto.response.JoinRoomResponse;
import com.topica.adapter.common.dto.response.RoomPresentResponse;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.model.portal.JoinRoomHistory;
import com.topica.adapter.common.service.BaseTypeService;
import com.topica.adapter.common.service.room.JoinRoomHistoryService;
import com.topica.adapter.common.service.room.RoomServicePortal;
import com.topica.adapter.common.util.ListRoomDisplay;
import com.topica.adapter.common.util.RoomUtil;
import com.topica.booking.model.Ticket;
import com.topica.booking.service.TicketService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static com.topica.adapter.common.constant.SubjectType.LS;
import static com.topica.adapter.common.constant.SubjectType.SC;
import static com.topica.adapter.common.model.portal.JoinRoomHistory.Type.*;
import static com.topica.adapter.common.util.ListRoomDisplay.ID_EXTEND_ROOM_LS;
import static com.topica.adapter.common.util.ListRoomDisplay.ID_EXTEND_ROOM_SC;

@Slf4j
@Service(value = "roomServicePortal")
public class RoomServicePortalImpl extends BaseTypeService<RoomServicePortal> implements RoomServicePortal {

    @Autowired
    @Qualifier("roomServiceSimple")
    private RoomServicePortal roomServiceSimple;

    @Autowired
    @Qualifier("roomServiceWebSimple")
    private RoomServicePortal roomServiceWebSimple;

    @Autowired
    @Qualifier("roomServiceVip")
    private RoomServicePortal roomServiceVip;

    @Autowired
    private JoinRoomHistoryService joinRoomHistoryService;

    @Autowired
    private ListRoomDisplay listRoomDisplay;

    @Autowired
    private AcceptVCR acceptVCR;

    @Autowired
    private TicketService ticketService;

    @Override
    public RoomDTO getJoinedRoom() throws BusinessException {
        return this.getService().getJoinedRoom();
    }

    @Override
    public RoomPresentResponse presentRoom() throws BusinessException {
        this.checkActivePackage();
        return this.getService().presentRoom();
    }

    @Override
    public Optional<RoomDTO> getRoom(Long classId) throws BusinessException {
        return this.getService().getRoom(classId);
    }

    @Override
    public List<RoomDTO> listRoom(String classType) throws BusinessException {
        this.checkActivePackage();

        RoomDTO joinedRoom = this.getJoinedRoom();
        if(joinedRoom != null){
            return Arrays.asList(joinedRoom);
        }
        List<RoomDTO> listRoom = this.getService().listRoom(classType);
        return this.displayListRoom(listRoom);
    }

    private List<RoomDTO> displayListRoom(List<RoomDTO> list) {
        ServiceType serviceType = this.getUserSession().getServiceType();
        switch (serviceType) {
            case LMS:
                return this.listRoomDisplay.show(list, this.acceptVCR.sortLMS());
            case LMS_WEB:
                return this.listRoomDisplay.show(list, this.acceptVCR.sortLMSWeb());
            default:
                return list;
        }
    }

    private Optional<JoinRoomResponse> getJoinedRoomOnPortal() {
        Long timeAvailable = RoomUtil.getTimeAvailableToSeconds();
        Optional<JoinRoomHistory> joinedRoomOpt = this.joinRoomHistoryService.getByTime(timeAvailable);

        if(!joinedRoomOpt.isPresent()) return Optional.empty();
        return Optional.ofNullable(joinedRoomOpt.get().toResponse());
    }

    @Override
    public JoinRoomResponse joinRoom(Long classId) throws BusinessException {
        this.checkActivePackage();

        RoomDTO joinedRoom = this.getJoinedRoom();
        if(joinedRoom != null) {
            return this.reJoinRoom(joinedRoom);
        }
//        RoomUtil.checkTimeToJoin();

        if (ID_EXTEND_ROOM_LS == classId) {
            return this.quickJoinRoom(LS);
        }
        if (ID_EXTEND_ROOM_SC == classId) {
            return this.quickJoinRoom(SC);
        }
        return this.join(classId);
    }

    @Override
    public JoinRoomResponse quickJoinRoom(SubjectType subjectType) throws BusinessException {
        this.checkActivePackage();

        RoomDTO joinedRoom = this.getJoinedRoom();
        if(joinedRoom != null) {
            return this.reJoinRoom(joinedRoom);
        }
//        RoomUtil.checkTimeToQuickJoin();
        return this.quickJoin(subjectType);
    }

    @Override
    public JoinRoomResponse quickJoinRoomAudit(SubjectType subjectType) throws BusinessException {
        this.checkActivePackage();

//        RoomDTO joinedRoom = this.getJoinedRoom();
        RoomDTO joinedRoom = this.getJoinedRoomByTicket();
        if(joinedRoom != null) {
            return this.reJoinRoom(joinedRoom);
        }
        RoomUtil.checkTimeToQuickJoin();
        return this.quickJoinAudit(subjectType);
    }

    private RoomDTO getJoinedRoomByTicket() {
        Long userId = this.getUserSession().getMdlUser().getId();
        Long timeAvailable = RoomUtil.getTimeAvailableToSeconds();
        Optional<Ticket> boughtTicket = this.ticketService.getBoughtTicketByTime(userId, timeAvailable);
        if(!boughtTicket.isPresent()) {
            return null;
        }

        Long roomId = boughtTicket.get().getRoomId();
        try {
            Optional<RoomDTO> roomDTO = this.getRoom(roomId);
            roomDTO.get().setRole(boughtTicket.get().getRole());
            return roomDTO.get();
        } catch (BusinessException e) {
            log.error("getRoom: {} - error: {}", roomId, e.getMessage());
        }
        return null;
    }

    @Override
    public List<RoomDTO> getAllRoomByTime(Long timeAvailable) throws BusinessException {
        return this.getService().getAllRoomByTime(timeAvailable);
    }

    @Override
    public JoinRoomResponse reJoinRoom(RoomDTO joinedRoom) throws BusinessException {
        Optional<JoinRoomResponse> joinedRoomPortal = this.getJoinedRoomOnPortal();
        
        if(joinedRoomPortal.isPresent()) {
            boolean changedVCR = this.isChangeVCRType(joinedRoomPortal.get().getVcrType(), joinedRoom.getVcrType());
            if(!changedVCR) {
                return joinedRoomPortal.get();
            }
        }
        JoinRoomResponse joinRoomResponse = this.getService().reJoinRoom(joinedRoom);
        this.joinRoomHistoryService.save(joinRoomResponse, REJOIN);
        return joinRoomResponse;
    }

    private boolean isChangeVCRType(String oldVCR, String originalVCR) {
        return !oldVCR.equalsIgnoreCase(originalVCR);
    }

    private JoinRoomResponse join(Long classId) throws BusinessException {
        JoinRoomResponse joinRoomResponse = this.getService().joinRoom(classId);
        this.joinRoomHistoryService.save(joinRoomResponse, SELECT);
        return joinRoomResponse;
    }

    private JoinRoomResponse quickJoin (SubjectType subjectType) throws BusinessException {
        JoinRoomResponse joinRoomResponse = this.getService().quickJoinRoom(subjectType);
        this.joinRoomHistoryService.save(joinRoomResponse, AUTO);
        return joinRoomResponse;
    }

    private JoinRoomResponse quickJoinAudit (SubjectType subjectType) throws BusinessException {
        JoinRoomResponse joinRoomResponse = this.getService().quickJoinRoomAudit(subjectType);
        this.joinRoomHistoryService.save(joinRoomResponse, AUTO);
        return joinRoomResponse;
    }

    @Override
    public RoomServicePortal vipService() {
        return roomServiceVip;
    }

    @Override
    public RoomServicePortal simpleService() {
        return roomServiceSimple;
    }

    @Override
    public RoomServicePortal simpleWebService() {
        return roomServiceWebSimple;
    }
}