package com.topica.portal.repository.portal;

import com.topica.portal.model.portal.SettingEngineeringTest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SettingEngineeringTestRepository extends JpaRepository<SettingEngineeringTest, Long> {

}
