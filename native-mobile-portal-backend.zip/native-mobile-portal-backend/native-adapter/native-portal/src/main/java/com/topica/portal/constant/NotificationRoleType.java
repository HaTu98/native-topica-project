package com.topica.portal.constant;

public enum  NotificationRoleType {
    ADMIN, MANAGER
}
