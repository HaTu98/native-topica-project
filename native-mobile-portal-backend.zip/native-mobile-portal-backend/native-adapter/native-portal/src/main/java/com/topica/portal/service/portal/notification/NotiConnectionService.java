package com.topica.portal.service.portal.notification;

import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.request.LoginRequest;
import com.topica.portal.model.dto.notification.output.NotificationRestResponseDTO;
import com.topica.portal.request.RemindRoomRequest;
import org.springframework.data.domain.Sort;

import java.util.List;

public interface NotiConnectionService {

    Boolean registerUserAndDeviceToken(LoginRequest loginRequest);
    Object loadNotificationByCurrentSession(Integer pageSize, Integer pageNumer, Sort sort) throws BusinessException;
    Object loadNotificationByCurrentSessionV2(Integer pageSize, Integer pageNumer, Sort sort) throws BusinessException;
    Object getNotReadNotificationByCurrentSession ();
    Object onReadListNotification(Long[] senderId);
    Object getDetailSender(String senderId) throws BusinessException;
    Long initializeRemind(RemindRoomRequest room, String username);
    Object addNewUserToSender(String username, Long senderId);
    Object removeUserInSender(String username, Long senderId);
    Object onlineRemindRegister (List<Long> mdlHourTeachIds);
    NotificationRestResponseDTO getOnlineRemindRegistered(Long userId);
    Object getAllBannerBySession() throws BusinessException;
}
