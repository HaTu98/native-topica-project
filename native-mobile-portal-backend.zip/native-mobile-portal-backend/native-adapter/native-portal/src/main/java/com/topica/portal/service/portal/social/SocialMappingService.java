package com.topica.portal.service.portal.social;

import com.topica.adapter.common.model.portal.SocialMapping;

import java.util.List;
import java.util.Map;
import java.util.Optional;

public interface SocialMappingService {

    SocialMapping mappingSocialId(String socialId, String socialType);

    Optional<SocialMapping> fetchBySocialIdAndSocialType(String socialId, String socialType);

    boolean haveSocialAccount(String socialType);

    Optional<List<SocialMapping>> fetchAllSocialByUserId();

    SocialMapping findBySocialIdAndSocialType(String socialId, String socialType);

    SocialMapping findByUserIdAndSocialType(String socialType);

    Map<String,Boolean> checkMapping();

    @Deprecated
    SocialMapping findByUserIdAndSocialTypeAndServiceType(String socialType);

    void save(SocialMapping socialMapping);
}
