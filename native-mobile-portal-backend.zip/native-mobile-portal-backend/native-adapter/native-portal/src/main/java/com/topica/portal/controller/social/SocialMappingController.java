package com.topica.portal.controller.social;

import com.topica.adapter.common.constant.ErrorCode;
import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.model.portal.SocialMapping;
import com.topica.adapter.common.service.social.SnsServiceFactory;
import com.topica.portal.controller.BaseController;
import com.topica.portal.service.portal.social.SocialMappingService;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/api/portal/v1/sns")
@Api(value = "Social", produces = MediaType.APPLICATION_JSON_VALUE)
public class SocialMappingController extends BaseController {

    @Autowired
    private SnsServiceFactory snsServiceFactory;

    @Autowired
    private SocialMappingService socialMappingService;

    @GetMapping("/{sns_code}")
    public ApiDataResponse createTwitterAccessToken(@PathVariable("sns_code") String snsCode,
                                                    @RequestParam("oauth_code") String code,
                                                    @RequestParam(value = "oauth_verifier", required = false) String verifier) {
        return ApiDataResponse.ok(snsServiceFactory.get(snsCode).getAccessToken(code, verifier));
    }

    @GetMapping(value = "mapping/{sns_code}", params = "access_token")
    @Deprecated
    public ApiDataResponse mappingApp(@PathVariable("sns_code") String snsCode, @RequestParam("access_token") String accessToken) {
        SocialMapping socialMapping = new SocialMapping();
        try {
            socialMapping = snsServiceFactory.get(snsCode).mappingSns(accessToken);
        } catch (BusinessException e) {
            return ApiDataResponse.error(e.getCode(), e.getMessage());
        }
        if (socialMapping == null) return ApiDataResponse.error(ErrorCode.ACCOUNT_ALREADY_EXISTS.getCode(),ErrorCode.ACCOUNT_ALREADY_EXISTS.getMessage());
        return ApiDataResponse.ok("Account has been linked");
    }

    @GetMapping(value = "mapping/{sns_code}", params = "social_id")
    public ApiDataResponse mappingWebSocialId(@PathVariable("sns_code") String snsCode, @RequestParam("social_id") String socialId) throws BusinessException {
        log.info("(mappingWebSocialId) {} {}",snsCode,  socialId);
        return ApiDataResponse.ok(snsServiceFactory.get(snsCode).mappingSnsSocialId(socialId));
    }

    @GetMapping(value = "check-mapping")
    public ApiDataResponse checkMapping(){
        return ApiDataResponse.ok(socialMappingService.checkMapping());
    }

    @GetMapping(value  = "unlink/{sns_code}")
    public ApiDataResponse unlinkMapping(@PathVariable("sns_code") String snsCode) throws BusinessException {
        snsServiceFactory.get(snsCode).unlinkMapping();
        return ApiDataResponse.ok("success");
    }
}
