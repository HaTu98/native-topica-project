package com.topica.portal.service.portal.user;

import com.topica.adapter.common.constant.ServiceType;
import com.topica.adapter.common.dto.PersonalInfoDTO;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.model.PortalUser;
import com.topica.adapter.common.request.LoginRequest;
import com.topica.adapter.common.request.UpdateInfoRequest;
import com.topica.adapter.common.service.BaseTypeService;
import com.topica.adapter.common.service.user.UserServicePortal;
import com.topica.lms.service.lms.UserSimpleService;
import com.topica.lmsvip.service.user.UserVipService;
import com.topica.portal.model.portal.UserSocial;
import com.topica.portal.service.portal.function.FunctionService;
import com.topica.portal.service.portal.social.UserSocialService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import static com.topica.adapter.common.config.room.ErrorMessageConfig.*;
import static com.topica.adapter.common.constant.ServiceSocial.NATIVE_PORTAL;

@Service("UserServicePortal")
public class UserServicePortalImpl extends BaseTypeService<UserServicePortal> implements UserServicePortal {

    private @Autowired UserVipService vipUserService;
    private @Autowired UserSimpleService simpleUserService;
    private @Autowired UserSocialService userSocialService;
    private @Autowired FunctionService functionService;

    @Override
    public Optional<? extends PortalUser> findUser(String userName, ServiceType type) throws BusinessException {
        return this.chooseService(type).findUser(userName, type);
    }

    @Override
    public PersonalInfoDTO findPersonalInfo(Long userId, ServiceType type) throws BusinessException {
        PersonalInfoDTO userInfo = this.chooseService(type).findPersonalInfo(userId, type);
        this.setLinkAvatar(userInfo);
        this.setFunctions(userInfo);
        return userInfo;
    }

    private void setFunctions(PersonalInfoDTO userInfo) {
        List<String> functions = this.functionService.getFunction(userInfo);
        userInfo.setFunctions(functions);
    }

    private void setLinkAvatar(PersonalInfoDTO info) {
        Optional<UserSocial> userSocial = this.userSocialService.getByServiceWithUser(info.getId(), info.getServiceType(), NATIVE_PORTAL.name());
        if(userSocial.isPresent()) {
            info.setAvatarLink(userSocial.get().getData());
        }
    }

    @Override
    public Optional<Long> registerVCRXUser(LoginRequest loginRequest) {
        return null;
    }

    @Override
    public UserServicePortal vipService() {
        return vipUserService;
    }

    @Override
    public UserServicePortal simpleService() {
        return simpleUserService;
    }

    @Override
    public UserServicePortal simpleWebService() {
        return simpleUserService;
    }

    private UserServicePortal chooseService(ServiceType type) throws BusinessException {
        switch (type) {
            case LMS_VIP_WEB:
            case LMS_VIP: return this.vipUserService;
            case LMS_WEB:
            case LMS: return this.simpleUserService;
            default: throw new BusinessException(HttpStatus.BAD_REQUEST.value(), "Not found ServiceType");
        }
    }

    @Override
    public String getMsgForExpiredPackage() {
        return DEFAULT_PACKAGE_EXPIRED;
    }

    @Override
    public String getMsgForDeactivedPackage() {
        return DEFAULT_PACKAGE_DEACTIVED;
    }

    @Override
    public String getMsgForInvalidGEN() {
        return DEFAULT_INVALID_GEN;
    }

    @Override
    public void checkValidGen(PersonalInfoDTO info, ServiceType type) throws BusinessException {
        this.chooseService(type).checkValidGen(info, type);
    }

    @Override
    public boolean changePassword(ServiceType serviceType, Long userId, String oldPassword, String newPassword) throws BusinessException {
        return this.chooseService(serviceType).changePassword(serviceType, userId, oldPassword, newPassword);
    }

    @Override
    public Optional<? extends PortalUser> update(Long userId, ServiceType type, UpdateInfoRequest updateInfoRequest) throws BusinessException {
        return this.chooseService(type).update(userId, type, updateInfoRequest);
    }
}
