package com.topica.portal.service.portal.material.impl;

import com.topica.adapter.common.constant.SubjectType;
import com.topica.adapter.common.dto.PersonalInfoDTO;
import com.topica.adapter.common.dto.material.MaterialDTO;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.service.BaseTypeService;
import com.topica.adapter.common.service.material.MaterialService;
import com.topica.adapter.common.service.user.UserServicePortal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service("materialPortalServiceImpl")
public class MaterialPortalServiceImpl extends BaseTypeService<MaterialService> implements MaterialService {

    private @Autowired @Qualifier("materialSimpleServiceImpl") MaterialService simpleRepository;
    private @Autowired @Qualifier("materialVipServiceImpl")  MaterialService vipRepository;
    private @Autowired @Qualifier("UserServicePortal") UserServicePortal userServicePortal;

    @Override
    public Map<SubjectType, List<MaterialDTO>> get(long start, long end, String levelClass, String packageCode) throws BusinessException {
        PortalMdlUser userSession = this.getUserSession();
        PersonalInfoDTO info = userServicePortal.findPersonalInfo(userSession.getMdlUser().getId(), userSession.getServiceType());
        packageCode = info.getPackageCode();
        return this.getService().get(start, end, info.getUserInfo().getUserlv(), packageCode);
    }

    @Override
    public MaterialService vipService() {
        return vipRepository;
    }

    @Override
    public MaterialService simpleService() {
        return simpleRepository;
    }

    @Override
    public MaterialService simpleWebService() {
        return simpleRepository;

    }
}
