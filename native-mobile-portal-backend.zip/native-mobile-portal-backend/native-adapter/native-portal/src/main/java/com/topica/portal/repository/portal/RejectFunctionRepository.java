package com.topica.portal.repository.portal;

import com.topica.portal.model.portal.function.RejectFunction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RejectFunctionRepository extends JpaRepository<RejectFunction, Long> {
    List<RejectFunction> getByLevelAndPackageParentAndService(String level, String packageParent, String service);
}
