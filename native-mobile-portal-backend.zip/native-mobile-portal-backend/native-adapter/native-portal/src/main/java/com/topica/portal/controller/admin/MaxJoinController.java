package com.topica.portal.controller.admin;

import com.topica.adapter.common.config.room.MaxUserInRoom;
import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.adapter.common.request.MaxJoinRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/api/portal/setting/maxJoin")
public class MaxJoinController {
    @Autowired
    private MaxUserInRoom maxUserInRoom;

    @PostMapping("/set")
    public ApiDataResponse setMaxJoin(@RequestBody MaxJoinRequest request) {
        maxUserInRoom.insetMaxJoin(request);
        return ApiDataResponse.ok("ok");
    }

    @PostMapping("/delete")
    public ApiDataResponse deleteMaxJoin(@RequestBody MaxJoinRequest request) {
        maxUserInRoom.deleteMaxJoin(request);
        return ApiDataResponse.ok("ok");
    }
}
