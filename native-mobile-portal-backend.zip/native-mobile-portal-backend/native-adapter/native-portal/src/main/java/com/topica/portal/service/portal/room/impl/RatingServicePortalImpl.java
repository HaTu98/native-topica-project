package com.topica.portal.service.portal.room.impl;

import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.model.cara.CaraResponse;
import com.topica.adapter.common.request.CaraRequest;
import com.topica.adapter.common.service.BaseTypeService;
import com.topica.adapter.common.service.rating.RatingServicePortal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.Optional;

@Service("ratingServicePortal")
public class RatingServicePortalImpl extends BaseTypeService<RatingServicePortal> implements RatingServicePortal {

    @Autowired
    @Qualifier("ratingServiceVip")
    private RatingServicePortal ratingServiceVip;

    @Autowired
    @Qualifier("ratingServiceSimple")
    private RatingServicePortal ratingServiceSimple;

    @Override
    public Optional<CaraResponse> canRate() throws BusinessException {
        return this.getService().canRate();
    }

    @Override
    public Optional<CaraResponse> rating(CaraRequest request) throws BusinessException {
        this.validateRequest(request);
        return this.getService().rating(request);
    }

    private void validateRequest(CaraRequest request) throws BusinessException{
        if(request.getRoom_id() == null) {
            throw new BusinessException(HttpStatus.BAD_REQUEST.value(), "RoomId empty");
        }

        if(!StringUtils.isEmpty(request.getOpinion()) && request.getOpinion().length() > 255) {
            throw new BusinessException(HttpStatus.BAD_REQUEST.value(), "Opinion too long: max = 255");
        }
    }

    @Override
    public RatingServicePortal vipService() {
        return ratingServiceVip;
    }

    @Override
    public RatingServicePortal simpleService() {
        return ratingServiceSimple;
    }

    @Override
    public RatingServicePortal simpleWebService() {
        return ratingServiceSimple;
    }
}