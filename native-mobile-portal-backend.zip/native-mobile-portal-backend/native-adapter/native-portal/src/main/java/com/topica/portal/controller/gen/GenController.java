package com.topica.portal.controller.gen;

import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.lms.service.lms.gen.MdlGenMappingFunctionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/api/portal/gen")
public class GenController {
    @Autowired
    private MdlGenMappingFunctionService genService;

    @GetMapping(value = "/list-function")
    public ApiDataResponse getGen() throws BusinessException {
        return ApiDataResponse.ok(genService.getUserGen());
    }
}
