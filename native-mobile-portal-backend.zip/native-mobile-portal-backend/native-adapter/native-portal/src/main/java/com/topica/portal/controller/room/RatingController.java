package com.topica.portal.controller.room;

import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.model.cara.CaraResponse;
import com.topica.adapter.common.request.CaraRequest;
import com.topica.adapter.common.service.rating.RatingServicePortal;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Slf4j
@RestController
@RequestMapping("/api/portal/room")
@Api(value = "Rating", description = "Rating Information", produces = MediaType.APPLICATION_JSON_VALUE)
public class RatingController {

    @Autowired
    @Qualifier("ratingServicePortal")
    private RatingServicePortal ratingService;

    @GetMapping(value = "/canRate")
    public ApiDataResponse canRate() throws BusinessException {
        Optional<CaraResponse> response = ratingService.canRate();
        if(!response.isPresent() || !response.get().getStatus()) {
            return ApiDataResponse.ok(new CaraResponse.CaraData(false));
        }
        return ApiDataResponse.ok(response.get().getData());
    }

    @PostMapping(value = "/rating")
    public ApiDataResponse rating(@RequestBody CaraRequest request) throws BusinessException {
        Optional<CaraResponse> response = ratingService.rating(request);
        if(!response.isPresent() || !response.get().getStatus()) {
            throw new BusinessException(HttpStatus.BAD_REQUEST.value(), "can not rating !");
        }
        return ApiDataResponse.ok("ok");
    }

}
