package com.topica.portal.service.portal.user.impl;

import com.topica.adapter.common.model.portal.SigninHistory;
import com.topica.adapter.common.service.room.TraceLogBlackBoxService;
import com.topica.portal.repository.portal.SigninHistoryRepository;
import com.topica.portal.service.portal.user.SigninHistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class SigninHistoryImpl implements SigninHistoryService {

    private @Autowired SigninHistoryRepository historyRepository;

    @Autowired
    @Qualifier("traceLogBlackBoxServiceImpl")
    private TraceLogBlackBoxService traceLogJoinRoomService;

    @Override
    public SigninHistory save(SigninHistory model) {
        traceLogJoinRoomService.traceLogLogin(model);
        return historyRepository.save(model);
    }

    @Override
    public SigninHistory get(Long id) {
        return historyRepository.findOne(id);
    }

    @Override
    public SigninHistory update(SigninHistory model) {
        if(!historyRepository.exists(model.getId())) return null;
        return historyRepository.save(model);
    }

    @Override
    public void delete(Long id) {
        historyRepository.delete(id);
    }
}
