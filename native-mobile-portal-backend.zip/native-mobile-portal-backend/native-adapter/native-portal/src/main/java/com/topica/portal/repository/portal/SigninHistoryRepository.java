package com.topica.portal.repository.portal;

import com.topica.adapter.common.model.portal.SigninHistory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SigninHistoryRepository extends JpaRepository<SigninHistory, Long> {
}
