package com.topica.portal.controller;

import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.adapter.common.exception.ExceptionCode;
import com.topica.portal.service.portal.externalservice.ExternalService;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@Slf4j
@RestController
@RequestMapping("/api/portal/external-service")
@Api(value = "External Service", produces = MediaType.APPLICATION_JSON_VALUE)
public class ExternalServiceController {

  @Autowired
  private ExternalService externalService;

  @RequestMapping(value = "/native-world", method = RequestMethod.GET)
  public ApiDataResponse getNativeWorldLink(Authentication auth) {
    return ApiDataResponse.ok(externalService.getNativeWorldLink());
  }

  @RequestMapping(value = "/check-domain", method = RequestMethod.GET)
  public ApiDataResponse checkDomain(HttpServletRequest request) {
    String host = request.getRemoteHost();
    return ApiDataResponse.ok(host);
  }

}
