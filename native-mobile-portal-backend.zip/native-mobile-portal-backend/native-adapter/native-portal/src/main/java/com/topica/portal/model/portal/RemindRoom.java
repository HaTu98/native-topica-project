package com.topica.portal.model.portal;

import com.topica.adapter.common.constant.ServiceType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Builder
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "remind_room")
public class RemindRoom {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="user_id")
    private Long userId;

    @Column(name="user_name")
    private String userName;

    @Column(name="time_available")
    private Long timeAvailable;

    @Column(name = "room_id")
    private Long roomId;

    @Column(name="room_type")
    private String roomType;

    @Column(name="room_name")
    private String roomName;

    @Enumerated(EnumType.STRING)
    @Column(name = "service_type")
    private ServiceType serviceType;
}
