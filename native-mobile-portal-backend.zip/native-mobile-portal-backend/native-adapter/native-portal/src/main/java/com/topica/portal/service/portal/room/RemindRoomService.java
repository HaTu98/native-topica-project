package com.topica.portal.service.portal.room;

import com.topica.adapter.common.exception.BusinessException;
import com.topica.portal.request.RemindRoomRequest;
import java.util.List;

public interface RemindRoomService {
    void remind(RemindRoomRequest request) throws BusinessException;
    void unRemind(RemindRoomRequest request) throws BusinessException;
    List<Long> getListRemindRoomId(List<Long> roomIds);
}
