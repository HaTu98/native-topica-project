package com.topica.portal.model.portal;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name = "setting_engineering_test")
@NoArgsConstructor
public class SettingEngineeringTest {
    @Id
    @Column(name = "user_id")
    private Long userid;

    @Column(name = "is_request_testing")
    private Boolean isRequestTesting;

    @Column(name = "time_updated")
    private Date timeUpdated;
}
