package com.topica.portal;

import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.EnableSchedulerLock;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.jpa.JpaRepositoriesAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;

@Slf4j
@ComponentScan({
        "com.topica.adapter.common",
        "com.topica.lms",
        "com.topica.lmsvip",
        "com.topica.portal",
        "com.topica.booking"
})
@EnableScheduling
@EnableSchedulerLock(defaultLockAtMostFor = "PT30S")
@SpringBootApplication
@EnableAutoConfiguration(exclude = JpaRepositoriesAutoConfiguration.class)
public class App {
    public static void main(String[] args) {
        log.info("Start native-portal application");
        SpringApplication.run(App.class, args);
    }
}
