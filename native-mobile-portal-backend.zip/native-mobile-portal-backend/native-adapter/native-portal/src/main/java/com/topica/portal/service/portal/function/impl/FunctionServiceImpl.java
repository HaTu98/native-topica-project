package com.topica.portal.service.portal.function.impl;

import com.topica.adapter.common.dto.PersonalInfoDTO;
import com.topica.portal.model.portal.function.Function;
import com.topica.portal.model.portal.function.RejectFunction;
import com.topica.portal.repository.portal.FunctionRepository;
import com.topica.portal.repository.portal.RejectFunctionRepository;
import com.topica.portal.service.portal.function.FunctionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class FunctionServiceImpl implements FunctionService {

    @Autowired
    private FunctionRepository functionRepository;

    @Autowired
    private RejectFunctionRepository rejectFunctionRepository;

    @Override
    public List<String> getFunction(PersonalInfoDTO info) {
        List<Function> functions = this.functionRepository.findAll();
        List<String> rejectFunctions = this.getAllRejectFunction(info);
        return functions.parallelStream()
                .map(p -> p.getCode())
                .filter(functionCode -> !rejectFunctions.contains(functionCode))
                .collect(Collectors.toList());
    }

    private List<String> getAllRejectFunction(PersonalInfoDTO info) {
        List<RejectFunction> rejectFunctions = this.rejectFunctionRepository.getByLevelAndPackageParentAndService(info.getLevel(),
                info.getPackageParent(), info.getServiceType().name());
        return rejectFunctions.parallelStream().map(RejectFunction::getFunction).collect(Collectors.toList());
    }

}
