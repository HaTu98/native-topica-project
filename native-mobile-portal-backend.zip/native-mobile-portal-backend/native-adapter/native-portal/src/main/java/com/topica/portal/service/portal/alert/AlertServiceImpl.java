package com.topica.portal.service.portal.alert;

import com.topica.adapter.common.request.alert.AlertRequest;
import com.topica.adapter.common.service.alert.AlertService;
import com.topica.adapter.common.service.invoker.InvokerService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Slf4j
@Service
public class AlertServiceImpl implements AlertService {

    @Autowired
    private InvokerService invokerService;

    @Value("${alert.lms.url}")
    private String alertSimpleURL;

    @Value("${alert.vip.url}")
    private String alertVipURL;

    @Value("${alert.vip.key}")
    private String alertKeyVip;

    public static final String SITE_VIP = "lmsVip";

    @Async
    @Override
    public void sendToLMS(AlertRequest request) {
        log.info("Send to POCO LMS :data = {}", request.getContent());
        Optional response = this.invokerService.postHeader(alertSimpleURL, (HttpEntity)request.getContent(), Object.class);
        if(!response.isPresent()) {
            log.error("Alert Full to LMS Fail!");
        }
    }

    @Async
    @Override
    public void sendToLMSVip(AlertRequest request) {
        log.info("Send to POCO LMS_VIP : data = {}", request.getContent());

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("site", SITE_VIP);
        headers.set("key", alertKeyVip);
        HttpEntity httpEntity = new HttpEntity(request.getContent(), headers);

        Optional response = this.invokerService.postHeader(alertVipURL, httpEntity, Object.class);
        if(!response.isPresent()) {
            log.error("Alert Full to LMS_VIP Fail!");
        }
    }
}