package com.topica.portal.config.db;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

@Configuration
@Slf4j
public class NotificaitonConfig {

    @Bean("oneSignalHttpURLConnection")
    public HttpURLConnection getHttpURLConnection() {
        try {
            URL url = new URL("https://onesignal.com/api/v1/notifications");
            HttpURLConnection con = (HttpURLConnection)url.openConnection();
            con.setUseCaches(false);
            con.setDoOutput(true);
            con.setDoInput(true);

            con.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            con.setRequestProperty("Authorization", "Basic MDM0ODZlYmMtZjY2OS00YzRlLWE2NGMtMDAxYTFmOGI0NzYx");
            con.setRequestMethod("POST");
            return con;
        } catch (IOException e) {
            log.error("Portall::getHttpURLConnection::e:: " + e.getMessage());
            return null;
        }
    }
}
