var stompClient = null;
var topic = '/topic/lms/full-class';
var url = 'http://mobilevipstaging.topica.edu.vn/socket';

$(document).ready(function() {
    connect();
});

function connect() {
    var socket = new SockJS(url);
    stompClient = Stomp.over(socket);
    stompClient.connect({}, function (frame) {
        console.log('Connected: ' + frame);
        stompClient.subscribe(topic, function (message) {
            showMessage(message.body);
        });
    });
}

function showMessage(message) {
    alert(message);
}

