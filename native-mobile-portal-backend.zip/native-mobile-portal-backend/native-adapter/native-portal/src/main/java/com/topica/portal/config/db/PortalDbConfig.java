package com.topica.portal.config.db;

import net.javacrumbs.shedlock.core.LockProvider;
import net.javacrumbs.shedlock.provider.jdbctemplate.JdbcTemplateLockProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
		entityManagerFactoryRef = "portalEntityManager",
		transactionManagerRef = "portalTransactionManager",
		basePackages = {
				"com.topica.portal.repository.portal",
				"com.topica.adapter.common.repository.portal",
				"com.topica.portal.redis.repository",
				"com.topica.booking.repository"
		}
)
public class PortalDbConfig extends DbConfig {
	
	private String[] ENTITYMANAGER_PACKAGES_TO_SCAN = {
			"com.topica.portal.model.portal",
			"com.topica.adapter.common.model.portal",
			"com.topica.portal.redis.model",
			"com.topica.booking.model"
	};
	{
		DB_URL = "portal.db.url";
		DB_USER = "portal.db.user";
		DB_PASSWORD = "portal.db.password";
	}

	@Primary
	@Bean(name = "portalDataSource")
	public DataSource portalDataSource() {
		return this.buildDataSource();
	}

	@Bean
	@Autowired
	public LockProvider lockProvider(@Qualifier("portalDataSource") DataSource dataSource) {
		return new JdbcTemplateLockProvider(dataSource);
	}

	@Primary
	@Bean
	public PlatformTransactionManager portalTransactionManager() {
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(vipEntityManager().getObject());
		return transactionManager;
	}

	@Primary
	@Bean(name = "portalEntityManager")
	public LocalContainerEntityManagerFactoryBean vipEntityManager() {
		LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
		em.setDataSource(portalDataSource());
		em.setPackagesToScan(ENTITYMANAGER_PACKAGES_TO_SCAN);
		em.setJpaVendorAdapter(vendorAdaptor());
		em.setPersistenceUnitName("native-portal");
		return em;
	}
}
