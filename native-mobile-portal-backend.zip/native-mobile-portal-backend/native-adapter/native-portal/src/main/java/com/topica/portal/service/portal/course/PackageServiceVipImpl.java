package com.topica.portal.service.portal.course;

import com.topica.adapter.common.constant.ServiceType;
import com.topica.adapter.common.dto.MarketPackage;
import com.topica.adapter.common.dto.request.ActiveRequest;
import com.topica.adapter.common.dto.response.GetPackageResponse;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.service.BaseUserSessionService;
import com.topica.adapter.common.service.course.ActivePackageService;
import com.topica.adapter.common.service.course.PackageServicePortal;
import com.topica.lmsvip.model.lms.MdlUserInfoData;
import com.topica.lmsvip.service.UserInfoDataService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service("packageServiceVip")
@Slf4j
public class PackageServiceVipImpl extends BaseUserSessionService implements
    PackageServicePortal {

  @Autowired
  private ActivePackageService packageService;

  @Autowired
  UserInfoDataService userInfoDataService;

  @Override
  public Optional<GetPackageResponse> getListPackage() {
    Long userId = this.getUserSession().getMdlUser().getId();
    MdlUserInfoData userInfo = userInfoDataService.findByUseridAndFieldid(userId,88);
    if(userInfo == null) {
      return Optional.empty();
    }
    String contactId = userInfo.getData();
    GetPackageResponse response = packageService.getListPackage(contactId);
    return Optional.of(response);
  }

  @Override
  public Optional<Boolean> activePackage(ActiveRequest activeRequest) {
    List<MarketPackage> deactivedPackage = Collections.emptyList();
    try {
      deactivedPackage = isCanActive();
    } catch (BusinessException e) {
      return Optional.of(false);
    }
    Optional<MarketPackage> targetPackage = deactivedPackage.stream()
            .filter(p -> activeRequest.getProductId().equals(p.getProductId()))
            .findFirst();
    if(!targetPackage.isPresent()) {
      log.error("not found deactive package on request!");
      return Optional.of(false);
    }
    activeRequest.setGenCode(targetPackage.get().getGenCode());
    activeRequest.setUserId(this.getUserSession().getMdlUser().getId());
    return packageService.activePackage(activeRequest, ServiceType.LMS_VIP);
  }

  @Override
  public List<MarketPackage> isCanActive() throws BusinessException {
    List<MarketPackage> listPackage = getListPackage().get().getData();
    return packageService.isCanActive(listPackage);
  }

}
