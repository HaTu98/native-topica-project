package com.topica.portal.service.portal.nativeSmile.impl;

import com.topica.adapter.common.constant.ServiceSocial;
import com.topica.adapter.common.dto.response.GetSmileStudentResponse;
import com.topica.adapter.common.request.FilterQuestionRequest;
import com.topica.adapter.common.service.BaseUserSessionService;
import com.topica.adapter.common.service.invoker.InvokerService;
import com.topica.adapter.common.util.ExceptionUtil;
import com.topica.portal.model.portal.UserSocial;
import com.topica.portal.service.portal.nativeSmile.NativeSmileService;
import com.topica.portal.service.portal.social.UserSocialService;
import lombok.extern.slf4j.Slf4j;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.Charset;
import java.util.Optional;

@Service
@Slf4j
public class NativeSmileServiceImpl extends BaseUserSessionService implements NativeSmileService {

  @Value("${native.smile.url}")
  private String baseUrl;

  private static final String uriGetAll = "getAllThreadInCourse";

  private static final String uriGetMyQuestion = "getMyThreadInCourse";

  private static final String uriAdd = "Add";

  private static final String uriDetail = "detailH2472";

  private static final String uriRate = "ratingReply";

  private static final String uriSearch = "search";

  private static final String uriFilter = "filter";

  private static final String uriInfoQuestionType = "infoFormAddH2472";

  private static final String uriCheckExist = "checkUserExist";

  @Value("${native.smile.username}")
  private String username;

  @Value("${native.smile.password}")
  private String password;

  @Value("${native.smile.courseId}")
  private String courseId;

  @Autowired
  private InvokerService invokerService;

  @Autowired
  private UserSocialService userSocialService;

  @Override
  public Optional<Object> getAllQuestion(Integer page) {
    String url = baseUrl.concat(uriGetAll).concat("?page=").concat(String.valueOf(page));
    return getListQuestionWithUrl(url);
  }

  @Override
  public Optional<Object> getMyQuestion(Integer page) {
    String url = baseUrl.concat(uriGetMyQuestion).concat("?page=").concat(page.toString());
    return getListQuestionWithUrl(url);
  }

  @Override
  public Optional<Object> addQuestion(String answerName, String topicId, String answerdes, String groupId, MultipartFile attach) {
    Optional<String> smileStudentId = this.getStudentId();
    if(!smileStudentId.isPresent()){
      return Optional.empty();
    }

    HttpHeaders headers = generateHeader();
    headers.setContentType(MediaType.MULTIPART_FORM_DATA);
    MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
    map.add("answername", answerName);
    map.add("topicid", topicId);
    map.add("answerdes", answerdes);
    map.add("courseid", courseId);
    map.add("groupid", groupId);
    map.add("userid", smileStudentId.get());

    File attachFile = null;
    if(attach != null){
      attachFile = convertToFile(attach);
      map.add("attach", new FileSystemResource(attachFile));
    }

    HttpEntity<Object> request = new HttpEntity<>(map, headers);
    Optional<Object> response = invokerService.postHeader(baseUrl.concat(uriAdd), request, Object.class);
    if(attachFile != null) {
      attachFile.delete();
    }
    return response;
  }

  @Override
  public Optional<Object> getQuestionDetail(String threadId) {
    MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
    map.add("threadId", threadId);
    HttpEntity<Object> request = new HttpEntity<>(map, generateHeader());

    Optional<Object> response = invokerService.postHeader(baseUrl.concat(uriDetail), request, Object.class);
    return response;
  }

  @Override
  public Optional<Object> ratingReply(String replyId, String ratingId, String ratingContent) {
    Optional<String> smileStudentId = this.getStudentId();
    if(!smileStudentId.isPresent()){
      return Optional.empty();
    }

    MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
    map.add("userID", smileStudentId.get());
    map.add("replyID", replyId);
    map.add("ratingID", ratingId);
    map.add("ratingContent", ratingContent);
    HttpEntity<Object> request = new HttpEntity<>(map, generateHeader());

    Optional<Object> response = invokerService.postHeader(baseUrl.concat(uriRate), request, Object.class);
    return response;
  }

  @Override
  public Optional<Object> searchQuestion(String key, Integer page) {
    Optional<String> smileStudentId = this.getStudentId();
    if(!smileStudentId.isPresent()){
      return Optional.empty();
    }

    UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(baseUrl.concat(uriSearch))
        .queryParam("page", page)
        .queryParam("key", key);

    MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
    map.add("userID", smileStudentId.get());

    HttpEntity<Object> request = new HttpEntity<>(map, generateHeader());

    Optional<Object> response = invokerService.postHeader(builder.toUriString(), request, Object.class);
    return response;
  }

  @Override
  public Optional<Object> filterQuestion(Integer page, FilterQuestionRequest filterInfo) {
    Optional<String> smileStudentId = this.getStudentId();
    if(!smileStudentId.isPresent()){
      return Optional.empty();
    }

    MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
    map.add("userID", smileStudentId.get());
    map.add("topicid", filterInfo.getTopicId());
    map.add("status", filterInfo.getStatus());
    map.add("attach", filterInfo.getAttach());
    HttpEntity<Object> request = new HttpEntity<>(map, generateHeader());

    String url = baseUrl.concat(uriFilter).concat("?page=").concat(page.toString());
    Optional<Object> response = invokerService.postHeader(url, request, Object.class);
    return response;
  }

  @Override
  public Optional<Object> getListQuestionType() {

    HttpEntity<Object> request = new HttpEntity<>(null, generateHeader());

    Optional<Object> response = invokerService.postHeader(baseUrl.concat(uriInfoQuestionType), request, Object.class);
    return response;
  }

  private Optional<Long> requestStudentId() {

    MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
    map.add("username_native", this.getUserSession().getMdlUser().getUsername());
    map.add("firstname", this.getUserSession().getFirstName());
    map.add("lastname", this.getUserSession().getLastName());
    map.add("email", this.getUserSession().getEmail());
    map.add("student_id", String.valueOf(this.getUserSession().getMdlUser().getId()));

    HttpEntity<Object> request = new HttpEntity<>(map, generateHeader());

    Optional<GetSmileStudentResponse> studentSmileIdResponse = invokerService.postHeader(baseUrl.concat(uriCheckExist), request, GetSmileStudentResponse.class);
    if(!studentSmileIdResponse.isPresent()){
      return Optional.empty();
    }

    return Optional.of(Long.valueOf(studentSmileIdResponse.get().getStudent_id()));
  }

  private String generateBasicAuth(){
    String auth = username + ":" + password;
    byte[] encodedAuth = Base64.encodeBase64(
        auth.getBytes(Charset.forName("US-ASCII")) );
    return "Basic " + new String( encodedAuth );
  }

  private HttpHeaders generateHeader(){

    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
    headers.set("Authorization", generateBasicAuth());
    return headers;
  }

  private Optional<String> getStudentId(){
    Optional<UserSocial> optionalSocial = userSocialService.getByService(ServiceSocial.NATIVE_SMILE.name());
    if(optionalSocial.isPresent()){
      return Optional.of(optionalSocial.get().getData());
    }

    Optional<Long> smileStudentId = this.requestStudentId();

    if(!smileStudentId.isPresent()){
      return Optional.empty();
    }

    Optional<UserSocial> optionalSocialSave = userSocialService.saveSmileStudentId(smileStudentId.get());

    if(!optionalSocialSave.isPresent()){
      return Optional.empty();
    }
    return Optional.of(optionalSocialSave.get().getData());
  }

  private Optional<Object> getListQuestionWithUrl(String url){
    Optional<String> smileStudentId = this.getStudentId();

    if(!smileStudentId.isPresent()){
      return Optional.empty();
    }

    MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
    map.add("courseID", courseId);
    map.add("userID", smileStudentId.get());

    HttpEntity<Object> request = new HttpEntity<>(map, generateHeader());

    Optional<Object> response = invokerService.postHeader(url, request, Object.class);
    if(!response.isPresent()){
      return Optional.empty();
    }

    return response;
  }

  private File convertToFile(MultipartFile multipartFile){
    try{
      File convFile = new File(multipartFile.getOriginalFilename());
      convFile.createNewFile();
      FileOutputStream fos = new FileOutputStream(convFile);
      fos.write(multipartFile.getBytes());
      fos.close();
      return convFile;
    }catch (Exception e){
      log.info("(convertToFile)err {}", ExceptionUtil.getStackTrace(e));
      return null;
    }


  }
}
