package com.topica.portal.service.portal.room.impl;

import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.dto.response.JoinRoomResponse;
import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.model.portal.JoinRoomHistory;
import com.topica.adapter.common.repository.portal.JoinRoomHistoryRepository;
import com.topica.adapter.common.service.BaseUserSessionService;
import com.topica.adapter.common.service.room.JoinRoomHistoryService;
import com.topica.adapter.common.util.RoomUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Optional;

@Slf4j
@Service
public class JoinRoomHistoryImpl extends BaseUserSessionService implements JoinRoomHistoryService {

    private @Autowired JoinRoomHistoryRepository repository;

    @Override
    public void save(JoinRoomHistory joinRoom) {
        this.repository.save(joinRoom);
    }

    @Override
    public void save(JoinRoomResponse joinRoomResponse, JoinRoomHistory.Type joinType) {
        if(joinRoomResponse == null || joinRoomResponse == JoinRoomResponse.empty) return;

        String vcrType = joinRoomResponse.getVcrType();
        switch (vcrType) {
            case RoomDTO.VCRX: this.saveVCRX(joinRoomResponse, joinType); break;
            case RoomDTO.ADB: this.saveADB(joinRoomResponse, joinType); break;
            case RoomDTO.BBB: this.saveBBB(joinRoomResponse, joinType); break;
            default:
                log.error("Cannot save joined room type: not found");
                return;
        }
    }

    private void saveBBB(JoinRoomResponse response, JoinRoomHistory.Type joinType) {
        if(StringUtils.isEmpty(response.getLink())) return;
        PortalMdlUser user = this.getUserSession();
        log.info("Save joined room: BBB - user:{}", user.getMdlUser().getUsername());
        this.repository.save(this.buildHistory(response, joinType, user));
    }

    private void saveVCRX(JoinRoomResponse response, JoinRoomHistory.Type joinType) {
        if(!response.getData().getStatus()) return;
        if(response.getData().getClassId() == null) return;
        if(response.getData().getClassIdVcrx() == null) return;

        PortalMdlUser user = this.getUserSession();
        log.info("Save joined room: VCRX - user: {}", user.getMdlUser().getUsername());
        this.repository.save(this.buildHistory(response, joinType, user));
    }

    private void saveADB(JoinRoomResponse response, JoinRoomHistory.Type joinType) {
        if(StringUtils.isEmpty(response.getLink())) return;

        PortalMdlUser user = this.getUserSession();
        log.info("Save joined room: ADB - user:{}", user.getMdlUser().getUsername());
        this.repository.save(this.buildHistory(response, joinType, user));
    }

    @Override
    public Optional<JoinRoomHistory> getByTime(Long timeAvailable) {
        PortalMdlUser user = this.getUserSession();
        Long userId = user.getMdlUser().getId();
        String serviceType = user.getServiceType().toString();

        List<JoinRoomHistory> joinRoomHistories = repository.
                findByUserIdAndServiceTypeAndTimeAvailableOrderByCreatedTimeDesc(userId, serviceType, timeAvailable);
        if(CollectionUtils.isEmpty(joinRoomHistories)) {
            return Optional.empty();
        }
        JoinRoomHistory joined = joinRoomHistories.get(0);
        log.info("User: {} - ReJoin Room: {} - {}", user.getMdlUser().getUsername(), joined.getRoomId(), joined.getVcrType());
        return Optional.of(joined);
    }

    private JoinRoomHistory buildHistory(JoinRoomResponse response, JoinRoomHistory.Type joinType, PortalMdlUser user) {
        return JoinRoomHistory.builder()
                .roomId(response.getRoomId())
                .ticketId(response.getTicketId())
                .link(response.getLink())
                .deepLink(response.getDeeplink())
                .userId(user.getMdlUser().getId())
                .serviceType(user.getServiceType().toString())
                .vcrType(response.getVcrType())
                .timeAvailable(RoomUtil.getTimeAvailableToSeconds())
                .joinType(joinType.name())
                .role(response.getRole())
                .sessionCreatedTime(response.getCreatedTime())
                .serviceType(user.getServiceType().name())
                .extenalRoomId(response.getData() == null ? null : response.getData().getClassIdVcrx())
                .build();
    }

}
