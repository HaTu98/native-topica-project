package com.topica.portal.controller.learningGoal;

import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.adapter.common.dto.LearningGoalData;
import com.topica.adapter.common.dto.LevelLearningGoalDTO;
import com.topica.adapter.common.dto.request.TotalLearningObjectRequest;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.service.learningResult.LearningResultService;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/api/portal/learning-goal")
@Api(value = "Learning Goal", produces = MediaType.APPLICATION_JSON_VALUE)
public class LearningGoalController {

  @Autowired
  private LearningResultService learningResultService;

  @Autowired
  private com.topica.adapter.common.service.LearningGoalNew.LearningGoalService learningGoalServiceNew;

  @GetMapping(value = "/student-level")
  public ApiDataResponse getLearningObjectMilestone() {
    List<LearningGoalData> learningGoalData = learningGoalServiceNew.getListLevel();
    return ApiDataResponse.ok(learningGoalData);
  }

  @GetMapping(value = "/get")
  public ApiDataResponse getAllLearningGoal() {
    return ApiDataResponse.ok(learningGoalServiceNew.getLearningGoal());
  }

  @GetMapping(value = "/get-level")
  public ApiDataResponse getGoal(@RequestParam(value = "options") String request) throws BusinessException {
    String[] data = request.split(",");

    return ApiDataResponse.ok(learningGoalServiceNew.getEngLevel(data));
  }

  @PostMapping(value = "/set-level")
  public ApiDataResponse setGoal(@RequestBody Map<String, List<Long>> request) throws BusinessException {
    return ApiDataResponse.ok(learningGoalServiceNew.setEndLevel(request.get("options")));
  }

  @GetMapping(value = "/get-level/learning")
  public ApiDataResponse getTargetLevel(@RequestParam(value = "userId", required = false) Long studentId, Authentication auth) throws BusinessException {
    LevelLearningGoalDTO levelLearningGoalDTO = learningGoalServiceNew.getTargetLevel();

    PortalMdlUser portalMdlUser = (PortalMdlUser) auth.getPrincipal();
    Long userId = portalMdlUser.getMdlUser().getId();
    levelLearningGoalDTO.setUsedPoint(learningResultService.getUsedPointOfUser(studentId == null ? userId : studentId));

    return ApiDataResponse.ok(levelLearningGoalDTO);
  }

  @GetMapping(value = "user-select")
  public ApiDataResponse getDataGoal() {
    return ApiDataResponse.ok(learningGoalServiceNew.getUserLearningGoal());
  }

  @PostMapping(value = "set-user-info")
  public ApiDataResponse setUserInfo(@RequestBody Map<String, List<Long>> request) {
    return ApiDataResponse.ok(learningGoalServiceNew.saveInfo(request.get("options")));
  }

  @PostMapping(value = "set-goal")
  public ApiDataResponse setUserGoal(@RequestBody Map<String, List<Long>> request) throws BusinessException {
    return ApiDataResponse.ok(learningGoalServiceNew.saveGoal(request.get("options")));
  }

  @GetMapping(value = "/top-pronounce")
  public ApiDataResponse getTopPronounce(@RequestParam(value = "userId", required = false) Long studentId, Authentication auth) {

    PortalMdlUser portalMdlUser = (PortalMdlUser) auth.getPrincipal();
    long userId = portalMdlUser.getMdlUser().getId();

    return ApiDataResponse.ok(learningResultService.getTopPronounceHistory(studentId == null ? userId : studentId));
  }

  @GetMapping(value = "/real-total-learning-object")
  public ApiDataResponse getRealTotalLearningObject(TotalLearningObjectRequest request, Authentication auth) {
    PortalMdlUser portalMdlUser = (PortalMdlUser) auth.getPrincipal();
    Long userId = portalMdlUser.getMdlUser().getId();
    if (request.getUserId() == null) {
      request.setUserId(userId);
    }
    return ApiDataResponse.ok(learningResultService.getRealTotalLearningObject(request));
  }

  @GetMapping(value = "/desire-total-learning-object")
  public ApiDataResponse getDesireTotalLearningObject(TotalLearningObjectRequest request, Authentication auth) {
    PortalMdlUser portalMdlUser = (PortalMdlUser) auth.getPrincipal();
    Long userId = portalMdlUser.getMdlUser().getId();
    if (request.getUserId() == null) {
      request.setUserId(userId);
    }
    return ApiDataResponse.ok(learningResultService.getDesireTotalLearningObject(request));
  }

}
