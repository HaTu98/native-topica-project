package com.topica.portal.service.portal.social;

import com.topica.adapter.common.constant.ErrorCode;
import com.topica.adapter.common.constant.ServiceType;
import com.topica.adapter.common.dto.PersonalInfoDTO;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.model.portal.SocialMapping;
import com.topica.adapter.common.service.social.BaseProviderService;
import com.topica.adapter.common.service.user.UserServicePortal;
import com.topica.adapter.common.util.SocialType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public abstract class ProviderPortalService<P> implements BaseProviderService<P> {

  @Autowired
  protected SocialMappingService socialMappingService;

  @Qualifier("UserServicePortal")
  @Autowired
  protected UserServicePortal userServicePortal;

  protected SocialMapping mappingSnsSocialId(String socialId, SocialType socialType) throws BusinessException {
    SocialMapping socialMapping = socialMappingService.findBySocialIdAndSocialType(socialId, socialType.getSnsCode());
    if (socialMapping != null) {
      throw new BusinessException(ErrorCode.ACCOUNT_ALREADY_EXISTS.getCode(), ErrorCode.ACCOUNT_ALREADY_EXISTS.getMessage());
    }
    return socialMappingService.mappingSocialId(socialId, socialType.getSnsCode());
  }

  protected PersonalInfoDTO getUserProfile(String snsId, SocialType socialType) throws BusinessException {
    SocialMapping socialMapping = socialMappingService.findBySocialIdAndSocialType(snsId, socialType.getSnsCode());
    if (socialMapping == null) return null;
    PersonalInfoDTO personalInfo = this.userServicePortal.findPersonalInfo(socialMapping.getUserId(), ServiceType.valueOf(socialMapping.getServiceType()));
    personalInfo.setServiceType(ServiceType.valueOf(socialMapping.getServiceType()));
    return personalInfo;
  }
}
