package com.topica.portal.service.portal.social;

import com.topica.adapter.common.constant.ServiceType;
import com.topica.portal.model.portal.UserSocial;

import java.util.Optional;

public interface UserSocialService {
  Optional<UserSocial> saveToken(UserSocial userSocial);

  Optional<UserSocial> getByService(String service);

  Optional<UserSocial> getByServiceWithUser(Long userId, ServiceType serviceType, String service);

  Optional<UserSocial> saveAvatar(String urlAvatar);

  Optional<UserSocial> saveSmileStudentId(Long studentId);
}
