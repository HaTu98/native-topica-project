package com.topica.portal.controller.admin;

import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.adapter.common.service.levelClassMapping.LevelClassMappingService;
import com.topica.adapter.common.request.LevelClassMappingRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/api/portal/setting/levelClass")
public class LevelClassMappingController {
    @Autowired
    private LevelClassMappingService levelClassMappingService;

    @PostMapping("set")
    public ApiDataResponse set(@RequestBody LevelClassMappingRequest request){
        levelClassMappingService.save(request);
        return ApiDataResponse.ok("ok");
    }

    @PostMapping("delete")
    public ApiDataResponse delete(@RequestBody LevelClassMappingRequest request){
        levelClassMappingService.delete(request);
        return ApiDataResponse.ok("ok");
    }

    @GetMapping("get")
    public ApiDataResponse get(@RequestBody LevelClassMappingRequest request) {
        return ApiDataResponse.ok(levelClassMappingService.getLevelClass(request));
    }

}
