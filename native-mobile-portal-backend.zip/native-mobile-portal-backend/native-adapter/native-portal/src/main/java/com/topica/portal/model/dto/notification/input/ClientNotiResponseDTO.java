package com.topica.portal.model.dto.notification.input;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ClientNotiResponseDTO {
    private Long senderId;
    private Long[] senderIds;
    private Long receiverId;
}
