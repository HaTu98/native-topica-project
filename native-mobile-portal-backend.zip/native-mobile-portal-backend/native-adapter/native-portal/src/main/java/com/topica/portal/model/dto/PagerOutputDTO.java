package com.topica.portal.model.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Data
@NoArgsConstructor
public class PagerOutputDTO<T> {
    private Integer size;
    private Integer number;
    private Long totalElements;
    private Integer totalPages;
    private List<T> content = Collections.EMPTY_LIST;
    private Long unread;

    public static PagerOutputDTO getDefault() {
        return new PagerOutputDTO();
    }
}
