package com.topica.portal.response;

import lombok.Data;

@Data
public class AlertResponse {
    private Object data;
    private String message;
    private String status;
}
