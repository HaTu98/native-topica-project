package com.topica.portal.service.portal.sercurity;

import com.topica.adapter.common.constant.ServiceType;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.model.PortalUser;
import com.topica.adapter.common.request.LoginRequest;
import com.topica.adapter.common.dto.PersonalInfoDTO;
import com.topica.adapter.common.service.user.UserServicePortal;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.session.SessionAuthenticationException;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.Optional;

@Slf4j
@Service("authenticationHelper")
public class AuthenticationHelper {

    @Qualifier("UserServicePortal")
    private @Autowired UserServicePortal userServicePortal;
    private @Autowired PasswordEncoder passwordEncoder;

    public PersonalInfoDTO verifyToken(Authentication authentication) throws BusinessException {
        PortalMdlUser userSession = (PortalMdlUser) authentication.getPrincipal();
        ServiceType serviceType = userSession.getServiceType();
        String password = userSession.getMdlUser().getPassword();
        String username = userSession.getMdlUser().getUsername();
        log.info("Verify token: user: {} - service: {}", username, serviceType.name());

        if(StringUtils.isEmpty(userSession.getLevel())) {
            throw new SessionAuthenticationException("Empty: Please login");
        }
        Optional<? extends PortalUser> optUser = userServicePortal.findUser(username, serviceType);
        if(!optUser.isPresent()) {
            throw new SessionAuthenticationException("User not found");
        }
//        if(!optUser.isPresent() || !this.passwordEncoder.matches(password, optUser.get().password())) {
//            throw new SessionAuthenticationException("User not found");
//        }
        if(optUser.get().delete().intValue() == 1 || optUser.get().suspended().intValue() == 1) {
            throw new SessionAuthenticationException("User not actived");
        }
        PersonalInfoDTO infoData = this.userServicePortal.findPersonalInfo(optUser.get().getUserId(), serviceType);
        infoData.buildToken(LoginRequest.builder().password(password).serviceType(serviceType).build());
        return infoData;
    }
}