package com.topica.portal.websocket.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;

@Controller
@Slf4j
public class WebSocketController {

  @MessageMapping("/lms/full-class")
  @SendTo("/topic/lms/full-class")
  @CrossOrigin
  public String fullClassAlert(String message) throws Exception {
    log.info("Receiver Message : fullClassAlert: {}", message);
//    return message;
    return null;
  }

}
