package com.topica.portal.controller.material;

import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.util.TimeUtil;
import com.topica.adapter.common.dto.material.MaterialDTO;
import com.topica.adapter.common.service.material.MaterialService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.security.auth.Subject;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/api/portal/material")
@Api(value = "Material", description = "Material Information", produces = MediaType.APPLICATION_JSON_VALUE)
public class MaterialController {

    @Autowired
    @Qualifier("materialPortalServiceImpl")
    private MaterialService materialService;

    @GetMapping("get")
    public ApiDataResponse<Map<Subject, MaterialDTO>> get(@ApiParam("week of Year")@RequestParam("week") int week) {
        long start = TimeUtil.getFirstDayOfWeekToSeconds(week);
        long end = TimeUtil.getLastDayOfWeekToSeconds(week);
        try {
            return ApiDataResponse.ok(materialService.get(start, end, null, null));
        } catch (BusinessException e) {
            return ApiDataResponse.error(null, HttpStatus.INTERNAL_SERVER_ERROR.value(), e.getMessage());
        }
    }
}
