package com.topica.portal.service.portal.notification;

import com.topica.adapter.common.service.BaseService;
import com.topica.portal.model.portal.RemindRoomSender;

public interface RemindRoomSenderService extends BaseService<RemindRoomSender, Long> {
    RemindRoomSender getByRoomId(Long roomId);
}
