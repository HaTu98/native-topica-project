package com.topica.portal.model.portal;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "user_social")
public class UserSocial {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "user_id")
  @JsonProperty("user_id")
  private Long userId;

  @Column(name = "service_type")
  @JsonProperty("service_type")
  private String serviceType;

  @Column(name = "token_access")
  @JsonProperty("token_access")
  private String tokenAccess;

  @Column(name = "token_refresh")
  @JsonProperty("token_refresh")
  private String tokenRefresh;

  private String service;

  private String data;
}
