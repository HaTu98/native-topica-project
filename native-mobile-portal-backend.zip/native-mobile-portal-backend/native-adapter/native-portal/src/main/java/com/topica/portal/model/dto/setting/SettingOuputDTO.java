package com.topica.portal.model.dto.setting;

import lombok.Builder;
import lombok.Data;

import java.util.Collections;
import java.util.Set;

@Data
@Builder
public class SettingOuputDTO {
    private Boolean isRequestTesting;
    private Object mdlHourTeachIds;
}
