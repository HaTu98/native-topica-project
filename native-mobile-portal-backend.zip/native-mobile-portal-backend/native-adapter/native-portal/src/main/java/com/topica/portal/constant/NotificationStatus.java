package com.topica.portal.constant;

public enum  NotificationStatus {
        ACTIVE, INACTIVE
}
