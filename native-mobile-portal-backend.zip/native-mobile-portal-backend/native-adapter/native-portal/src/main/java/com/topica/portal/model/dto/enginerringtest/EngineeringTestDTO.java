package com.topica.portal.model.dto.enginerringtest;

import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
public class EngineeringTestDTO {
    private String deviceid;
    private String os;
    private String appversion;
}
