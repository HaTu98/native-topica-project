package com.topica.portal.repository.portal;

import com.topica.adapter.common.constant.ServiceType;
import com.topica.portal.model.portal.RemindRoom;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RemindRoomRepository extends JpaRepository<RemindRoom, Long> {
    List<RemindRoom> findByTimeAvailable(Long timeAvailable);
    List<RemindRoom> findByUserIdAndRoomIdAndRoomType(Long userId, Long roomId, String roomType);

    @Query("SELECT room.roomId FROM RemindRoom room WHERE room.userId=:userId AND room.serviceType=:serviceType AND room.roomId IN :listRoomId ")
    List<Long> getListRemindRoomId(@Param("userId") Long userId, @Param("serviceType") ServiceType serviceType, @Param("listRoomId") List<Long> roomId);

}
