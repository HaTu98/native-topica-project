package com.topica.portal.controller;


import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.portal.constant.Constants;
import com.topica.portal.errorcode.Errors;
import com.topica.portal.model.dto.enginerringtest.EngineeringTestDTO;
import com.topica.portal.model.portal.EngineeringTest;
import com.topica.portal.service.portal.engineeringtest.EngineeringTestService;
import com.topica.portal.service.portal.setting.SettingEngineeringTestService;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.Calendar;
import java.util.Date;

@Slf4j
@RestController
@RequestMapping("/api/portal")
public class EngineeringTestController {

    @Autowired
    private EngineeringTestService engineeringTestService;

    @Autowired
    private SettingEngineeringTestService settingEngineeringTestService;

    private final ModelMapper mapper = new ModelMapper();

    @RequestMapping(value = "/enginerringtest/getstatus", method = RequestMethod.POST)
    public ApiDataResponse testEngineer(@RequestBody EngineeringTestDTO model) throws BusinessException{
        if(settingEngineeringTestService.isIgnoreTestingByCurrentSession()) {
            return ApiDataResponse.ok(Constants.PASS);
        }
        if(model == null || model.getDeviceid() == null) {
            return ApiDataResponse.error(Errors.DEVICE_ID_EMPTY.getCode(), Errors.DEVICE_ID_EMPTY.getMessage());
        }
        EngineeringTest engineeringTest = engineeringTestService.getEngieeringTestOnDay(model.getDeviceid());
        if(engineeringTest == null || engineeringTest.getPassDate() == null) {
            return ApiDataResponse.ok(Constants.FAIL);
        }
        if(this.passInToday(engineeringTest.getPassDate())) {
            return ApiDataResponse.ok(Constants.PASS);
        }
        return ApiDataResponse.ok(Constants.FAIL);
    }

    private boolean passInToday(Date timeToCheck) {
        Calendar calendar = Calendar.getInstance();
        calendar.clear(Calendar.MILLISECOND);
        calendar.clear(Calendar.SECOND);
        calendar.clear(Calendar.MINUTE);
        calendar.set(Calendar.HOUR, 0);
        return calendar.getTime().before(timeToCheck);
    }

    @RequestMapping(value = "/enginerringtest/update_pass_status", method = RequestMethod.POST)
    public ApiDataResponse upDatePassTestEngineer(@RequestBody EngineeringTestDTO model) throws BusinessException {
        if(model == null || model.getDeviceid() == null) {
            return ApiDataResponse.error(Errors.DEVICE_ID_EMPTY.getCode(), Errors.DEVICE_ID_EMPTY.getMessage());
        }
        EngineeringTest engineeringTest = mapper.map(model, EngineeringTest.class);
        engineeringTest.setPassDate(new Date());
        engineeringTest.setStatus(Constants.PASS);
        return ApiDataResponse.ok(engineeringTestService.save(engineeringTest));
    }
}