package com.topica.portal.constant;

import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Getter
@AllArgsConstructor
public enum  LmsRoleType {
    Manager("manager"),
    CourseCreator("coursecreator"),
    EditingTeacher("editingteacher"),
    Teacher("teacher"),
    Student("student"),
    POVH("povh"),
    POHT("poht"),
    POHC("pohc");

    private static final List<String> VALUES;

    static {
        VALUES = new ArrayList<>();
        for (LmsRoleType roleType : LmsRoleType.values())
            VALUES.add(roleType.getRole());
    }

    private final String role;

    public static List<String> getValues() {
        return VALUES;
    }
}
