package com.topica.portal.model.dto;

import lombok.Data;

import java.time.ZoneId;
import java.util.Date;

@Data
public class BaseJobRequestDTO {
    private String jobName;
    private Date timeSent;
    private String cronExpression;
    private ZoneId timeZone;

    public void setTimeSent(Long timeSent) {
        this.timeSent = (timeSent == 0 || timeSent == null) ? null : new Date(timeSent);
    }
}
