package com.topica.portal.service.portal.notification.impl;

import com.topica.adapter.common.constant.ServiceType;
import com.topica.adapter.common.constant.StudentType;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.request.LoginRequest;
import com.topica.adapter.common.service.BaseUserSessionService;
import com.topica.adapter.common.service.invoker.InvokerService;
import com.topica.portal.constant.Constants;
import com.topica.portal.errorcode.Errors;
import com.topica.portal.model.dto.PagerOutputDTO;
import com.topica.portal.model.dto.notification.output.NotificationRestResponseDTO;
import com.topica.portal.request.RemindRoomRequest;
import com.topica.portal.service.portal.notification.NotiConnectionService;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.*;
import java.util.concurrent.CompletableFuture;

@Slf4j
@Service("notiConnectionService")
public class NotiConnectionServiceImpl extends BaseUserSessionService implements NotiConnectionService {

    private @Autowired InvokerService invokerService;

    @Value("${portal.notification.appId}")
    private String appId;

    @Value("${portal.notification.privateKey}")
    private String privateKey;

    @Value("${portal.notification.client.base_api_url}")
    private String baseApiUrl;

    @Value("${livestream.notificaiton.time.pre.send.second}")
    private Long liveStreamTimePreSend;

    private static final String listUri = "/api/notify/client/list";
    private static final String onReadSendersUri= "/api/notify/client/onReadBySenderIdList";
    private static final String registerUri = "/api/notify/client/register";
    private static final String getDetailSenderUri = "/api/notify/client/getDetail";
    private static final String getUnreadNumberUri = "/api/notify/client/count_not_read";
    private static final String postInitializeRemind = "/api/notify/remind/initialize";
    private static final String addUserToSender = "/api/notify/remind/addNewUserToSender";
    private static final String removeUserInSender = "/api/notify/remind/removeUserInSender";

    @Autowired
    private HttpHeaders headers;
    private UriComponentsBuilder uriBuilder;

    @Override
    public Boolean registerUserAndDeviceToken(LoginRequest loginRequest) {
        uriBuilder = UriComponentsBuilder.fromUriString(baseApiUrl + registerUri);JSONObject request = new JSONObject();
        request.put("username", loginRequest.getUsername());
        request.put("deviceToken", loginRequest.getDeviceToken());
        request.put("os", loginRequest.getOperatingSystem());
        request.put("studentType", (loginRequest.getServiceType() == ServiceType.LMS_VIP) ? StudentType.VIP.name() : StudentType.NORMAL.name());
        request.put("name", loginRequest.getUsername());
        HttpEntity entity = new HttpEntity<>(request.toString(), headers);
        Optional<Object> responseOpt = invokerService.postHeader(uriBuilder.build().toString(), entity, Object.class);
        if(responseOpt.isPresent()) {
            return true;
        }
        try {

        } catch (Exception e) {
            log.error("NotiConnectionService::registerUserAndDeviceToken:: " + e.getMessage());
        }
        return false;
    }

    @Override
    public Object loadNotificationByCurrentSession(Integer pageSize, Integer pageNumer, Sort sort) throws BusinessException {
        uriBuilder = UriComponentsBuilder.fromUriString(baseApiUrl + listUri);
        String currentUser = this.getCurrentUser();
        if(currentUser == null) return null;
        try {
            JSONObject request = new JSONObject();
            request.put("username", currentUser);
            request.put("number", pageNumer + 2);
            request.put("size", pageSize);
            HttpEntity entity = new HttpEntity<>(request.toString(), headers);
            Optional<NotificationRestResponseDTO> responseOpt = invokerService.postHeader(uriBuilder.build().toString(), entity, NotificationRestResponseDTO.class);
            if(responseOpt.isPresent() && responseOpt.get().getCode() == 200) {
                return responseOpt.get().getData();
            }
        } catch (Exception e) {
            log.error("NotiConnectionService::registerUserAndDeviceToken:: " + e.getMessage());
        }
        return PagerOutputDTO.getDefault();
    }

    @Override
    public Object loadNotificationByCurrentSessionV2(Integer pageSize, Integer pageNumer, Sort sort) throws BusinessException {
        uriBuilder = UriComponentsBuilder.fromUriString(baseApiUrl + Constants.NOTIFICATION_LIST_V2_URI);
        String currentUser = this.getCurrentUser();
        if(currentUser == null) return null;
        try {
            JSONObject request = new JSONObject();
            request.put("username", currentUser);
            request.put("number", pageNumer + 2);
            request.put("size", pageSize);
            HttpEntity entity = new HttpEntity<>(request.toString(), headers);
            Optional<NotificationRestResponseDTO> responseOpt = invokerService.postHeader(uriBuilder.build().toString(), entity, NotificationRestResponseDTO.class);
            if(responseOpt.isPresent() && responseOpt.get().getCode() == 200) {
                return responseOpt.get().getData();
            }
        } catch (Exception e) {
            log.error("NotiConnectionService::registerUserAndDeviceToken:: " + e.getMessage());
        }
        return PagerOutputDTO.getDefault();
    }

    @Override
    public Object getNotReadNotificationByCurrentSession() {
        String currentUser = this.getCurrentUser();
        if(currentUser == null) return null;
        uriBuilder = UriComponentsBuilder.fromUriString(baseApiUrl + getUnreadNumberUri)
                .queryParam("username",currentUser);
        Optional<NotificationRestResponseDTO> responseOpt = invokerService.get(uriBuilder.build().toString(), headers, NotificationRestResponseDTO.class);
        if(responseOpt.isPresent() && responseOpt.get().getCode() == 200) {
            return responseOpt.get().getData();
        }
        return 0;
    }

    @Override
    public Object onReadListNotification(Long[] senderId) {
        uriBuilder = UriComponentsBuilder.fromUriString(baseApiUrl + onReadSendersUri);
        String currentUser = this.getCurrentUser();
        if(currentUser == null) return null;
        CompletableFuture.supplyAsync(() -> {
            JSONObject request = new JSONObject();
            request.put("senderIds", senderId);
            request.put("username", currentUser);
            HttpEntity entity = new HttpEntity<>(request.toString(), headers);
            Optional<Object> responseOpt = invokerService.postHeader(uriBuilder.build().toString(), entity, Object.class);
            if(responseOpt.isPresent() ) {
                return responseOpt.get();
            };
            return "SuccessFully";
        });
        return "SuccessFully";
    }

    @Override
    public Object getDetailSender(String senderId) throws BusinessException{
        uriBuilder = UriComponentsBuilder.fromUriString(baseApiUrl + getDetailSenderUri)
                .queryParam("senderId", senderId)
                .queryParam("username", this.getCurrentUser());
        Optional<NotificationRestResponseDTO> responseOpt = invokerService.get(uriBuilder.build().toString(), headers, NotificationRestResponseDTO.class);
        if(responseOpt.isPresent() && responseOpt.get().getCode() == 200) {
            return responseOpt.get().getData();
        } else if(responseOpt.isPresent() && responseOpt.get().getCode() != 200) {
            throw new BusinessException(responseOpt.get().getCode(), responseOpt.get().getMessage());
        }
        throw new BusinessException(Errors.NOT_FOUND_SENDER.getCode(), Errors.NOT_FOUND_SENDER.getMessage());
    }

    @Override
    public Long initializeRemind(RemindRoomRequest room, String username) {
        uriBuilder = UriComponentsBuilder.fromUriString(baseApiUrl + postInitializeRemind);
        JSONObject request = new JSONObject();
        request.put("usernameReceivedList", new HashSet<String>(Arrays.asList(username)));
        request.put("title", Constants.LiveStreamNotifyTitle );
        request.put("body",  Constants.LiveStreamNotifyBody + " " + room.getSubject());
        request.put("bodyHtml",  Constants.LiveStreamNotifyBody + " " + room.getSubject());
        request.put("timeSent", (room.getTimeAvailable() - 15 * 60) * 1000);
        HttpEntity entity = new HttpEntity<>(request.toString(), headers);
        Optional<NotificationRestResponseDTO> responseOpt = invokerService.postHeader(uriBuilder.build().toString(), entity, NotificationRestResponseDTO.class);
        if(responseOpt.isPresent() ) {
            log.info("NotiConnectionService::initializeRemind:result:: " + responseOpt.get().toString());
            return Long.parseLong(responseOpt.get().getData().toString());
        };
        return null;
    }

    @Override
    public Object addNewUserToSender(String username, Long senderId) {
        uriBuilder = UriComponentsBuilder.fromUriString(baseApiUrl + addUserToSender);
        JSONObject request = new JSONObject();
        request.put("username", username);
        request.put("senderId", senderId);
        HttpEntity entity = new HttpEntity<>(request.toString(), headers);
        Optional<NotificationRestResponseDTO> responseOpt = invokerService.postHeader(uriBuilder.build().toString(), entity, NotificationRestResponseDTO.class);
        if(responseOpt.isPresent() ) {
            log.info("NotiConnectionService::addNewUserToSender:result:: " + responseOpt.get().toString());
            return responseOpt.get();
        };
        return null;
    }

    @Override
    public Object removeUserInSender(String username, Long senderId) {
        log.info("NotiConnectionService::removeUserInSender ----------- username: " + username + " - senderId: " + senderId);
        uriBuilder = UriComponentsBuilder.fromUriString(baseApiUrl + removeUserInSender);
        JSONObject request = new JSONObject();
        request.put("username", username);
        request.put("senderId", senderId);
        HttpEntity entity = new HttpEntity<>(request.toString(), headers);
        Optional<NotificationRestResponseDTO> responseOpt = invokerService.postHeader(uriBuilder.build().toString(), entity, NotificationRestResponseDTO.class);
        if(responseOpt.isPresent() ) {
            log.info("NotiConnectionService::addNewUserToSender:result:: " + responseOpt.get().toString());
            return responseOpt.get();
        };
        return null;
    }

    @Override
    public Object onlineRemindRegister(List<Long> mdlHourTeachIds) {
        PortalMdlUser user = this.getUserSession();
        if(user == null || user.getMdlUser() == null || user.getMdlUser().getUsername() == null) return null;
        uriBuilder = UriComponentsBuilder.fromUriString(baseApiUrl + Constants.ONLINE_REMIND_REGISTER_URI);
        JSONObject request = new JSONObject();
        request.put("userId", user.getMdlUser().getId());
        request.put("username", user.getMdlUser().getUsername());
        request.put("fullName", user.getFirstName() + " " + user.getLastName());
        request.put("mdlHourTeachIds", mdlHourTeachIds);
        HttpEntity entity = new HttpEntity<>(request.toString(), headers);
        Optional<NotificationRestResponseDTO> responseOpt = invokerService.postHeader(uriBuilder.build().toString(), entity, NotificationRestResponseDTO.class);
        if(responseOpt.isPresent() ) {
            log.info("NotiConnectionService::onlineRemindRegister:result:: " + responseOpt.get().toString());
            return responseOpt.get();
        };
        return null;
    }


    @Override
    public NotificationRestResponseDTO getOnlineRemindRegistered(Long userId) {
        uriBuilder = UriComponentsBuilder.fromUriString(baseApiUrl + Constants.ONLINE_REMIND_GET_URI)
                .queryParam("userId", userId);
        Optional<NotificationRestResponseDTO> responseOpt = invokerService.get(uriBuilder.build().toString(), headers, NotificationRestResponseDTO.class);
        if(responseOpt.isPresent() ) {
            log.info("NotiConnectionService::getOnlineRemindRegistered:result:: " + responseOpt.get().toString());
            return responseOpt.get();
        };
        return null;
    }


    @Override
    public Object getAllBannerBySession() throws BusinessException {
        uriBuilder = UriComponentsBuilder.fromUriString(baseApiUrl + Constants.BANNER_URI)
                .queryParam("serviceType", this.getUserSession().getServiceType())
                .queryParam("emailStudent", this.getCurrentUser());
        Optional<NotificationRestResponseDTO> responseOpt = invokerService.get(uriBuilder.build().toString(), headers, NotificationRestResponseDTO.class);
        if(responseOpt.isPresent() && responseOpt.get().getCode() == 200) {
            return responseOpt.get().getData();
        } else if(responseOpt.isPresent() && responseOpt.get().getCode() != 200) {
            throw new BusinessException(responseOpt.get().getCode(), responseOpt.get().getMessage());
        }
        return Collections.EMPTY_LIST;
    }

    private String getCurrentUser() {
        PortalMdlUser user = this.getUserSession();
        if(user == null || user.getMdlUser() == null || user.getMdlUser().getUsername() == null) return null;
        return user.getMdlUser().getUsername();
    }

    @Bean
    private HttpHeaders getHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("appId", appId);
        headers.add("privateKey", privateKey);
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        return headers;
    }
}
