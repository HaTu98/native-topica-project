package com.topica.portal.config.db;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
        entityManagerFactoryRef = "lmsVipEntityManager",
        transactionManagerRef = "vipTransactionManager",
        basePackages = { "com.topica.lmsvip.repository" }
)
public class LmsVipDbConfig extends DbConfig {

    private String[] ENTITYMANAGER_PACKAGES_TO_SCAN = {"com.topica.lmsvip.model.lms", "vn.edu.topica.lms.authentication.model"};

    {
        DB_URL = "lmsvip.db.url";
        DB_USER = "lmsvip.db.user";
        DB_PASSWORD = "lmsvip.db.password";
    }

    @Bean(name = "vipDataSource")
    public DataSource vipDataSource() {
        return this.buildDataSource();
    }

    @Bean
    public PlatformTransactionManager vipTransactionManager() {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(vipEntityManager().getObject());
        return transactionManager;
    }

    @Bean(name = "lmsVipEntityManager")
    public LocalContainerEntityManagerFactoryBean vipEntityManager() {
        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(vipDataSource());
        em.setPackagesToScan(ENTITYMANAGER_PACKAGES_TO_SCAN);
        em.setJpaVendorAdapter(vendorAdaptor());
        em.setPersistenceUnitName("lms-vip");
        return em;
    }
}
