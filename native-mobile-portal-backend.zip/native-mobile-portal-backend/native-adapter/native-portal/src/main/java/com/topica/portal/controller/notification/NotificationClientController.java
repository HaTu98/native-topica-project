package com.topica.portal.controller.notification;

import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.portal.controller.BaseController;
import com.topica.portal.model.dto.notification.input.ClientNotiReceiverInputDTO;
import com.topica.portal.model.dto.notification.input.ClientNotiResponseDTO;
import com.topica.portal.service.portal.notification.NotiConnectionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/api/portal/notify")
public class NotificationClientController extends BaseController {

    @Autowired
    private NotiConnectionService notiConnectionService;

    @RequestMapping(value = "/list", method = RequestMethod.POST)
    public ApiDataResponse listNotificationByUser(@RequestBody ClientNotiReceiverInputDTO search) throws BusinessException{
        String orderBy = (search.getOrderBy() != null) ? search.getOrderBy() : "timeReceived";
        return ApiDataResponse.ok(notiConnectionService.loadNotificationByCurrentSession(search.getSize(),
                search.getNumber() ,new Sort(search.getDirection(), orderBy)));
    }

    @RequestMapping(value = "/list_v2", method = RequestMethod.POST)
    public ApiDataResponse listNotificationByUserV2(@RequestBody ClientNotiReceiverInputDTO search) throws BusinessException{
        String orderBy = (search.getOrderBy() != null) ? search.getOrderBy() : "timeReceived";
        return ApiDataResponse.ok(notiConnectionService.loadNotificationByCurrentSessionV2(search.getSize(),
                search.getNumber() ,new Sort(search.getDirection(), orderBy)));
    }

    @RequestMapping(value = "/count_not_read", method = RequestMethod.GET)
    public ApiDataResponse CountNotiticaitonNotRead() {
        return ApiDataResponse.ok(notiConnectionService.getNotReadNotificationByCurrentSession());
    }


    @RequestMapping(value = "/onRead", method = RequestMethod.POST)
    public ApiDataResponse onReadNotification(@RequestBody ClientNotiResponseDTO clientResponse) throws BusinessException{
        Long[] senders = { clientResponse.getSenderId() };
        notiConnectionService.onReadListNotification(senders);
        return ApiDataResponse.ok("Update successfully");
    }

    @RequestMapping(value = "/onReadBySenderIdList", method = RequestMethod.POST)
    public ApiDataResponse onReadBySenderIdList(@RequestBody ClientNotiResponseDTO clientResponse) {
        notiConnectionService.onReadListNotification(clientResponse.getSenderIds());
        return ApiDataResponse.ok("Update successfully");
    }

    @RequestMapping(value = "/detailSender", method = RequestMethod.GET)
    public ApiDataResponse detailSender(@RequestParam("senderId") String senderId) throws BusinessException {
        return ApiDataResponse.ok(notiConnectionService.getDetailSender(senderId));
    }

}
