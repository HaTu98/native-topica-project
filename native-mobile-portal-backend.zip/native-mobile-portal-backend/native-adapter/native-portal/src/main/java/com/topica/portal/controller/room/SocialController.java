package com.topica.portal.controller.room;

import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.portal.model.portal.UserSocial;
import com.topica.portal.service.portal.social.UserSocialService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Slf4j
@RestController
@RequestMapping("/api/social")
public class SocialController {

  @Autowired
  private UserSocialService userSocialService;

  @GetMapping(value = "/{service}")
  public ApiDataResponse get(@PathVariable("service") String service) {
    log.info("(get) {}", service);
    Optional<UserSocial> userSocial =  userSocialService.getByService(service);
    if(!userSocial.isPresent()){
      return ApiDataResponse.error(400,"Not exist!");
    }
    return ApiDataResponse.ok(userSocial.get());
  }

  @PostMapping()
  public ApiDataResponse save(@RequestBody UserSocial userSocial) {
    log.info("(save) {}, {}", userSocial.getTokenAccess(), userSocial.getTokenRefresh());
    Optional<UserSocial> userSocialInfo =  userSocialService.saveToken(userSocial);
    if(!userSocialInfo.isPresent()){
      ApiDataResponse.error(400,"Can not save!");
    }
    return ApiDataResponse.ok(userSocialInfo.get());
  }
}
