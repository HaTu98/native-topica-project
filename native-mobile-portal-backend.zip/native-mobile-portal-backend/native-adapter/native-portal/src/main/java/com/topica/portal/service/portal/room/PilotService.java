package com.topica.portal.service.portal.room;

import java.io.IOException;
import org.springframework.web.multipart.MultipartFile;

public interface PilotService {
  void updatePilotUsers(MultipartFile pilots) throws IOException;
}
