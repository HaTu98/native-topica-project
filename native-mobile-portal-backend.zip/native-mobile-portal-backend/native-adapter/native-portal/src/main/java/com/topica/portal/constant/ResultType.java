package com.topica.portal.constant;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Getter
@AllArgsConstructor
public enum  ResultType {
    SUCCESS("SUCCESS"),
    FAIL("FAIL"),
    InProgress("INPROGRESS"),
    SCHEDULED("SCHEDULED"),
    UNSCHEDULED("UNSCHEDULED"),
    PAUSED("PAUSED"),
    DELETED("DELETED"),
    WAITE_SENDING("WAITE_SENDING"),
    RUNNING("RUNNING"),
    CANCEL("CANCEL");

    private static final List<String> VALUES;

    static {
        VALUES = new ArrayList<>();
        for (ResultType resultType : ResultType.values())
            VALUES.add(resultType.getResult());
    }

    private final String result;

    public static List<String> getValues() {
        return VALUES;
    }
}
