package com.topica.portal.service.portal.setting.impl;

import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.service.BaseUserSessionService;
import com.topica.portal.errorcode.Errors;
import com.topica.portal.model.dto.notification.output.NotificationRestResponseDTO;
import com.topica.portal.model.dto.setting.SettingOuputDTO;
import com.topica.portal.model.portal.SettingEngineeringTest;
import com.topica.portal.repository.portal.SettingEngineeringTestRepository;
import com.topica.portal.service.portal.notification.NotiConnectionService;
import com.topica.portal.service.portal.setting.SettingEngineeringTestService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.concurrent.CompletableFuture;

@Slf4j
@Service("settingEngineeringTestService")
public class SettingEngineeringTestServiceImpl extends BaseUserSessionService implements SettingEngineeringTestService {

    @Autowired
    private SettingEngineeringTestRepository settingEngineeringTestRepository;

    @Autowired
    private NotiConnectionService notiConnectionService;

    @Override
    public SettingEngineeringTest save(SettingEngineeringTest model) throws BusinessException {
        if(model == null || model.getIsRequestTesting() == null) {
            throw new BusinessException(Errors.IS_REQUEST_TEST_EMPTY.getCode(), Errors.IS_REQUEST_TEST_EMPTY.getMessage());
        }
        model.setUserid(this.getUserSession().getMdlUser().getId());
        model.setTimeUpdated(new Date());
        CompletableFuture.supplyAsync(() -> settingEngineeringTestRepository.save(model));
        return model;
    }

    @Override
    public SettingEngineeringTest get(Long id) throws BusinessException {
        try {
            SettingEngineeringTest model = settingEngineeringTestRepository.findOne(id);
            if(model == null) throw new BusinessException(Errors.ID_NOT_FOUND.getCode(), Errors.ID_NOT_FOUND.getMessage());
            return model;
        } catch (Exception e) {
            log.error(e.getMessage());
            throw new BusinessException(Errors.ID_NOT_FOUND.getCode(), Errors.ID_NOT_FOUND.getMessage());
        }
    }

    @Override
    public Boolean isIgnoreTestingByUserId(Long userId) {
        try {
            Boolean isIgnore = settingEngineeringTestRepository.getOne(userId).getIsRequestTesting();
            if(isIgnore != null) return isIgnore;
        } catch (Exception e) {
            log.error("SettingEngineeringTestService::isIgnoreTestingByUserId ------------- " + e.getMessage());
        }
        return false;
    }

    @Override
    public Boolean isIgnoreTestingByCurrentSession() {
        try {
            Boolean isIgnore = settingEngineeringTestRepository.getOne(this.getUserSession().getMdlUser().getId()).getIsRequestTesting();
            if(isIgnore != null) return !isIgnore;
        } catch (Exception e) {
            log.error("SettingEngineeringTestService::isIgnoreTestingByCurrentSession " + e.getMessage());
        }
        return false;
    }


    @Override
    public SettingOuputDTO getSettingValues() {
        Long userId = this.getUserSession().getMdlUser().getId();
//        CompletableFuture<SettingOuputDTO> combinedFuture = getIsRequestTestingFuture(userId).thenCombine(getMdlHourTeachIdsFuture(userId),
//            (isRequestTesting, mdlHourTeachIds) -> {
//                SettingOuputDTO ouput = SettingOuputDTO.builder()
//                                .isRequestTesting(isRequestTesting)
//                                .mdlHourTeachIds(mdlHourTeachIds.getData())
//                                .build();
//                return ouput;
//            });
        SettingOuputDTO result;
//        try {
//            result = combinedFuture.get();
//            return result;
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        } catch (ExecutionException e) {
//            e.printStackTrace();
//        }


        result = SettingOuputDTO.builder()
                .isRequestTesting(isIgnoreTestingByUserId(userId))
                .mdlHourTeachIds(notiConnectionService.getOnlineRemindRegistered(userId).getData())
                .build();
        return result;
    }

    private CompletableFuture<Boolean> getIsRequestTestingFuture(Long userId) {
        return CompletableFuture.supplyAsync(() ->
            isIgnoreTestingByUserId(userId)
        );
    }

    private CompletableFuture<NotificationRestResponseDTO> getMdlHourTeachIdsFuture(Long userId) {
        return CompletableFuture.supplyAsync(() ->
             notiConnectionService.getOnlineRemindRegistered(userId)
        );
    }

    @Override
    public SettingEngineeringTest update(SettingEngineeringTest model) throws BusinessException {
        return null;
    }

    @Override
    public void delete(Long id) throws BusinessException {

    }
}
