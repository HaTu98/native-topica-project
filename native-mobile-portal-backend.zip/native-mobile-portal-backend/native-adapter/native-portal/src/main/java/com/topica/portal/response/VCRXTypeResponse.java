package com.topica.portal.response;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class VCRXTypeResponse {
    private List<String> lms;
    private List<String> lms_web;
    private List<String> lms_vip;
}
