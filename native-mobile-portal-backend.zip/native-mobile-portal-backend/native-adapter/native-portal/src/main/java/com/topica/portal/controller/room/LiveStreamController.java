package com.topica.portal.controller.room;

import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.model.cara.CaraResponse;
import com.topica.adapter.common.request.CaraRequest;
import com.topica.adapter.common.service.liveStream.LiveStreamServicePortal;
import com.topica.portal.request.RemindRoomRequest;
import com.topica.portal.service.portal.room.RemindRoomService;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Slf4j
@RestController
@RequestMapping("/api/portal/stream")
@Api(value = "LiveStream", description = "Live stream class ", produces = MediaType.APPLICATION_JSON_VALUE)
public class LiveStreamController {

  @Autowired
  private LiveStreamServicePortal liveStreamServicePortal;

  @Autowired
  private RemindRoomService remindRoomService;


  @GetMapping("/streaming")
  public ApiDataResponse streaming() throws BusinessException {
    return liveStreamServicePortal.getListClassStreaming();
  }

  @GetMapping("/past")
  public ApiDataResponse past(
      @RequestParam(name = "name", required = false) String name,
      @RequestParam(name = "page", required = false, defaultValue = "0") int page,
      @RequestParam(name = "size", required = false, defaultValue = "10") int size,
      @RequestParam(name = "sort", required = false, defaultValue = "view") String sort) throws BusinessException {
    if(name != null){
      return liveStreamServicePortal.searchClassPastByName(page, size, name, sort);
    }
    return liveStreamServicePortal.getListClassPast(page, size, sort);
  }

  @GetMapping("/past/increaseView")
  public ApiDataResponse increaseView(
      @RequestParam(name = "calendarTeachId") Long calendarTeachId,
      @RequestParam(name = "roomId") String roomId) throws BusinessException {
    return liveStreamServicePortal.increaseViewClassPast(roomId, calendarTeachId);
  }

  @GetMapping("/future")
  public ApiDataResponse future(
      @RequestParam(name = "page", required = false, defaultValue = "0") int page,
      @RequestParam(name = "size", required = false, defaultValue = "10") int size) throws BusinessException {
    return liveStreamServicePortal.getListClassFuture(page, size);
  }

  @GetMapping("/join/{roomId}")
  public ApiDataResponse join(@PathVariable("roomId") String roomId) throws BusinessException {
    return liveStreamServicePortal.joinRoom(roomId);
  }

  @PostMapping("/remind")
  public ApiDataResponse remind(@RequestBody RemindRoomRequest remindRoom) throws BusinessException {
    this.remindRoomService.remind(remindRoom);
    return ApiDataResponse.ok("ok");
  }

  @PostMapping("/unRemind")
  public ApiDataResponse unRemind(@RequestBody RemindRoomRequest remindRoom) throws BusinessException {
    this.remindRoomService.unRemind(remindRoom);
    return ApiDataResponse.ok("ok");
  }

  @GetMapping("/getPublicToken")
  public ApiDataResponse getPublicToken() {
    return ApiDataResponse.ok(this.liveStreamServicePortal.getPublicToken());
  }

  @PostMapping(value = "/rating")
  public ApiDataResponse rating(@RequestBody CaraRequest request) throws BusinessException {
    Optional<CaraResponse> response = this.liveStreamServicePortal.rating(request);

    if(!response.isPresent() || !response.get().getStatus()) {
      throw new BusinessException(HttpStatus.BAD_REQUEST.value(), "can not rating !");
    }
    return ApiDataResponse.ok("ok");
  }
}