package com.topica.portal.request;

import com.topica.adapter.common.constant.ServiceType;
import lombok.Data;

import java.util.List;

@Data
public class AcceptVCRRequest {
    private ServiceType serviceType;
    private List<String> vcrTypes;
}
