package com.topica.portal.constant;

public enum NotificationType {
    NORMAL, PREPLAN, SCHEDULED, QUICKSEND
}
