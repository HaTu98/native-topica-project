package com.topica.portal.service.portal.externalservice.impl;

import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.service.BaseUserSessionService;
import com.topica.portal.service.portal.externalservice.ExternalService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class ExternalServiceImpl extends BaseUserSessionService implements ExternalService {

  @Value("${app.native-world.url}")
  private String nativeWorldHost;

  @Override
  public String getNativeWorldLink() {
    PortalMdlUser userSession = getUserSession();
    return nativeWorldHost.concat("?level=").concat(mappingLevelNativeWorld(userSession.getLevel())).concat("&email=").concat(userSession.getEmail());
  }

  private String mappingLevelNativeWorld(String lmsLevel) {
    switch (lmsLevel) {
      case "basic":
      case "basic1":
      case "basic100":
        return "basic";
      case "basic23":
      case "basic200":
      case "basic300":
        return "pre-inte";
      case "inter":
      case "inter1":
      case "inter100":
      case "inter23":
      case "inter200":
      case "inter300":
      case "advan":
      case "advan1":
      case "advan100":
      case "advan23":
      case "advan200":
      case "advan300":
        return "inter";
      default:
        return "super-basic";
    }
  }

}
