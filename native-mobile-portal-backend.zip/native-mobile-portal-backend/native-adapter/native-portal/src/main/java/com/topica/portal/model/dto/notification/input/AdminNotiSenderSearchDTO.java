package com.topica.portal.model.dto.notification.input;

import com.topica.portal.model.dto.BasePagerDTO;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
public class AdminNotiSenderSearchDTO extends BasePagerDTO {
    private String usernameSender;
    private String [] statuses;
    private String [] types;
    private Date sentFrom;
    private Date sentTo;
    private Long appId;

    public void setSentFrom(Long sentFrom) {
        this.sentFrom = (sentFrom == null || sentFrom == 0) ? null : new Date(sentFrom);
    }

    public void setSentTo(Long sentTo) {
        this.sentTo = (sentTo == null || sentTo == 0) ? null : new Date(sentTo);
    }

    @Override
    public String toString() {
        return "AdminNotiSenderSearchDTO{" +
                "usernameSender='" + usernameSender + '\'' +
                ", statuses=" + statuses +
                ", types=" + types +
                ", sentFrom=" + sentFrom +
                ", sentTo=" + sentTo +
                ", appId=" + appId +
                '}';
    }
}
