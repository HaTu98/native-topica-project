package com.topica.portal.repository.portal;

import com.topica.adapter.common.model.portal.SocialMapping;
import com.topica.adapter.common.model.portal.SocialMappingId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SocialMappingRepository extends JpaRepository<SocialMapping, SocialMappingId> {
    @Query(value = "select * from social_mapping where service_type = ?1 and social_type = ?2 and social_id = ?3", nativeQuery = true)
    Optional<SocialMapping> findByServiceTypeAndSocialTypeAndSocialId(String serviceType, String socialType, String socialId);

    @Query(value = "select * from social_mapping where user_id = ?1 and social_type = ?2 and social_id is not null and social_id != ''", nativeQuery = true)
    Optional<SocialMapping> findBySocialType(long userId, String socialType);

    @Query(value = "select * from social_mapping where social_id = ?1 and social_type = ?2 and status = 'active'", nativeQuery = true)
    List<SocialMapping> findBySocialIdAndSocialType(String socialId, String socialType);

    @Query(value = "select * from social_mapping where user_id = ?1 and social_type = ?2 and service_type = ?3 and status = 'active'", nativeQuery = true)
    @Deprecated
    List<SocialMapping> findByUserIdAndSocialTypeAndServiceType(Long userId, String socialType, String serviceType);

    @Query(value = "select sm from SocialMapping sm where sm.userId = :userId and sm.socialType = :socialType and sm.serviceType in ('LMS', 'LMS_WEB') and sm.serviceType = 'active'")
    List<SocialMapping> findByUserIdAndSocialTypeNormal(@Param("userId") Long userId,@Param("socialType") String socialType);

    @Query(value = "select sm from SocialMapping sm where sm.userId = :userId and sm.socialType = :socialType and sm.serviceType in ('LMS_VIP', 'LMS_VIP_WEB')  and sm.serviceType = 'active'")
    List<SocialMapping> findByUserIdAndSocialTypeVIP(@Param("userId") Long userId,@Param("socialType") String socialType);

    @Query(value = "select * from social_mapping where user_id = ?1 and social_type = ?2 and status = 'active'", nativeQuery = true)
    List<SocialMapping> findByUserIdAndSocialType(Long userId, String socialType);

    @Query(value = "select * from social_mapping where user_id =?1 and status = 'active'", nativeQuery = true)
    List<SocialMapping> findByUserId(Long userId);

    Optional<List<SocialMapping>> getAllByUserId(long userId);
}
