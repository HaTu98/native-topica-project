package com.topica.portal.model.dto;

import com.topica.portal.constant.Constants;
import lombok.*;
import org.springframework.data.domain.Sort;

@Data
@ToString(includeFieldNames = false)
public class BasePagerDTO {
    private String search;
    private String orderBy;
    private Sort.Direction direction = Sort.Direction.DESC;
    private Integer number = Constants.CURRENT_PAGE_DEFAULT_VALUE;
    private Integer size = Constants.NO_OF_ROWS_DEFAULT_VALUE;

    public void setSearch(String search) {
        this.search = ("".equals(search)) ? null : search;
    }

    public void setNumber(Integer number) {
        this.number = number - 1;
    }

    @Override
    public String toString() {
        return "BasePagerDTO{" +
                "orderBy='" + orderBy + '\'' +
                ", direction=" + direction +
                ", number=" + number +
                ", size=" + size +
                ", search=" + search +
                '}';
    }
}
