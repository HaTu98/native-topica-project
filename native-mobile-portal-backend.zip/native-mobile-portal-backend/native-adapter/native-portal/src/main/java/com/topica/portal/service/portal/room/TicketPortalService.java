package com.topica.portal.service.portal.room;

import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.service.room.RoomServicePortal;
import com.topica.adapter.common.util.RoomUtil;
import com.topica.booking.service.TicketService;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.core.SchedulerLock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
@EnableAsync
public class TicketPortalService {

    @Autowired
    @Qualifier("roomServiceSimple")
    private RoomServicePortal roomServiceSimple;

    @Autowired
    @Qualifier("roomServiceVip")
    private RoomServicePortal roomServiceVip;

    @Autowired
    private TicketService ticketService;

    @Scheduled(cron = "0 40 * * * *")
    @SchedulerLock(name = "generateTicket", lockAtLeastForString = "PT5M", lockAtMostForString = "PT14M")
    public void generateTicket() throws Exception {
        this.generateTicketSimple();
//        this.generateTicketVip();
    }

    private void generateTicketSimple() throws Exception {
        Long timeAvailableNextSession = RoomUtil.getTimeAvailableOfNextSession();
        log.info("GenerateTicketSimple time: {}", timeAvailableNextSession);
        List<RoomDTO> listRoomLS = this.roomServiceSimple.getAllRoomByTime(timeAvailableNextSession);
        this.ticketService.generate(listRoomLS);
    }

    private void generateTicketVip() throws Exception {
    }
}