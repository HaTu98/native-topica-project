package com.topica.portal.service.portal.notification.impl;

import com.topica.adapter.common.exception.BusinessException;
import com.topica.portal.model.portal.RemindRoomSender;
import com.topica.portal.repository.portal.RemindRoomSenderRepository;
import com.topica.portal.service.portal.notification.RemindRoomSenderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("remindRoomSenderService")
public class RemindRoomSenderServiceImpl implements RemindRoomSenderService {

    @Autowired
    private RemindRoomSenderRepository remindRoomSenderRepository;

    @Override
    public RemindRoomSender save(RemindRoomSender model) throws BusinessException {
        try {
            return remindRoomSenderRepository.save(model);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public RemindRoomSender get(Long id) throws BusinessException {
        try {
            return remindRoomSenderRepository.findOne(id);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public RemindRoomSender update(RemindRoomSender model) throws BusinessException {
        return null;
    }

    @Override
    public void delete(Long id) throws BusinessException {

    }

    @Override
    public RemindRoomSender getByRoomId(Long roomId) {
        try {
            return remindRoomSenderRepository.findOne(roomId);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
