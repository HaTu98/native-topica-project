package com.topica.portal.repository.portal;

import com.topica.adapter.common.constant.ServiceType;
import com.topica.portal.model.portal.UserSocial;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserSocialRepository extends JpaRepository<UserSocial, Long>{
  Optional<UserSocial> findByUserIdAndAndServiceAndServiceType(Long userId, String service, String serviceType);

}
