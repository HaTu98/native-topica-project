package com.topica.portal.constant;

public enum  NullBehavior {
    EQUALS, IS, IGNORED
}