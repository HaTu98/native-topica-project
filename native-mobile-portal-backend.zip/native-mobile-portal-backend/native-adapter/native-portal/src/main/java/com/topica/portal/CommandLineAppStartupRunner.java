package com.topica.portal;

import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.dto.RoomUserCountDTO;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.service.room.RoomServicePortal;
import com.topica.adapter.common.util.RoomUtil;
import com.topica.booking.model.TicketSold;
import com.topica.booking.service.BookingRoomService;
import com.topica.lms.service.lms.room.LogsMoveUserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.topica.adapter.common.constant.RoleInClass.NORMAL;
import static com.topica.adapter.common.constant.ServiceType.LMS;

@Slf4j
@Component
public class CommandLineAppStartupRunner implements CommandLineRunner {

    @Autowired
    private BookingRoomService bookingRoomService;

    @Autowired
    @Qualifier("roomServiceSimple")
    private RoomServicePortal roomServiceSimple;

    @Autowired
    private LogsMoveUserService moveUserService;

    @Override
    public void run(String...args) throws Exception {
        this.syncTicketLMS();
    }

    private void syncTicketLMS() throws BusinessException {
        log.info("Sync Ticket LMS:....");
        Long time = RoomUtil.getTimeAvailableToSeconds();
        Map<Long, Long> ticketSoldPerRoomMap = this.getTicketSoldPerRoom(time);
        List<RoomDTO> listRoomLMS = this.getListRoomLMS(time);

        listRoomLMS.parallelStream()
                .forEach(room -> {
                    Long quantitySold = ticketSoldPerRoomMap.get(room.getId());
                    if(quantitySold != null) {
                        long totalUserJoined = room.getTotalJoin();
                        if(quantitySold.longValue() != totalUserJoined) {
                            buyTicketToSync(room.getId(), totalUserJoined - quantitySold.longValue());
                        }
                    }
                });
    }

    private void buyTicketToSync(Long roomId, long quantity) {
        if(quantity <= 0) return;
        try {
            log.info("Buy Ticket to Sync: room {} - quantity: {}", roomId, quantity);
            this.bookingRoomService.buyTicket(roomId,0L, NORMAL.name(), LMS);
        } catch (BusinessException e) {
            log.error("Sync ticket error: {}", e.getMessage());
        }
    }

    private List<RoomDTO> getListRoomLMS(Long time) throws BusinessException {
        List<RoomDTO> listRoomLMS = this.roomServiceSimple.getAllRoomByTime(time);
        return listRoomLMS.parallelStream()
                .map(room -> {
                    if (room.isOpened()) {
                        RoomUserCountDTO userCount = moveUserService.getUserCountWithRoleNormal(room.getId());
                        if (userCount != null) {
                            room.setTotalJoin(userCount.getTotalJoin());
                        }
                    }
                    return room;
                })
                .filter(r -> r.getTotalJoin() > 0)
                .collect(Collectors.toList());
    }

    private Map<Long, Long> getTicketSoldPerRoom(Long time) {
        List<TicketSold> ticketSolds = this.bookingRoomService.ticketSoldPerRoomInLession(time);
        return ticketSolds.parallelStream().collect(Collectors.toMap(TicketSold::getRoomId, TicketSold::getQuantitySold));
    }

}
