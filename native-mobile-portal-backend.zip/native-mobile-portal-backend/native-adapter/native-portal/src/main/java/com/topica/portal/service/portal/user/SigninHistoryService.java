package com.topica.portal.service.portal.user;

import com.topica.adapter.common.model.portal.SigninHistory;
import com.topica.adapter.common.service.BaseService;

public interface SigninHistoryService extends BaseService<SigninHistory, Long> {

}
