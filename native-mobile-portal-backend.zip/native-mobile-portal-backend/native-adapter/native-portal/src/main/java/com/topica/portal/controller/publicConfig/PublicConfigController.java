package com.topica.portal.controller.publicConfig;

import com.topica.adapter.common.dto.ApiDataResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/api/portal/public")
public class PublicConfigController {

    private static final Map<String, String> ENV;
    static {
        ENV = new HashMap<>();
        ENV.put("TEST", "http://localhost:8082");
        ENV.put("DEV", "http://portalstaging.topicanative.edu.vn");
        ENV.put("IT", "https://portalit.topicanative.edu.vn");
        ENV.put("STG", "https://portalstg.topicanative.edu.vn");
        ENV.put("PROD", "https://portal.topicanative.edu.vn");
    }

    @GetMapping(value = "/env")
    public ApiDataResponse getEnv() {
        log.info("getEnv: {}", ENV);
        return ApiDataResponse.ok(ENV);
    }
}
