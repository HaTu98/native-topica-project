package com.topica.portal.service.portal.externalservice;

public interface ExternalService {
  String getNativeWorldLink();
}
