package com.topica.portal.constant;

public enum  BannerServiceType {
    LMS, LMS_VIP, ALL, NORMAL
}
