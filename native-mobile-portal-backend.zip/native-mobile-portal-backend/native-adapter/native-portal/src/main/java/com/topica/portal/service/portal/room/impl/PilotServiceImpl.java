package com.topica.portal.service.portal.room.impl;

import com.topica.portal.redis.redis.service.PilotUserService;
import com.topica.portal.service.portal.room.PilotService;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

@Service
@Slf4j
public class PilotServiceImpl implements PilotService {

  @Autowired
  private PilotUserService pilotUserService;

  @Override
  public void updatePilotUsers(MultipartFile pilots) throws IOException {
    List<String> userNames = getListUserFromExcel(pilots);
    if(CollectionUtils.isEmpty(userNames)){
      return;
    }
    pilotUserService.set(userNames);
  }

  private List<String> getListUserFromExcel(MultipartFile pilots)throws IOException {
    List<String> userNames = new ArrayList<>();
    XSSFWorkbook workbook = new XSSFWorkbook(pilots.getInputStream());
    XSSFSheet worksheet = workbook.getSheetAt(0);

    if(worksheet.getPhysicalNumberOfRows() == 0 ){
      return null;
    }

    for(int i=0 ; i < worksheet.getPhysicalNumberOfRows() ; i++) {
      XSSFRow row = worksheet.getRow(i);
      userNames.add(row.getCell(0).getStringCellValue());
    }

    return userNames;
  }
}
