package com.topica.portal.controller.healthCheck;

import com.topica.adapter.common.dto.ApiDataResponse;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/api/portal/check")
@Api(value = "Health Check", description = "Health Check", produces = MediaType.APPLICATION_JSON_VALUE)
public class HealthCheckController {

    @Value("${token.health.check}")
    private String tokenHealthCheck;

    @GetMapping(value = "/ping")
    public ApiDataResponse ping(@RequestParam("token") String tokenCheck) {
        log.info("Health Check: Ping...");
        if(!tokenHealthCheck.equals(tokenCheck)) {
            return ApiDataResponse.error(HttpStatus.BAD_REQUEST.value(), "Bad request");
        }
        return ApiDataResponse.ok("07/08/2019");
    }
}
