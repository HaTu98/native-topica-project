package com.topica.portal.controller.room;

import com.topica.adapter.common.constant.ServiceType;
import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.booking.model.Ticket;
import com.topica.booking.service.BookingRoomService;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

import static com.topica.adapter.common.constant.RoleInClass.NORMAL;

@Slf4j
@EnableAsync
@RestController
@RequestMapping("/api/portal/room")
@Api(value = "Room", description = "Room Information", produces = MediaType.APPLICATION_JSON_VALUE)
public class TicketController {

    @Value("${lms.key.join.room.vcrx}")
    private String keyVCRX;

    @Autowired
    private BookingRoomService bookingRoomService;

    @GetMapping(value = "/buyTicket")
    public ApiDataResponse buyTicket(@RequestParam("roomId") Long roomId,
                                     @RequestParam("userId") Long userId,
                                     @RequestParam("key") String key,
                                     @RequestParam(value = "system", required = false) String system) {

        if(roomId == null) {
            return ApiDataResponse.error(HttpStatus.BAD_REQUEST.value(), "Bad Request");
        }
        if(!keyVCRX.equalsIgnoreCase(key)) {
            return ApiDataResponse.error(HttpStatus.BAD_REQUEST.value(), "Invalid key");
        }
        try {
            Optional<Ticket> ticket = this.bookingRoomService.buyTicket(roomId, userId, NORMAL.name(), ServiceType.LMS);
            log.info("Buy ticket from: System: {} - Room: {} - ticket: {}", system, roomId, ticket.get().getId());
        } catch (BusinessException e) {
            log.info("Buy ticket from: System: {} - Room: {} -> Empty", system, roomId);
            return ApiDataResponse.error(HttpStatus.BAD_REQUEST.value(), "Cannot buy ticket !");
        }
        return ApiDataResponse.ok("done");
    }
}