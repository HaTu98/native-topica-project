package com.topica.portal.constant;

public class LmsConstants {
    public final static long ACCOUNT_ACTIVE = 0;

}
