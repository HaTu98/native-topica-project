package com.topica.portal.constant;

public enum  BannerDeepLinkType {
    HOME,
    NOTIFY_DETAIL,
    LIVE_STREAM,
    WEB,
    NONE
}
