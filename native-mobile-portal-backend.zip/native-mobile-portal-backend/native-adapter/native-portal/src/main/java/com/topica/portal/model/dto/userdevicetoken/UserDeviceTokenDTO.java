package com.topica.portal.model.dto.userdevicetoken;


import lombok.*;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserDeviceTokenDTO implements Serializable {
    @NonNull
    private String username;
    @NonNull
    private String deviceToken;
    private String os;
    private String studentType;

    @Override
    public String toString() {
        String value = "username: " + username + " - deviceToken: " + deviceToken + " - os: " + os + " - studentType: " + studentType;
        return value;
    }
}
