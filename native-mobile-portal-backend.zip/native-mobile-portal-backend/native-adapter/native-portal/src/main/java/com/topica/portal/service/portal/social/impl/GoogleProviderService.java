package com.topica.portal.service.portal.social.impl;

import com.topica.adapter.common.constant.ErrorCode;
import com.topica.adapter.common.constant.ServiceType;
import com.topica.adapter.common.dto.PersonalInfoDTO;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.model.portal.SocialMapping;
import com.topica.adapter.common.util.SocialType;
import com.topica.portal.service.portal.social.ProviderPortalService;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.social.google.api.Google;
import org.springframework.social.google.api.impl.GoogleTemplate;
import org.springframework.social.google.api.plus.Person;
import org.springframework.social.google.connect.GoogleConnectionFactory;
import org.springframework.social.oauth2.GrantType;
import org.springframework.social.oauth2.OAuth2Operations;
import org.springframework.social.oauth2.OAuth2Parameters;
import org.springframework.stereotype.Service;

@Service
@Getter
public class GoogleProviderService extends ProviderPortalService<Google> {

    public static final String DEFAULT_PERMISSION = "profile email";
    private static final GrantType DEFAULT_GRANT_TYPE = GrantType.AUTHORIZATION_CODE;
    private static String DEFAULT_REDIRECT_URI;
    private OAuth2Operations oAuth2Operations;

    public GoogleProviderService(@Value("${spring.social.google.appId}") String googleAppId,
                                 @Value("${spring.social.google.appSecret}") String googleSecret,
                                 @Value("${spring.social.google.redirectURI}") String googleRedirectUri) {
        this.oAuth2Operations = new GoogleConnectionFactory(googleAppId, googleSecret).getOAuthOperations();
        DEFAULT_REDIRECT_URI = googleRedirectUri;
    }

    @Override
    public String createAuthorizationURL() throws BusinessException {
        return createAuthorizationURL(DEFAULT_GRANT_TYPE, DEFAULT_REDIRECT_URI);
    }

    @Override
    public String createAuthorizationURL(GrantType grantType, String url) throws BusinessException {
        OAuth2Parameters params = new OAuth2Parameters();
        params.setRedirectUri(url);
        params.setScope(DEFAULT_PERMISSION);
        return getOAuth2Operations().buildAuthenticateUrl(grantType, params);
    }

    @Override
    public String getAccessToken(String code) {
        return getAccessToken(code, DEFAULT_REDIRECT_URI);
    }

    @Override
    public String getAccessToken(String code, String uri) {
        return getOAuth2Operations().exchangeForAccess(code, uri, null).getAccessToken();
    }

    @Override
    public PersonalInfoDTO getUserProfile(Google providerObject) throws BusinessException {
        return getUserFromProvider(providerObject);
    }

    @Override
    public PersonalInfoDTO getUserProfile(String accessToken, String accessTokenSecret) throws BusinessException {
        return getUserFromProvider(new GoogleTemplate(accessToken));
    }

    @Override
    public boolean supports(String providerName) {
        return SocialType.GOOGLE.getSnsCode().equals(providerName);
    }

    @Override
    public Person getSnsProfile(String accessToken, String accessTokenSecret) throws BusinessException {
        return getSnsProfile(new GoogleTemplate(accessToken));
    }

    @Override
    public Person getSnsProfile(Google providerObject) throws BusinessException {
        return providerObject.plusOperations().getGoogleProfile();
    }

    private PersonalInfoDTO getUserFromProvider(Google providerObject) throws BusinessException {
        Person profile = providerObject.plusOperations().getGoogleProfile();
        //TODO: find user LMS from social identity
//        SocialMapping socialMapping = socialMappingService.findBySocialIdAndSocialType(profile.getId(),SocialType.GOOGLE.getSnsCode());
//        if(socialMapping == null) return null;
//        return this.userServicePortal.findPersonalInfo(socialMapping.getUserId(), ServiceType.valueOf(socialMapping.getServiceType()));
        return getUserProfile(profile.getId());
    }

    @Override
    public SocialMapping mappingSns(String code, String urlRedirect) throws BusinessException {
        String accessToken = this.getAccessToken(code, urlRedirect);
        return mappingSns(accessToken);
    }

    @Override
    public SocialMapping mappingSns(String accessToken) throws BusinessException {
        Person person = this.getSnsProfile(accessToken, "");
        SocialMapping socialMapping = socialMappingService.findBySocialIdAndSocialType(person.getId(), SocialType.GOOGLE.getSnsCode());
        //SocialMapping userSocial = socialMappingService.findByUserIdAndSocialType(SocialType.GOOGLE.getSnsCode());
        if (socialMapping == null) {
            return socialMappingService.mappingSocialId(person.getId(), SocialType.GOOGLE.getSnsCode());
        }
        return null;
    }

    @Override
    public SocialMapping mappingSnsSocialId(String socialId) throws BusinessException {
        return mappingSnsSocialId(socialId, SocialType.GOOGLE);
    }

    @Override
    @Deprecated
    public void unlinkMapping() throws BusinessException {
        SocialMapping socialMapping = socialMappingService.findByUserIdAndSocialTypeAndServiceType(SocialType.GOOGLE.getSnsCode());
        if (socialMapping == null) {
            throw new BusinessException(ErrorCode.ACCOUNT_IS_NOT_LINKED.getCode(),ErrorCode.ACCOUNT_IS_NOT_LINKED.getMessage());
        }
        socialMapping.setStatus("inactive");
        socialMappingService.save(socialMapping);
    }

    @Override
    public PersonalInfoDTO getUserProfile(String snsId) throws BusinessException {
        return getUserProfile(snsId, SocialType.GOOGLE);
    }

}
