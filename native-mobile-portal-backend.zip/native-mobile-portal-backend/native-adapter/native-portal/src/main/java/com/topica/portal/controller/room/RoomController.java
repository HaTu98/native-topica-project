package com.topica.portal.controller.room;

import com.topica.adapter.common.constant.SubjectType;
import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.dto.response.ListRoomResponse;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.service.room.RoomServicePortal;
import com.topica.portal.service.portal.room.PilotService;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/portal/room")
@Api(value = "Room", description = "Room Information", produces = MediaType.APPLICATION_JSON_VALUE)
public class RoomController {

  @Autowired
  @Qualifier("roomServicePortal")
  private RoomServicePortal roomService;

  @Autowired
  private PilotService pilotService;

  @GetMapping(value = "/present")
  public ApiDataResponse presentRoom() throws BusinessException {
    return ApiDataResponse.ok(roomService.presentRoom());
  }

  @GetMapping(value = "/list")
  public ApiDataResponse listRoom( @RequestParam SubjectType classType) throws BusinessException {
    List<RoomDTO> listRoom = roomService.listRoom(classType.toString());
    return new ListRoomResponse(listRoom);
  }

  @GetMapping(value = "/quickJoin")
  public ApiDataResponse quickJoin(@RequestParam("typeClass") SubjectType subjectType) throws BusinessException {
    return ApiDataResponse.ok(roomService.quickJoinRoom( subjectType));
  }

  @GetMapping(value = "/quickJoin/audit")
  public ApiDataResponse quickJoinAudit(@RequestParam("typeClass") SubjectType subjectType) throws BusinessException {
    return ApiDataResponse.ok(roomService.quickJoinRoomAudit( subjectType));
  }

  @GetMapping(value = "/join")
  public ApiDataResponse join(@RequestParam("classId") Long classId) throws BusinessException {
    return ApiDataResponse.ok(roomService.joinRoom(classId));
  }

  @PostMapping(value = "/pilot")
  public ApiDataResponse pilot(@RequestParam MultipartFile pilots) {
    try{
      pilotService.updatePilotUsers(pilots);
      return ApiDataResponse.ok("OK");
    }catch (Exception e){
      log.info("(pilot) {}", e.getMessage());
      return ApiDataResponse.error(500, "Cannot read file!");
    }
  }
}