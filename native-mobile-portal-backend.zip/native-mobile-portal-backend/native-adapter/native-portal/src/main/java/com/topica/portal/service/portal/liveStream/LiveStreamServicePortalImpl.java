package com.topica.portal.service.portal.liveStream;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.topica.adapter.common.constant.RoleType;
import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.adapter.common.dto.response.LiveStreamClassInfo;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.model.cara.CaraResponse;
import com.topica.adapter.common.request.CaraRequest;
import com.topica.adapter.common.request.LiveStreamUser;
import com.topica.adapter.common.service.BaseUserSessionService;
import com.topica.adapter.common.service.invoker.InvokerService;
import com.topica.adapter.common.service.liveStream.LiveStreamServicePortal;
import com.topica.adapter.common.util.StringUtil;
import com.topica.portal.service.portal.room.RemindRoomService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class LiveStreamServicePortalImpl extends BaseUserSessionService implements LiveStreamServicePortal {

  @Autowired
  private InvokerService invokerService;

  @Value("${stream.url}")
  private String url;

  private static final String uriStreaming = "/api/client/listPresent";
  private static final String uriPast = "/api/client/listPast";
  private static final String uriPastSearch = "/api/client/listPast/filter";
  private static final String uriPastCount = "/api/client/listPast/count";
  private static final String uriFuture = "/api/client/listFuture";
  private static final String uriJoin = "/api/client/room/login";

  @Value("${stream.key}")
  private String key;

  @Value("${stream.app.id}")
  private String appId;

  @Value("${stream.app.token}")
  private String appToken;

  @Value("${stream.live.url}")
  private String urlLive;

  @Autowired
  private RemindRoomService remindRoomService;

  @Autowired
  private RatingLiveStreamServiceImpl ratingService;

  @Override
  public ApiDataResponse getListClassStreaming() {

    HttpEntity<Object> request = new HttpEntity<>(generateLiveStreamUser(), generateClassHeader());

    Optional<ApiDataResponse> response = invokerService.postHeader(url.concat(uriStreaming), request, ApiDataResponse.class);

    if(!response.isPresent()){
      return ApiDataResponse.error(HttpStatus.BAD_REQUEST.value(),"Cannot get class streaming!");
    }

    return response.get();
  }

  @Override
  public ApiDataResponse getListClassPast(int page, int size, String sort) {
    HttpEntity<Object> request = new HttpEntity<>(generateLiveStreamUser(), generateClassHeader());

    UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url.concat(uriPast));
    builder.queryParam("page", page);
    builder.queryParam("size", size);
    builder.queryParam("sort", sort);
    log.info("(getListClassPast) {}", builder.toUriString());
    Optional<ApiDataResponse> response = invokerService.postHeader(builder.toUriString(), request, ApiDataResponse.class);


    if(!response.isPresent()){
      return ApiDataResponse.error(HttpStatus.BAD_REQUEST.value(),"Cannot get class past!");
    }

    return response.get();
  }

  @Override
  public ApiDataResponse searchClassPastByName(int page, int size, String name, String sort) {
    log.info("(searchClassPastByName) {} ", name);
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.set("key", key);

    HttpEntity<Object> request = new HttpEntity<>(generateLiveStreamUser(), headers);

    UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url.concat(uriPastSearch));
    builder.queryParam("page", page);
    builder.queryParam("size", size);
    builder.queryParam("sort", sort);
    String urlSearch = builder.toUriString().concat("&name=").concat(name);
    log.info("(searchClassPastByName) {}", urlSearch);
    Optional<ApiDataResponse> response = invokerService.postHeader(urlSearch, request, ApiDataResponse.class);

    if(!response.isPresent()){
      return ApiDataResponse.error(HttpStatus.BAD_REQUEST.value(),"Cannot get past class!");
    }

    return response.get();
  }

  @Override
  public ApiDataResponse increaseViewClassPast(String roomId, Long calendarTeachId) {
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.set("key", key);
    headers.set("calendarTeachId", calendarTeachId.toString());
    headers.set("roomId", roomId);

    HttpEntity<Object> request = new HttpEntity<>(generateLiveStreamUser(), headers);

    Optional<ApiDataResponse> response = invokerService.postHeader(url.concat(uriPastCount), request, ApiDataResponse.class);

    if(!response.isPresent()){
      return ApiDataResponse.error(HttpStatus.BAD_REQUEST.value(),"Cannot get past class!");
    }

    return response.get();
  }

  @Override
  public ApiDataResponse getListClassFuture(int page, int size) {
    HttpEntity<Object> request = new HttpEntity<>(generateLiveStreamUser(), generateClassHeader());

    Optional<ApiDataResponse> response = invokerService.postHeader(url.concat(uriFuture).concat(
        generatePagingParam(page, size)), request, ApiDataResponse.class);

    if(!response.isPresent()){
      return ApiDataResponse.error(HttpStatus.BAD_REQUEST.value(),"Cannot get future class!");
    }

    ApiDataResponse apiDataResponse = response.get();

    LinkedHashMap classInfoMapPage = (LinkedHashMap) apiDataResponse.getData();
    ObjectMapper mapper = new ObjectMapper();

    ArrayList infoList = (ArrayList) classInfoMapPage.get("content");

    if(infoList.isEmpty()){
      return response.get();
    }

    ArrayList<LiveStreamClassInfo> classInfoList = new ArrayList<>();
    List<Long> roomIds = new ArrayList<>();
    for(Object info : infoList){
      LiveStreamClassInfo infoLive = mapper.convertValue(info, LiveStreamClassInfo.class);
      classInfoList.add(infoLive);
      roomIds.add(infoLive.getId());
    }

    List<Long> remindRoomIds = remindRoomService.getListRemindRoomId(roomIds);


    classInfoList.parallelStream().forEach(info -> {
      if(remindRoomIds.contains(info.getId()))
        info.setIsRemind(true);
    });

    PageRequest pageable = new PageRequest(page, size);
    Page<LiveStreamClassInfo> pageClassInfo = new PageImpl<>(classInfoList, pageable, Integer.valueOf(classInfoMapPage.get("totalElements").toString()));
    return ApiDataResponse.ok(pageClassInfo);
  }

  @Override
  public ApiDataResponse joinRoom(String roomId) {
    log.info("(joinRoom) {}, {}", roomId, this.getUserSession().getMdlUser().getId());
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.set("key", key);
    headers.set("roomId", roomId);

    HttpEntity<Object> request = new HttpEntity<>(generateLiveStreamUser(), headers);

    Optional<ApiDataResponse> response = invokerService.postHeader(url.concat(uriJoin), request, ApiDataResponse.class);

    if(!response.isPresent()){
      return ApiDataResponse.error(HttpStatus.BAD_REQUEST.value(),"Cannot joint room!");
    }

    return response.get();
  }

  @Override
  public String getPublicToken() {
    String url = this.urlLive.concat("/api/apps/login");

    Long userId = this.getUserSession().getMdlUser().getId();
    String info = this.appId + userId.toString();
    String hashValue = StringUtil.hashInfo(info, this.appToken);


    UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromUriString(url);
    uriBuilder.queryParam("appId", this.appId);
    uriBuilder.queryParam("externalUserId", userId);
    uriBuilder.queryParam("hashValue", hashValue);
    Optional<ApiDataResponse> response = this.invokerService.postHeader(uriBuilder.build().toString(), null, ApiDataResponse.class);
    if(!response.isPresent()) return null;
    LinkedHashMap data = (LinkedHashMap) response.get().getData();
    return (String)data.get("token");
  }

  private HttpHeaders generateClassHeader(){
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.set("key", key);
    return headers;

  }

  private LiveStreamUser generateLiveStreamUser(){
    LiveStreamUser liveStreamUser = new LiveStreamUser();
    PortalMdlUser user = this.getUserSession();
    liveStreamUser.setRole(RoleType.Student);
    liveStreamUser.setType(user.getServiceType());
    liveStreamUser.setUserName(user.getFirstName()+" "+ user.getLastName());
    liveStreamUser.setUserId(String.valueOf(user.getMdlUser().getId()));
    liveStreamUser.setLevel(user.getLevel());
    return liveStreamUser;
  }

  private String generatePagingParam(int page, int size){
    return "?".concat("page=").concat(String.valueOf(page)).concat("&").concat("size=").concat(String.valueOf(size));
  }

  @Override
  public Optional<CaraResponse> rating(CaraRequest request) throws BusinessException {
    return this.ratingService.rating(request);
  }
}