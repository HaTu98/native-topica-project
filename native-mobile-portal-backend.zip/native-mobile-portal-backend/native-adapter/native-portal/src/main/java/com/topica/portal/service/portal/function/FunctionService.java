package com.topica.portal.service.portal.function;

import com.topica.adapter.common.dto.PersonalInfoDTO;

import java.util.List;

public interface FunctionService {
    List<String> getFunction(PersonalInfoDTO info);
}
