package com.topica.portal.service.portal.social.impl;

import com.topica.adapter.common.constant.ServiceSocial;
import com.topica.adapter.common.constant.ServiceType;
import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.service.BaseUserSessionService;
import com.topica.portal.model.portal.UserSocial;
import com.topica.portal.repository.portal.UserSocialRepository;
import com.topica.portal.service.portal.social.UserSocialService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@Slf4j
public class UserSocialServiceImpl extends BaseUserSessionService implements UserSocialService {

  @Autowired
  private UserSocialRepository userSocialRepository;

  @Override
  public Optional<UserSocial> saveToken(UserSocial userSocialRequest) {
    Optional<UserSocial> social = userSocialRepository
        .findByUserIdAndAndServiceAndServiceType(this.getUserSession().getMdlUser().getId(), userSocialRequest.getService(),
            this.getUserSession().getServiceType().name());
    if(social.isPresent()){
      UserSocial userSocial = social.get();
      userSocial.setTokenAccess(userSocialRequest.getTokenAccess());
      userSocial.setTokenRefresh(userSocialRequest.getTokenRefresh());
      userSocial.setData(userSocialRequest.getData());
      return Optional.of(userSocialRepository.save(userSocial));

    }

    userSocialRequest.setUserId(this.getUserSession().getMdlUser().getId());
    userSocialRequest.setServiceType(this.getUserSession().getServiceType().toString());
    return Optional.of(userSocialRepository.save(userSocialRequest));
  }

  @Override
  public Optional<UserSocial> getByService(String service) {
    return userSocialRepository
        .findByUserIdAndAndServiceAndServiceType(this.getUserSession().getMdlUser().getId(), service,
            this.getUserSession().getServiceType().name());
  }

  @Override
  public Optional<UserSocial> getByServiceWithUser(Long userId, ServiceType serviceType, String service) {
    return userSocialRepository
            .findByUserIdAndAndServiceAndServiceType(userId, service, serviceType.name());
  }

  @Override
  public Optional<UserSocial> saveAvatar(String urlAvatar) {
    PortalMdlUser user = this.getUserSession();
    Optional<UserSocial> oldUser = this.getByService(ServiceSocial.NATIVE_PORTAL.name());
    if(oldUser.isPresent()) {
      oldUser.get().setData(urlAvatar);
      UserSocial newUser = this.userSocialRepository.save(oldUser.get());
      return Optional.of(newUser);
    }

    UserSocial newUser = UserSocial.builder()
            .service(ServiceSocial.NATIVE_PORTAL.name())
            .data(urlAvatar)
            .serviceType(user.getServiceType().toString())
            .userId(user.getMdlUser().getId())
            .build();
    newUser = this.userSocialRepository.save(newUser);
    return Optional.of(newUser);
  }

  @Override
  public Optional<UserSocial> saveSmileStudentId(Long studentId) {
    PortalMdlUser user = this.getUserSession();
    Optional<UserSocial> oldUser = this.getByService(ServiceSocial.NATIVE_SMILE.name());
    if(oldUser.isPresent()) {
      oldUser.get().setData(studentId.toString());
      UserSocial newUser = this.userSocialRepository.save(oldUser.get());
      return Optional.of(newUser);
    }

    UserSocial newUser = UserSocial.builder()
        .service(ServiceSocial.NATIVE_SMILE.name())
        .data(studentId.toString())
        .serviceType(user.getServiceType().toString())
        .userId(user.getMdlUser().getId())
        .build();
    newUser = this.userSocialRepository.save(newUser);
    return Optional.of(newUser);
  }
}
