package com.topica.portal.controller.admin;

import com.topica.adapter.common.config.room.AcceptVCR;
import com.topica.adapter.common.config.room.TotalEmptyRoomDisplay;
import com.topica.adapter.common.config.room.UseDeeplinkAdobe;
import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.portal.redis.constant.KeyConfig;
import com.topica.portal.redis.service.config.ConfigService;
import com.topica.portal.request.AcceptVCRRequest;
import com.topica.portal.request.MaxUserSetRequest;
import com.topica.portal.response.VCRXTypeResponse;
import com.topica.portal.service.portal.room.TicketPortalService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/api/portal/setting")
public class AdminRoomController {

    private @Autowired AcceptVCR acceptVcr;
    private @Autowired ConfigService configService;
    private @Autowired UseDeeplinkAdobe useDeeplinkAdobe;
    private @Autowired TicketPortalService ticketPortalService;
    private @Autowired TotalEmptyRoomDisplay totalEmptyRoomDisplay;

    @Value("${portal.notification.privateKey}")
    private String privateKey;

    @RequestMapping(value = "/vcrType", method = RequestMethod.POST)
    public ApiDataResponse vcrType( @RequestHeader String key, @RequestBody AcceptVCRRequest request) {
        log.info("ADMIN CHANGE CONFIG: Set VCR Type: {}", request);

        if(!key.equalsIgnoreCase(privateKey)){
            return ApiDataResponse.error(HttpStatus.BAD_REQUEST.value(), "Invalid key");
        }

        if(request.getServiceType() == null) {
            return ApiDataResponse.error(HttpStatus.BAD_REQUEST.value(), "Service Type empty");
        }

        if(CollectionUtils.isEmpty(request.getVcrTypes())) {
            return ApiDataResponse.error(HttpStatus.BAD_REQUEST.value(), "VCR empty");
        }

        switch (request.getServiceType()) {
            case LMS_VIP:
                this.configService.save(KeyConfig.LMS_VIP_VCR_KEY, String.join(",", request.getVcrTypes()));
                break;
            case LMS_WEB:
                this.configService.save(KeyConfig.LMS_WEB_VCR_KEY, String.join(",", request.getVcrTypes()));
                break;
            case LMS:
                this.configService.save(KeyConfig.LMS_VCR_KEY, String.join(",", request.getVcrTypes()));
                break;
        }
        return ApiDataResponse.ok(request.getVcrTypes());
    }

    @GetMapping(value = "/vcrType/get")
    public ApiDataResponse getVcrType( @RequestHeader String key) {

        if(!key.equalsIgnoreCase(privateKey)){
            return ApiDataResponse.error(HttpStatus.BAD_REQUEST.value(), "Invalid key");
        }

        List<String> vcrSimple = this.acceptVcr.getForSimple();
        List<String> vcrWebSimple = this.acceptVcr.getForSimpleWeb();
        List<String> vcrvip = this.acceptVcr.getForVip();
        return ApiDataResponse.ok(new VCRXTypeResponse(vcrSimple, vcrWebSimple, vcrvip));
    }

    @GetMapping(value = "/adobe/deeplink/set/{use}")
    public ApiDataResponse useDeeplinkAdobe( @RequestHeader String key, @PathVariable("use") Boolean use) {
        log.info("ADMIN CHANGE CONFIG: Set useDeeplinkAdobe: {}", use);

        if(!key.equalsIgnoreCase(privateKey)){
            return ApiDataResponse.error(HttpStatus.BAD_REQUEST.value(), "Invalid key");
        }

        this.configService.save(KeyConfig.USE_DEEPLINK_ADOBE_KEY, use.toString());
        return ApiDataResponse.ok("OK");
    }

    @GetMapping(value = "/adobe/deeplink/get")
    public ApiDataResponse getUseDeeplinkAdobe(@RequestHeader String key) {

        if(!key.equalsIgnoreCase(privateKey)){
            return ApiDataResponse.error(HttpStatus.BAD_REQUEST.value(), "Invalid key");
        }

        return ApiDataResponse.ok(this.useDeeplinkAdobe.get());
    }

    @GetMapping(value = "/list/mix/set/{use}")
    public ApiDataResponse setMixListRoom( @RequestHeader String key, @PathVariable("use") Boolean use) {
        log.info("ADMIN CHANGE CONFIG: Set setMixListRoom: {}", use);

        if(!key.equalsIgnoreCase(privateKey)){
            return ApiDataResponse.error(HttpStatus.BAD_REQUEST.value(), "Invalid key");
        }

        this.configService.save(KeyConfig.MIX_LIST_ROOM, use.toString());
        return ApiDataResponse.ok("OK");
    }
    @GetMapping(value = "/list/mix/get")
    public ApiDataResponse getMixListRoom(@RequestHeader String key) {

        if(!key.equalsIgnoreCase(privateKey)){
            return ApiDataResponse.error(HttpStatus.BAD_REQUEST.value(), "Invalid key");
        }

        return ApiDataResponse.ok(this.configService.get(KeyConfig.MIX_LIST_ROOM));
    }

    @GetMapping(value = "/list/empty/get")
    public ApiDataResponse listEmptyShow(@RequestHeader String key) {

        if(!key.equalsIgnoreCase(privateKey)){
            return ApiDataResponse.error(HttpStatus.BAD_REQUEST.value(), "Invalid key");
        }

        return ApiDataResponse.ok(this.configService.get(KeyConfig.TOTAL_EMPTY_ROOM_SHOW));
    }

    @GetMapping(value = "/list/empty/set/{total}")
    public ApiDataResponse setListEmptyShow( @RequestHeader String key, @PathVariable("total") int total) {
        log.info("ADMIN CHANGE CONFIG: Set total Empty Room: {}", total);

        if(!key.equalsIgnoreCase(privateKey)){
            return ApiDataResponse.error(HttpStatus.BAD_REQUEST.value(), "Invalid key");
        }

        return ApiDataResponse.ok(this.totalEmptyRoomDisplay.set(total));
    }

    @GetMapping(value = "/list/empty/setMax/{max}")
    public ApiDataResponse setListEmptyShowMax( @RequestHeader String key, @PathVariable("max") int max) {
        log.info("ADMIN CHANGE CONFIG: Set total Empty Room Max: {}", max);

        if(!key.equalsIgnoreCase(privateKey)){
            return ApiDataResponse.error(HttpStatus.BAD_REQUEST.value(), "Invalid key");
        }

        return ApiDataResponse.ok(this.totalEmptyRoomDisplay.setMax(max));
    }

    @GetMapping(value = "/maxUser/get")
    public ApiDataResponse getMaxUser(@RequestHeader String key) {

        if(!key.equalsIgnoreCase(privateKey)){
            return ApiDataResponse.error(HttpStatus.BAD_REQUEST.value(), "Invalid key");
        }

        Map<String, String> result = new LinkedHashMap<>();
        result.put("LMS", this.configService.get(KeyConfig.MAX_USER_JOIN_SIMPLE));
        result.put("LMS_SN", this.configService.get(KeyConfig.MAX_USER_JOIN_SIMPLE_SN));
        result.put("LMS_VIP", this.configService.get(KeyConfig.MAX_USER_JOIN_VIP));
        result.put("LMS_VIP_SN", this.configService.get(KeyConfig.MAX_USER_JOIN_VIP_SN));
        return ApiDataResponse.ok(result);
    }

    @PostMapping(value = "/maxUser/set")
    public ApiDataResponse setMaxUser( @RequestHeader String key, @RequestBody MaxUserSetRequest request) {

        if(!key.equalsIgnoreCase(privateKey)){
            return ApiDataResponse.error(HttpStatus.BAD_REQUEST.value(), "Invalid key");
        }

        this.configService.save(KeyConfig.MAX_USER_JOIN_SIMPLE, String.valueOf(request.getLms()));
        this.configService.save(KeyConfig.MAX_USER_JOIN_VIP, String.valueOf(request.getLmsVip()));
        this.configService.save(KeyConfig.MAX_USER_JOIN_SIMPLE_SN, String.valueOf(request.getLmsSN()));
        this.configService.save(KeyConfig.MAX_USER_JOIN_VIP_SN, String.valueOf(request.getLmsVipSN()));
        return ApiDataResponse.ok("ok");
    }

    @GetMapping(value = "/genTicket")
    public ApiDataResponse getTicket(@RequestHeader String key) throws Exception {
        if(!key.equalsIgnoreCase(privateKey)){
            return ApiDataResponse.error(HttpStatus.BAD_REQUEST.value(), "Invalid key");
        }
        this.ticketPortalService.generateTicket();
        return ApiDataResponse.ok("ok");
    }
}