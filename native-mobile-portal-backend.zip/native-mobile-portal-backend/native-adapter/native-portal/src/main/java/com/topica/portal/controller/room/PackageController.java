package com.topica.portal.controller.room;

import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.adapter.common.dto.request.ActiveRequest;
import com.topica.adapter.common.dto.response.GetPackageResponse;
import com.topica.adapter.common.dto.response.TransactionHistory;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.service.course.PackageServicePortal;
import com.topica.adapter.common.service.course.TransactionHistoryService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Slf4j
@RestController
@RequestMapping("/api/portal/package")
public class PackageController {

  @Autowired
  @Qualifier("packageServicePortal")
  PackageServicePortal packageService;

  @Autowired
  @Qualifier("transactionHistoryPortal")
  TransactionHistoryService transactionHistoryService;

  @GetMapping()
  public ApiDataResponse listPackage() throws BusinessException {
    Optional<GetPackageResponse> response = packageService.getListPackage();
    return ApiDataResponse.ok(response.get());
  }

  @PostMapping("/active")
  public ApiDataResponse activePackage(@RequestBody ActiveRequest request) throws BusinessException {
    Optional<Boolean> response = packageService.activePackage(request);
    if (!response.isPresent() || !response.get()) {
      return ApiDataResponse.error(false, 400);
    }
    return ApiDataResponse.ok(true);
  }

  @GetMapping("/transaction-history")
  public ApiDataResponse activePackage() throws BusinessException {
    Optional<List<TransactionHistory>> response = transactionHistoryService.getTransactionHistory();
    if (!response.isPresent()) {
      return ApiDataResponse.error(false, 400);
    }
    return ApiDataResponse.ok(response.get());
  }

  @GetMapping("/check")
  public ApiDataResponse checkCanActive() {
    try {
      packageService.isCanActive();
    } catch (BusinessException e) {
      return ApiDataResponse.error(false, 400);
    }
    return ApiDataResponse.ok(true);
  }
}