package com.topica.portal.service.portal.social.impl;

import com.topica.adapter.common.constant.ServiceType;
import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.service.BaseUserSessionService;
import com.topica.adapter.common.model.portal.SocialMapping;
import com.topica.adapter.common.util.SocialType;
import com.topica.portal.repository.portal.SocialMappingRepository;
import com.topica.portal.service.portal.social.SocialMappingService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.*;

@Service
@Slf4j
public class SocialMappingServiceImpl extends BaseUserSessionService implements SocialMappingService {

    @Autowired
    private SocialMappingRepository socialMappingRepository;

    @Override
    public SocialMapping mappingSocialId(String socialId, String socialType) {
        PortalMdlUser userSession = getUserSession();
        SocialMapping socialActive = this.findByUserIdAndSocialType(socialType);
        if (socialActive != null) {
            socialActive.setStatus("inactive");
            socialMappingRepository.save(socialActive);
        }
        SocialMapping socialMapping = new SocialMapping();
        socialMapping.setServiceType(userSession.getServiceType().name());
        socialMapping.setSocialId(socialId);
        socialMapping.setSocialType(socialType);
        socialMapping.setStatus("active");
        socialMapping.setUserId(userSession.getMdlUser().getId());
        return socialMappingRepository.save(socialMapping);
    }

    @Override
    public Optional<SocialMapping> fetchBySocialIdAndSocialType(String socialId, String socialType) {
        return socialMappingRepository.findByServiceTypeAndSocialTypeAndSocialId(
                getUserSession().getServiceType().name(), socialType, socialId);
    }

    @Override
    public boolean haveSocialAccount(String socialType) {
        return socialMappingRepository.findBySocialType(getUserSession().getMdlUser().getId(), socialType).isPresent();
    }

    @Override
    public Optional<List<SocialMapping>> fetchAllSocialByUserId() {
        return socialMappingRepository.getAllByUserId(getUserSession().getMdlUser().getId());
    }

    @Override
    public SocialMapping findBySocialIdAndSocialType(String socialId, String socialType) {
        List<SocialMapping> socialMappings = socialMappingRepository.findBySocialIdAndSocialType(socialId, socialType);
        if (CollectionUtils.isEmpty(socialMappings)) {
            return null;
        }
        return socialMappings.get(0);
    }

    @Override
    public SocialMapping findByUserIdAndSocialType(String socialType) {
        List<SocialMapping> socialMappings = getBySocialType(socialType);
        if (CollectionUtils.isEmpty(socialMappings)) {
            return null;
        }
        return socialMappings.get(0);
    }

    @Override
    public Map<String,Boolean> checkMapping() {
        log.info("(check mapping) {}", getUserSession().getMdlUser().getId());
        Map<String,Boolean> result = new HashMap<>();
        List<SocialMapping> socialMappings = socialMappingRepository.findByUserId(getUserSession().getMdlUser().getId());
        Arrays.asList(SocialType.values()).parallelStream().forEach(sm -> {
            result.put(sm.getSnsCode(),
              socialMappings.parallelStream()
                .anyMatch(w -> w.getSocialType().equalsIgnoreCase(sm.getSnsCode()))
            );
        });
        return result;
    }

    @Override
    @Deprecated
    public SocialMapping findByUserIdAndSocialTypeAndServiceType(String socialType) {
        Long userId = getUserSession().getMdlUser().getId();
        String serviceType = getUserSession().getServiceType().name();
        log.info("(unlinkMapping) {}"+serviceType +", "+ socialType, userId);
        List<SocialMapping> socialMappings = socialMappingRepository.findByUserIdAndSocialTypeAndServiceType(userId, socialType, serviceType);
        if (CollectionUtils.isEmpty(socialMappings)) {
            return null;
        }
        return socialMappings.get(0);
    }

    @Override
    public void save(SocialMapping socialMapping) {
        socialMappingRepository.save(socialMapping);
    }

    private List<SocialMapping> getBySocialType(String socialType) {
        PortalMdlUser userSession = getUserSession();
        switch (userSession.getServiceType()) {
            case LMS:
            case LMS_WEB:
                return socialMappingRepository.findByUserIdAndSocialTypeNormal(userSession.getMdlUser().getId(), socialType);
            case LMS_VIP_WEB:
            case LMS_VIP:
                return socialMappingRepository.findByUserIdAndSocialTypeVIP(userSession.getMdlUser().getId(), socialType);
            default:
                return new ArrayList<>();
        }
    }
}
