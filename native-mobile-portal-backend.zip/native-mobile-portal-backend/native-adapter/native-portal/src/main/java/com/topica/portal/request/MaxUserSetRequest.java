package com.topica.portal.request;

import lombok.Data;

@Data
public class MaxUserSetRequest {
    private int lms;
    private int lmsVip;
    private int lmsVipSN;
    private int lmsSN;
}
