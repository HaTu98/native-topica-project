package com.topica.portal.repository.portal;

import com.topica.portal.model.portal.EngineeringTest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.security.access.method.P;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Repository
public interface EngineeringTestRepository extends JpaRepository<EngineeringTest, Long> {
    @Transactional(readOnly = true)
    Optional<EngineeringTest> findFirstByUsernameAndDeviceid(String username, String deviceid);
}
