package com.topica.portal.controller.file;

import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.adapter.common.service.amazon.AmazonS3ClientService;
import com.topica.portal.model.portal.UserSocial;
import com.topica.portal.service.portal.social.UserSocialService;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Slf4j
@RestController
@RequestMapping("/api/portal/file")
@Api(value = "File", description = "File handling", produces = MediaType.APPLICATION_JSON_VALUE)
public class FileController {
    public static final List<String> imgContentTypes = Arrays.asList("image/png", "image/jpeg", "image/gif");

    @Autowired
    private AmazonS3ClientService amazonS3ClientService;

    @Autowired
    private UserSocialService userSocialService;

    @PostMapping("/upload")
    public ApiDataResponse uploadFile(@RequestPart(value = "file") MultipartFile file)
    {
        String url = this.amazonS3ClientService.uploadFileToS3Bucket(file);
        if(StringUtils.isEmpty(url)) {
            return ApiDataResponse.error(HttpStatus.NO_CONTENT.value(), "Upload error");
        }
        return ApiDataResponse.ok(url);
    }

    @PostMapping("/avatar/upload")
    public ApiDataResponse uploadAvatar(@RequestPart(value = "avatar") MultipartFile file) {

        if(!this.isImage(file)) {
            return ApiDataResponse.error(HttpStatus.NO_CONTENT.value(), "Not found image");
        }

        String url = this.amazonS3ClientService.uploadFileToS3Bucket(file);
        if(StringUtils.isEmpty(url)) {
            return ApiDataResponse.error(HttpStatus.NO_CONTENT.value(), "Upload error");
        }
        Optional<UserSocial> userSocial = userSocialService.saveAvatar(url);
        if(!userSocial.isPresent()) {
            return ApiDataResponse.error(HttpStatus.NO_CONTENT.value(), "Save avatar error");
        }
        return ApiDataResponse.ok(url);
    }

    private boolean isImage(MultipartFile file) {
        return this.imgContentTypes.contains(file.getContentType());
    }
}
