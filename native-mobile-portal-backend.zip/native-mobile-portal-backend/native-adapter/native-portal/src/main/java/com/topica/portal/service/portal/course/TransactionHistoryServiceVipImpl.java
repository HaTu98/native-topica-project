package com.topica.portal.service.portal.course;

import com.topica.adapter.common.dto.response.TransactionHistory;
import com.topica.adapter.common.dto.response.TransactionHistoryResponse;
import com.topica.adapter.common.service.BaseUserSessionService;
import com.topica.adapter.common.service.course.ActivePackageService;
import com.topica.adapter.common.service.course.TransactionHistoryService;
import com.topica.lmsvip.model.lms.MdlUserInfoData;
import com.topica.lmsvip.service.UserInfoDataService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service("transactionHistoryServiceVip")
@Slf4j
public class TransactionHistoryServiceVipImpl extends BaseUserSessionService implements TransactionHistoryService {

  @Autowired
  UserInfoDataService userInfoDataService;
  @Autowired
  private ActivePackageService packageService;

  @Override
  public Optional<List<TransactionHistory>> getTransactionHistory() {
    Long userId = this.getUserSession().getMdlUser().getId();
    MdlUserInfoData userInfo = userInfoDataService.findByUseridAndFieldid(userId, 88);
    if (userInfo == null) {
      return Optional.empty();
    }
    String contactId = userInfo.getData();
    TransactionHistoryResponse transactionHistory = packageService.getTransactionHistory(contactId);
    return Optional.of(transactionHistory.getData());
  }
}
