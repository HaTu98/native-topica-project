package com.topica.portal.service.portal.engineeringtest.impl;

import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.service.BaseUserSessionService;
import com.topica.portal.errorcode.Errors;
import com.topica.portal.model.portal.EngineeringTest;
import com.topica.portal.repository.portal.EngineeringTestRepository;
import com.topica.portal.service.portal.engineeringtest.EngineeringTestService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Slf4j
@Service("engineeringTestService")
public class EngineeringTestServiceImpl extends BaseUserSessionService implements EngineeringTestService {

    @Autowired
    private EngineeringTestRepository engineeringTestRepository;

    @Override
    public EngineeringTest save(EngineeringTest model) throws BusinessException{
        log.info("Portal::EngineeringTestService::save: " + model);
        if(model != null) {
            model.setUsername(this.getUserSession().getMdlUser().getUsername());
            Optional<EngineeringTest> optional = engineeringTestRepository.findFirstByUsernameAndDeviceid(model.getUsername(), model.getDeviceid());
            if(optional.isPresent()) {
                model.setId(optional.get().getId());
            }
            return engineeringTestRepository.save(model);
        }
        return null;
    }

    @Override
    public EngineeringTest get(Long id) throws BusinessException {
        return null;
    }

    @Override
    public EngineeringTest update(EngineeringTest model) throws BusinessException {
        return null;
    }

    @Override
    public void delete(Long id) throws BusinessException {

    }

    @Override
    public EngineeringTest getEngieeringTestOnDay(String deviceid) throws BusinessException {
        if(deviceid == null) throw  new BusinessException(Errors.DATA_INPUT_INCORRECT.getCode(), Errors.DATA_INPUT_INCORRECT.getMessage());
        log.info("Portal::getEngieeringTestOnDay username: " + this.getUserSession().getMdlUser().getUsername() + " - deviceid: " + deviceid);
        Optional<EngineeringTest> optional = engineeringTestRepository.
            findFirstByUsernameAndDeviceid(this.getUserSession().getMdlUser().getUsername(), deviceid);
        if(optional.isPresent()) {
            return optional.get();
        }
        return null;
    }
}
