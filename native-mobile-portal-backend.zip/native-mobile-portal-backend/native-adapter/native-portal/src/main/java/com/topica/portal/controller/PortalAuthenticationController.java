package com.topica.portal.controller;

import com.topica.adapter.common.constant.ServiceType;
import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.adapter.common.dto.PersonalInfoDTO;
import com.topica.adapter.common.exception.AuthenticationException;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.exception.ExceptionCode;
import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.model.PortalUser;
import com.topica.adapter.common.model.portal.SigninHistory;
import com.topica.adapter.common.request.LoginRequest;
import com.topica.adapter.common.service.user.UserServicePortal;
import com.topica.adapter.common.util.Messages;
import com.topica.lms.service.lms.UserSimpleService;
import com.topica.portal.constant.LmsRoleType;
import com.topica.portal.redis.redis.service.PilotUserService;
import com.topica.portal.redis.service.config.ConfigService;
import com.topica.portal.service.portal.notification.NotiConnectionService;
import com.topica.portal.service.portal.sercurity.AuthenticationHelper;
import com.topica.portal.service.portal.user.SigninHistoryService;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static com.topica.adapter.common.constant.ServiceType.LMS;
import static com.topica.adapter.common.constant.ServiceType.LMS_WEB;

@Slf4j
@RestController
@RequestMapping("/api/portal")
@Api(value = "Authentication", description = "Authentication Information", produces = MediaType.APPLICATION_JSON_VALUE)
public class PortalAuthenticationController extends BaseController{

	public static String MODE_PILOT_PORTAL = "MODE_PILOT_PORTAL";

	@Value("${stream.live.socket.url}")
	private String streamBaseUrl;

	@Value("${stream.live.socket.url.https}")
	private String streamBaseUrlHttps;

	private @Autowired PasswordEncoder passwordEncoder;
	private @Autowired Messages messages;

	@Autowired
	@Qualifier("UserServicePortal")
	private UserServicePortal userServicePortal;

	@Autowired
	private UserSimpleService userServiceSimple;

	@Autowired
	private ConfigService configService;

	@Autowired
	private PilotUserService pilotUserService;

	private @Autowired SigninHistoryService signinHistoryService;
	private @Autowired AuthenticationHelper authenticationHelper;
	private @Autowired NotiConnectionService notiConnectionService;

	@PostMapping(value = "/login/lms")
	public ApiDataResponse loginWebLMS(@RequestBody LoginRequest loginRequest) throws BusinessException {
		log.info("Begin login web lms: " + loginRequest);
		loginRequest.setServiceType(LMS_WEB);
		PersonalInfoDTO info = this.login(loginRequest);
		info.buildTokenForStarter();
		return ApiDataResponse.ok(info);
	}

	@PostMapping(value = "/login/lmsvip")
	public ApiDataResponse loginWebVip(@RequestBody LoginRequest loginRequest) throws BusinessException {
		log.info("Begin login web lms vip: " + loginRequest);
		loginRequest.setServiceType(ServiceType.LMS_VIP_WEB);
		PersonalInfoDTO info = this.login(loginRequest);
		return ApiDataResponse.ok(info);
	}

	@PostMapping(value = "/login")
	public ApiDataResponse loginApp(@RequestBody LoginRequest request) throws BusinessException {
		log.info("Begin login App: " + request);
		PersonalInfoDTO info = this.login(request);
		this.userServicePortal.checkValidGen(info, request.getServiceType());
		return ApiDataResponse.ok(info);
	}

	private PersonalInfoDTO login(@RequestBody LoginRequest loginRequest) throws BusinessException {
		String userName = loginRequest.getUsername();
		String password = loginRequest.getPassword();
		ServiceType serviceType = loginRequest.getServiceType();
		if(StringUtils.isEmpty(userName) || StringUtils.isEmpty(password)) {
			throw new BusinessException(HttpStatus.UNAUTHORIZED.value(),"Username or password is empty !");
		}

		if(!this.isValidUserInPilotMode(userName)){
			throw new BusinessException(HttpStatus.FORBIDDEN.value(),"User do not in pilot list!");
		}

		Optional<? extends PortalUser> optUser = userServicePortal.findUser(userName, serviceType);
		if(!optUser.isPresent() || !this.passwordEncoder.matches(password, optUser.get().password())) {
			throw new BusinessException(HttpStatus.UNAUTHORIZED.value(), "Username or password is invalid !");
		}
		if(optUser.get().delete().intValue() == 1 || optUser.get().suspended().intValue() == 1) {
			throw new BusinessException(HttpStatus.FORBIDDEN.value(), "Status is invalid !");
		}
		PersonalInfoDTO infoData = this.userServicePortal.findPersonalInfo(optUser.get().getUserId(), serviceType);
		if(!infoData.getRoleName().equals(LmsRoleType.Student.getRole())) {
			throw new BusinessException(HttpStatus.FORBIDDEN.value(), "Role is invalid !");
		}
		this.checkUserVCRXRegisted(infoData, loginRequest);
		this.logSignin(loginRequest, infoData, SigninHistory.LOG_IN);
		this.saveUserDeviceToken(loginRequest);

		infoData.buildToken(loginRequest);
		this.setUrlStream(infoData);
		return infoData;
	}

	private boolean isValidUserInPilotMode(String userName) {
		try{
			String isPilot = this.configService.getFromRemote(MODE_PILOT_PORTAL);
			if(org.springframework.util.StringUtils.isEmpty(isPilot)) {
				return true;
			}

			if(!Boolean.valueOf(isPilot)){
				return true;
			}

			Optional<Object> pilotUsers = pilotUserService.get();

			if(!pilotUsers.isPresent()){
				return false;
			}

			List<String> listUser = Arrays.asList(pilotUsers.get().toString().split(","));
			return listUser.parallelStream().anyMatch(user -> user.toUpperCase().contains(userName.toUpperCase()));

		}catch (Exception e){
			return true;
		}
	}

	private void saveUserDeviceToken(LoginRequest loginRequest) {
		if(!StringUtils.isEmpty(loginRequest.getDeviceToken())) {
			portalExecutorService.submit(() -> notiConnectionService.registerUserAndDeviceToken(loginRequest));
		}
	}

	private void checkUserVCRXRegisted(PersonalInfoDTO userInfo, LoginRequest loginRequest) throws BusinessException {
		ServiceType serviceType = loginRequest.getServiceType();
		Long vcrxUserId = userInfo.getUserInfo().getVcrxuserid();
		if((LMS == serviceType || LMS_WEB == serviceType) && vcrxUserId == null) {
			this.userServiceSimple.registerVCRXUser(loginRequest);
			Optional<Long> userVCRXId = userServiceSimple.getIdVCRX(userInfo.getId());
			userInfo.getUserInfo().setVcrxuserid(userVCRXId.orElse(null));
		}
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public ApiDataResponse logout(Authentication authentication) throws AuthenticationException {
		if (authentication == null || authentication.getPrincipal() == null) {
			throw new AuthenticationException(ExceptionCode.Authentication.AUTHENTICATION_TOKEN_INVALID, "Token is invalid !");
		}
		return new ApiDataResponse(true, HttpStatus.OK.value(), messages.get("response.successful"));
	}
	 
	@GetMapping(value = "/verify")
	public ApiDataResponse verifyToken(Authentication authentication) throws AuthenticationException {
		PersonalInfoDTO info;
		try {
			info = authenticationHelper.verifyToken(authentication);
			this.checkGen(info, authentication);

			LoginRequest emptyRequest = LoginRequest.empty;
			emptyRequest.setServiceType(info.getServiceType());
			this.logSignin(LoginRequest.empty, info, SigninHistory.RESUM);
		} catch (Exception e) {
			throw new AuthenticationException(HttpStatus.UNAUTHORIZED.value(), e.getMessage());
		}
		this.setUrlStream(info);
		return ApiDataResponse.ok(info);
    }

	private void checkGen(PersonalInfoDTO info, Authentication authentication) throws BusinessException {
		PortalMdlUser user = (PortalMdlUser) authentication.getPrincipal();
		switch (user.getServiceType()) {
			case LMS_VIP:
			case LMS:
				this.userServicePortal.checkValidGen(info, info.getServiceType());
				break;
			case LMS_WEB:
			case LMS_VIP_WEB:
		}
	}

	private void logSignin(LoginRequest loginRequest, PersonalInfoDTO infoData, String action) {
		SigninHistory signin = SigninHistory.from(loginRequest, infoData, action);
		portalExecutorService.submit(() -> signinHistoryService.save(signin));
	}

	private void setUrlStream(PersonalInfoDTO info) {
		info.setStreamSocketBaseUrl(streamBaseUrl);
		info.setStreamSocketBaseUrlHttps(streamBaseUrlHttps);
	}
}
