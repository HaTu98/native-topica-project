package com.topica.portal.errorcode;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum  Errors {
    // Notification: Prefix 0xx
    USER_SENT_EMPTY(101, "User sent from is empty"),
    NOTIFICATION_CONTENT_EMPTY(102, "Nội dung thông báo không hợp lệ"),
    NOTIFICATION_TITLE_EMPTY(103, "Tiêu đề thông báo không hợp lệ"),
    NOTIFICATION_BODY_EMPTY(104, "Nội dung thông báo không hợp lệ"),
    NOTIFICATION_GET_DEVICE_TOKEN_FAIL(105, "Username chưa đăng kí thiết bị"),
    PUSH_NOTIFICATION_FAIL(106, "Lỗi gửi thông báo"),
    SAVE_NOTIFICATION_FAIL(107, "Lỗi lưu thông báo"),
    USER_NOT_REGISTERED_DEVICE_TOKEN(108, "User chưa đăng kí thiết bị"),
    USER_RECEIVED_EMPTY(109, "User received empty"),
    USERNAMES_NOT_REGISTERED_DEVICE_TOKEN(110, "Username chưa đăng kí thiết bị"),
    DEVICE_TOKEN_EXISTING(111, "Devicetoken không tồn tại"),


    FILE_EXCEL_UPLOADED_NULL(112, "File upload rỗng"),
    FILE_UPLOAD_NULL(113, "File upload rỗng"),
    UPLOAD_EXCEL_FAIL(114, "Lỗi upload file"),
    USERNAME_INCORRECT(115, "Username không hợp lệ"),
    STUDENT_TYPE_INVALID(116, "Student Type không hợp lệ"),
    NOTIFICATION_TILE_EXCEED_LENGTH(117, "Tiêu đề thông báo vượt quá 50 kí tự"),
    NOTIFICATION_BODY_EXCEED_LENGTH(118, "Nội dung thông báo vượt  quá 320 kí tự"),

    STUDENT_EXCEL_TEMPLATE_INCORRECT(119, "Template không hợp lệ, Xin vui lòng download template chuẩn trước"),
    STUDENT_ID_INCORRECT(120, "UserId không hợp lệ"),
    STUDENT_EXCEL_NO_DATA(121, "File upload rỗng"),
    STUDENT_EXCEL_FILE_SO_MUCH(122, "File vượt quá 3000 dòng"),
    FILE_UPLOAD_EMPTY(123, "File upload rỗng, xin vui lòng điền học viên trước"),
    FILE_UPLOAD_EXCEED(124, "File vượt quá 1000 dòng"),
    FILE_NOT_SUPPORTED(125, "Chỉ chấp nhận file xlsx và xls"),


    DATA_INPUT_NULL(126, "Đữ liệu rỗng"),
    USER_AND_DEVICE_NOT_REGISTERED(127, "User và deviceId chưa được đăng kí"),
    DATA_INPUT_INCORRECT(128, "Dữ liệu không hợp lệ"),
    DEVICE_ID_EMPTY(129, "Device Id is empty"),
    MODEL_NULL(130, "Dữ liệu rỗng"),
    EXIST_STUDENTS_ERROR(134, "Tồn tại student không hợp  lệ xin vui lòng dowload file "),
    NOT_FOUND_SENDER(135, "Not found notification"),
    TITLE_AND_BODY_NOT_ENOUGH(136, "Thiếu tiêu đề và nội dung thông báo"),
    CRON_EXPRESSION_EMPTY(137, "Không tồn tại conExpression"),
    NOT_SUPPORT_QUICKSEND_TYPE(138, "Không cho phép sủa với kiểu Qửi ngay "),
    SENDER_ID_EMPTY(138, "SENDER_ID_EMPTY"),
    SENDER_WAS_RUNNING(139, "Notification đang chạy không thể update"),
    RECEIVERS_NULL(140, "Không có người nhận hợp lệ"),
    TIME_SENT_BEFORE_CURRENT(141, "Thời gian muốn gửi đang là quá khứ "),
    SENDER_IS_NOT_SCHEDULED(142, "Không thể dừng thông báo đang không trong lịch trình chạy"),
    SENDER_IS_SCHEDULED(143, "Không thể Chạy lịch trình gửi, Thông báo vẫn đang chạy"),
    NOT_SCHEDULE_TYPE(144, "Không thể Chạy lịch trình gửi, thông báo không phải loại: Gửi nhiều lần theo lịch"),
    USER_DEVICETOKEN_NULL(145, "User dang không xác định dược deviceToken"),
    NOT_SUPPORT_TYPE(146, "Chưa chọn đúng kiểu thông báo"),
    NOT_SCHEDULE_TYPE_UNSCHEDULE(147, "Không thể Hủy lịch trình gửi. Chức năng chỉ cho phép với loại Gửi Nhiều Lần Với Lịch Trình"),
    NOT_PREPLAN_TYPE(148, "Không thể Hủy thông báo. Chức năng chỉ cho phép với thông báo đang chờ gửi"),
    JOB_NAME_EXISTING(149, "Job's name existing"),
    IS_REQUEST_TEST_EMPTY(150, "isRequestTest is empty"),

    // JobService

    JOB_NAME_EMPTY (301, "Jobname is empty"),
    INITIALIZE_JOB_ERROR(302, "INITIALIZE_JOB_ERROR"),
    JOB_WITH_SAME_NAME_EXIST(303, "JOB_WITH_SAME_NAME_EXIST"),

    SAVE_NOTIFICATION_CONTENT_FAIL(304, "SAVE_NOTIFICATION_CONTENT_FAIL"),
    SAVE_NOTIFICATION_SENDER_FAIL(305, "SAVE_NOTIFICATION_SENDER_FAIL"),
    SAVE_NOTIFICATION_RECEIVERS_FAIL(306, "SAVE_NOTIFICATION_RECEIVERS_FAIL"),
    UNSCHEULED_JOB_ERROR(307, "Đang xảy ra lỗi mời thử lại"),
    START_JOB_ERROR(308, "Đang xảy ra lỗi mời thử lại"),



    // App
    CREATE_NEW_APP_FAIL(401, "Tao App mới không thành công"),
    APP_NAME_OR_APPID_EXISTING(402, "Tên App hoặc AppId đã tồn tại"),
    APP_NOT_FOUND(403, "Không tìm thấy App"),
    MANAGER_INFO_NOT_ENOUGH(404, "Thông tin người cần cấp quyền không đầy đủ"),
    APP_INFO_NOT_ENOUGH(404, "Thông tin App không đầy đủ"),
    MANAGER_APP_ID_EMPTY(405, "Thiếu thông tin id"),
    APP_FIELDS_NOT_ENOUGH(406, "Các trường bắt buộc không đủ"),
    USER_HAS_AUTHORIZE_WITH_APP(407, "Người dùng đang được đăng kí vào app này"),
    USER_NOT_FOUND(407, "Không tìm thấy User"),
    STATUS_INVALID(408, "Tài khoảng đang bị kháo trên hệ thông"),
    ROLE_INVALID(409, "Tài khoảng không dược phép gửi notification"),
    IS_NOT_AUTHORIZED_NOTIFICATION(410, "Tài khoản chưa được cấp quyền truy cập hệ thống notification"),
    APP_ID_EMPTY(415, "Thông tin app không chính xác, Mời chọn lại App"),
    IS_NOT_AUTHORIZED_FOR_APP(416, "Bạn không dược phép gửi notification với App hiện tại"),


    // Banner
    BANNER_CONTENT_EMPTY(500, "name or bodyHtml is empty"),
    TIME_START_IS_PAST(501, "timeStart đang là quá khứ"),
    TIME_END_LESS_THAN_TIME_START(502, "timeEnd không được nhỏ hơn timeStart"),
    WEB_LINK_EMPTY(503, "Không để trống webLink khi chọn deepLinkType là WEB"),


    // Setting
    ID_NOT_FOUND(450, "Không tìm thấy thông tin theo userid này"),
    CONNECT_ONESIGNAL_FAIL(600, "Không thể kết nối được tới Onesignal"),


    SAVE_ERROR(701, "Save Error"),


    ERRORS_SYSTEM(999, "ERRORS_SYSTEM"),
    ;

    private final int code;
    private final String message;
    public String getAdditionalMessage(String additionalMessage) {
        return message + ": " + additionalMessage;
    }
}
