package com.topica.portal.extension;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.topica.portal.constant.Constants;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;

import java.util.TimeZone;

public class CustomDateDeserializer extends JsonDeserializer<Date> {
    @Override
    public Date deserialize(JsonParser jsonparser,
                            DeserializationContext deserializationcontext) throws IOException {
        Constants.DATE_TIME_FORMAT.setTimeZone(TimeZone.getTimeZone("Asia/Ho_Chi_Minh"));
        Constants.DATE_TIME_FORMAT.setTimeZone(TimeZone.getTimeZone("Asia/Ho_Chi_Minh"));
        String date = jsonparser.getText();
        try {
            return Constants.DATE_TIME_FORMAT.parse(date);
        } catch (ParseException e){
            throw new RuntimeException(e);
        }
    }
}
