package com.topica.portal.service.portal.liveStream;

import com.topica.adapter.common.constant.CaraRateType;
import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.adapter.common.model.cara.CaraResponse;
import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.model.cara.RateInfo;
import com.topica.adapter.common.model.cara.RateProperties;
import com.topica.adapter.common.request.CaraRequest;
import com.topica.adapter.common.service.invoker.InvokerService;
import com.topica.adapter.common.service.rating.BasePortalCaraService;
import com.topica.adapter.common.service.rating.RatingServicePortal;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.topica.adapter.common.constant.ServiceType.LMS;
import static com.topica.adapter.common.constant.ServiceType.LMS_VIP;

@Slf4j
@Service
public class RatingLiveStreamServiceImpl extends BasePortalCaraService implements RatingServicePortal {

    @Value("${cara.rate.id.livestream}")
    private Long rateId;

    @Autowired
    private InvokerService invokerService;

    @Override
    public Optional<CaraResponse> canRate() {
        return Optional.empty();
    }

    @Override
    public Optional<CaraResponse> rating(CaraRequest request) {
        Long userId = this.getUserSession().getMdlUser().getId();
        if(!this.checkCanRate(userId, request.getRoom_id())){
            return Optional.empty();
        }
        request.setStudent_id(userId);
        return this.rate(userId, request);
    }

    private Optional<CaraResponse> rate(Long userId, CaraRequest request) {
        Boolean canRate = this.checkCanRate(userId, request.getRoom_id());
        if(!canRate){
            return Optional.empty();
        }

        String token = this.getCaraToken();
        if(StringUtils.isEmpty(token)){
            return Optional.empty();
        }

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization",token);

        RateInfo rateRequest = this.createRateRequest(request);
        HttpEntity requestCara = new HttpEntity(rateRequest, headers);

        String url = domainCaraServer.concat(uriCreateRate);
        Optional<ApiDataResponse> response = this.invokerService.postHeader(url, requestCara, ApiDataResponse.class);

        if(!response.isPresent() || response.get().getCode() != 200){
            return Optional.empty();
        }
        return Optional.of(new CaraResponse(true));
    }

    private RateInfo createRateRequest(CaraRequest request) {
        RateInfo rateInfo = new RateInfo(request);
        rateInfo.setRateId(this.rateId);
        rateInfo.setStudyTime(request.getTimeAvailable());
        rateInfo.setStatus(RateInfo.STATUS_OK);
        rateInfo.setExtraInfos(this.createRatePros(request));
        return rateInfo;
    }

    private List<RateProperties> createRatePros(CaraRequest request) {
        PortalMdlUser user = this.getUserSession();

        if(LMS == user.getServiceType()) {
            return Arrays.asList(new RateProperties(CaraRateType.getCode(request.getVote())));
        }
        if(LMS_VIP == user.getServiceType()) {
            return request.getVotes()
                    .parallelStream()
                    .map(type -> new RateProperties(CaraRateType.getCode(type)))
                    .collect(Collectors.toList());
        }
        return Collections.emptyList();
    }

    private boolean checkCanRate(Long userId, Long roomId) {
        String token = this.getCaraToken();
        if(StringUtils.isEmpty(token)){
            return false;
        }

        Boolean isRated = this.isRated(userId, roomId, token);
        if(isRated == null || isRated){
            log.info("(rated liveStream) roomID: {}", roomId);
            return false;
        }
        return true;
    }

    @Override
    public Long getTeacherIdByRoomId(Long roomId) {
        return null;
    }
}
