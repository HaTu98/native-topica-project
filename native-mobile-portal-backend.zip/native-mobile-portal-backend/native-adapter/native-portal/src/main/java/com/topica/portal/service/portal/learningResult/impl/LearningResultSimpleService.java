package com.topica.portal.service.portal.learningResult.impl;

import com.topica.adapter.common.dto.request.TotalLearningObjectRequest;
import com.topica.adapter.common.dto.response.PronounceDetail;
import com.topica.adapter.common.dto.response.PronounceDetailHistory;
import com.topica.adapter.common.dto.response.TotalLearningObject;
import com.topica.adapter.common.model.odin.StudentKnowledgeNumberHistory;
import com.topica.adapter.common.repository.odin.StudentKnowledgeBloomHistoryRepository;
import com.topica.adapter.common.repository.odin.StudentKnowledgeNumberHistoryRepository;
import com.topica.adapter.common.repository.odin.StudentPhoneticNumberHistoryRepository;
import com.topica.adapter.common.service.learningResult.LearningResultService;
import com.topica.adapter.common.util.TimeUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class LearningResultSimpleService implements LearningResultService {

  private final Integer NUMBER_TYPE_CORRECT = 1;
  private final Integer NUMBER_TYPE_WRONG = -1;
  private final String DICTIONARY_URL = "https://dictionary.cambridge.org/dictionary/english/";
  private final int DEFAULT_TOP_PRONOUNCE = 24;

  @Autowired
  private StudentKnowledgeNumberHistoryRepository studentKNHRepository;

  @Autowired
  private StudentKnowledgeBloomHistoryRepository studentKBHRepository;

  @Autowired
  private StudentPhoneticNumberHistoryRepository studentPNHRepository;

  @Override
  public Map<String, Long> getUsedPointOfUser(Long userId) {
    Long lastTimeOdin = TimeUtil.getLastTimeOdin();
    Long sumBloomPoint = studentKBHRepository.sumBloomPointByStudentId(userId, lastTimeOdin);
    return new HashMap<String, Long>() {{
      put("grammar", sumBloomPoint);
    }};
  }

  @Override
  public PronounceDetailHistory getTopPronounceHistory(Long userId) {
    return PronounceDetailHistory.builder()
        .topCorrects(getTopPronounceHistoryByUserIdAndNumberType(userId, NUMBER_TYPE_CORRECT))
        .topWrongs(getTopPronounceHistoryByUserIdAndNumberType(userId, NUMBER_TYPE_WRONG))
        .build();
  }

  private List<PronounceDetail> getTopPronounceHistoryByUserIdAndNumberType(Long userId, int numberType) {
    return studentPNHRepository.findTopByStudentIdAndNumberType(userId, numberType, TimeUtil.getLastTimeOdin(), new PageRequest(0, DEFAULT_TOP_PRONOUNCE))
        .stream()
        .map(w ->
            PronounceDetail.builder()
            .objectName(w.getLearningObject().getLearningObjectName())
            .transcription(w.getLearningObject().getTranscription())
            .referenceLink(DICTIONARY_URL + w.getLearningObject().getLearningObjectName())
            .build()
        ).collect(Collectors.toList());
  }

  @Override
  public List<TotalLearningObject> getRealTotalLearningObject(TotalLearningObjectRequest totalLearningObjectRequest) {
    log.info("(getRealTotalLearningObject) {}", totalLearningObjectRequest);
    NavigableMap<Long, String> mapTime = getListStartTimeToEndTime(totalLearningObjectRequest.getStartTime(),
        totalLearningObjectRequest.getEndTime(), totalLearningObjectRequest.getTimeType());

    List<Long> listTime = mapTime.keySet().parallelStream().sorted().collect(Collectors.toList());
    List<StudentKnowledgeNumberHistory> data = studentKNHRepository.findAllByStudentIdAndAndCreatedDateId(totalLearningObjectRequest.getUserId(), listTime);
    List<TotalLearningObject> result = new ArrayList<>();
    for (Map.Entry<Long, String> entry: mapTime.entrySet()) {
      Optional<StudentKnowledgeNumberHistory> first = data.parallelStream().filter(w -> w.getCreatedDateId().equals(entry.getKey())).findFirst();
      result.add(
          TotalLearningObject.builder()
              .time(entry.getValue())
              .value(first.isPresent()
                  ? first.get().getLoNumberByType(totalLearningObjectRequest.getLearningObjectType())
                  : result.size() > 0 ? result.get(result.size() - 1).getValue() : 0L )
              .build()
      );
    }
    return result;
  }

  private NavigableMap<Long, String> getListStartTimeToEndTime(Long startTime, Long endTime, String timeType) {
    switch (timeType) {
      case "day":
        return this.getMapTimeByDay(startTime, endTime);
      case "week":
        return this.getMapTimeByWeek(startTime, endTime);
      case "month":
        return this.getMapTimeByMonth(startTime, endTime);
      default:
        return new TreeMap<>();
    }
  }

  private NavigableMap<Long, String> getMapTimeByDay(Long startTime, Long endTime) {
    NavigableMap<Long, String> map = new TreeMap<>();
    LocalDate endTimeLocalDate = TimeUtil.convertToLocalDate(endTime);
    for (LocalDate date = TimeUtil.convertToLocalDate(startTime); date.isBefore(endTimeLocalDate); date = date.plusDays(1)) {
      map.put(TimeUtil.convertToTimeId(date), TimeUtil.convertToTimeId(date).toString());
    }
    return map;
  }

  private NavigableMap<Long, String> getMapTimeByWeek(Long startTime, Long endTime) {
    NavigableMap<Long, String> map = new TreeMap<>();
    LocalDate endTimeLocalDate = TimeUtil.getLocaleDateLastDayInWeek(endTime);
    //TODO: Check current week
    for (LocalDate date = TimeUtil.getLocaleDateLastDayInWeek(startTime);
         date.isBefore(endTimeLocalDate) || date.equals(endTimeLocalDate);
         date = date.plusWeeks(1)) {
      map.put(TimeUtil.convertToTimeId(date), String.valueOf(TimeUtil.getWeekOfYearFromLocaleDate(date)));
    }
    return map;
  }

  private NavigableMap<Long, String> getMapTimeByMonth(Long startTime, Long endTime) {
    NavigableMap<Long, String> map = new TreeMap<>();
    LocalDate endTimeLocalDate = TimeUtil.getLocalDateLastInMonth(endTime);
    for (LocalDate date = TimeUtil.getLocalDateLastInMonthBeforePresent(startTime);
         date.isBefore(endTimeLocalDate) || date.equals(endTimeLocalDate);
         date = date.plusMonths(1)) {
      map.put(date.getMonthValue() == endTimeLocalDate.getMonthValue()
              ? TimeUtil.getLastTimeOdin()
              : TimeUtil.convertToTimeId(date),
          String.valueOf(date.getMonthValue()));
    }
    return map;
  }

  @Override
  public List<TotalLearningObject> getDesireTotalLearningObject(TotalLearningObjectRequest totalLearningObjectRequest) {
    return null;
  }
}
