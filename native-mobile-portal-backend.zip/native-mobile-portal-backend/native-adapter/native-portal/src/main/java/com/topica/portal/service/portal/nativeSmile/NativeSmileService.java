package com.topica.portal.service.portal.nativeSmile;

import com.topica.adapter.common.request.FilterQuestionRequest;
import java.io.IOException;
import java.util.Optional;
import org.springframework.web.multipart.MultipartFile;

public interface NativeSmileService {
  Optional<Object> getAllQuestion(Integer page);

  Optional<Object> getMyQuestion(Integer page);

  Optional<Object> addQuestion(String answerName, String topicId, String answerdes, String groupId, MultipartFile attach)
      throws IOException;

  Optional<Object> getQuestionDetail(String threadId);

  Optional<Object> ratingReply(String replyId, String ratingId, String ratingContent);

  Optional<Object> searchQuestion(String key, Integer page);

  Optional<Object> filterQuestion(Integer page, FilterQuestionRequest filterInfo);

  Optional<Object> getListQuestionType();

}
