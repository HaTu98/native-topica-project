package com.topica.portal.request;

import com.topica.adapter.common.constant.ServiceType;
import com.topica.adapter.common.constant.SubjectType;
import lombok.Data;

@Data
public class RemindRoomRequest {
    private Long roomId;
    private SubjectType roomType;
    private String subject;
    private Long timeAvailable;
    private String imgUrl;
}
