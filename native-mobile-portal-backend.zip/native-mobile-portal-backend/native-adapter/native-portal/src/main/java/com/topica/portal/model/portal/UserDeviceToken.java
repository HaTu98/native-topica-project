package com.topica.portal.model.portal;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

import javax.persistence.*;
import java.io.Serializable;

@NoArgsConstructor
@Entity
@Data
@Table(name = "user_device_token")
public class UserDeviceToken implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String username;
    @Column(name = "device_token")
    @NonNull
    private String deviceToken;
    private String os;
    @Column(name = "student_type")
    private String studentType;

    @Override
    public String toString() {
        return "username: " + username + " - deviceToken: " + deviceToken + " - os: " + os;
    }

}
