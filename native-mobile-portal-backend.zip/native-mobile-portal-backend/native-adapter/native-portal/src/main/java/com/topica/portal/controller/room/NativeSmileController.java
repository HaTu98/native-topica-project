package com.topica.portal.controller.room;

import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.request.FilterQuestionRequest;
import com.topica.adapter.common.util.ExceptionUtil;
import com.topica.portal.service.portal.nativeSmile.NativeSmileService;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@Slf4j
@RestController
@RequestMapping("/api/portal/smile")
public class NativeSmileController {

  @Autowired
  private NativeSmileService nativeSmileService;

  @GetMapping("/all")
  public ApiDataResponse getAll(
      @RequestParam(required = true) Integer page) throws BusinessException {
    Optional<Object> listQuestion = nativeSmileService.getAllQuestion(page);
    if(!listQuestion.isPresent()){
      return ApiDataResponse.error("Cannot connect to Native Smile server!", 400 );
    }
    return ApiDataResponse.ok(listQuestion.get());
  }

  @GetMapping("/myQuestion")
  public ApiDataResponse getMyQuestion(
      @RequestParam(required = true) Integer page) throws BusinessException {
    Optional<Object> listQuestion = nativeSmileService.getMyQuestion(page);
    if(!listQuestion.isPresent()){
      return ApiDataResponse.error("Cannot connect to Native Smile server!", 400 );
    }
    return ApiDataResponse.ok(listQuestion.get());
  }

  @PostMapping("/add")
  public ApiDataResponse add(
      @RequestParam(required = false) MultipartFile attach,
      @RequestParam String answerName,
      @RequestParam String topicId,
      @RequestParam String answerdes,
      @RequestParam String groupId) {
    try{
      Optional<Object> addQuestionResponse = nativeSmileService.addQuestion(answerName, topicId, answerdes, groupId, attach);
      if(!addQuestionResponse.isPresent()){
        return ApiDataResponse.error("Cannot connect to Native Smile server!", 400 );
      }
      return ApiDataResponse.ok(addQuestionResponse.get());
    }catch (Exception e){
      log.info("(add) {}", ExceptionUtil.getStackTrace(e));
      return ApiDataResponse.error("Cannot connect to Native Smile server!", 400 );
    }

  }

  @GetMapping("/detail/{threadId}")
  public ApiDataResponse getDetail(
      @PathVariable("threadId") String threadId) throws BusinessException {

    Optional<Object> getQuestionResponse = nativeSmileService.getQuestionDetail(threadId);
    if(!getQuestionResponse.isPresent()){
      return ApiDataResponse.error("Cannot connect to Native Smile server!", 400 );
    }
    return ApiDataResponse.ok(getQuestionResponse.get());
  }

  @PostMapping("/rating")
  public ApiDataResponse rate(
      @RequestParam String replyId,
      @RequestParam String ratingId,
      @RequestParam String ratingContent) throws BusinessException {

    Optional<Object> rateResponse = nativeSmileService.ratingReply(replyId, ratingId, ratingContent);
    if(!rateResponse.isPresent()){
      return ApiDataResponse.error("Cannot connect to Native Smile server!", 400 );
    }
    return ApiDataResponse.ok(rateResponse.get());
  }

  @GetMapping("/search")
  public ApiDataResponse search(
      @RequestParam String key,
      @RequestParam Integer page) throws BusinessException {

    Optional<Object> searchResponse = nativeSmileService.searchQuestion(key, page);
    if(!searchResponse.isPresent()){
      return ApiDataResponse.error("Cannot connect to Native Smile server!", 400 );
    }

    return ApiDataResponse.ok(searchResponse.get());
  }

  @PostMapping("/filter")
  public ApiDataResponse filter(
      @RequestParam Integer page,
      @RequestBody FilterQuestionRequest filterInfo) throws BusinessException {
    Optional<Object> filterResponse = nativeSmileService.filterQuestion(page, filterInfo);
    if(!filterResponse.isPresent()){
      return ApiDataResponse.error("Cannot connect to Native Smile server!", 400 );
    }
    return ApiDataResponse.ok(filterResponse.get());
  }

  @GetMapping("/listQuestionType")
  public ApiDataResponse getListQuestionType() throws BusinessException {
    Optional<Object> response = nativeSmileService.getListQuestionType();
    if(!response.isPresent()){
      return ApiDataResponse.error("Cannot connect to Native Smile server!", 400 );
    }
    return ApiDataResponse.ok(response.get());
  }

}
