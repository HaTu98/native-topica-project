package com.topica.portal.config.db;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
    entityManagerFactoryRef = "odinEntityManager",
    transactionManagerRef = "odinTransactionManager",
    basePackages = {
        "com.topica.adapter.common.model.odin",
        "com.topica.adapter.common.repository.odin"
    }
)
public class OdinDbConfig extends DbConfig {
  private String[] ENTITYMANAGER_PACKAGES_TO_SCAN = {
      "com.topica.adapter.common.model.odin",
      "com.topica.portal.model.odin"
  };
  {
    DB_URL = "odin.db.url";
    DB_USER = "odin.db.user";
    DB_PASSWORD = "odin.db.password";
  }

  @Bean(name = "odinDataSource")
  public DataSource odinDataSource() {
    return this.buildDataSource();
  }

  @Bean
  public PlatformTransactionManager odinTransactionManager() {
    JpaTransactionManager transactionManager = new JpaTransactionManager();
    transactionManager.setEntityManagerFactory(vipEntityManager().getObject());
    return transactionManager;
  }

  @Bean(name = "odinEntityManager")
  public LocalContainerEntityManagerFactoryBean vipEntityManager() {
    LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
    em.setDataSource(odinDataSource());
    em.setPackagesToScan(ENTITYMANAGER_PACKAGES_TO_SCAN);
    em.setJpaVendorAdapter(vendorAdaptor());
    em.setPersistenceUnitName("odin-data-warehouse");
    return em;
  }
}
