package com.topica.portal.redis.constant;

public enum KeyConfig {
    LMS_VCR_KEY("lms.vcr"),
    LMS_WEB_VCR_KEY("lms.web.vcr"),
    LMS_VCR_AUDIT_KEY("lms.vcr.audit"),
    LMS_VIP_VCR_KEY("lms.vip.vcr"),
    USE_DEEPLINK_ADOBE_KEY("use.deepLink.adobe"),
    MIX_LIST_ROOM("mix.list.room"),
    TOTAL_EMPTY_ROOM_SHOW("total.empty.room.show"),
    TOTAL_EMPTY_ROOM_SHOW_MAX("total.empty.room.show.max"),

    MAX_USER_JOIN_VIP("max.user.join.vip"),
    MAX_USER_JOIN_VIP_SN("max.user.join.vip.sn"),
    MAX_USER_JOIN_SIMPLE("max.user.join.simple"),
    MAX_USER_JOIN_AUDIT_SIMPLE("max.user.join.audit.simple"),
    MAX_USER_JOIN_AUDIT_SIMPLE_SN("max.user.join.audit.simple.sn"),
    MAX_USER_JOIN_AUDIT_VIP("max.user.join.audit.vip"),
    MAX_USER_JOIN_SIMPLE_SN("max.user.join.simple.sn"),
    MAX_USER_JOIN_SIMPLE_STARTER("max.user.join.simple.starter");

    private String value;
    KeyConfig(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}