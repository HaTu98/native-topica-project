package com.topica.portal.redis.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Calendar;
import java.util.Date;

@Data
@Entity
@Table(name = "configure")
@NoArgsConstructor
public class Configure {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;

    @Column(name="key_config")
    private String keyConfig;

    @Column(name="value_config")
    private String valueConfig;

    @Column(name="created_date")
    private Date created_date;

    @Column(name="last_modified")
    private Date lastModified;

    public Configure(String keyConfig, String valueConfig) {
        this.keyConfig = keyConfig;
        this.valueConfig = valueConfig;
    }

    @PrePersist
    protected void onCreate() {
        this.created_date = Calendar.getInstance().getTime();
    }
    @PreUpdate
    protected void onUpate() {
        this.lastModified = Calendar.getInstance().getTime();
    }

}
