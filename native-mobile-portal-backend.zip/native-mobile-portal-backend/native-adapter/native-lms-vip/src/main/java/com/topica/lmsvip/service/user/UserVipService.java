package com.topica.lmsvip.service.user;

import com.topica.adapter.common.dto.PersonalInfoDTO;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.service.user.UserServicePortal;
import com.topica.lmsvip.model.lms.MdlUserData;

import java.util.List;

public interface UserVipService extends UserServicePortal {

  PersonalInfoDTO findPersonalInfo(Long studentId) throws BusinessException;

  MdlUserData findOne(Long userId);

  List<MdlUserData> findByUserNames(List<String> usernames);

  String getUserCountry(Long userId);
}
