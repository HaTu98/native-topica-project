package com.topica.lmsvip.service.impl.course;

import com.topica.adapter.common.dto.MarketPackage;
import com.topica.adapter.common.dto.request.ActiveRequest;
import com.topica.adapter.common.dto.response.GetPackageResponse;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.service.BaseTypeService;
import com.topica.adapter.common.service.course.PackageServicePortal;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


@Slf4j
@Service("packageServicePortal")
public class PackageServicePortalImpl extends BaseTypeService<PackageServicePortal> implements
    PackageServicePortal {

  @Autowired
  @Qualifier("packageServiceVip")
  private PackageServicePortal packageServiceVip;

  @Autowired
  @Qualifier("packageServiceSimple")
  private PackageServicePortal packageServiceSimple;

  @Override
  public PackageServicePortal vipService() {
    return packageServiceVip;
  }

  @Override
  public PackageServicePortal simpleService() {
    return packageServiceSimple;
  }

  @Override
  public PackageServicePortal simpleWebService() {
    return packageServiceSimple;
  }

  @Override
  public Optional<GetPackageResponse> getListPackage() throws BusinessException {
    return this.getService().getListPackage();
  }

  @Override
  public Optional<Boolean> activePackage(ActiveRequest request) throws BusinessException {
    return this.getService().activePackage(request);
  }

  @Override
  public List<MarketPackage> isCanActive() throws BusinessException {
    return this.getService().isCanActive();
  }

}
