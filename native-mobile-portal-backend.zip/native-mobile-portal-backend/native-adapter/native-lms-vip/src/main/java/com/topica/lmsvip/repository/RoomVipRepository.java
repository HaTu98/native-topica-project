package com.topica.lmsvip.repository;

import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.dto.RoomPresentDTO;
import com.topica.lmsvip.model.lms.MdlTpeBBB;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface RoomVipRepository extends JpaRepository<MdlTpeBBB, Long> {

  @Query(value =
          "SELECT NEW com.topica.adapter.common.dto.RoomPresentDTO( b.id, b.name, h.hourStart, m.topic, b.vcrType, 0L , " +
                  "b.timeavailable, c.levelClass, c.typeClass,m.objective, m.background, m.fileUrl, 0) " +
                  "FROM MdlTpeBBB  b " +
                  "JOIN MdlTpeCanlendarTeach c ON  b.calendarCode= c.calendarCode " +
                  "JOIN MdlHourTeach h ON c.hourId = h.id " +
                  "LEFT JOIN MdlMaterialService m ON c.subjectCode = m.subjectCode " +
                  "WHERE b.roomType = 'ROOM' " +
                  "AND b.vcrType = 'ADB' " +
                  "AND c.status > 0 " +
                  "AND b.timeavailable = :timeavailable " +
                  "AND c.teacherType <> 'ORIENTATION' " +
                  "AND (( c.typeClass = 'LS' AND c.levelClass =:LSlevelClass ) OR (c.typeClass = 'SC' AND c.levelClass = :SClevelClass) )" +
                  "group by c.typeClass")
  List<RoomPresentDTO> getRoomPresent(@Param("timeavailable") Long timeavailable,
                                      @Param("SClevelClass") String SClevelClass,
                                      @Param("LSlevelClass") String LSlevelClass);

  @Query(value = " SELECT b, calendar , teacher " +
          "FROM LogsserviceMoveUser mv " +
          "LEFT JOIN MdlTpeBBB b ON mv.roomidto = b.id " +
          "LEFT JOIN MdlTpeCanlendarTeach calendar ON calendar.calendarCode = b.calendarCode " +
          "LEFT JOIN MdlUserData teacher ON teacher.id = calendar.teacherId " +
          "WHERE b.roomType = 'room' " +
          "AND b.timeavailable = :timeAvailable " +
          "AND mv.userid = :userId " +
          "ORDER BY mv.id DESC ")
  List getJoinedRoom(@Param("userId") Long userId, @Param("timeAvailable") Long timeAvailable);

  @Query(value = "SELECT  b, c, count(distinct ra.userid), teacher "
                  + "FROM MdlTpeBBB b "
                  + "JOIN MdlTpeCanlendarTeach c ON b.calendarCode = c.calendarCode "
                  + "LEFT JOIN MdlUserData teacher ON teacher.id = c.teacherId "
                  + "LEFT JOIN LogsserviceMoveUser log ON log.roomidto = b.id "
                  + "LEFT JOIN MdlRoleAssignments ra ON log.userid = ra.userid AND ra.roleId = 5 "
                  + "WHERE b.roomType = 'ROOM' "
                  + " AND b.timeavailable = :timeAvailable "
                  + " AND b.vcrType = 'ADB' "
                  + " AND c.status > 0 "
                  + " AND c.teacherType <> 'ORIENTATION' "
                  + " AND c.studentType = :studentType"
                  + " AND c.typeClass = :typeClass "
                  + " AND c.levelClass = :levelClass "
                  + " GROUP BY b.id ")
  List<Object[]> getListRoom_2(@Param("timeAvailable") Long timeAvailable,
                            @Param("levelClass") String levelClass,
                            @Param("typeClass") String typeClass,
                            @Param("studentType") String studentType);


  @Query(value = "SELECT  b, c, count(distinct ra.userid) "
          + "FROM MdlTpeBBB b "
          + "JOIN MdlTpeCanlendarTeach c ON b.calendarCode = c.calendarCode "
          + "LEFT JOIN LogsserviceMoveUser log ON log.roomidto = b.id "
          + "LEFT JOIN MdlRoleAssignments ra ON log.userid = ra.userid AND ra.roleId = 5 "
          + "WHERE b.roomType = 'ROOM' "
          + " AND b.timeavailable = :timeAvailable "
          + " AND b.vcrType = 'ADB' "
          + " AND c.status > 0 "
          + " AND c.teacherType <> 'ORIENTATION' "
          + " AND c.studentType = :studentType "
          + " AND c.typeClass = :typeClass "
          + " AND c.levelClass = :levelClass "
          + " GROUP BY b.id having count(distinct ra.userid) < :maxUser")
  List<Object[]> getListRoomNotFull(@Param("timeAvailable") Long timeAvailable,
                               @Param("levelClass") String levelClass,
                               @Param("typeClass") String typeClass,
                               @Param("studentType") String studentType,
                               @Param("maxUser") long maxUser);

  @Query(value = "SELECT b.timeavailable "
          + "FROM MdlTpeBBB b "
          + "JOIN MdlTpeCanlendarTeach c ON b.calendarCode = c.calendarCode "
          + "WHERE b.roomType = 'ROOM' "
          + " AND b.vcrType = 'ADB' "
          + " AND c.status > 0 "
          + " AND b.timeavailable >= :timeAvailable "
          + " AND c.teacherType <> 'ORIENTATION' "
          + " AND c.levelClass = :levelClass"
          + " order by b.timeavailable ASC ")
  Optional<List<Long>> getClosestRoom(@Param("timeAvailable") Long now,
                                      @Param("levelClass") String levelClass, Pageable firstResult);

  @Query(value = "SELECT b, c "
          + "FROM MdlTpeBBB b "
          + "JOIN MdlTpeCanlendarTeach c ON b.calendarCode = c.calendarCode "
          + "WHERE b.id = :classId "
          + "AND b.roomType = 'ROOM' "
          + "AND b.vcrType = 'ADB' ")
  List<Object[]> findById(@Param("classId") Long classId);

  @Query(value =
          "SELECT NEW com.topica.adapter.common.dto.RoomPresentDTO( b.id, b.name, h.hourStart, m.topic, b.vcrType, 0L , b.timeavailable, " +
                  "c.levelClass, c.typeClass,m.objective, m.background, m.fileUrl, 0 ) " +
                  "FROM MdlTpeBBB  b " +
                  "JOIN MdlTpeCanlendarTeach c ON  b.calendarCode= c.calendarCode " +
                  "JOIN MdlHourTeach h ON c.hourId = h.id " +
                  "LEFT JOIN MdlMaterialService m ON c.subjectCode = m.subjectCode " +
                  "WHERE b.roomType = 'ROOM' " +
                  "AND b.vcrType = 'ADB' " +
                  "AND b.timeavailable >= :timeAvailable " +
                  "AND c.status > 0 " +
                  "AND c.teacherType = 'ORIENTATION' " +
                  "order by b.timeavailable ASC ")
  Page<RoomPresentDTO> getRoomPresentORI(@Param("timeAvailable") Long now, Pageable page);

  @Query(value =
          "SELECT NEW com.topica.adapter.common.dto.RoomDTO(b.id, c.levelClass, b.name, teacher.firstName, teacher.lastName, b.timeavailable, " +
                  "0L, c.typeClass, b.vcrType, c.teacherId, teacher.imageAlt, b.vcrClassId) "
                  + "FROM MdlTpeBBB b "
                  + "JOIN MdlTpeCanlendarTeach c ON b.calendarCode = c.calendarCode "
                  + "JOIN MdlHourTeach h ON h.id = c.hourId "
                  + "LEFT JOIN MdlUserData teacher ON teacher.id = c.teacherId "
                  + "WHERE b.roomType = 'ROOM' "
                  + " AND b.vcrType = 'ADB' "
                  + " AND c.status > 0 "
                  + " AND c.teacherType = 'ORIENTATION' "
                  + " AND b.timeavailable = :timeAvailable ")
  List<RoomDTO> getListRoomORI(@Param("timeAvailable") Long timeAvailable);
}