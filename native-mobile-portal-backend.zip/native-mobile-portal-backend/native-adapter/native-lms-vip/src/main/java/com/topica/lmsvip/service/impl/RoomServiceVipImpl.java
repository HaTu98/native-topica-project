package com.topica.lmsvip.service.impl;

import com.topica.adapter.common.constant.PageUtil;
import com.topica.adapter.common.constant.SubjectType;
import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.dto.RoomPresentDTO;
import com.topica.adapter.common.dto.response.JoinRoomResponse;
import com.topica.adapter.common.dto.response.RoomPresentResponse;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.exception.RoomError;
import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.service.room.JoinRoomMaker;
import com.topica.adapter.common.service.room.RoomServicePortal;
import com.topica.adapter.common.util.RoomUtil;
import com.topica.lmsvip.model.lms.RoomResultVip;
import com.topica.lmsvip.repository.RoomVipRepository;
import com.topica.lmsvip.service.LogsserviceInOutService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.topica.adapter.common.constant.LevelStudent.basic;
import static com.topica.adapter.common.constant.LevelStudent.sbasic;
import static com.topica.adapter.common.constant.SubjectType.*;

@Slf4j
@Service("roomServiceVip")
public class RoomServiceVipImpl extends BaseRoomServiceVIP implements RoomServicePortal {

    @Autowired
    private LogsserviceInOutService inOutService;

    @Autowired
    @Qualifier("joinRoomVipMaker")
    private JoinRoomMaker joinRoomMaker;

    @Autowired
    private RoomVipRepository roomRepository;

    @Override
    public RoomDTO getJoinedRoom() {
        PortalMdlUser user = this.getUserSession();
        Long timeAvailable = RoomUtil.getTimeAvailableToSeconds();
        log.info("getJoinedRoom user VIP: {}, time: {}", user.getMdlUser().getUsername(), timeAvailable);
        List<Object[]> res = roomRepository.getJoinedRoom(user.getMdlUser().getId(), timeAvailable);
        if (CollectionUtils.isEmpty(res)) {
            return null;
        }
        RoomDTO joinedRoom = RoomResultVip.toRoomJoined(res.get(0));
        this.updateRoomInfo(joinedRoom, user.getLevel());
        return joinedRoom;
    }

    @Override
    public RoomPresentResponse presentRoom() {
        if (this.isFirstTimeJoinClass(this.getUserSession())) {
            return this.getRoomPresentORI();
        }
        return this.getRoomPresent();
    }

    private RoomPresentResponse getRoomPresentORI() {
        Long timeAvailable = RoomUtil.getTimeAvailableToSeconds();
        Page<RoomPresentDTO> rooms = this.roomRepository.getRoomPresentORI(timeAvailable, PageUtil.FIRST_RESULT);

        if (CollectionUtils.isEmpty(rooms.getContent())) {
            return RoomUtil.convertToRoomPresent(Collections.emptyList(), null);
        }

        List<RoomPresentDTO> roomsPresent = rooms.getContent();
        roomsPresent.forEach(r -> r.setTypeClass(ORI.toString()));

        RoomDTO joinedORI = this.getJoinedRoom();
        if(joinedORI != null) {
            joinedORI.setTypeClass(ORI.name());
        }
        return RoomUtil.convertToRoomPresent(roomsPresent, joinedORI);
    }

    private RoomPresentResponse getRoomPresent() {
        PortalMdlUser user = this.getUserSession();
        String userLevel = user.getLevel();
        Long timeAvailable = RoomUtil.getTimeAvailableToSeconds();

        String SClevelClass = userLevel;
        String LSlevelClass = sbasic.name().equals(userLevel) ? basic.name() : userLevel;

        List<RoomPresentDTO> roomPresentDTO = roomRepository.getRoomPresent(timeAvailable, SClevelClass, LSlevelClass);
        if (CollectionUtils.isEmpty(roomPresentDTO)) {
            Optional<Long> closestTime = this.getClosestTimeRoom(LSlevelClass);
            if (closestTime.isPresent()) {
                roomPresentDTO = roomRepository.getRoomPresent(closestTime.get(), SClevelClass, LSlevelClass);
            }
        }
        RoomDTO joinedRoom = this.getJoinedRoom();
        return RoomUtil.convertToRoomPresent(roomPresentDTO, joinedRoom);
    }

    private Optional<Long> getClosestTimeRoom(String levelClass) {
        long nowInSeconds = System.currentTimeMillis() / 1000;
        Optional<List<Long>> closestTime = roomRepository.getClosestRoom(nowInSeconds, levelClass, PageUtil.FIRST_RESULT);
        if (!closestTime.isPresent()) {
            return Optional.empty();
        }
        return Optional.of(closestTime.get().get(0));
    }

    @Override
    public Optional<RoomDTO> getRoom(Long classId) {
        List<Object[]> result = roomRepository.findById(classId);
        if (CollectionUtils.isEmpty(result)) {
            return Optional.empty();
        }
        RoomDTO room = RoomResultVip.toRoomDTO(result.get(0));
        this.updateRoomInfo(room, this.getUserSession().getLevel());
        return Optional.of(room);
    }

    @Override
    public List<RoomDTO> listRoom(String classType) {
        PortalMdlUser user = this.getUserSession();
        if (this.isFirstTimeJoinClass(user)) {
            return this.getListRoomORI();
        }
        return this.getListRoom(user.getLevel(), classType, user.getPackageParent());
    }


    public List<RoomDTO> listRoomNotFull(String classType) {
        PortalMdlUser user = this.getUserSession();
        if (this.isFirstTimeJoinClass(user)) {
            return this.getListRoomORI();
        }
        String userLevel = user.getLevel();
        classType = RoomUtil.checkTypeClass(classType);
        String levelClass = LS == SubjectType.valueOf(classType) ? RoomUtil.getLSLevelClassVip(userLevel) : userLevel;
        String studentType = user.getPackageParent();
        Long timeAvailable = RoomUtil.getTimeAvailableToSeconds();
        int maxUser = this.getMaxUserAllow(levelClass, classType);

        log.info("List Room Vip: timeAvailable: {} - {} - {} - {} - {}", timeAvailable, levelClass, classType, studentType, maxUser);
        List<Object[]> listRoom = this.roomRepository.getListRoomNotFull(timeAvailable, levelClass, classType, studentType, maxUser);
        return listRoom.parallelStream()
                .map(r -> {
                    RoomDTO room = RoomResultVip.toListRoomDTONotFull(r);
                    this.setMaxJoin(room);
                    return room;
                }).collect(Collectors.toList());
    }

    private List<RoomDTO> getListRoomORI() {
        Long timeAvailable = RoomUtil.getTimeAvailableToSeconds();
        String userLevel = this.getUserSession().getLevel();
        List<RoomDTO> list = roomRepository.getListRoomORI(timeAvailable);
        list.parallelStream().forEach(roomDTO -> this.updateRoomInfo(roomDTO, userLevel));
        return list;
    }

    private List<RoomDTO> getListRoom(String userLevel, String classType, String studentType) {
        Long timeAvailable = RoomUtil.getTimeAvailableToSeconds();
        String levelClass = LS == SubjectType.valueOf(classType) ? RoomUtil.getLSLevelClassVip(userLevel) : userLevel;
        classType = RoomUtil.checkTypeClass(classType);

        log.info("List Room Vip: timeAvailable: {} - {} - {} - {}", timeAvailable, levelClass, classType, studentType);
        List<Object[]> listRoom = this.roomRepository.getListRoom_2(timeAvailable, levelClass, classType, studentType);
        return listRoom.parallelStream()
                .map(r -> {
                    RoomDTO room = RoomResultVip.toListRoomDTO(r);
                    this.setMaxJoin(room);
                    this.setTeacherInfo(room);
                    this.changeTypeSC(room, userLevel);
                    return room;
                }).collect(Collectors.toList());
    }

    @Override
    public JoinRoomResponse quickJoinRoom(SubjectType subjectType) throws BusinessException {
        log.info("QUICK JOIN ROOM: user VIP: {} - type: {}", this.getUserSession().getMdlUser().getUsername(), subjectType);
        JoinRoomResponse response = joinRoomMaker.quickJoin(subjectType);
        return response;
    }

    @Override
    public JoinRoomResponse quickJoinRoomAudit(SubjectType subjectType) {
        return null;
    }

    @Override
    public JoinRoomResponse joinRoom(Long classId) throws BusinessException {
        log.info("JOIN ROOM: user VIP: {} - roomID: {}", this.getUserSession().getMdlUser().getUsername(), classId);
        Optional<RoomDTO> roomDTO = this.getRoom(classId);
        if (!roomDTO.isPresent()) {
            throw new BusinessException(RoomError.NOT_FOUND_ROOM, "Not found room ID: " + classId);
        }
        return joinRoomMaker.join(roomDTO.get());
    }

    @Override
    public JoinRoomResponse reJoinRoom(RoomDTO joinedRoom) throws BusinessException {
        log.info("ReJOIN ROOM: user VIP: {} - roomID: {}", this.getUserSession().getMdlUser().getUsername(), joinedRoom.getId());
        return joinRoomMaker.reJoin(joinedRoom);
    }

    @Override
    public List<RoomDTO> getAllRoomByTime(Long timeAvailable) {
        return Collections.emptyList();
    }

    private boolean isFirstTimeJoinClass(PortalMdlUser user) {
        return !this.inOutService.existLogThisUser(user);
    }
}