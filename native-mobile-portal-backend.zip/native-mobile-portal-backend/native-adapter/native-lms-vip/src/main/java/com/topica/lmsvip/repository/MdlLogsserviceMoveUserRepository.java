package com.topica.lmsvip.repository;

import com.topica.adapter.common.dto.RoomUserCountDTO;
import com.topica.lmsvip.model.lms.LogsserviceMoveUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface MdlLogsserviceMoveUserRepository extends JpaRepository<LogsserviceMoveUser, Long> {
  @Query(value = "SELECT NEW com.topica.adapter.common.dto.RoomUserCountDTO(m.roomidto, COUNT(DISTINCT ra.userid)) "
      + "FROM LogsserviceMoveUser m "
      + "LEFT JOIN MdlRoleAssignments ra ON m.userid = ra.userid "
      + "WHERE ra.roleId = 5 "
      + " AND m.roomidto = :roomId")
  RoomUserCountDTO getUserCountByRoomId(@Param("roomId") Long roomId);
}