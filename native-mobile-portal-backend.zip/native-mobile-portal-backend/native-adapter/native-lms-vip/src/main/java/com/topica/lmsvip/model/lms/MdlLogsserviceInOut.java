package com.topica.lmsvip.model.lms;

import javax.persistence.*;

@Entity
@Table(name = "mdl_logsservice_in_out")
public class MdlLogsserviceInOut {
    private Long id;
    private Long courseid;
    private Long userid;
    private String povhid;
    private Long roomid;
    private String action;
    private Long timeIn;
    private Long timeOut;
    private String sessionid;

    @Id
    @Column(name = "id")
    public Long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Basic
    @Column(name = "courseid")
    public Long getCourseid() {
        return courseid;
    }

    public void setCourseid(long courseid) {
        this.courseid = courseid;
    }

    @Basic
    @Column(name = "userid")
    public Long getUserid() {
        return userid;
    }

    public void setUserid(long userid) {
        this.userid = userid;
    }

    @Basic
    @Column(name = "povhid")
    public String getPovhid() {
        return povhid;
    }

    public void setPovhid(String povhid) {
        this.povhid = povhid;
    }

    @Basic
    @Column(name = "roomid")
    public Long getRoomid() {
        return roomid;
    }

    public void setRoomid(long roomid) {
        this.roomid = roomid;
    }

    @Basic
    @Column(name = "action")
    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    @Basic
    @Column(name = "time_in")
    public Long getTimeIn() {
        return timeIn;
    }

    public void setTimeIn(Long timeIn) {
        this.timeIn = timeIn;
    }

    @Basic
    @Column(name = "time_out")
    public Long getTimeOut() {
        return timeOut;
    }

    public void setTimeOut(Long timeOut) {
        this.timeOut = timeOut;
    }

    @Basic
    @Column(name = "sessionid")
    public String getSessionid() {
        return sessionid;
    }

    public void setSessionid(String sessionid) {
        this.sessionid = sessionid;
    }

}
