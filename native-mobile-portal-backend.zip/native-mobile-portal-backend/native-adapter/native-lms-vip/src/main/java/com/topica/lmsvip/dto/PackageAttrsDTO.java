package com.topica.lmsvip.dto;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
public class PackageAttrsDTO  {
    private String cat_code;
    private String package_name;
    private String package_code;
    private String package_parent;
    private String link_img;

    public String getCat_code() {
        return cat_code;
    }

    @JsonSetter("cat_code")
    public void setCat_code(String cat_code) {
        this.cat_code = cat_code;
    }

    public String getPackage_name() {
        return package_name;
    }

    @JsonSetter("package_name")
    public void setPackage_name(String package_name) {
        this.package_name = package_name;
    }

    public String getPackage_code() {
        return package_code;
    }

    @JsonSetter("package_code")
    public void setPackage_code(String package_code) {
        this.package_code = package_code;
    }

    public String getPackage_parent() {
        return package_parent;
    }

    @JsonSetter("package_parent")
    public void setPackage_parent(String package_parent) {
        this.package_parent = package_parent;
    }

    public String getLink_img() {
        return link_img;
    }

    @JsonSetter("link_img")
    public void setLink_img(String link_img) {
        this.link_img = link_img;
    }
}
