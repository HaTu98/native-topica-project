package com.topica.lmsvip.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@NoArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class MarketResponseDTO {
    private boolean status = false;
    private List<PackageResponse> data = new ArrayList<>();
}
