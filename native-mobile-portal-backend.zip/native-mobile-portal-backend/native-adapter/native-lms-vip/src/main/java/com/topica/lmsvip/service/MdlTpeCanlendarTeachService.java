package com.topica.lmsvip.service;

import com.topica.lmsvip.model.lms.MdlTpeCanlendarTeach;

public interface MdlTpeCanlendarTeachService {
	MdlTpeCanlendarTeach findById(Long id);
	
	MdlTpeCanlendarTeach findByCalendarCode(String calendarCode);
}
