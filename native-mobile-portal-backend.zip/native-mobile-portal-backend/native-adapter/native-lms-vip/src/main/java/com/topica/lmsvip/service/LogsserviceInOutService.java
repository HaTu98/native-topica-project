package com.topica.lmsvip.service;

import com.topica.adapter.common.model.PortalMdlUser;

public interface LogsserviceInOutService {
  Object getPoJoinRoom(Long roomId);

  Long getLastRoomId(Long userId);

  Long getTotalTimeLearnInClass(Long roomId, Long userId);

  Long getRealTeacherOfRoom(Long roomId, String teacherType);

  boolean existLogThisUser(PortalMdlUser user);

  Long getTimeBetweenTwoTimeJoinClassLatest(Long userId, boolean isFromCurrentTime);
}
