package com.topica.lmsvip.common;

public class PackageStatus {
    public static final String ACTIVED = "ACTIVED";
    public static final String CANCELLED = "CANCELLED";
    public static final String DEACTIVATED = "DEACTIVATED";
    public static final String EXPIRED = "EXPIRED";
    public static final String SUSPENDED = "SUSPENDED";
}
