package com.topica.lmsvip.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ConfigInfoDTO {
    @ApiModelProperty(value = "URL_GET_LINK_ADB")
    private String urlGetLinkAdb;
    
}
