package com.topica.lmsvip.service.impl.course;


import com.topica.adapter.common.dto.response.TransactionHistory;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.service.BaseTypeService;
import com.topica.adapter.common.service.course.TransactionHistoryService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Slf4j
@Service("transactionHistoryPortal")
public class TransactionHistoryServicePortalImpl extends BaseTypeService<TransactionHistoryService> implements TransactionHistoryService {

  @Autowired
  @Qualifier("transactionHistoryServiceSimple")
  private TransactionHistoryService transactionHistoryServiceSimple;

  @Autowired
  @Qualifier("transactionHistoryServiceVip")
  private TransactionHistoryService transactionHistoryServiceVip;

  @Override
  public TransactionHistoryService vipService() {
    return transactionHistoryServiceVip;
  }

  @Override
  public TransactionHistoryService simpleService() {
    return transactionHistoryServiceSimple;
  }

  @Override
  public TransactionHistoryService simpleWebService() {
    return transactionHistoryServiceSimple;
  }

  @Override
  public Optional<List<TransactionHistory>> getTransactionHistory() throws BusinessException {
    return this.getService().getTransactionHistory();
  }
}
