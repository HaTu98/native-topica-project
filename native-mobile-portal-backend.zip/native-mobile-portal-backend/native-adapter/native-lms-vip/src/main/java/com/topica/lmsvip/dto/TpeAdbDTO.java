package com.topica.lmsvip.dto;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class TpeAdbDTO {

    @ApiModelProperty(value = "ID")
    private Long id;
    
    @ApiModelProperty(value = "course")
    private Long course;
    
    @ApiModelProperty(value = "name")
    private String name;
    
    @ApiModelProperty(value = "intro")
    private String intro;
    
    @ApiModelProperty(value = "introformat")
    private int introformat;
    
    @ApiModelProperty(value = "userid")
    private Long userid;
    
    @ApiModelProperty(value = "templatescoid")
    private Long templatescoid;

    @ApiModelProperty(value = "meeturl")
    private String meeturl;
    
    @ApiModelProperty(value = "date_start")
    private Long dateStart;
    
    @ApiModelProperty(value = "endtime")
    private Long endtime;
    
    @ApiModelProperty(value = "starttime")
    private Long starttime;

    @ApiModelProperty(value = "meetingpublic")
    private int meetingpublic;
    
    @ApiModelProperty(value = "timecreated")
    private Long timecreated;
    
    @ApiModelProperty(value = "timemodified")
    private Long timemodified;

    @ApiModelProperty(value = "class_id_url")
    private Long classIdUrl;

}
