package com.topica.lmsvip.repository;

import com.topica.lmsvip.model.lms.MdlLogsserviceInOut;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface MdlLogsserviceInOutRepository extends JpaRepository<MdlLogsserviceInOut, Long> {
  @Query(value = "SELECT NEW com.topica.adapter.common.dto.LogInOutDTO(log.roomid, role.roleId) "
      + "FROM MdlLogsserviceInOut log "
      + "JOIN MdlRoleAssignments role "
      + " ON role.userid = log.userid "
      + "WHERE role.roleId = 9 "
      + " AND log.roomid = :roomId "
      + "GROUP BY log.roomid ")
  Object getPoJoinRoom(@Param("roomId") Long roomId);

  @Query(value = "SELECT log.roomid FROM MdlLogsserviceInOut log "
      + "LEFT JOIN MdlTpeBBB room ON log.roomid = room.id "
      + "LEFT JOIN MdlTpeCanlendarTeach teach ON room.calendarCode = teach.calendarCode "
      + "WHERE log.userid = :userId "
      + " AND teach.teacherType NOT IN ('TRAINING','ORIENTATION') "
      + " AND room.roomType = 'room' "
      + " AND teach.status > 0 "
      + "ORDER BY log.id DESC ")
  List<Long> getLastRoomId(@Param("userId")Long userId, Pageable firstResult);

  @Query(value = "SELECT SUM(log.timeOut) - SUM(log.timeIn) FROM MdlLogsserviceInOut log "
      + "WHERE log.roomid = :roomId "
      + " AND log.userid = :userId "
      + " AND log.timeIn IS NOT NULL "
      + " AND log.timeOut IS NOT NULL ")
  Long getTotalTimeLearnInClass(@Param("roomId") Long roomId,@Param("userId") Long userId);

  @Query(value = "SELECT log.userid FROM MdlLogsserviceInOut log "
      + " LEFT JOIN MdlRoleAssignments role ON log.userid = role.userid "
      + " LEFT JOIN MdlUserInfoData user ON log.userid = user.userid "
      + " WHERE log.roomid = :roomId "
      + "   AND role.roleId IN (3, 10, 11, 12) "
      + "   AND log.timeOut IS NOT NULL "
      + "   AND log.timeIn IS NOT NULL "
      + "   AND user.fieldid = 93 "
      + "   AND user.data = 'VN' "
      + " GROUP BY log.userid "
      + " ORDER BY SUM(log.timeOut) - SUM(log.timeIn) DESC ")
  Long getRealTeacherVNOfRoom(@Param("roomId") Long roomId);

  @Query(value = "SELECT log.userid FROM MdlLogsserviceInOut log "
      + " LEFT JOIN MdlRoleAssignments role ON log.userid = role.userid "
      + " LEFT JOIN MdlUserInfoData user ON log.userid = user.userid "
      + " WHERE log.roomid = :roomId "
      + "   AND role.roleId IN (3, 10, 11, 12) "
      + "   AND log.timeOut IS NOT NULL "
      + "   AND log.timeIn IS NOT NULL "
      + "   AND user.fieldid = 93 "
      + "   AND user.data <> 'VN' "
      + " GROUP BY log.userid "
      + " ORDER BY SUM(log.timeOut) - SUM(log.timeIn) DESC ")
  Long getRealTeacherOfRoom(@Param("roomId") Long roomId);

  @Query(value = "SELECT log.roomidto "
          + "FROM com.topica.lmsvip.model.lms.LogsserviceMoveUser log "
          + "JOIN MdlTpeBBB room ON log.roomidto = room.id "
          + "JOIN MdlTpeCanlendarTeach ca ON room.calendarCode = ca.calendarCode "
          + "WHERE log.userid = :userId "
          + " AND room.timeavailable < :timeAvailable"
          + " AND ca.status <> -1")
  List<Long> existsByUseridNotORI(@Param("userId")Long userId, @Param("timeAvailable") Long timeAvailable, Pageable firstResult);

  @Query(value = "SELECT log.timeIn FROM MdlLogsserviceInOut log " +
          "WHERE log.userid = ?1 " +
          "AND log.action = 'in' " +
          "ORDER BY log.timeIn")
  List<Long> getTimeInJoinRoomLatestByUserId(Long userId, Pageable pageable);
}
