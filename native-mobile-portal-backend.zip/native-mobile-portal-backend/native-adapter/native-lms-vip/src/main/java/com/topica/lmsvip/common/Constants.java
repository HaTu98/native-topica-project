package com.topica.lmsvip.common;

public interface Constants {

    String CODE_SUCCESS = "SUCCESS";

    String HTTP_PROTOCOL = "http://";
    
    String EMPTY_STRING = "";
    
    String SPACE_STRING = " ";
    
    String TICK_STRING = "x";
    
    String UNDERLINE_STRING = "_";
    
    String CLASS_POSTFIX_STRING = "-NLS";
    
    String NOT_PILOT_STRING = "Không theo đợt";
    
    int SIZE_ID_CLASS_FORMAT = 7;
    
    String DATE_FORMAT = "dd/MM/yyyy";
    
    String DATETIME_FORMAT = "dd/MM/yyyy_HH:mm:ss";
    
    String TIME_FORMAT = "HH:mm:ss";
    
    String ALPHABET = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
    
    String R4R_LOG_EXCHANGE_NAME = "R4R_LOG";
    
    String [] R4R_LOG_ROUTING_KEY = {"log_sign_in", "log_action_po_room", "log_action_teacher_room", "log_action_teacher_count_time", "log_action_user_comment", "log_stream"};
    
    int ROOM_MAX_USER = 200;
    
    interface R4rLogRabbitMQ {
    	String HOST = "127.0.0.1";
        int PORT = 5672;
        String USER_NAME = "guest";
        String PASSWORD = "guest";
        String VIRTUAL_HOST = "/";
    }
    
    interface UpdateStreaming {
        int SUCCESS = 0;
        int FAILED = 1;
        int NOT_FOUND = 3;
    }

    interface Delete {
        int SUCCESS = 0;
        int FAILED = 1;
        int NOT_FOUND = 3;
    }

    interface Room {
        int SUCCESS = 0;
        int FAILED = 1;
        int NOT_FOUND = 3;
    }


    interface Update {
        int SUCCESS = 0;
        int FAILED = 1;
        int NOT_FOUND = 3;
    }

    interface TypeNotification {
        int NOTI_NATIVE_SMILE = 0;
        int NOTI_ANSWER_COMMENT = 1;
        int NOTI_LIST_TOPIC = 2;
        int NOTI_LIVESTREAM = 3;
        int NOTI_HOT_TOPIC = 4;
    }

    interface Firebase {
        String SERVER_KEY = "AAAAEhfxTSY:APA91bE7mfas4Raga1sjhnbhKj39KRDUamHrN0YQkn7E1IHElxCx-whWegJ6uFwOiYlSyU-aVauGSCjmqFpOABH87oLbyfUKmCLX_Nh96Kq8w0w_ibcculcKTrnxy-qi4NRRVle2rco1";
        String API_URL = "https://fcm.googleapis.com/fcm/send";
    }

    interface PushNotification {
        String LIST_TOPIC_TITLE = "Topica Thông Báo";
        String LIST_TOPIC_CONTENT = "Đã có danh sách chủ đề Livestream tuần tới. Hãy vào app để đăng ký lịch học live";
        String LIVESTREAM_TITLE = "Livestream Sắp Diễn Ra";
        String LIVESTREAM_CONTENT = "Còn 30 phút nữa GV: ";
        String NATIVE_SMILE_CONTENT = "Câu hỏi của bạn đã được Native Smile trả lời";
    }
    
    interface Rating {
    	String RATING = "rating";
    }
    
}

