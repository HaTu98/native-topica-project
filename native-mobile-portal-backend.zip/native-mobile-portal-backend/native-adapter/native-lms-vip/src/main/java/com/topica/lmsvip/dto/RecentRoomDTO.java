package com.topica.lmsvip.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class RecentRoomDTO {

  @ApiModelProperty(value = "tpebbbid")
  private Long tpebbbId;

  @ApiModelProperty(value = "title")
  private String title;

  @ApiModelProperty(value = "calendar_code")
  private String calendarCode;

  @ApiModelProperty(value = "vcr_type")
  private String vcrType;

  @ApiModelProperty(value = "type")
  private String type;

  @ApiModelProperty(value = "teacher ")
  private String teacher;

  @ApiModelProperty(value = "levelClass ")
  private String levelClass;

  public RecentRoomDTO(Long tpebbbId, String title, String calendarCode, String vcrType,
      String type, String teacher, String levelClass) {
    super();
    this.tpebbbId = tpebbbId;
    this.title = title;
    this.calendarCode = calendarCode;
    this.vcrType = vcrType;
    if (type.equals("SC") && levelClass.equals("sbasic")) {
      this.type = "SN";
    } else {
      this.type = type;
    }
    this.teacher = teacher;
    this.levelClass = levelClass;
  }


}
