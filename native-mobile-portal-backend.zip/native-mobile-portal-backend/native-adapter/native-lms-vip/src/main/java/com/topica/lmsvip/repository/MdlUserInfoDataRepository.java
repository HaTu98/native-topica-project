package com.topica.lmsvip.repository;

import com.topica.lmsvip.model.lms.MdlUserInfoData;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface MdlUserInfoDataRepository extends JpaRepository<MdlUserInfoData, Long> {

  Optional<MdlUserInfoData> findByUseridAndFieldid(Long userId, Integer fieldId);
}