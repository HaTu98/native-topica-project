package com.topica.lmsvip.service.impl;

import com.topica.adapter.common.constant.PageUtil;
import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.service.BaseUserSessionService;
import com.topica.adapter.common.util.RoomUtil;
import com.topica.lmsvip.repository.MdlLogsserviceInOutRepository;
import com.topica.lmsvip.service.LogsserviceInOutService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;

@Service
@Slf4j
public class LogsserviceInOutServiceImpl extends BaseUserSessionService implements LogsserviceInOutService {

  @Autowired
  private MdlLogsserviceInOutRepository inOutRepository;

  @Override
  public Object getPoJoinRoom(Long roomId) {
    return inOutRepository.getPoJoinRoom(roomId);
  }

  @Override
  public Long getLastRoomId(Long userId) {
    List<Long> listRoom = inOutRepository.getLastRoomId(userId, PageUtil.FIRST_RESULT);
    return listRoom.get(0);
  }

  @Override
  public Long getTotalTimeLearnInClass(Long roomId, Long userId) {
    return inOutRepository.getTotalTimeLearnInClass(roomId, userId);
  }

  @Override
  public Long getRealTeacherOfRoom(Long roomId, String teacherType) {
    if(teacherType.equalsIgnoreCase("VN")){
      return inOutRepository.getRealTeacherVNOfRoom(roomId);
    }
    return inOutRepository.getRealTeacherOfRoom(roomId);
  }

  @Override
  public boolean existLogThisUser(PortalMdlUser user) {
    Long timeAvailable = RoomUtil.getTimeAvailableToSeconds();
    Long userId = user.getMdlUser().getId();
    List<Long> anyRoomNotOri = inOutRepository.existsByUseridNotORI(userId, timeAvailable, PageUtil.FIRST_RESULT);
    return !CollectionUtils.isEmpty(anyRoomNotOri);
  }

  @Override
  public Long getTimeBetweenTwoTimeJoinClassLatest(Long userId, boolean isFromCurrentTime) {
    List<Long> times = inOutRepository.getTimeInJoinRoomLatestByUserId(userId, new PageRequest(0, isFromCurrentTime ? 1 : 2));
    if (isFromCurrentTime) times.add(0, System.currentTimeMillis() / 1000);
    if (times.size() < 2) return 0L;
    return times.get(0) - times.get(1);
  }
}
