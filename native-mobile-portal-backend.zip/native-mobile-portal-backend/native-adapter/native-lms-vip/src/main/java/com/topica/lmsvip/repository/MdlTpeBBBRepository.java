package com.topica.lmsvip.repository;

import com.topica.lmsvip.model.lms.MdlTpeBBB;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

public interface MdlTpeBBBRepository extends PagingAndSortingRepository<MdlTpeBBB, Long>, JpaSpecificationExecutor<MdlTpeBBB> {

  MdlTpeBBB findById(Long id);

  @Query(value = "SELECT teach.teacherType FROM MdlTpeBBB room "
      + " JOIN MdlTpeCanlendarTeach teach "
      + "   ON room.calendarCode = teach.calendarCode "
      + " WHERE room.id = :roomId ")
  String getTeacherTypeByRoomId(@Param("roomId") Long roomId);
}
