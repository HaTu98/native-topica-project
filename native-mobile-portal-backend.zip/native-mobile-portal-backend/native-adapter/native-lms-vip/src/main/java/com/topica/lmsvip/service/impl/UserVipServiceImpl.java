package com.topica.lmsvip.service.impl;

import com.google.common.base.Strings;
import com.topica.adapter.common.config.room.ErrorMessageConfig;
import com.topica.adapter.common.constant.ServiceType;
import com.topica.adapter.common.dto.PersonalInfoDTO;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.exception.ExceptionCode;
import com.topica.adapter.common.model.PortalUser;
import com.topica.adapter.common.request.LoginRequest;
import com.topica.adapter.common.request.UpdateInfoRequest;
import com.topica.adapter.common.service.market.MarketService;
import com.topica.lmsvip.model.lms.MdlUserData;
import com.topica.lmsvip.model.lms.MdlUserInfoData;
import com.topica.lmsvip.model.lms.UserInfoVip;
import com.topica.lmsvip.repository.MdlUserDataRepository;
import com.topica.lmsvip.service.user.UserVipService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Optional;

import static com.topica.adapter.common.config.room.ErrorMessageConfig.*;
import static com.topica.adapter.common.constant.ServiceType.LMS_VIP;

@Slf4j
@Service("UserVipService")
public class UserVipServiceImpl implements UserVipService {

  @Autowired
  private MdlUserDataRepository repository;

  @Autowired
  private MarketService marketService;

  @Autowired
  private UserInfoDataServiceImpl userInfoDataService;
  
  @Autowired
  private ErrorMessageConfig errorMessageConfig;

  @Autowired
  private PasswordEncoder passwordEncoder;

  @Value("${function.mobile.vip}")
  private String functionMobileVIP;

  @Value("${function.livestream}")
  private String functionMobileLive;

  @Value("${portal.user.update.require-password}")
  private Boolean requirePassword;

  @Override
  public MdlUserData findOne(Long userId) {
    return repository.findOne(userId);
  }

  @Override
  public List<MdlUserData> findByUserNames(List<String> usernames) {
    return repository.findByUserNames(usernames);
  }

  @Override
  public String getUserCountry(Long userId) {
    log.info("(getUserCountry) {}", userId);
    return repository.getUserCountry(userId);
  }

  @Override
  public Optional<? extends PortalUser> findUser(String userName, ServiceType type) {
    return repository.findFirstByUsername(userName);
  }

  @Override
  public PersonalInfoDTO findPersonalInfo(Long userId) throws BusinessException {
    UserInfoVip info = repository.findPersonalInfo(userId);
    if (info == null) {
      throw new BusinessException(ExceptionCode.User.USER_NOT_FOUND, "user not found !");
    }
    info.setInfoData(repository.getInfoByUserid(info.getId(), PersonalInfoDTO.listField));
    info.setServiceType(LMS_VIP);
    info = marketService.setPackages(info, LMS_VIP);
    return info;
  }

  @Override
  public void checkValidGen(PersonalInfoDTO info, ServiceType serviceType) throws BusinessException {
    List<String> listGenCode = this.getListGenCode(info);
    if(!CollectionUtils.isEmpty(listGenCode)) {
      boolean anyValidPackage = listGenCode.parallelStream().anyMatch(p -> isValidFunctionGen(p));
      if(anyValidPackage) {
        return;
      }
    }
    throw new BusinessException(ExceptionCode.Authentication.AUTHENTICATION_GEN_INVALID, this.getMsgForInvalidGEN());
  }

  @Override
  public boolean changePassword(ServiceType serviceType, Long userId, String oldPassword, String newPassword) throws BusinessException {
    MdlUserData userData = repository.findOneById(userId);
    if (userData == null) {
      throw new BusinessException(ExceptionCode.User.USER_NOT_FOUND, "user not found !");
    }
    if (!this.passwordEncoder.matches(oldPassword, userData.getPassword())) {
      throw new BusinessException(ExceptionCode.User.INCORRECT_PASSWORD, "Old Password incorrect");
    }
    userData.setPassword(this.passwordEncoder.encode(newPassword));
    repository.save(userData);
    return true;
  }

  @Override
  public Optional<? extends PortalUser> update(Long userId, ServiceType type, UpdateInfoRequest updateInfoRequest) throws BusinessException {
    MdlUserData userData = repository.findOne(userId);
    if (userData == null) {
      throw new BusinessException(ExceptionCode.User.USER_NOT_FOUND, "user not found !");
    }
    if (requirePassword && !this.passwordEncoder.matches(updateInfoRequest.getPassword(), userData.getPassword())) {
        throw new BusinessException(ExceptionCode.User.INCORRECT_PASSWORD, "Old Password incorrect");
    }
    this.updateUserInfoData(userId, updateInfoRequest);
    userData.setFirstName(updateInfoRequest.getFirstName());
    userData.setLastName(updateInfoRequest.getLastName());
    userData.setPhone1(updateInfoRequest.getPhone());
    userData.setEmail(updateInfoRequest.getEmail());
    return Optional.of(repository.save(userData));
  }

  private void updateUserInfoData(Long userId, UpdateInfoRequest updateInfoRequest) {
    if (!Strings.isNullOrEmpty(updateInfoRequest.getGender())) {
      userInfoDataService.insert(MdlUserInfoData.builder()
        .userid(userId).fieldid(PersonalInfoDTO.GENDER).data(updateInfoRequest.getGender()).build());
    }
    if (!Strings.isNullOrEmpty(updateInfoRequest.getBirthday())) {
      userInfoDataService.insert(MdlUserInfoData.builder()
        .userid(userId).fieldid(PersonalInfoDTO.BIRTHDAY).data(updateInfoRequest.getBirthday()).build());
    }
  }

  private boolean isValidFunctionGen(String genCode) {
    List<String> allowFuncs = this.repository.getListFunction(genCode);
    return allowFuncs.parallelStream()
            .anyMatch(f -> f.contains(functionMobileVIP) || f.contains(functionMobileLive));
  }

  @Override
  public PersonalInfoDTO findPersonalInfo(Long userId, ServiceType type) throws BusinessException {
    return this.findPersonalInfo(userId);
  }

  @Override
  public Optional<Long> registerVCRXUser(LoginRequest loginRequest) {
    return null;
  }

  @Override
  public String getMsgForExpiredPackage() {
    String msg = this.errorMessageConfig.getByKey(PACKAGE_EXPIRED);
    if(StringUtils.isEmpty(msg)) msg = DEFAULT_PACKAGE_EXPIRED;
    return msg;
  }

  @Override
  public String getMsgForDeactivedPackage() {
    String msg = this.errorMessageConfig.getByKey(PACKAGE_DEACTIVED);
    if(StringUtils.isEmpty(msg)) msg = DEFAULT_PACKAGE_DEACTIVED;
    return msg;
  }

  @Override
  public String getMsgForInvalidGEN() {
    String msg = this.errorMessageConfig.getByKey(INVALID_GEN);
    if(StringUtils.isEmpty(msg)) msg = DEFAULT_INVALID_GEN;
    return msg;
  }
}