package com.topica.lmsvip.model.lms;

import com.topica.adapter.common.model.PortalUser;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@AllArgsConstructor
@Data
@Entity
@EqualsAndHashCode(of = "id")
@NoArgsConstructor
@Table(name = "mdl_user")
public class MdlUserData implements PortalUser {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false)
    private String username;

    @Column(nullable = false)
    private Long deleted;

    @Column(nullable = false)
    private Long suspended;

    @Column(name = "firstname", nullable = false)
    private String firstName;

    @Column(name = "lastname", nullable = false)
    private String lastName;

    @Column(nullable = false)
    private String email;

    @Column(nullable = false)
    private String phone1;

    @Column(nullable = false)
    private String phone2;

    @Column(name = "imagealt")
    private String imageAlt;

    @Override
    public String password() {
        return this.getPassword();
    }

    @Override
    public Long delete() {
        return this.getDeleted();
    }

    @Override
    public Long suspended() {
        return this.getSuspended();
    }

    @Override
    public Long getUserId() {
        return this.getId();
    }
}