package com.topica.lmsvip.service.impl;

import com.topica.adapter.common.constant.LevelClass;
import com.topica.adapter.common.constant.SubjectType;
import com.topica.adapter.common.dto.material.MaterialDTO;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.service.material.MaterialService;
import com.topica.lmsvip.model.lms.VipMdlMaterialservice;
import com.topica.lmsvip.repository.material.MaterialVipRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.topica.adapter.common.constant.LevelClass.BO;
import static com.topica.adapter.common.constant.LevelClass.SBO;

@Service("materialVipServiceImpl")
public class MaterialVipServiceImpl implements MaterialService {

    private @Autowired MaterialVipRepository repository;

    @Override
    public Map<SubjectType, List<MaterialDTO>> get(long start, long end, String userLevel, String packageCode) throws BusinessException {
        LevelClass levelClass = LevelClass.levelOf(userLevel);
        LevelClass levelLS = SBO == levelClass ? BO : levelClass;
        LevelClass levelSC = levelClass;
        List<String> teacherTypes = this.getTeacherType(packageCode);
        String studentType = this.getStudentType(packageCode);
        studentType = "%" + studentType + "%";

        return repository.findByTime(start, end, teacherTypes, levelLS.name(), levelSC.name(), studentType)
                .stream()
                .map(e -> this.of(e))
                .collect(Collectors.groupingBy(MaterialDTO::getSubjectType));
    }

    private String getStudentType(String packageCode) {
        return "VIP3";
    }

    public MaterialDTO of (VipMdlMaterialservice vip) {
        return MaterialDTO.builder()
                .id(vip.getId())
                .subjectType(SubjectType.valueOf(vip.getSubjectType()))
                .objective(vip.getObjective())
                .topic(vip.getTopic())
                .subject(vip.getSubject())
                .classOutline(vip.getClassOutline())
                .fileurl(vip.getFileurl())
                .outlineHomework(vip.getOutlineHomework())
                .lessonPlan(vip.getLessonPlan())
                .videoWarmup(vip.getVideoWarmup() != null ? vip.getVideoWarmup() : vip.getLinkVideoWarmup())
                .background(vip.getBackground())
                .timeBegin(vip.getTimeBegin())
                .teacherType(vip.getTeacherType())
                .levelOutline(vip.getLevelOutline())
                .code(vip.getCode())
                .build();
    }
}
