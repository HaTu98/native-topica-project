package com.topica.lmsvip.service.impl;

import com.topica.adapter.common.dto.request.KibanaLogDTO;
import com.topica.adapter.common.model.portal.SigninHistory;
import com.topica.adapter.common.service.log.ExternalLogService;
import com.topica.adapter.common.service.room.TraceLogBlackBoxService;
import com.topica.lmsvip.service.LogsserviceInOutService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service("traceLogBlackBoxVipServiceImpl")
@Slf4j
public class TraceLogBlackBoxVipServiceImpl implements TraceLogBlackBoxService {

    private final static String SOURCE = "portal_nvn";

    @Value("${portal.warning-last-join-room-day}")
    protected int warningLastJoinRoomDay;

    @Autowired
    private LogsserviceInOutService logsserviceInOutService;

    @Autowired
    private ExternalLogService externalLogService;

    @Override
    public void traceLogLogin(SigninHistory model) {
        KibanaLogDTO log = KibanaLogDTO.builder()
                .objectType("Student")
                .objectId(model.getUserid().toString())
                .objectName("userId")
                .objectName(model.getUsername())
                .objectAttribute("username=" + model.getUsername())
                .actionType("login_portal")
                .actionTime(model.getTime().getTime())
                .targetType("client_portal_" + model.getServiceType())
                .targetId(model.getDeviceId())
                .targetKey("deviceId")
                .targetName(model.getOs())
                .targetAttribute("device=" + model.getDevice() + ";appversion=" + model.getAppVersion())
                .source("portal")
                .build();
        externalLogService.save(log);
    }

    @Override
    public long calTimeComeBackFromLast(Long userId, boolean isFromCurrentTime) {
        Long time = logsserviceInOutService.getTimeBetweenTwoTimeJoinClassLatest(userId, isFromCurrentTime);
        int warningLastJoinRoomTime = warningLastJoinRoomDay * 24 * 60 * 60;

        return time - warningLastJoinRoomTime;
    }

    @Override
    public void traceLogWarningReJoinRoom(Long userId, String serviceType, Long roomId, Long comeBackTime) {
        KibanaLogDTO log = KibanaLogDTO.builder()
                .objectType("Student")
                .objectId(String.valueOf(userId))
                .objectName("userId")
                .actionType("warning_last_time_join_room_too_long")
                .actionTime(System.currentTimeMillis())
                .targetType("client_portal_" + serviceType)
                .targetId(roomId.toString())
                .targetKey("roomId")
                .targetName(roomId.toString())
                .source(SOURCE)
                .build();
        externalLogService.save(log);
    }
}
