package com.topica.lmsvip.model.lms;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@AllArgsConstructor
@Data
@Entity
@EqualsAndHashCode(of = "id")
@NoArgsConstructor
@Table(name = "mdl_tpebbb")
public class MdlTpeBBB {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "timeavailable")
    private Long timeavailable;
    
    @Column(name = "roomtype")
    private String roomType;
    
    @Column(name = "calendar_code")
    private String calendarCode;
    
    @Column(name = "subject_code")
    private String subjectCode;

    @Column(name = "vcr_type")
    private String vcrType;
    
    @Column(name = "vcr_class_id")
    private Long vcrClassId;
}
