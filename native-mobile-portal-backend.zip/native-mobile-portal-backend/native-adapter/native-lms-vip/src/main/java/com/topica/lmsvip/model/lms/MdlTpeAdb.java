package com.topica.lmsvip.model.lms;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Data
@Entity
@EqualsAndHashCode(of = "id")
@NoArgsConstructor
@Table(name = "mdl_tpeadb")
public class MdlTpeAdb {
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
	
	@Column(name = "course")
	private Long course;

	@Column(name = "name")
	private String name;

	@Column(name = "intro")
	private String intro;

	@Column(name = "introformat")
	private Integer introFormat;

	@Column(name = "userid")
	private Long userId;

	@Column(name = "templatescoid")
	private Long templatEscoId;

	@Column(name = "meeturl")
	private String meetUrl;

	@Column(name = "starttime")
	private Long startTime;

	@Column(name = "endtime")
	private Long endTime;

	@Column(name = "meetingpublic")
	private Boolean meetingPublic;

	@Column(name = "timecreated")
	private Long timeCreated;

	@Column(name = "timemodified")
	private Long timeModified;
}
