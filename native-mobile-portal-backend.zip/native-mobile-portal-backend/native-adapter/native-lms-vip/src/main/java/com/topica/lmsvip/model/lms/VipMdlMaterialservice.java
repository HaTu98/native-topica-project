package com.topica.lmsvip.model.lms;

import javax.persistence.*;

@Entity
@Table(name = "mdl_materialservice")
public class VipMdlMaterialservice {
    private Long id;
    private Long courseId;
    private String code;
    private String subject;
    private String subjectCode;
    private String subjectType;
    private String teacherType;
    private String studentType;
    private String levelOutline;
    private String topic;
    private String objective;
    private String classOutline;
    private String background;
    private String videoWarmup;
    private String lessonPlan;
    private String relatedSubject;
    private Long timeBegin;
    private Long timecreated;
    private Long timemodified;
    private Short status;
    private String fileurl;
    private String originCode;
    private String outlineVn;
    private String outlineHomework;
    private String linkVideoWarmup;

    @Id
    @Column(name = "id")
    public long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Basic
    @Column(name = "course_id")
    public long getCourseId() {
        return courseId;
    }

    public void setCourseId(Long courseId) {
        this.courseId = courseId;
    }

    @Basic
    @Column(name = "code")
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @Basic
    @Column(name = "subject")
    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    @Basic
    @Column(name = "subject_code")
    public String getSubjectCode() {
        return subjectCode;
    }

    public void setSubjectCode(String subjectCode) {
        this.subjectCode = subjectCode;
    }

    @Basic
    @Column(name = "subject_type")
    public String getSubjectType() {
        return subjectType;
    }

    public void setSubjectType(String subjectType) {
        this.subjectType = subjectType;
    }

    @Basic
    @Column(name = "teacher_type")
    public String getTeacherType() {
        return teacherType;
    }

    public void setTeacherType(String teacherType) {
        this.teacherType = teacherType;
    }

    @Basic
    @Column(name = "student_type")
    public String getStudentType() {
        return studentType;
    }

    public void setStudentType(String studentType) {
        this.studentType = studentType;
    }

    @Basic
    @Column(name = "level_outline")
    public String getLevelOutline() {
        return levelOutline;
    }

    public void setLevelOutline(String levelOutline) {
        this.levelOutline = levelOutline;
    }

    @Basic
    @Column(name = "topic")
    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    @Basic
    @Column(name = "objective")
    public String getObjective() {
        return objective;
    }

    public void setObjective(String objective) {
        this.objective = objective;
    }

    @Basic
    @Column(name = "class_outline")
    public String getClassOutline() {
        return classOutline;
    }

    public void setClassOutline(String classOutline) {
        this.classOutline = classOutline;
    }

    @Basic
    @Column(name = "background")
    public String getBackground() {
        return background;
    }

    public void setBackground(String background) {
        this.background = background;
    }

    @Basic
    @Column(name = "video_warmup")
    public String getVideoWarmup() {
        return videoWarmup;
    }

    public void setVideoWarmup(String videoWarmup) {
        this.videoWarmup = videoWarmup;
    }

    @Basic
    @Column(name = "lesson_plan")
    public String getLessonPlan() {
        return lessonPlan;
    }

    public void setLessonPlan(String lessonPlan) {
        this.lessonPlan = lessonPlan;
    }

    @Basic
    @Column(name = "related_subject")
    public String getRelatedSubject() {
        return relatedSubject;
    }

    public void setRelatedSubject(String relatedSubject) {
        this.relatedSubject = relatedSubject;
    }

    @Basic
    @Column(name = "time_begin")
    public Long getTimeBegin() {
        return timeBegin;
    }

    public void setTimeBegin(Long timeBegin) {
        this.timeBegin = timeBegin;
    }

    @Basic
    @Column(name = "timecreated")
    public Long getTimecreated() {
        return timecreated;
    }

    public void setTimecreated(Long timecreated) {
        this.timecreated = timecreated;
    }

    @Basic
    @Column(name = "timemodified")
    public Long getTimemodified() {
        return timemodified;
    }

    public void setTimemodified(Long timemodified) {
        this.timemodified = timemodified;
    }

    @Basic
    @Column(name = "status")
    public Short getStatus() {
        return status;
    }

    public void setStatus(Short status) {
        this.status = status;
    }

    @Basic
    @Column(name = "fileurl")
    public String getFileurl() {
        return fileurl;
    }

    public void setFileurl(String fileurl) {
        this.fileurl = fileurl;
    }

    @Basic
    @Column(name = "origin_code")
    public String getOriginCode() {
        return originCode;
    }

    public void setOriginCode(String originCode) {
        this.originCode = originCode;
    }

    @Basic
    @Column(name = "outline_vn")
    public String getOutlineVn() {
        return outlineVn;
    }

    public void setOutlineVn(String outlineVn) {
        this.outlineVn = outlineVn;
    }

    @Basic
    @Column(name = "outline_homework")
    public String getOutlineHomework() {
        return outlineHomework;
    }

    public void setOutlineHomework(String outlineHomework) {
        this.outlineHomework = outlineHomework;
    }

    @Basic
    @Column(name = "link_video_warmup")
    public String getLinkVideoWarmup() {
        return linkVideoWarmup;
    }

    public void setLinkVideoWarmup(String linkVideoWarmup) {
        this.linkVideoWarmup = linkVideoWarmup;
    }

}
