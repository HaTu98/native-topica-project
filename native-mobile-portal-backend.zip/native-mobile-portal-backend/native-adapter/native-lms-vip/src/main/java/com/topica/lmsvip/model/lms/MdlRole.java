package com.topica.lmsvip.model.lms;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@AllArgsConstructor
@Data
@Entity
@EqualsAndHashCode(of = "id")
@NoArgsConstructor
@Table(name = "mdl_role")
public class MdlRole {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "name", nullable = false)
    private String name;
    
    @Column(name = "shortname", nullable = false)
    private String shortname;

    @Column(name = "description", nullable = false)
    private String description;
    
    @Column(name = "sortorder", nullable = false)
    private Long sortorder;
    
    @Column(name = "archetype", nullable = false)
    private String archetype;


}
