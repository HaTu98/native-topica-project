package com.topica.lmsvip.service;

import com.topica.lmsvip.model.lms.MdlUserInfoData;
import java.util.Optional;

public interface UserInfoDataService {

  Optional<MdlUserInfoData> findContactId(Long userId);

  MdlUserInfoData findByUseridAndFieldid(Long userId, Integer fieldId);

  void save(MdlUserInfoData userInfoData);

  void insert(MdlUserInfoData userInfoData);
}
