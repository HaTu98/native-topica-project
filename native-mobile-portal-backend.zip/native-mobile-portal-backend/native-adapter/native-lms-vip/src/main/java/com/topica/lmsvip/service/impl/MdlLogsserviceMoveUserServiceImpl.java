package com.topica.lmsvip.service.impl;

import com.topica.adapter.common.dto.RoomUserCountDTO;
import com.topica.lmsvip.repository.MdlLogsserviceMoveUserRepository;
import com.topica.lmsvip.service.MdlLogsserviceMoveUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MdlLogsserviceMoveUserServiceImpl implements MdlLogsserviceMoveUserService {

  @Autowired
  MdlLogsserviceMoveUserRepository userRepository;

  @Override
  public RoomUserCountDTO getUserCountByRoomId(Long roomId) {
    return userRepository.getUserCountByRoomId(roomId);
  }
}
