package com.topica.lmsvip.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.Gson;
import lombok.NoArgsConstructor;

import java.util.Date;

@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class PackageResponse {
    private Integer id;
    private String product_id;
    private String contact_id;
    private String status;
    private String cat_code;
    private String gen_code;
    private Date starttime;
    private Date timecreated;
    private Date timemodified;
    private PackageAttrsDTO package_attrs;

    public String getGen_code() {
        return gen_code;
    }

    public void setGen_code(String gen_code) {
        this.gen_code = gen_code;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getContact_id() {
        return contact_id;
    }

    public void setContact_id(String contact_id) {
        this.contact_id = contact_id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public PackageAttrsDTO getPackage_attrs() {
        return package_attrs;
    }


    public void setPackage_attrs(String package_attrs) {
        this.package_attrs = new Gson().fromJson(package_attrs, PackageAttrsDTO.class);
    }

    public Date getStarttime() {
        return starttime;
    }

    public void setStarttime(Date starttime) {
        this.starttime = starttime;
    }

    public Date getTimecreated() {
        return timecreated;
    }

    public void setTimecreated(Date timecreated) {
        this.timecreated = timecreated;
    }

    public Date getTimemodified() {
        return timemodified;
    }

    public void setTimemodified(Date timemodified) {
        this.timemodified = timemodified;
    }

    public String getCat_code() {
        return cat_code;
    }

    public void setCat_code(String cat_code) {
        this.cat_code = cat_code;
    }
}
