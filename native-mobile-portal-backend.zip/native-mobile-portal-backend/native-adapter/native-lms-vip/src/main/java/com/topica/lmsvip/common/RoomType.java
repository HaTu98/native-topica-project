package com.topica.lmsvip.common;

public enum RoomType {
	ROOM,
	TECHSUPPORT,
	TECHSUPPORTNEWBIE,
	TECHTESTTEACHER,
	TECHSUPPORTNEWBIEADOBE,
	TECHTEST
}
