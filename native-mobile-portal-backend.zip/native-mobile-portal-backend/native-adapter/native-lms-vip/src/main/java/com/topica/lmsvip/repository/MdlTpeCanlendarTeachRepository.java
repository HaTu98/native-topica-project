package com.topica.lmsvip.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.topica.lmsvip.model.lms.MdlTpeCanlendarTeach;

public interface MdlTpeCanlendarTeachRepository extends PagingAndSortingRepository<MdlTpeCanlendarTeach, Long>, JpaSpecificationExecutor<MdlTpeCanlendarTeach> {
	MdlTpeCanlendarTeach findById(Long id);

	MdlTpeCanlendarTeach findByCalendarCode(String calendarCode);
}
