package com.topica.lmsvip.model.lms;

import com.topica.adapter.common.dto.RoomDTO;
import lombok.Data;

import static com.topica.adapter.common.constant.ServiceType.LMS_VIP;

@Data
public class RoomResultVip {
    private MdlTpeBBB bbb;
    private MdlTpeCanlendarTeach calendar;
    private long totalUserNormal;
    private MdlUserData teacher;
    private LogsserviceMoveUser logMove;

    public RoomResultVip() {
    }

    public RoomDTO toRoomDTO() {
        return new RoomDTO().builder()
                .packageType(LMS_VIP.name())
                .id(bbb.getId())
                .name(bbb.getName())
                .levelClass(calendar.getLevelClass())
                .timeAvailable(bbb.getTimeavailable())
                .typeClass(calendar.getTypeClass())
                .vcrType(bbb.getVcrType())
                .vcrClassId(bbb.getVcrClassId())
                .vcrType(bbb.getVcrType())
                .totalJoin(totalUserNormal)
                .isOpened(isOpened())
                .teacherFirstName(teacher != null ? teacher.getFirstName() : "")
                .teacherLastName(teacher != null ? teacher.getLastName() : "")
                .teacherAvatar(teacher != null ? teacher.getImageAlt() : "")
                .teacherId(calendar.getTeacherId())
                .build();
    }

    private boolean isOpened() {
        if(totalUserNormal > 0) {
            return true;
        }
        if(bbb.getVcrClassId() != null) {
            return true;
        }
        return false;
    }

    public static RoomDTO toListRoomDTO(Object[] records) {
        RoomResultVip result = new RoomResultVip();
        result.setBbb((MdlTpeBBB) records[0]);
        result.setCalendar((MdlTpeCanlendarTeach) records[1]);
        result.setTotalUserNormal((Long) records[2]);
        result.setTeacher((MdlUserData) records[3]);
        return result.toRoomDTO();
    }
    public static RoomDTO toListRoomDTONotFull(Object[] records) {
        RoomResultVip result = new RoomResultVip();
        result.setBbb((MdlTpeBBB) records[0]);
        result.setCalendar((MdlTpeCanlendarTeach) records[1]);
        result.setTotalUserNormal((Long) records[2]);
        return result.toRoomDTO();
    }
    public static RoomDTO toRoomJoined(Object[] records) {
        RoomResultVip result = new RoomResultVip();
        result.setBbb((MdlTpeBBB) records[0]);
        result.setCalendar((MdlTpeCanlendarTeach) records[1]);
        result.setTeacher((MdlUserData) records[2]);
        RoomDTO room = result.toRoomDTO();
        room.setOpened(true);
        room.setJoined(true);
        return room;
    }
    public static RoomDTO toRoomDTO(Object[] records) {
        RoomResultVip result = new RoomResultVip();
        result.setBbb((MdlTpeBBB) records[0]);
        result.setCalendar((MdlTpeCanlendarTeach) records[1]);
        return result.toRoomDTO();
    }
}