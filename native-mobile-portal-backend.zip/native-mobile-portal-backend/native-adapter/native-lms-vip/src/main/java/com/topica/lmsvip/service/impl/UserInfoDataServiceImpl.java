package com.topica.lmsvip.service.impl;

import com.topica.lmsvip.model.lms.MdlUserInfoData;
import com.topica.lmsvip.repository.MdlUserInfoDataRepository;
import com.topica.lmsvip.service.UserInfoDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserInfoDataServiceImpl implements UserInfoDataService {

  @Autowired
  private MdlUserInfoDataRepository userInfoDataRepository;

  @Override
  public Optional<MdlUserInfoData> findContactId(Long userId) {
    return userInfoDataRepository.findByUseridAndFieldid(userId, 88);
  }

  @Override
  public MdlUserInfoData findByUseridAndFieldid(Long userId, Integer fieldId) {
    Optional userInfoOpt = userInfoDataRepository.findByUseridAndFieldid(userId, fieldId);
    if(!userInfoOpt.isPresent()) return null;
    return userInfoDataRepository.findByUseridAndFieldid(userId, fieldId).get();
  }

  @Override
  public void save(MdlUserInfoData userInfoData) {
    userInfoDataRepository.save(userInfoData);
  }

  @Override
  public void insert(MdlUserInfoData userInfoData) {
    Optional<MdlUserInfoData> mdlUserInfoDataOptional = userInfoDataRepository.findByUseridAndFieldid(userInfoData.getUserid(), userInfoData.getFieldid());
    if (!mdlUserInfoDataOptional.isPresent()) {
      userInfoDataRepository.save(userInfoData);
      return;
    }
    MdlUserInfoData mdlUserInfoData = mdlUserInfoDataOptional.get();
    mdlUserInfoData.setData(userInfoData.getData());
    userInfoDataRepository.save(mdlUserInfoData);
  }
}