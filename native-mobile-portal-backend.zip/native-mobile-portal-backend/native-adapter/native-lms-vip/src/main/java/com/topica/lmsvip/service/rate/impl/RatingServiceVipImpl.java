package com.topica.lmsvip.service.rate.impl;

import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.model.cara.CaraResponse;
import com.topica.adapter.common.model.cara.RateInfo;
import com.topica.adapter.common.model.cara.RateProperties;
import com.topica.adapter.common.request.CaraRequest;
import com.topica.adapter.common.service.invoker.InvokerService;
import com.topica.adapter.common.service.rating.BasePortalCaraService;
import com.topica.adapter.common.service.rating.RatingServicePortal;
import com.topica.adapter.common.service.room.RoomServicePortal;
import com.topica.lmsvip.repository.MdlTpeBBBRepository;
import com.topica.lmsvip.service.LogsserviceInOutService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Optional;

import static com.topica.adapter.common.constant.RoleInClass.NORMAL;

@Service("ratingServiceVip")
@Slf4j
public class RatingServiceVipImpl extends BasePortalCaraService implements RatingServicePortal {

  @Value("${cara.rate.id.lms_vip}")
  private Long rateId;

  @Autowired
  protected LogsserviceInOutService inOutService;

  @Autowired
  private MdlTpeBBBRepository mdlTpeBBBRepository;

  @Autowired
  @Qualifier("roomServiceVip")
  protected RoomServicePortal roomVipService;

  @Autowired
  private InvokerService invokerService;

  @Override
  public Optional<CaraResponse> canRate() {
    String token = this.getCaraToken();
    if(StringUtils.isEmpty(token)){
      return Optional.empty();
    }
    return this.isCanRate(token);
  }

  private Optional<CaraResponse> isCanRate(String token) {
    Long userId = this.getUserSession().getMdlUser().getId();
    Optional<RoomDTO> room = this.getLastRoomLearned(userId);
    if (!room.isPresent()) {
      return Optional.empty();
    }
    if (isCurrentTime(room.get().getTimeAvailable())) {
      return Optional.empty();
    }

    Long roomId = room.get().getId();
    if (this.isRated(userId, roomId, token)) {
      return Optional.empty();
    }
    CaraResponse caraResponse;
    try {
      caraResponse = this.getCaraResponse(room.get(), rateId, token, NORMAL.name());
    } catch (BusinessException e) {
      return Optional.empty();
    }
    return Optional.of(caraResponse);
  }

    @Override
  public Optional<CaraResponse> rating(CaraRequest request) {
    if(CollectionUtils.isEmpty(request.getOptions()) && CollectionUtils.isEmpty(request.getVotes())) {
      return Optional.empty();
    }
    String token = this.getCaraToken();
    if(StringUtils.isEmpty(token)){
      return Optional.empty();
    }
    Optional<CaraResponse> isCanRateOpt = this.isCanRate(token);
    if(!isCanRateOpt.isPresent() || !isCanRateOpt.get().getStatus()){
      return Optional.empty();
    }

    this.completeRequest(request, isCanRateOpt);

    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.set("Authorization",token);
    RateInfo rateInfo = this.createRateInfo(request, token);
    HttpEntity httpEntity = new HttpEntity<>(rateInfo, headers);

    String url = domainCaraServer.concat(uriCreateRate);
    Optional<ApiDataResponse> response = this.invokerService.postHeader(url, httpEntity, ApiDataResponse.class);
    if(!response.isPresent()) {
      return Optional.empty();
    }

    if(response.get().getCode() != 200 ){
      return Optional.empty();
    }
    return Optional.of(new CaraResponse(true));
  }

  private void completeRequest(CaraRequest request, Optional<CaraResponse> isCanRateOpt) {
    Long userId = this.getUserSession().getMdlUser().getId();
    request.setStudent_id(userId);
    request.setTeacher_id(isCanRateOpt.get().getData().getClass_info().getTeacher_id());
  }

  private Optional<RoomDTO> getLastRoomLearned(Long userId) {
    try {
      Long roomId = inOutService.getLastRoomId(userId);
      return roomVipService.getRoom(roomId);
    } catch (Exception e) {
      log.error("Get last room learned for userId error: {}", userId);
    }
    return Optional.empty();
  }

  private RateInfo createRateInfo(CaraRequest request, String token) {
    RateInfo rateInfo = new RateInfo(request);
    rateInfo.setRateId(rateId);
    Long timeConfig = this.getTimeConfig(token);
    rateInfo.setStudyTime(request.getTimeAvailable());
    rateInfo.setStatus(this.getStatusRate(request.getTimeAvailable(), timeConfig));

    if(!CollectionUtils.isEmpty(request.getOptions())) {
      List<RateProperties> rateProperties = this.getRateProperties(request);
      rateInfo.setExtraInfos(rateProperties);
      return rateInfo;
    }
    rateInfo.setExtraInfos(this.getExtraInfos(request));
    return rateInfo;
  }

  public Long getTeacherIdByRoomId(Long roomId){
    log.info("(getTeacherIdByRoomId){}", roomId);
    String teacherType = mdlTpeBBBRepository.getTeacherTypeByRoomId(roomId);
    return inOutService.getRealTeacherOfRoom(roomId, teacherType);
  }
}
