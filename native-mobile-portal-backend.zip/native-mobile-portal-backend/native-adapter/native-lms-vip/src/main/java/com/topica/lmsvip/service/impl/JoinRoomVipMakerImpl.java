package com.topica.lmsvip.service.impl;

import com.topica.adapter.common.config.room.UseDeeplinkAdobe;
import com.topica.adapter.common.constant.SubjectType;
import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.dto.response.JoinRoomResponse;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.exception.RoomError;
import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.request.JoinRoomRequest;
import com.topica.adapter.common.request.alert.AlertVipRequest;
import com.topica.adapter.common.service.BaseUserSessionService;
import com.topica.adapter.common.service.alert.AlertService;
import com.topica.adapter.common.service.invoker.InvokerService;
import com.topica.adapter.common.service.room.JoinRoomMaker;
import com.topica.adapter.common.service.room.TraceLogBlackBoxService;
import com.topica.adapter.common.util.AdobeUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.topica.adapter.common.dto.RoomDTO.ADB;

@Slf4j
@Service("joinRoomVipMaker")
public class JoinRoomVipMakerImpl extends BaseUserSessionService implements JoinRoomMaker {

    @Value("${domain.lmsvip.link.adb}")
    private String linkADB;

    @Autowired
    private ApplicationContext applicationContext;

    @Autowired
    private InvokerService invokerService;

    @Autowired
    private UseDeeplinkAdobe useDeeplinkAdobe;

    @Autowired
    private AlertService alertService;

    @Autowired
    @Qualifier("traceLogBlackBoxVipServiceImpl")
    private TraceLogBlackBoxService traceLogJoinRoomService;

    @Override
    public boolean validRoom(RoomDTO room) throws BusinessException {
        if(!room.isOpened()) {
            throw new BusinessException(RoomError.ROOM_NOT_OPEN, "Room not open !");
        }
        if(!room.isJoined()) {
            if(room.getTotalJoin() >= room.getMaxJoin()) {
                throw new BusinessException(RoomError.FULL_USER_IN_ROOM, "Full user in room !");
            }
        }
        return true;
    }

    @Override
    public Optional<RoomDTO> findTargetRoom(SubjectType type) throws BusinessException {
        List<RoomDTO> listRoom = Collections.emptyList();
        try {
            listRoom = this.getListRoomNotFull(type);
        } catch (Exception e) {
            log.error("Get List room to join fail: {}", e.getMessage());
        }
        if (CollectionUtils.isEmpty(listRoom)) {
            this.alertFullUser(type);
        }
        return this.filterRoom(listRoom);
    }

    private List<RoomDTO> getListRoomNotFull(SubjectType type) {
        RoomServiceVipImpl bean = this.applicationContext.getBean(RoomServiceVipImpl.class);
        return bean.listRoomNotFull(type.name());
    }

    private Optional<RoomDTO> filterRoom(List<RoomDTO> listRoom) throws BusinessException {
        listRoom = listRoom.parallelStream()
                .filter(RoomDTO::isOpened)
                .filter(room -> room.getTotalJoin() < room.getMaxJoin())
                .collect(Collectors.toList());
        if (CollectionUtils.isEmpty(listRoom)) {
            throw new BusinessException(RoomError.NOT_FOUND_VALID_ROOM, "Not Found Available Room");
        }
        return Optional.of(listRoom.get(0));
    }

    @Override
    public JoinRoomResponse joinInto(RoomDTO targetRoom) {
        PortalMdlUser user = this.getUserSession();
        log.info("(joinRoom) VIP user: {}, classID: {}", user.getMdlUser().getUsername(), targetRoom.getId());
        JoinRoomRequest joinRequest = JoinRoomRequest.builder()
                .username(user.getMdlUser().getUsername())
                .password(user.getMdlUser().getPassword())
                .typeClass("")
                .classId(targetRoom.getId())
                .build();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> httpEntity = new HttpEntity<>(joinRequest, headers);
        Optional<JoinRoomResponse> response = invokerService.postHeader(linkADB, httpEntity, JoinRoomResponse.class);

        if(!response.isPresent() || StringUtils.isEmpty(response.get().getLink())) {
            log.error("Vip Join room ADB error: {}", response.isPresent() ? response.get().getMessage() : "");
            return JoinRoomResponse.empty;
        }
        traceLogJoinRoomService.traceReJoinRoomAfterLongTime(user.getMdlUser().getId(),
                user.getServiceType().name(), targetRoom.getId(), false);
        response.get().setRoomId(targetRoom.getId());
        response.get().setVcrType(ADB);

        if(!useDeeplinkAdobe.get()) {
            return response.get();
        }

        String linkJoinRoomAdobe = response.get().getLink();
        String deepLink = AdobeUtil.getDeepLink(linkJoinRoomAdobe);
        if(!StringUtils.isEmpty(deepLink)) {
            response.get().setDeeplink(deepLink);
            response.get().setUseDeeplink(true);
        }
        return response.get();
    }

    @Override
    public void alertFullUser(SubjectType subjectType) {
        PortalMdlUser user = this.getUserSession();
        AlertVipRequest request = AlertVipRequest.builder()
                .userEmail(user.getMdlUser().getUsername())
                .levelUser(user.getLevel())
                .userId(user.getMdlUser().getId())
                .typeClass(subjectType.name())
                .build();
        this.alertService.sendToLMSVip(request);
    }
}