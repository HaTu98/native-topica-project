package com.topica.lmsvip.service;

import com.topica.adapter.common.dto.RoomUserCountDTO;

public interface MdlLogsserviceMoveUserService {
  RoomUserCountDTO getUserCountByRoomId(Long roomId);
}
