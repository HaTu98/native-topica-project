package com.topica.lmsvip.common;
import lombok.Getter;

@Getter
public enum TimeAv {
	DefaultTimeOpenBefore(15), DefaultTimeOpen(45);
	
	private long value;

	private TimeAv(long value) {
		this.value = value;
	}
	

}
