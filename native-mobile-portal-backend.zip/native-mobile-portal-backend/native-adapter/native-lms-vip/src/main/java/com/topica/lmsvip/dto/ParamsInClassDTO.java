package com.topica.lmsvip.dto;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class ParamsInClassDTO {
    @ApiModelProperty(value = "UserId")
    private Long userId;
    
    @ApiModelProperty(value = "type_class")
    private String typeClass;

}
