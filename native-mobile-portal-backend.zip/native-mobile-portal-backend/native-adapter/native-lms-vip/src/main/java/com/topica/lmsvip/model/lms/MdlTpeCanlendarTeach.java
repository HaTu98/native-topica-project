package com.topica.lmsvip.model.lms;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@AllArgsConstructor
@Data
@Entity
@EqualsAndHashCode(of = "id")
@NoArgsConstructor
@Table(name = "mdl_tpe_calendar_teach")
public class MdlTpeCanlendarTeach {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "hour_id")
    private Long hourId;

    @Column(name = "teacher_id")
    private Long teacherId;

    @Column(name = "calendar_code")
    private String calendarCode;
    
    @Column(name = "level_class")
    private String levelClass;
    
    @Column(name = "teacher_type")
    private String teacherType;
    
    @Column(name = "student_type")
    private String studentType;

    @Column(name = "type_class")
    private String typeClass;

    @Column(name = "subject_code")
    private String subjectCode;

    @Column(name = "status")
    private int status;
}
