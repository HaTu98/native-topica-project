package com.topica.lmsvip.handleException;

import com.topica.adapter.common.exception.AuthenticationException;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.exception.ErrorInfo;
import com.topica.adapter.common.exception.ExceptionCode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.text.MessageFormat;
import java.util.List;

@Slf4j
@ControllerAdvice
@RestController
public class HandleException {

	@ExceptionHandler(value = Exception.class)
	public ErrorInfo handleException(Exception e) {
		e.printStackTrace();
		return new ErrorInfo(ExceptionCode.ERROR_RUNTIME, HttpStatus.INTERNAL_SERVER_ERROR.value(), e.getMessage());
	}

	@ExceptionHandler(value = DataIntegrityViolationException.class)
	public ErrorInfo handleDataIntegrityViolationException(DataIntegrityViolationException e) {
		e.printStackTrace();
		return new ErrorInfo(ExceptionCode.ERROR_RUNTIME, HttpStatus.INTERNAL_SERVER_ERROR.value(), e.getMessage());
	}

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(value = MethodArgumentNotValidException.class)
	public ErrorInfo handleMethodArgumentNotValidException(MethodArgumentNotValidException e) {
		e.printStackTrace();
		StringBuilder msgBuider = new StringBuilder();
		List<FieldError> fieldErrors = e.getBindingResult().getFieldErrors();
		fieldErrors.forEach(item -> {
			String message = item.getDefaultMessage();
			if (item.getArguments().length > 1) {
				Object[] params = new Object[item.getArguments().length - 1];
				for (int i = 1; i < item.getArguments().length; i++) {
					params[i - 1] = item.getArguments()[i];
				}
				message = MessageFormat.format(message, params);
			}
			msgBuider.append(message).append(";");
		});
		return new ErrorInfo(ExceptionCode.BAD_REQUEST, HttpStatus.BAD_REQUEST.value(), msgBuider.toString());
	}

	@ExceptionHandler(value = BusinessException.class)
	public ErrorInfo handleValidBusinessException(BusinessException e) {
		log.error(e.getMessage());
		return new ErrorInfo(Integer.valueOf(e.getCode()), e.getMessage());
	}

	@ResponseStatus(HttpStatus.UNAUTHORIZED)
	@ExceptionHandler(value = AuthenticationException.class)
	public ErrorInfo handleValidAuthenticationException(AuthenticationException e) {
		log.error(e.getMessage());
		return new ErrorInfo(e.getCode(), HttpStatus.UNAUTHORIZED.value(), e.getMessage());
	}
}