package com.topica.lmsvip.repository;

import com.topica.lmsvip.model.lms.MdlUserData;
import com.topica.lmsvip.model.lms.MdlUserInfoData;
import com.topica.lmsvip.model.lms.UserInfoVip;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RestResource;

import java.util.List;
import java.util.Optional;


public interface MdlUserDataRepository extends JpaRepository<MdlUserData, Long> {

  @Query(value = "SELECT NEW com.topica.lmsvip.model.lms.UserInfoVip (u, r) " +
                  "FROM MdlUserData u " +
                  "left join MdlRoleAssignments a on u.id = a.userid " +
                  "left join MdlRole r on a.roleId = r.id " +
                  "WHERE u.id = :studentId")
  UserInfoVip findPersonalInfo(@Param("studentId") Long studentId);

  @Query(value = "SELECT u FROM MdlUserData u where u.id = :teacherId ")
  MdlUserData findOneById(@Param("teacherId") Long teacherId);

  @Query(value = "SELECT u FROM MdlUserData u where u.id in :userIds")
  @RestResource(exported = false)
  List<MdlUserData> findByIds(@Param("userIds") List<Long> userIds);

  @Query(value = "SELECT u FROM MdlUserData u where u.username in :usernames")
  List<MdlUserData> findByUserNames(@Param("usernames") List<String> usernames);

  @RestResource(exported = false)
  Optional<MdlUserData> findFirstByUsername(String username);

  @Query(value = "SELECT info.data "
      + "FROM MdlUserData user "
      + "JOIN MdlUserInfoData info "
      + " ON info.userid = user.id "
      + "WHERE info.fieldid = 90 "
      + " AND user.id = :userId")
  String getUserCountry(@Param("userId") Long userId);

  @Query(value = "SELECT info FROM MdlUserInfoData info WHERE info.userid = :userId and info.fieldid in :fieldIds")
  List<MdlUserInfoData> getInfoByUserid(@Param("userId") Long userId, @Param("fieldIds") List<Integer> fieldIds);

  @Query(value = "SELECT info.data FROM MdlUserInfoData info WHERE info.userid = :studentId and info.fieldid = 86")
  String getLevel(@Param("studentId") Long studentId);

  @Query(value = "SELECT info.data FROM MdlUserInfoData info WHERE info.userid = :userId and info.fieldid = 92")
  String getPackageParent(@Param("userId") Long userId);

  @Query(value = "SELECT map.functionCode " +
          "FROM VipMdlPackageMappingFunction map "
          + "INNER JOIN VipMdlGenFunction func ON func.status = 'ACTIVE' AND func.functionCode = map.functionCode "
          + "WHERE map.genCode = :genCode")
  List<String> getListFunction(@Param("genCode") String genCode);
}