package com.topica.lmsvip.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.topica.lmsvip.model.lms.MdlTpeCanlendarTeach;
import com.topica.lmsvip.repository.MdlTpeCanlendarTeachRepository;
import com.topica.lmsvip.service.MdlTpeCanlendarTeachService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MdlTpeCanlendarTeachServiceImpl implements MdlTpeCanlendarTeachService {
	
	@Autowired
	MdlTpeCanlendarTeachRepository mdlTpeCanlendarTeachRepository; 
	
	@Override
	public MdlTpeCanlendarTeach findById(Long id) {
		log.info("(findById) {}", id);
		return mdlTpeCanlendarTeachRepository.findById(id);
	}
	@Override
	public MdlTpeCanlendarTeach findByCalendarCode(String calendarCode) {
		return mdlTpeCanlendarTeachRepository.findByCalendarCode(calendarCode);
	}

}
