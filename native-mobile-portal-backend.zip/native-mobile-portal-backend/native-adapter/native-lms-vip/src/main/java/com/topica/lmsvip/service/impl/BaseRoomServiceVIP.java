package com.topica.lmsvip.service.impl;

import com.topica.adapter.common.config.room.MaxUserInRoom;
import com.topica.adapter.common.constant.LevelStudent;
import com.topica.adapter.common.constant.SubjectType;
import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.dto.RoomUserCountDTO;
import com.topica.adapter.common.service.BaseUserSessionService;
import com.topica.lmsvip.service.MdlLogsserviceMoveUserService;
import com.topica.lmsvip.service.user.UserVipService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.topica.adapter.common.constant.LevelStudent.sbasic;
import static com.topica.adapter.common.constant.ServiceType.LMS_VIP;
import static com.topica.adapter.common.constant.SubjectType.LS;
import static com.topica.adapter.common.constant.SubjectType.SC;
import static com.topica.adapter.common.constant.SubjectType.SN;

@Component
public class BaseRoomServiceVIP extends BaseUserSessionService {

    private @Autowired MdlLogsserviceMoveUserService moveUserService;
    private @Autowired UserVipService userVipService;
    private @Autowired MaxUserInRoom maxUserInRoom;

    public void updateRoomInfo(RoomDTO roomDTO, String userLevel) {
        roomDTO.setPackageType(LMS_VIP.name());
        this.setMaxJoin(roomDTO);
        this.setOpenStatus(roomDTO);
        this.countTotalUser(roomDTO);
        this.setTeacherInfo(roomDTO);
        this.changeTypeSC(roomDTO, userLevel);
    }

    public void changeTypeSC(RoomDTO room, String userLevel) {
        if(isRoomSN(room.getTypeClass(), userLevel)) {
            room.setTypeClass(SN.name());
        }
    }

    public void setOpenStatus(RoomDTO room) {
        if(room.getVcrClassId() != null) {
            room.setOpened(true);
        }
    }

    public void countTotalUser(RoomDTO room) {
        if(room.isOpened()) {
            RoomUserCountDTO userCount = moveUserService.getUserCountByRoomId(room.getId());
            if (userCount != null) {
                room.setTotalJoin(userCount.getTotalJoin());
            }
        }
    }

    public void setTeacherInfo(RoomDTO roomDTO) {
        if (roomDTO.getTeacherId() != null && roomDTO.getTeacherId() != 0) {
            roomDTO.setTeacherCountry(userVipService.getUserCountry(roomDTO.getTeacherId()));
        }
    }

    public void setMaxJoin(RoomDTO roomDTO) {
        if(this.isRoomSN(roomDTO.getTypeClass(), roomDTO.getLevelClass())) {
            roomDTO.setMaxJoin(maxUserInRoom.getMaxVipForRoomSN());
        } else {
            roomDTO.setMaxJoin(maxUserInRoom.getMaxVip());
        }
    }

    public boolean isRoomSN(String typeClass, String levelUser) {
        boolean isSBASIC = sbasic == LevelStudent.of(levelUser);
        boolean notLS = !LS.name().equalsIgnoreCase(typeClass);
        return  isSBASIC && notLS;
    }

    public int getMaxUserAllow(String levelClass, String classType) {
        if(sbasic == LevelStudent.of(levelClass)) {
            SubjectType type = SubjectType.valueOf(classType);
            if(type == SN || type == SC) {
                return this.maxUserInRoom.getMaxVipForRoomSN();
            }
        }
        return this.maxUserInRoom.getMaxVip();
    }
}
