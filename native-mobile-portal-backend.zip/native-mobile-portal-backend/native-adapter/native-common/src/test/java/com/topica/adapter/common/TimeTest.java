package com.topica.adapter.common;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Calendar;
import java.util.Date;

public class TimeTest {
//    @Test
    public void test() {
        this.getNextTime();
        this.getNextTime_2();
    }

    public void getNextTime() {
    LocalDate currentDate = LocalDate.now();
    LocalTime time = LocalTime.now();
    int hour = time.getHour(); // 15
    int minute = time.getMinute(); // 30

    if (minute >= 45) {
      hour = hour + 1;
    }

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    String dateString = currentDate + " " + hour + ":00:00";
    try {
      // formatting the dateString to convert it into a Date
      Date date = sdf.parse(dateString);
        System.out.println(date.getTime());

    } catch (Exception e) {
    }
    }

    public void getNextTime_2() {
        Calendar cal = Calendar.getInstance();
        int hour = cal.get(Calendar.HOUR_OF_DAY);
        int minute = cal.get(Calendar.MINUTE);

        if(minute >= 45) {
            hour++;
        }
        if(hour >= 23) {
            cal.add(Calendar.DAY_OF_YEAR, 1);
        }
        if(hour >= 23 || hour < 8) {
            hour = 8;
        }

        cal.set(Calendar.HOUR_OF_DAY, hour);
        cal.clear(Calendar.MINUTE);
        cal.clear(Calendar.SECOND);
        cal.clear(Calendar.MILLISECOND);
        System.out.println(cal.getTimeInMillis());
    }
}
