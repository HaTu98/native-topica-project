package com.topica.adapter.common.config.room;

import com.topica.portal.redis.constant.KeyConfig;
import com.topica.portal.redis.service.config.ConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class UseDeeplinkAdobe {

    @Autowired
    private ConfigService configService;

    public boolean get() {
        String config = this.configService.get(KeyConfig.USE_DEEPLINK_ADOBE_KEY);
        return Boolean.valueOf(config);
    }
}
