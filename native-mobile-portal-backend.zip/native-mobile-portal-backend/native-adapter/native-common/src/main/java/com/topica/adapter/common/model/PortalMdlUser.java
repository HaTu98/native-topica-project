package com.topica.adapter.common.model;

import com.topica.adapter.common.constant.ServiceType;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PortalMdlUser {
	private MdlUser mdlUser;
	private String email;
	private String level;
	private String packageParent;
	private String firstName;
	private String lastName;
	private ServiceType serviceType;
	private boolean activedPackage;
	private String role;
	private Long vcrxUserId;
}
