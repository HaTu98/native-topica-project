package com.topica.adapter.common.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PackageDetail {

  @JsonProperty("cat_code")
  private String cat_code;

  @JsonProperty("package_name")
  private String package_name;

  @JsonProperty("package_parent")
  private String package_parent;

  @JsonProperty("package_description")
  private String package_description;

  @JsonProperty("package_cost")
  private String package_cost;

  @JsonProperty("max_lock_account")
  private String max_lock_account;

  @JsonProperty("max_lock_day")
  private String max_lock_day;

  @JsonProperty("subscribe_cost")
  private String subscribe_cost;

  @JsonProperty("ls_cost")
  private String ls_cost;

  @JsonProperty("sc_cost")
  private String sc_cost;

  @JsonProperty("package_time")
  private String package_time;

  @JsonProperty("package_code")
  private String package_code;

  @JsonProperty("package_type")
  private String package_type;

  @JsonProperty("package_time_max")
  private String package_time_max;

  @JsonProperty("package_unit")
  private String package_unit;

  @JsonProperty("actual_cost")
  private String actual_cost;
}
