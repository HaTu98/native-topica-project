package com.topica.adapter.common.constant;

public enum PackageParent {
    TAAM, TENUP, DEMO, VIP
}
