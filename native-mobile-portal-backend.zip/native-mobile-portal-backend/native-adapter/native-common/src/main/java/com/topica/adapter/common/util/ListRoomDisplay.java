package com.topica.adapter.common.util;

import com.topica.adapter.common.config.room.TotalEmptyRoomDisplay;
import com.topica.adapter.common.constant.SubjectType;
import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.service.BaseUserSessionService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.ListUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import static com.topica.adapter.common.constant.SubjectType.LS;

@Slf4j
@Component
public class ListRoomDisplay extends BaseUserSessionService {

    public static final String TEACHER_IMD_DEFAULT = "https://s3-ap-southeast-1.amazonaws.com/nativeportal/99038_1558435518028_teacher_img_default.png";
    public static long ID_EXTEND_ROOM_LS = 0;
    public static long ID_EXTEND_ROOM_SC = 1;

    @Autowired
    private TotalEmptyRoomDisplay totalEmptyRoomDisplay;

    private Comparator<RoomDTO> comparator;

    public List<RoomDTO> show(List<RoomDTO> rooms, Comparator comparator) {
        if(CollectionUtils.isEmpty(rooms)) {
            return rooms;
        }
        this.comparator = comparator;

        List<RoomDTO> hasUserRooms = this.getRoomNotEmpty(rooms);
        List<RoomDTO> emptyRooms = this.showRoomEmpty(rooms, hasUserRooms);
        List<RoomDTO> combineRooms = ListUtils.union(hasUserRooms, emptyRooms);

        if(!CollectionUtils.isEmpty(emptyRooms) || combineRooms.size() < rooms.size()) {
            combineRooms.add(this.createExtendRoom(rooms.get(0)));
        }
        return combineRooms;
    }

    private List<RoomDTO> showRoomEmpty(List<RoomDTO> rooms, List<RoomDTO> notEmptyRooms) {
        long maxJoinInRoom = rooms.get(0).getMaxJoin();
        long slotToShow = this.getSlotToShow(rooms.size(), maxJoinInRoom);

        long slotsShowing = this.getSlotShowing(notEmptyRooms, maxJoinInRoom);
        if(slotsShowing >= slotToShow) {
            return Collections.emptyList();
        }

        long slotNeedToShow = slotToShow - slotsShowing;
        long roomNeedToShowFinal = this.getTotalRoomNeedShow(slotNeedToShow, maxJoinInRoom);
        return this.getEmptyRoomToShow(rooms, roomNeedToShowFinal);
    }

    private long getSlotToShow(int roomSize, long maxJoinInRoom) {
        int maxEmptyRoom = this.totalEmptyRoomDisplay.getMax();
        float percentEmptyRoom = this.totalEmptyRoomDisplay.get();
        long roomNeedShow = Math.round(percentEmptyRoom / 100 * roomSize);
        roomNeedShow = roomNeedShow < maxEmptyRoom ? roomNeedShow : maxEmptyRoom;
        long slotToShow = roomNeedShow * maxJoinInRoom;
        return slotToShow;
    }

    private long getSlotShowing(List<RoomDTO> notEmptyRooms, long maxJoin) {
        long totalUserJoined = notEmptyRooms.stream()
                .map(r -> r.getTotalJoin())
                .collect(Collectors.summingInt(Long::intValue));
        return notEmptyRooms.size() * maxJoin - totalUserJoined;
    }

    private long getTotalRoomNeedShow(long slotNeedToShow, long maxJoinInRoom) {
        long totalRoomNeedShow = slotNeedToShow / maxJoinInRoom;
        long pivot = maxJoinInRoom / 2;
        return slotNeedToShow % maxJoinInRoom >= pivot ? totalRoomNeedShow + 1 : totalRoomNeedShow;
    }

    private List<RoomDTO> getRoomNotEmpty(List<RoomDTO> rooms) {
        return rooms.parallelStream()
                .filter(r -> r.getTotalJoin() > 0)
                .sorted(this.comparator)
                .collect(Collectors.toList());
    }

    private List<RoomDTO> getEmptyRoomToShow(List<RoomDTO> rooms, long roomNeedToShow) {
        List<RoomDTO> totalEmptyRooms = rooms.parallelStream()
                .filter(room -> room.getTotalJoin() == 0)
                .sorted(this.comparator)
                .collect(Collectors.toList());

        List<RoomDTO> results = Collections.emptyList();
        if(roomNeedToShow >= totalEmptyRooms.size()) {
            results = totalEmptyRooms;
        } else {
            results = totalEmptyRooms.subList(0, (int) roomNeedToShow);
        }

        if(!this.isTimeToFillUser()) {
            return results;
        }
        results.parallelStream().forEach(r -> r.setTotalJoin(r.getMaxJoin()));
        return results;
    }

    private boolean isTimeToFillUser() {
        return RoomUtil.remainTimeToNextHour() < 60 * 10;
    }

    private RoomDTO createExtendRoom(RoomDTO roomPrototype) {
        SubjectType subjectType = SubjectType.valueOf(roomPrototype.getTypeClass());
        return new RoomDTO().builder()
                .id(subjectType == LS ? ID_EXTEND_ROOM_LS : ID_EXTEND_ROOM_SC)
                .typeClass(subjectType.name())
                .vcrType(RoomDTO.EXTEND)
                .isOpened(true)
                .totalJoin(0)
                .teacherFirstName("Lớp kế hoạch")
                .teacherLastName("- Plan Class")
                .teacherCountry(" ")
                .teacherAvatar(TEACHER_IMD_DEFAULT)
                .maxJoin(roomPrototype.getMaxJoin())
                .build();
    }
}