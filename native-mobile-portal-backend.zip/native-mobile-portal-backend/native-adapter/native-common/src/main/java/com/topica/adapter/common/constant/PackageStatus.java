package com.topica.adapter.common.constant;

public enum PackageStatus {
  ACTIVED,CANCELLED,DEACTIVED,EXPIRED,SUSPENDED
}
