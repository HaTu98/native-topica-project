package com.topica.adapter.common.repository.portal;

import com.topica.adapter.common.model.portal.LearningGoalLevel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LearningGoalLevelRepository extends JpaRepository<LearningGoalLevel, Long> {
    List<LearningGoalLevel> findAll();
}
