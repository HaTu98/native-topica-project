package com.topica.adapter.common.service.rating;

import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.model.cara.CaraResponse;
import com.topica.adapter.common.request.CaraRequest;

import java.util.Optional;

public interface RatingServicePortal {
    Optional<CaraResponse> canRate() throws BusinessException;
    Optional<CaraResponse> rating(CaraRequest request) throws BusinessException;
}
