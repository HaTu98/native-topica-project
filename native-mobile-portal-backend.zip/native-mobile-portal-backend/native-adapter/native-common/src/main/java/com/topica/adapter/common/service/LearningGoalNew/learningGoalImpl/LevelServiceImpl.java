package com.topica.adapter.common.service.LearningGoalNew.learningGoalImpl;

import com.topica.adapter.common.model.portal.LearningGoalLevel;
import com.topica.adapter.common.repository.portal.LearningGoalLevelRepository;
import com.topica.adapter.common.service.LearningGoalNew.LearningGoalLevelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LevelServiceImpl implements LearningGoalLevelService {
    @Autowired
    private LearningGoalLevelRepository learningGoalLevelRepository;

    @Override
    public List<LearningGoalLevel> getAllLevel() {
        return learningGoalLevelRepository.findAll();
    }
}
