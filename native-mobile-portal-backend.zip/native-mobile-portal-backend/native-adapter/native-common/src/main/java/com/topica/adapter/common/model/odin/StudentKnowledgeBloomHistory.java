package com.topica.adapter.common.model.odin;

import lombok.*;
import lombok.extern.slf4j.Slf4j;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Builder
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "student_knowledge_bloom_history")
public class StudentKnowledgeBloomHistory {
  @Id
  @Column(name = "id")
  private Long id;

  @Column(name = "student_id")
  private Long studentId;

  @Column(name = "user_id")
  private Long userId;

  @Column(name = "bloom_point")
  private Long bloomPoint;

  @Column(name = "created_date_id")
  private Long createdDateId;
}
