package com.topica.adapter.common.model.portal;

import com.topica.adapter.common.request.LoginRequest;
import com.topica.adapter.common.dto.PersonalInfoDTO;
import lombok.*;

import javax.persistence.*;
import java.util.Calendar;
import java.util.Date;

@Data
@Builder
@Entity
@Table(name = "signin_history")
public class SigninHistory {

    public static final String LOG_IN = "LOGIN";
    public static final String RESUM = "RESUM";
    public static final String LOG_OUT = "LOGOUT";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "userid")
    private Long userid;

    @Column(name = "username")
    private String username;

    @Column(name = "action")
    private String action;

    @Column(name = "time")
    private Date time;

    @Column(name = "device")
    private String device;

    @Column(name = "appversion")
    private String appVersion;

    @Column(name = "deviceid")
    private String deviceId;

    @Column(name = "os")
    private String os;

    @Column(name = "service_type")
    private String serviceType;

    public static SigninHistory from(LoginRequest request, PersonalInfoDTO userInfo, String action) {
        return SigninHistory.builder()
                .userid(userInfo.getId())
                .username(userInfo.getUserName())
                .action(action)
                .time(Calendar.getInstance().getTime())
                .device(request.getDevice())
                .appVersion(request.getAppVersion())
                .deviceId(request.getDeviceId())
                .os(request.getOperatingSystem())
                .serviceType(request.getServiceType().toString())
                .build();
    }

}
