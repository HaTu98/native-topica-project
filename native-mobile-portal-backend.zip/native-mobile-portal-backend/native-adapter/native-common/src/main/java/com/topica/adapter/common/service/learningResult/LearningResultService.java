package com.topica.adapter.common.service.learningResult;

import com.topica.adapter.common.dto.request.TotalLearningObjectRequest;
import com.topica.adapter.common.dto.response.PronounceDetailHistory;
import com.topica.adapter.common.dto.response.TotalLearningObject;
import com.topica.adapter.common.dto.response.UserLearningObjectDetail;

import java.util.List;
import java.util.Map;

public interface LearningResultService {

  Map<String, Long> getUsedPointOfUser(Long userId);

  PronounceDetailHistory getTopPronounceHistory(Long userId);

  List<TotalLearningObject> getRealTotalLearningObject(TotalLearningObjectRequest totalLearningObjectRequest);

  List<TotalLearningObject> getDesireTotalLearningObject(TotalLearningObjectRequest totalLearningObjectRequest);
}
