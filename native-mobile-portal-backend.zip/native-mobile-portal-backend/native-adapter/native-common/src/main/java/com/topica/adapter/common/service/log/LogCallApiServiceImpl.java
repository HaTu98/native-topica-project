package com.topica.adapter.common.service.log;

import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.model.portal.LogCallApi;
import com.topica.adapter.common.repository.portal.LogCallApiRepository;
import com.topica.adapter.common.service.BaseUserSessionService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringEscapeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

@Slf4j
@Service
public class LogCallApiServiceImpl extends BaseUserSessionService implements LogCallApiService {

    private final Executor executor = Executors.newFixedThreadPool(3);
    @Autowired
    private LogCallApiRepository repository;

    @Override
    public void save(LogCallApi logApi) {
        try {
            PortalMdlUser user = this.getUserSession();
            logApi.setUserName(user.getMdlUser().getUsername());
        } catch (Exception e) {}

        this.executor.execute(() -> {
            logApi.setResponse(StringEscapeUtils.escapeJava(logApi.getResponse()));
            logApi.setUrl(StringEscapeUtils.escapeJava(logApi.getUrl()));
            this.repository.save(logApi);
        });
    }
}
