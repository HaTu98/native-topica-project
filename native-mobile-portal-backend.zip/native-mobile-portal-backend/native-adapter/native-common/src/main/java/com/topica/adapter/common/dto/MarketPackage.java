package com.topica.adapter.common.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.topica.adapter.common.constant.PackageStatus;
import com.topica.adapter.common.dto.response.PackageDetail;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MarketPackage {

  @JsonProperty("id")
  private Long id;

  @JsonProperty("contact_id")
  private String contactId;

  @JsonProperty("product_id")
  private Long productId;

  @JsonProperty("usetime")
  private Long useTime;

  @JsonProperty("starttime")
  private Long startTime;

  @JsonProperty("endtime")
  private Long endTime;

  @JsonProperty("endtime_tc")
  private Long endTimeTc;

  @JsonProperty("balance_used")
  private Long balanceUsed;

  @JsonProperty("status_code")
  private String statusCode;

  @JsonProperty("status")
  private PackageStatus status;

  @JsonProperty("timecreated")
  private Long timeCreated;

  @JsonProperty("timemodified")
  private Long timeModified;

  @JsonProperty("cat_code")
  private String catCode;

  @JsonProperty("invoice_code")
  private String invoiceCode;

  @JsonProperty("package_cost")
  private Long packageCost;

  @JsonProperty("subscribe_cost")
  private Long subscribeCost;

  @JsonProperty("ls_cost")
  private Long lsCost;

  @JsonProperty("sc_cost")
  private Long scCost;

  @JsonProperty("package_attrs")
  private String packageAttrs;

  @JsonProperty("enduser_email")
  private String endUserEmail;

  @JsonProperty("course_id")
  private Long courseId;

  @JsonProperty("enduser_name")
  private String endUserName;

  @JsonProperty("tvts_username")
  private String tvtsUserName;

  @JsonProperty("tvts_name")
  private String tvtsName;

  @JsonProperty("gen_code")
  private String genCode;

  public PackageDetail getPackageDetail(){
    if(this.packageAttrs == null){
       return null;
    }
    Gson gson = new Gson();
    JsonParser parser = new JsonParser();
    JsonElement packageJson = parser.parse(this.packageAttrs);
    PackageDetail packageDetail = gson.fromJson(packageJson,PackageDetail.class);
    return packageDetail;
  }
}
