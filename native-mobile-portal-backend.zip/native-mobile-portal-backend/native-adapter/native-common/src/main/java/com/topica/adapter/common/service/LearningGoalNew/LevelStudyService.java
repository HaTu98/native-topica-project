package com.topica.adapter.common.service.LearningGoalNew;

import com.topica.adapter.common.model.portal.LevelStudy;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.logging.Level;

@Service
public interface LevelStudyService {
    List<LevelStudy> getAllLevelUser();
    LevelStudy getLevelValue(String content);
    LevelStudy getLevelContent(String value);
}
