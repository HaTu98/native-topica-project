package com.topica.adapter.common.model.portal;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Data
@NoArgsConstructor
@Entity
@Table(name = "social_mapping")
@IdClass(SocialMappingId.class)
public class SocialMapping {
    @Id
    @Column(name = "user_id")
    private Long userId;

    @Id
    @Column(name = "service_type")
    private String serviceType;

    @Id
    @Column(name = "social_type")
    private String socialType;

    @Id
    @Column(name = "social_id")
    private String socialId;

    @Basic
    @Column(name = "status")
    private String status;

    @Column(name = "created_date")
    @CreationTimestamp
    private Timestamp createdDate;

    @Override
    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;
        SocialMapping that = (SocialMapping) object;
        return userId == that.userId &&
                Objects.equals(serviceType, that.serviceType) &&
                Objects.equals(socialType, that.socialType) &&
                Objects.equals(socialId, that.socialId) &&
                Objects.equals(status, that.status);
    }

    @Override
    public int hashCode() {
        return Objects.hash(userId, serviceType, socialType, socialId, status);
    }
}
