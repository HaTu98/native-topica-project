package com.topica.adapter.common.service.log;

import com.topica.adapter.common.dto.ExternalLog;

public interface ExternalLogService {
    <T extends ExternalLog> T  save(T externalLog);
}
