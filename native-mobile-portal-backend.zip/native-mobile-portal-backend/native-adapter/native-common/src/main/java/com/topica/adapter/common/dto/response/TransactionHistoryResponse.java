package com.topica.adapter.common.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransactionHistoryResponse {

  private Boolean status;

  @JsonProperty("status_code")
  private String statusCode;

  private String msg;

  private int total;

  private List<TransactionHistory> data;

}
