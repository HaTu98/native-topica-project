package com.topica.adapter.common.model.odin;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Builder
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "student_phonetic_number_history")
public class StudentPhoneticNumberHistory {
  @Id
  @Column(name = "id")
  private Long id;

  @Column(name = "user_id")
  private Long userId;

  @Column(name = "student_id")
  private Long studentId;

  @Column(name = "learning_object_id")
  private Long learningObjectId;

  @Column(name = "learning_object_number")
  private Long learningObjectNumber;

  @Column(name = "learning_last_date_id")
  private Long learningLastDateId;

  @Column(name = "number_type")
  private int numberType;

  @Column(name = "created_date_id")
  private Long createdDateId;

  @ManyToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "learning_object_id", updatable = false, insertable = false)
  private LearningObject learningObject;
}
