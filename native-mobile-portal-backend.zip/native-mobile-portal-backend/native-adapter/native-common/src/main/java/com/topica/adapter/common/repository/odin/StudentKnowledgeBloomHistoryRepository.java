package com.topica.adapter.common.repository.odin;

import com.topica.adapter.common.model.odin.StudentKnowledgeBloomHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentKnowledgeBloomHistoryRepository extends JpaRepository<StudentKnowledgeBloomHistory, Long> {
  @Query(value = "SELECT SUM (skbh.bloomPoint) from StudentKnowledgeBloomHistory skbh where skbh.studentId = :studentId and skbh.createdDateId = :createdDateId")
  Long sumBloomPointByStudentId(@Param("studentId") Long studentId, @Param("createdDateId") Long createdDateId);
}
