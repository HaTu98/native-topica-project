package com.topica.adapter.common.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class LearningGoalData {
    private Long studentLevelId;
    private String studentLevelName;
    private LearningObjects learningObjects;
}
