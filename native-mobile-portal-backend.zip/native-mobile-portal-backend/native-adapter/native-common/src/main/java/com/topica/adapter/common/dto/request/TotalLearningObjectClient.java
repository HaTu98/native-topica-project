package com.topica.adapter.common.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TotalLearningObjectClient {
  private long startTime;
  private long endTime;
  private String timeType;
  private String learningObjectType;
}
