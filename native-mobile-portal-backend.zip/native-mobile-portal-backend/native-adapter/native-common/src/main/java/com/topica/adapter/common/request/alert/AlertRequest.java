package com.topica.adapter.common.request.alert;

public interface AlertRequest {
    Object getContent();
}