package com.topica.adapter.common.request;

import com.topica.adapter.common.constant.ServiceType;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LoginRequest {

    public static LoginRequest empty = new LoginRequest();

	@ApiModelProperty(value = "username")
    private String username;

    @ApiModelProperty(value = "password")
    private String password;

    @ApiModelProperty(value = "ServiceType")
    private ServiceType serviceType;

    @ApiModelProperty(value = "device")
    private String device;
    @ApiModelProperty(value = "appVersion")
    private String appVersion;
    @ApiModelProperty(value = "deviceId")
    private String deviceId;
    @ApiModelProperty(value = "operatingSystem")
    private String operatingSystem;
    @ApiModelProperty(value = "deviceToken")
    private String deviceToken;

    @Override
    public String toString() {
        return "LoginRequest{" +
                "username='" + username + '\'' +
                ", serviceType=" + serviceType +
                ", device='" + device + '\'' +
                ", appVersion='" + appVersion + '\'' +
                ", deviceId='" + deviceId + '\'' +
                ", operatingSystem='" + operatingSystem + '\'' +
                ", deviceToken='" + deviceToken + '\'' +
                '}';
    }

    public void setUsername(String username) {
        this.username = (username != null) ? username.toLowerCase() : null;
    }
}
