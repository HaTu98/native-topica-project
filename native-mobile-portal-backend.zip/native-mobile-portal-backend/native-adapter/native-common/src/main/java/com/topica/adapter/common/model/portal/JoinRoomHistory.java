package com.topica.adapter.common.model.portal;

import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.dto.response.JoinRoomResponse;
import com.topica.adapter.common.dto.response.JoinRoomVCRXRespose;
import com.topica.adapter.common.util.AdobeUtil;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

import javax.persistence.*;
import java.util.Calendar;
import java.util.Date;

import static com.topica.adapter.common.constant.RoleInClass.NORMAL;
import static com.topica.adapter.common.constant.ServiceType.LMS;

@Data
@Slf4j
@Builder
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "join_room_history")
public class JoinRoomHistory {

    public static final long SESSION_ADB_EXPIRED = 30 * 60;

    public enum Type {
        SELECT, AUTO, REJOIN
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="user_id", nullable = false)
    private Long userId;

    @Column(name="service_type", nullable = false)
    private String serviceType ;

    @Column(name="room_id", nullable = false)
    private Long roomId;

    @Column(name="vcr_type", nullable = false)
    private String vcrType;

    @Column(name="extenal_room_id")
    private Long extenalRoomId;

    @Column(name="time_available", nullable = false)
    private Long timeAvailable;

    @Column(name="link")
    private String link;

    @Column(name="deeplink")
    private String deepLink;

    @Column(name="created_time")
    private Date createdTime;

    @Column(name="join_type")
    private String joinType;

    @Column(name="role")
    private String role;

    @Column(name="ticket_id")
    private Long ticketId;

    @Column(name="session_time")
    private Long sessionCreatedTime;

    @PrePersist
    protected void onCreate() {
        this.createdTime = Calendar.getInstance().getTime();
    }

    public JoinRoomResponse toResponse() {
        switch (this.vcrType){
            case RoomDTO.VCRX: return this.toResponseJoinVCRX();
            case RoomDTO.ADB: return this.toResponseJoinADB();
            case RoomDTO.BBB: return this.toResponseJoinBBB();
            default: return null;
        }
    }

    private JoinRoomResponse toResponseJoinBBB() {
        // BBB need to refresh
        return null;
//        return JoinRoomResponse.builder()
//                .link(this.link)
//                .vcrType(RoomDTO.BBB)
//                .roomId(this.roomId)
//                .ticketId(this.ticketId)
//                .role(StringUtils.isEmpty(this.role) ? NORMAL.name() : this.role)
//                .build();
    }

    private JoinRoomResponse toResponseJoinVCRX() {
        return JoinRoomResponse.builder()
                .link(this.link)
                .data(JoinRoomVCRXRespose.Result.builder()
                        .classId(this.roomId)
                        .classIdVcrx(this.extenalRoomId)
                        .timeAvailable(this.timeAvailable)
                        .status(true)
                        .build())
                .vcrType(this.vcrType)
                .roomId(this.roomId)
                .ticketId(this.ticketId)
                .role(StringUtils.isEmpty(this.role) ? NORMAL.name() : this.role)
                .build();
    }

    private JoinRoomResponse toResponseJoinADB() {
        if(this.isAdobeSessionExpired()) {
            log.info("ADB session expired: room {} - session: {}", this.roomId, this.sessionCreatedTime);
            return null;
        }
        String newDeeplink = "";
        if(LMS.name().equals(this.serviceType)) {
            newDeeplink = AdobeUtil.getDeepLink(this.link);
        }
        return JoinRoomResponse.builder()
                .link(this.link)
                .deeplink(newDeeplink)
                .useDeeplink(StringUtils.isEmpty(newDeeplink) ? false: true)
                .vcrType(RoomDTO.ADB)
                .roomId(this.roomId)
                .ticketId(this.ticketId)
                .role(StringUtils.isEmpty(this.role) ? NORMAL.name() : this.role)
                .build();
    }

    private boolean isAdobeSessionExpired() {
        if(this.sessionCreatedTime == null) return true;
        return (System.currentTimeMillis()/1000 - this.sessionCreatedTime) > SESSION_ADB_EXPIRED;
    }
}