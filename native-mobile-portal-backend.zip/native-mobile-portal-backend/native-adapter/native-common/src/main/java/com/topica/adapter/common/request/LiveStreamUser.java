package com.topica.adapter.common.request;

import com.topica.adapter.common.constant.RoleType;
import com.topica.adapter.common.constant.ServiceType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Data
@NoArgsConstructor
public class LiveStreamUser {
  private String userId;
  private String userName;
  private RoleType role;
  private ServiceType type;
  private String level;
}
