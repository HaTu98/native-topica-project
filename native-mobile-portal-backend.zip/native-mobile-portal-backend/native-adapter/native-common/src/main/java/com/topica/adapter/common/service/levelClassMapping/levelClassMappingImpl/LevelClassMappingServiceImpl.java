package com.topica.adapter.common.service.levelClassMapping.levelClassMappingImpl;

import com.topica.adapter.common.model.portal.LevelClassMapping;
import com.topica.adapter.common.repository.portal.LevelClassMappingRepository;
import com.topica.adapter.common.request.LevelClassMappingRequest;
import com.topica.adapter.common.service.BaseUserSessionService;
import com.topica.adapter.common.service.levelClassMapping.LevelClassMappingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;

@Service
public class LevelClassMappingServiceImpl extends BaseUserSessionService implements LevelClassMappingService {
    @Autowired
    private LevelClassMappingRepository levelClassMappingRepository;

    @Override
    public LevelClassMapping getLevelClass(LevelClassMappingRequest request) {
        List<LevelClassMapping> result = levelClassMappingRepository.findByPackageParentAndTypeClassAndLevelUser(request.getPackageParent(), request.getTypeClass(), request.getLevelUser());
        if (CollectionUtils.isEmpty(result)) {
            return null;
        }
        return result.get(0);
    }

    @Override
    public void save(LevelClassMappingRequest request) {
        LevelClassMapping levelClassMapping = getLevelClass(request);
        if (levelClassMapping == null) {
            levelClassMapping = new LevelClassMapping();
            levelClassMapping.setTypeClass(request.getTypeClass());
            levelClassMapping.setLevelUser(request.getLevelUser());
            levelClassMapping.setPackageParent(request.getPackageParent());
        }
        levelClassMapping.setLevelClass(request.getLevelClass());

        levelClassMappingRepository.save(levelClassMapping);
    }

    @Override
    public void delete(LevelClassMappingRequest request) {
        LevelClassMapping levelClassMapping = getLevelClass(request);
        if (levelClassMapping != null) {
            levelClassMappingRepository.delete(levelClassMapping);
        }
    }
}
