package com.topica.adapter.common.service.material;

import com.topica.adapter.common.constant.SubjectType;
import com.topica.adapter.common.dto.material.MaterialDTO;
import com.topica.adapter.common.exception.BusinessException;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import static com.topica.adapter.common.constant.PackageParent.TENUP;
import static com.topica.adapter.common.constant.TeacherType.*;

public interface MaterialService {
    Map<SubjectType, List<MaterialDTO>> get(long start, long end, String levelClass, String packageCode) throws BusinessException;

    default List<String> getTeacherType(String packageCode) {
        List<String> teacherTypes = new LinkedList<>();
        teacherTypes.add(VN.name());

        if (packageCode.contains(TENUP.name())) {
            teacherTypes.add(PHI.name());
        } else {
            teacherTypes.add(AM.name());
        }
        return teacherTypes;
    }
}