package com.topica.adapter.common.constant;

import com.topica.adapter.common.exception.BusinessException;
import org.springframework.http.HttpStatus;

public enum LevelClass {
    BO,
    B1O,
    B23O,
    IO,
    SBO;

    public static LevelClass levelOf(String levelStudent) throws BusinessException {
        switch (levelStudent) {
            case "sbasic": return SBO;
            case "basic": return BO;
            case "basic1": return B1O;
            case "basic23": return B23O;
            case "inter": return IO;
            default: throw new BusinessException(HttpStatus.NO_CONTENT.value(), "Not found level class for: " + levelStudent);
        }
    }

    public static LevelClass levelOf(LevelStudent levelStudent) throws BusinessException {
        switch (levelStudent) {
            case sbasic: return SBO;
            case basic: return BO;
            case basic1: return B1O;
            case basic23: return B23O;
            case inter: return IO;
            default: throw new BusinessException(HttpStatus.NO_CONTENT.value(), "Not found level class for: " + levelStudent.toString());
        }
    }

}
