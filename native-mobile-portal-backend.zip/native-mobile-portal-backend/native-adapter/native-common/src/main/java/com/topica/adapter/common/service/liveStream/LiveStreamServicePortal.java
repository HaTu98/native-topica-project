package com.topica.adapter.common.service.liveStream;

import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.model.cara.CaraResponse;
import com.topica.adapter.common.request.CaraRequest;

import java.util.Optional;

public interface LiveStreamServicePortal {
  ApiDataResponse getListClassStreaming();

  ApiDataResponse getListClassPast(int page, int size, String sort);

  ApiDataResponse searchClassPastByName(int page, int size, String name, String sort);

  ApiDataResponse increaseViewClassPast(String roomId, Long calendarTeachId);

  ApiDataResponse getListClassFuture(int page, int size);

  ApiDataResponse joinRoom(String roomId);

  String getPublicToken ();

  Optional<CaraResponse> rating(CaraRequest request) throws BusinessException;
}
