package com.topica.adapter.common.model.portal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Calendar;
import java.util.Date;
import java.util.Objects;

@Entity
@Table(name = "log_call_api")
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class LogCallApi {
    private int id;
    private String method;
    private String url;
    private String response;

    private Date createdTime;
    private long duration;
    private String status;
    private String userName;
    private String request;

    @PrePersist
    protected void onCreate() {
        this.createdTime = Calendar.getInstance().getTime();
    }

    @Id
    @Column(name = "id", nullable = false)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "method", nullable = true, length = 10)
    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    @Basic
    @Column(name = "url", nullable = true, length = -1)
    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Basic
    @Column(name = "response", nullable = true, length = -1)
    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    @Basic
    @Column(name = "created_time", nullable = true)
    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    @Basic
    @Column(name = "duration", nullable = true)
    public long getDuration() {
        return duration;
    }

    public void setDuration(long duration) {
        this.duration = duration;
    }

    @Basic
    @Column(name = "status", nullable = true, length = 10)
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Basic
    @Column(name = "user_name", nullable = true, length = 100)
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    @Basic
    @Column(name = "request", nullable = true, length = 300)
    public String getRequest() {
        return request;
    }

    public void setRequest(String request) {
        this.request = request;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LogCallApi that = (LogCallApi) o;
        return id == that.id &&
                Objects.equals(method, that.method) &&
                Objects.equals(url, that.url) &&
                Objects.equals(response, that.response) &&
                Objects.equals(createdTime, that.createdTime) &&
                Objects.equals(duration, that.duration) &&
                Objects.equals(status, that.status) &&
                Objects.equals(userName, that.userName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, method, url, response, createdTime, duration, status, userName);
    }

    @Override
    public String toString() {
        return "LogCallApi{" +
                "id=" + id +
                ", method='" + method + '\'' +
                ", url='" + url + '\'' +
                ", response='" + response + '\'' +
                ", createdTime=" + createdTime +
                ", duration=" + duration +
                ", status='" + status + '\'' +
                ", userName='" + userName + '\'' +
                '}';
    }
}
