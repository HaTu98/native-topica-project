package com.topica.adapter.common.constant;

import com.topica.adapter.common.exception.BusinessException;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;

@Getter
@AllArgsConstructor
@Slf4j
public enum GoalLevel {
    STARTER("Starter",1,"starter"),
    SUPER_BASIC("Super Basic",2,"sbasic"),
    BASIC_100("Basic 100",3,"basic100"),
    BASIC_200("Basic 200",4,"basic200"),
    BASIC_300("Basic 300",5, "basic300"),
    INTERMEDIATE_100("Intermediate 100",6,"inter100"),
    INTERMEDIATE_200("Intermediate 200",7,"inter200"),
    INTERMEDIATE_300("Intermediate 300",8,"inter300"),
    ADVANCED("Advanced",9,"advan");

    private final String level;
    private final Integer value;
    private final String code;

    public static GoalLevel fromStringValue(String code) {
        switch (code){
            case "starter" : return STARTER;
            case "sbasic" : return SUPER_BASIC;
            case "basic100" : return BASIC_100;
            case "basic200" : return BASIC_200;
            case "basic300" : return BASIC_300;
            case "inter100" : return INTERMEDIATE_100;
            case "inter200" : return INTERMEDIATE_200;
            case "inter300" : return INTERMEDIATE_300;
            case "advan" : return ADVANCED;
            default:
                log.error("Unexpected value: {}", code);
                return STARTER;
        }
    }

    public static GoalLevel fromInteger(Integer value) {
        switch (value){
            case 1 : return STARTER;
            case 2 : return SUPER_BASIC;
            case 3 : return BASIC_100;
            case 4 : return BASIC_200;
            case 5 : return BASIC_300;
            case 6 : return INTERMEDIATE_100;
            case 7 : return INTERMEDIATE_200;
            case 8 : return INTERMEDIATE_300;
            case 9 : return ADVANCED;
            default:
                log.error("Unexpected value: " + value);
                return STARTER;
        }
    }

    public static GoalLevel fromStringLevel(String level) {
        switch (level){
            case "Starter" : return STARTER;
            case "Super Basic" : return SUPER_BASIC;
            case "Basic 100" : return BASIC_100;
            case "Basic 200" : return BASIC_200;
            case "Basic 300" : return BASIC_300;
            case "Intermediate 100" : return INTERMEDIATE_100;
            case "Intermediate 200" : return INTERMEDIATE_200;
            case "Intermediate 300" : return INTERMEDIATE_300;
            case "Advanced" : return ADVANCED;
            default:
                log.error("Unexpected value: " + level);
                return STARTER;
        }
    }
}
