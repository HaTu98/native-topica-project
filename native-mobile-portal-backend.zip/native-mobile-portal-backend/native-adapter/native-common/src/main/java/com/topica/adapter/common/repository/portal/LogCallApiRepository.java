package com.topica.adapter.common.repository.portal;

import com.topica.adapter.common.model.portal.LogCallApi;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LogCallApiRepository extends JpaRepository<LogCallApi, Long> {
}
