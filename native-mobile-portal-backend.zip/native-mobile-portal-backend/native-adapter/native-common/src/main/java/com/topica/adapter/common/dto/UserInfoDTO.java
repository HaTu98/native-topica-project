package com.topica.adapter.common.dto;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class UserInfoDTO {
    @ApiModelProperty(value = "USER ID")
    private Long userID;

    @ApiModelProperty(value = "USER VCRX ID tag for join room VCRX")
    private Long vcrxuserid;
    
    @ApiModelProperty(value = "First name")
    private String firstName;
    
    @ApiModelProperty(value = "Last name")
    private String lastName;
    
    @ApiModelProperty(value = "Email")
    private String email;
    
    @ApiModelProperty(value = "Phone")
    private String phone1;
    
    @ApiModelProperty(value = "userlv select from data of mdl_user_info_data")
    private String userlv;
    
}
