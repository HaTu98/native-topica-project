package com.topica.adapter.common.service.alert;

import com.topica.adapter.common.request.alert.AlertRequest;

public interface AlertService {
    void sendToLMS(AlertRequest request);
    void sendToLMSVip(AlertRequest request);
}
