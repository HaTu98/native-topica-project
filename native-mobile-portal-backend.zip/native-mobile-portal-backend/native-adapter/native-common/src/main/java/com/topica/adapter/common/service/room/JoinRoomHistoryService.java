package com.topica.adapter.common.service.room;

import com.topica.adapter.common.dto.response.JoinRoomResponse;
import com.topica.adapter.common.model.portal.JoinRoomHistory;

import java.util.Optional;

public interface JoinRoomHistoryService {
    void save(JoinRoomHistory joinRoom);
    void save(JoinRoomResponse joinRoomResponse, JoinRoomHistory.Type joinType);
    Optional<JoinRoomHistory> getByTime(Long timeAvailable);
}
