package com.topica.adapter.common.service.LearningGoalNew;

import com.topica.adapter.common.model.portal.LearningGoalOptionSelect;

import java.util.List;

public interface LearningGoalOptionSelectService {
    void saveAll(List<LearningGoalOptionSelect> data);
    List<LearningGoalOptionSelect> getUserSelect(Long studentId);
    List<LearningGoalOptionSelect> getUserInfo(Long studentId, List<Long> optionId);
    List<LearningGoalOptionSelect> saveUserInfo(Long studentId, List<LearningGoalOptionSelect> newInfo);
   Boolean saveUserGoal(Long studentId, List<LearningGoalOptionSelect> newInfo);
}
