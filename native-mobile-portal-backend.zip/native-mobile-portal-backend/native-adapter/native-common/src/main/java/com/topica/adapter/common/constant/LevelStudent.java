package com.topica.adapter.common.constant;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public enum LevelStudent {
    starter ,sbasic, basic, basic1, basic23, inter, advan;

    public static LevelStudent of(String level) {
        for(LevelStudent e : values()) {
            if(e.name().equalsIgnoreCase(level)) {
                return e;
            }
        }
        log.error("Not found enum of: {}", level);
        throw new IllegalArgumentException();
    }
}
