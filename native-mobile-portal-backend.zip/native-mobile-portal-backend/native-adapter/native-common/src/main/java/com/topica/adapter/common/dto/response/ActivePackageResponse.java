package com.topica.adapter.common.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ActivePackageResponse {

  private Boolean status;

  private String msg_code;

  private String msg;

  private String data;

}
