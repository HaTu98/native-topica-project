package com.topica.adapter.common.repository.portal;

import com.topica.adapter.common.model.portal.UserJob;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserJobRepository extends JpaRepository<UserJob, Long> {
}
