package com.topica.adapter.common.config.room;

import com.topica.portal.redis.service.config.ConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.topica.portal.redis.constant.KeyConfig.MIX_LIST_ROOM;

@Component
public class ListRoomStrategy {

    @Autowired
    private ConfigService configService;

    public Boolean isMix() {
        String value = this.configService.get(MIX_LIST_ROOM);
        return Boolean.valueOf(value);
    }
}
