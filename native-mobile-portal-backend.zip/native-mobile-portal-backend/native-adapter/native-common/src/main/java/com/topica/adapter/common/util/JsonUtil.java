package com.topica.adapter.common.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.io.IOException;

@Slf4j
@Component
public class JsonUtil {

  @Autowired
  @Qualifier("portalMapper")
  private ObjectMapper mapper;

  @Bean("portalMapper")
  public ObjectMapper getMapper() {
    return new ObjectMapper();
  }

  public <T> T convert(String json, Class<T> clazz) {
    if(StringUtils.isEmpty(json)) return null;
    try {
      return this.mapper.readValue(json, clazz);
    } catch (IOException ex) {
      log.error("Convert JSON ERROR: {}", ex.getMessage());
      return null;
    }
  }

  public String convertToJson(Object object) {
    try {
      return this.mapper.writeValueAsString(object);
    } catch (IOException ex) {
      return null;
    }
  }
}
