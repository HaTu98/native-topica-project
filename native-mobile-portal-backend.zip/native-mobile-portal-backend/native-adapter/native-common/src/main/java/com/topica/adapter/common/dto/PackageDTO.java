package com.topica.adapter.common.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Date;

/*
 *  model for the student's course
 *
 */
@Data
@NoArgsConstructor
public class PackageDTO {
    private Long id;
    private String contactId;
    private String status;
    private String catCode;
    private Date starttime;
    private Date timecreated;
    private Date timemodified;
    private String genCode;
    private PackageDetailDTO packageDetail;
}
