package com.topica.adapter.common.dto;

import com.topica.adapter.common.constant.SubjectType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import static com.topica.adapter.common.constant.LevelStudent.sbasic;
import static com.topica.adapter.common.constant.SubjectType.SC;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RoomDTO {

  public static final String VCRX = "VCRX";
  public static final String ADB = "ADB";
  public static final String BBB = "BBB";
  public static final String EXTEND = "EXTEND";

  private Long id;
  private Long ticketId;
  private Long classIdVcrx;
  private boolean isVCRX;
  private Long vcrClassId;
  private String calendarCode;
  private String levelClass;
  private String name;
  private Long teacherId;
  private String teacherAvatar;
  private String teacherCountry;
  private String teacherFirstName;
  private String teacherLastName;
  private String teacherType;
  private Long timeAvailable;
  private Long timeDue;
  private long maxJoin;
  private long totalJoin;
  private long totalAuditJoin;
  private String typeClass;
  private String vcrType;
  private boolean isOpened;
  private boolean hasTeacher;
  private boolean joined;
  private String packageType;
  private String role;
  private Integer status;

  public RoomDTO(Long id, String levelClass, String name, String teacherFirstName,
                 String teacherLastName, Long timeAvailable, Long timeDue, String typeClass,
                 String vcrType, Long teacherId, String teacherAvatar, Long vcrClassId) {
    this.id = id;
    this.levelClass = levelClass;
    this.name = name;
    this.teacherFirstName = teacherFirstName;
    this.teacherLastName = teacherLastName;
    this.timeAvailable = timeAvailable;
    this.timeDue = timeDue;
    this.typeClass = typeClass;
    this.vcrType = vcrType;
    this.teacherId = teacherId;
    this.teacherAvatar = teacherAvatar;
    this.vcrClassId = vcrClassId;
  }

  public RoomDTO(Long id, String levelClass, String name, String teacherFirstName,
                 String teacherLastName, Long timeAvailable, Long timeDue, String typeClass,
                 String vcrType, Long teacherId, String teacherAvatar, int isVCRX) {
    this.id = id;
    this.levelClass = levelClass;
    this.name = name;
    this.teacherFirstName = teacherFirstName;
    this.teacherLastName = teacherLastName;
    this.timeAvailable = timeAvailable;
    this.timeDue = timeDue;
    this.typeClass = typeClass;
    this.vcrType = vcrType;
    this.teacherId = teacherId;
    this.teacherAvatar = teacherAvatar;
    this.isVCRX = isVCRX == 1 ? true : false;
    if(this.isVCRX) {
      this.vcrType = RoomDTO.VCRX;
    }
  }

  public RoomDTO(Long id, String levelClass, String name, String teacherFirstName,
                 String teacherLastName, Long timeAvailable, Long timeDue, String typeClass,
                 String vcrType, Long teacherId, String teacherAvatar, int isVCRX, Long vcrxRoomId) {
    this.id = id;
    this.levelClass = levelClass;
    this.name = name;
    this.teacherFirstName = teacherFirstName;
    this.teacherLastName = teacherLastName;
    this.timeAvailable = timeAvailable;
    this.timeDue = timeDue;
    this.typeClass = typeClass;
    this.vcrType = vcrType;
    this.teacherId = teacherId;
    this.teacherAvatar = teacherAvatar;
    this.isVCRX = isVCRX == 1 ? true : false;
    if(this.isVCRX) {
      this.vcrType = RoomDTO.VCRX;
      this.classIdVcrx = vcrxRoomId;
    }
  }

  public RoomDTO(Long id, String levelClass, String name, String teacherFirstName,
                 String teacherLastName, Long timeAvailable, Long timeDue, String typeClass,
                 String vcrType, Long teacherId, String teacherAvatar, Long vcrxRoomId, int isVCRX) {
    this.id = id;
    this.levelClass = levelClass;
    this.name = name;
    this.teacherFirstName = teacherFirstName;
    this.teacherLastName = teacherLastName;
    this.timeAvailable = timeAvailable;
    this.timeDue = timeDue;
    this.typeClass = typeClass;
    this.vcrType = vcrType;
    this.teacherId = teacherId;
    this.teacherAvatar = teacherAvatar;
    this.classIdVcrx = vcrxRoomId;
    this.isVCRX = isVCRX == 1 ? true : false;
    if(this.isVCRX) {
      this.vcrType = RoomDTO.VCRX;
    }
  }

  public RoomDTO(Long id, String levelClass, String name, String teacherFirstName,
                 String teacherLastName, Long timeAvailable, Long timeDue, String typeClass,
                 String vcrType, Long teacherId, String teacherAvatar, Long vcrxRoomId, int isVCRX, long totalJoin, long totalAuditJoin) {
    this.id = id;
    this.levelClass = levelClass;
    this.name = name;
    this.teacherFirstName = teacherFirstName;
    this.teacherLastName = teacherLastName;
    this.timeAvailable = timeAvailable;
    this.timeDue = timeDue;
    this.typeClass = typeClass;
    this.vcrType = vcrType;
    this.teacherId = teacherId;
    this.teacherAvatar = teacherAvatar;
    this.classIdVcrx = vcrxRoomId;
    this.isVCRX = isVCRX == 1 ? true : false;
    if(this.isVCRX) {
      this.vcrType = RoomDTO.VCRX;
    }
    this.totalJoin = totalJoin;
    this.totalAuditJoin = totalAuditJoin;
  }

  public RoomDTO(Long id, String name, String calendarCode , String vcrType, String typeClass,
                 String teacherFirstName, String teacherLastName, String levelClass, Long teacherId, Long timeAvailable, String teacherType){
    this.id = id;
    this.name = name;
    this.calendarCode = calendarCode;
    this.vcrType = vcrType;
    this.typeClass = typeClass;
    if(typeClass.equals(SC.toString()) && levelClass.equals(sbasic.toString())) {
      this.typeClass = SubjectType.SN.toString();
    }
    this.teacherType = teacherType;
    if(("ORIENTATION").equals(teacherType)) {
      this.typeClass = SubjectType.ORI.toString();
    }
    this.teacherFirstName = teacherFirstName;
    this.teacherLastName = teacherLastName;
    this.levelClass = levelClass;
    this.teacherId = teacherId;
    this.timeAvailable = timeAvailable;
  }

  public RoomDTO(Long id, String name, String calendarCode , String vcrType, String typeClass,
                 String teacherFirstName, String teacherLastName, String levelClass, Long teacherId,
                 Long timeAvailable, Long vcrxRoomId, int isVCRX){
    this.id = id;
    this.name = name;
    this.calendarCode = calendarCode;
    this.vcrType = vcrType;
    this.typeClass = typeClass;
    if(typeClass.equals("SC") && levelClass.equals("sbasic")) {
      this.typeClass = "SN";
    }
    this.teacherFirstName = teacherFirstName;
    this.teacherLastName = teacherLastName;
    this.levelClass = levelClass;
    this.teacherId = teacherId;
    this.timeAvailable = timeAvailable;
    this.classIdVcrx = vcrxRoomId;
    this.isVCRX = isVCRX == 1 ? true : false;
    if(this.isVCRX) {
      this.vcrType = RoomDTO.VCRX;
    }
  }

}
