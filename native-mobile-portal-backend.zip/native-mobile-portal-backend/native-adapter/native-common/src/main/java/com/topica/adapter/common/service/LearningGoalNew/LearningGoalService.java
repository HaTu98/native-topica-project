package com.topica.adapter.common.service.LearningGoalNew;

import com.topica.adapter.common.constant.GoalLevel;
import com.topica.adapter.common.constant.GoalType;
import com.topica.adapter.common.dto.*;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.dto.AdvisorResponse;
import com.topica.adapter.common.model.portal.*;
import com.topica.adapter.common.service.BaseUserSessionService;
import com.topica.adapter.common.service.invoker.InvokerService;
import com.topica.adapter.common.service.user.UserServicePortal;
import com.topica.adapter.common.util.MappingLevelUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.*;

@Service
@Slf4j
public class LearningGoalService extends BaseUserSessionService {
    @Value("${api.advisor.url}")
    private String advisorUrl;

    @Value("${api.advisor.username}")
    private String username;

    @Value("${api.advisor.password}")
    private String password;

    @Value("${api.advisor.key}")
    private String advisorKey;

    @Autowired
    @Qualifier("UserServicePortal")
    private UserServicePortal userServicePortal;

    @Autowired
    private LearningGoalLevelService levelService;

    @Autowired
    private InvokerService invokerService;

    @Autowired
    private LearningGoalOptionService learningGoalOptionService;

    @Autowired
    private LearningGoalStepService learningGoalStepService;

    @Autowired
    private LevelStudyService levelStudyService;

    @Autowired
    private LearningGoalOptionSelectService optionSelectService;

    @Autowired
    private LearningGoalStudentLevelService studentLevelService;

    public List<StepDTO> getLearningGoal() {
        log.info("(getLearningGoal) {}",getUserSession().getMdlUser().getId());
        List<LearningGoalStep> steps = learningGoalStepService.getAllStepActive();
        return getListStep(steps);
    }

    public List<StepDTO> getUserLearningGoal() {
        log.info("(getUserLearningGoal) {}",getUserSession().getMdlUser().getId());
        List<LearningGoalOption> userSelect = this.getUserSelect();
        List<LearningGoalStep> steps = learningGoalStepService.getAllStepActive();
        List<LearningGoalStep> userSteps = new ArrayList<>();
        for (LearningGoalStep step : steps) {
            List<LearningGoalOption> options = new ArrayList<>();
            for (LearningGoalOption select : userSelect) {
                if (select.getStepId().equals(step.getStepId())){
                    options.add(select);
                }
            }
            step.setOptions(options);
            userSteps.add(step);
        }
        return getListStep(userSteps);
    }

    public Map<String,String> getEngLevel(String[] request) throws BusinessException {
        log.info("(getEngLevel) {}"+ Arrays.toString(request),getUserSession().getMdlUser().getId());
        List<Long> data = new ArrayList<>();
        for (String temp : request) data.add(Long.parseLong(temp));
        String goalType = "";
        List<LearningGoalOption> learningGoalOptions = learningGoalOptionService.getAllByOptionId(data);
        List<LearningGoalOption> answers = new ArrayList<>();
        for (LearningGoalOption learningGoalOption : learningGoalOptions) {
            Long stepId = learningGoalOption.getStepId();
            if (stepId == 2) {
                goalType = learningGoalOption.getOptionValue();
            }
            if (stepId == 4) {
                answers.add(learningGoalOption);
            }
        }
        String level = this.getLevel(answers, goalType);
        String finalLevel = this.checkGoalLevel(level);
        return new HashMap<String,String>(){{
            put("level", finalLevel);
        }
        };
    }

    public List<LearningGoalOptionSelect> saveInfo(List<Long> request) {
        log.info("(saveInfo) {}"+request, getUserSession().getMdlUser().getId());
        Long userId = getUserSession().getMdlUser().getId();
        List<LearningGoalOption> options = learningGoalOptionService.getAllByOptionId(request);
        List<LearningGoalOptionSelect> newInfo = new ArrayList<>();
        for (LearningGoalOption option : options) {
            LearningGoalOptionSelect select = new LearningGoalOptionSelect();
            select.setStepId(option.getStepId());
            select.setParentId(option.getOptionParentId());
            select.setOptionAnswer(option.getOptionValue());
            select.setStudentId(userId);
            select.setOptionId(option.getOptionId());
            select.setStatus(true);
            newInfo.add(select);
        }
        return optionSelectService.saveUserInfo(userId,newInfo);
    }

    public Map<String, String> saveGoal(List<Long> request) throws BusinessException {
        log.info("(saveGoal) {}"+request, getUserSession().getMdlUser().getId());
        String goalType = "";
        Long userId = getUserSession().getMdlUser().getId();
        List<LearningGoalOption> options = learningGoalOptionService.getAllByOptionId(request);
        List<LearningGoalOption> answers = new ArrayList<>();
        List<LearningGoalOptionSelect> newInfo = new ArrayList<>();
        for (LearningGoalOption option : options) {
            Long stepId = option.getStepId();
            LearningGoalOptionSelect select = new LearningGoalOptionSelect();
            select.setStepId(stepId);
            select.setParentId(option.getOptionParentId());
            select.setOptionAnswer(option.getOptionValue());
            select.setStudentId(userId);
            select.setOptionId(option.getOptionId());
            select.setStatus(true);
            newInfo.add(select);
            if (stepId == 2) {
                goalType = option.getOptionValue();
            }
            if (stepId == 4) {
                answers.add(option);
            }
        }
        Boolean result = optionSelectService.saveUserGoal(userId,newInfo);

        String level = this.getLevel(answers, goalType);
        String finalLevel = this.checkGoalLevel(level);
        if (result) {
            this.setLevelStudy(userId, finalLevel);
        }
        return new HashMap<String,String>(){{
            put("level", finalLevel);
        }
        };
    }

    public Map<String, String> setEndLevel(List<Long> request) throws BusinessException {
        log.info("(setEndLevel) {}"+request, getUserSession().getMdlUser().getId());
        String goalType = "";
        Long studentId = getUserSession().getMdlUser().getId();
        List<LearningGoalOptionSelect> optionSelects = new ArrayList<>();
        List<LearningGoalOption> learningGoalOptions = learningGoalOptionService.getAllByOptionId(request);
        List<LearningGoalOption> answers = new ArrayList<>();
        for (LearningGoalOption learningGoalOption : learningGoalOptions) {
            LearningGoalOptionSelect optionSelect = new LearningGoalOptionSelect();
            optionSelect.setOptionId(learningGoalOption.getOptionId());
            optionSelect.setOptionAnswer(learningGoalOption.getOptionValue());
            optionSelect.setStudentId(studentId);
            optionSelect.setStepId(learningGoalOption.getStepId());
            optionSelect.setParentId(learningGoalOption.getOptionParentId());
            optionSelect.setStatus(true);
            Long stepId = learningGoalOption.getStepId();
            if (stepId == 2) {
                goalType = learningGoalOption.getOptionValue();
            }
            if (stepId == 4) {
                answers.add(learningGoalOption);
            }
            optionSelects.add(optionSelect);
        }
        String level = this.getLevel(answers, goalType);
        String finalLevel = this.checkGoalLevel(level);

        this.setLevelStudy(studentId, finalLevel);
        optionSelectService.saveAll(optionSelects);
        return new HashMap<String,String>(){{
            put("level", finalLevel);
        }
        };
    }

    public List<LearningGoalData> getListLevel(){
        log.info("(getListLevel) {}", getUserSession().getMdlUser().getId());
        List<LearningGoalData> learningGoalData = new ArrayList<>();
        List<LearningGoalLevel> listLevel = levelService.getAllLevel();
        for (LearningGoalLevel level : listLevel) {
            LearningObjects learningObjects = LearningObjects.builder()
                    .phonetic(level.getPhonetic())
                    .grammar(level.getGrammar())
                    .vocabulary(level.getVocabulary())
                    .bloom(level.getBloom())
                    .build();
            learningGoalData.add(LearningGoalData.builder()
                    .studentLevelId(level.getStudentLevelId())
                    .studentLevelName(level.getStudentLevelName())
                    .learningObjects(learningObjects)
                    .build()
            );

        }
        return learningGoalData;
    }

    private OptionDTO setOptionDTO(LearningGoalOption option) {
        OptionDTO optionDTO = new OptionDTO();
        optionDTO.setOptionValue(option.getOptionValue());
        optionDTO.setOptionNameEn(option.getOptionNameEN());
        optionDTO.setOptionId(option.getOptionId());
        optionDTO.setOptionParent(option.getOptionParentId());
        optionDTO.setOptionName(option.getOptionName());
        optionDTO.setOptionOrder(option.getOptionOrder());
        optionDTO.setOptionDesc(option.getOptionDescription());
        return optionDTO;
    }

    private void setLevelStudy(Long studentId, String goal) {
        LearningGoalStudentLevel studentLevel = studentLevelService.getStudentLevel(studentId);
        if (studentLevel.getStudentId() == null) {
            studentLevel.setStudentId(studentId);
            studentLevel.setStatus(true);
        }
        studentLevel.setEndLevel(goal);
        studentLevelService.save(studentLevel);
    }

    private String getLevel(List<LearningGoalOption> answers, String goalType) {
        if (goalType.equalsIgnoreCase(GoalType.CERTIFICATE.getGoalType())) {
            return answers.get(0).getOptionValue();
        } else {
            return this.getNoCertificateLevel(answers);
        }
    }

    private String getLevel(String value) {
        if(StringUtils.isEmpty(value)) return null;
        return GoalLevel.fromStringValue(value).getLevel();
    }

    private String getNoCertificateLevel(List<LearningGoalOption> answers) {
        List<NoCertificateDTO> noCertificate = new ArrayList<>();

        for (LearningGoalOption answer : answers) {
            NoCertificateDTO noCer = new NoCertificateDTO();
            LearningGoalOption parent = learningGoalOptionService.getOption(answer.getOptionParentId());
            noCer.setOptionId(answer.getOptionId());
            noCer.setValue(answer.getOptionValue());
            noCer.setWeight(parent.getOptionWeight());
            noCertificate.add(noCer);
        }
        return this.getMaxLevel(noCertificate);
    }

    private String getMaxLevel(List<NoCertificateDTO> noCertificate) {
        Map<String, Long> listLevel = new HashMap<>();
        for (NoCertificateDTO nocer : noCertificate) {
            listLevel.merge(nocer.getValue(), nocer.getWeight(), Long::sum);
        }
        String level = Collections.max(listLevel.entrySet(), Comparator.comparingLong(Map.Entry::getValue)).getKey();
        return level;
    }

    private List<StepDTO> getListStep(List<LearningGoalStep> learningGoalSteps) {
        List<StepDTO> stepList = new ArrayList<>();
        for (LearningGoalStep step : learningGoalSteps) {
            StepDTO stepDTO = new StepDTO();
            stepDTO.setStep(step.getStepId());
            stepDTO.setStepName(step.getStepName());
            stepDTO.setStepPrevious(step.getStepPreviousId());
            List<LearningGoalOption> options = step.getOptions();
            stepDTO.setOptions(findOption(options));
            stepList.add(stepDTO);
        }
        return stepList;
    }

    private List<OptionDTO> findOption(List<LearningGoalOption> options) {
        List<OptionDTO> list = new ArrayList<>();
        for (LearningGoalOption option : options) {
            Long optionId = option.getOptionId();
            if (isParent(options, optionId)) {
                OptionDTO optionDTO  = this.setOptionDTO(option);
                if (!CollectionUtils.isEmpty(option.getOptionMappings())) {
                    optionDTO.setOptionPrevious(option.getOptionMappings().get(0).getOptionPreviousId());
                }
                optionDTO.setOptionChild(findOptionChild(options, optionDTO));
                list.add(optionDTO);
            }
        }
        return list;
    }

    private boolean isParent(List<LearningGoalOption> options, Long optionId) {
        for (LearningGoalOption option : options) {
            if (option.getOptionParentId() != null) {
                if (option.getOptionParentId().equals(optionId)) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean isChild(LearningGoalOption child, Long parentId) {
        if (child.getOptionParentId() == null) return false;
        else return child.getOptionParentId().equals(parentId);
    }

    private List<OptionDTO> findOptionChild(List<LearningGoalOption> options, OptionDTO parent) {
        List<OptionDTO> child = new ArrayList<>();
        int i = 0;
        for (LearningGoalOption option : options) {
            if (isChild(option, parent.getOptionId())) {
                OptionDTO optionDTO = this.setOptionDTO(option);
                if (!CollectionUtils.isEmpty(option.getOptionMappings())) {
                    optionDTO.setOptionPrevious(option.getOptionMappings().get(0).getOptionPreviousId());
                }
                if (isParent(options, option.getOptionId())) {
                    optionDTO.setOptionChild(this.findOptionChild(options, optionDTO));
                }
                child.add(optionDTO);
            }
        }
        return child;
    }

    public LevelLearningGoalDTO getTargetLevel() throws BusinessException {
        Long userId = getUserSession().getMdlUser().getId();
        String studentLevel = studentLevelService.getStudentLevel(userId).getEndLevel();

        AdvisorResponse data = this.getLevelAdvisor(userId);
        String startLevel = this.getStartLevelFromDB(userId);
        String currentLevel;
        if (data.getData() != null) {
            if (StringUtils.isEmpty(startLevel)){
                startLevel = MappingLevelUtil.mappingLevelAdvisor(data.getData().getStart_level()).getLevel();
                this.saveStartLevelToDB(startLevel);
            }
            currentLevel = MappingLevelUtil.mappingLevelAdvisor(data.getData().getCurrent_level()).getLevel();
        } else {
            if (StringUtils.isEmpty(startLevel)) {
                startLevel = GoalLevel.STARTER.getLevel();
            }
            currentLevel = startLevel;
        }

        return LevelLearningGoalDTO.builder()
                .goalLevel(studentLevel)
                .startLevel(startLevel)
                .currentLevel(currentLevel)
                .build();
    }

    private List<LearningGoalOption> getUserSelect(){
        Long userId = getUserSession().getMdlUser().getId();
        List<LearningGoalOptionSelect> optionSelects = optionSelectService.getUserSelect(userId);
        Map<Long,Long> userSelect = new HashMap<>();
        for(LearningGoalOptionSelect optionSelect : optionSelects) {
            userSelect.put(optionSelect.getOptionId(),optionSelect.getOptionId());
            userSelect.put(optionSelect.getParentId(),optionSelect.getParentId());
        }
        List<Long> result = new ArrayList<>(userSelect.values());
        return learningGoalOptionService.getAllByOptionId(result);
    }

    private String checkGoalLevel(String level) throws BusinessException {
        String startLevel = this.getStartLevel();
        Integer goalValue = GoalLevel.fromStringLevel(level).getValue();
        if (startLevel != null) {
            Integer startValue = GoalLevel.fromStringLevel(startLevel).getValue();
            if (startValue >= goalValue) {
                if (GoalLevel.fromStringLevel(startLevel).getLevel().equalsIgnoreCase("Advanced")) {
                    goalValue = GoalLevel.fromStringLevel("Advanced").getValue();
                } else {
                    goalValue = GoalLevel.fromStringLevel(startLevel).getValue() + 1;
                }
            }
        }
        String goalLevel = GoalLevel.fromInteger(goalValue).getLevel();
        if (goalLevel.equalsIgnoreCase(GoalLevel.ADVANCED.getLevel()))
            goalLevel = GoalLevel.INTERMEDIATE_300.getLevel();
        return goalLevel;
    }

    private String getStartLevel() throws BusinessException {
        Long userId = getUserSession().getMdlUser().getId();
        String startLevel = this.getStartLevelFromDB(userId);
        if (StringUtils.isEmpty(startLevel)) {
            AdvisorResponse data = this.getLevelAdvisor(userId);
            return MappingLevelUtil.mappingLevelAdvisor(data.getData().getStart_level()).getLevel();
        }
        return startLevel;
    }

    private void saveStartLevelToDB(String level){
        Long userId = getUserSession().getMdlUser().getId();
        log.info("saveStartLevelToDB() {}" + level, userId );
        LearningGoalStudentLevel studentLevel = studentLevelService.getStudentLevel(userId);
        if(studentLevel.getStudentId() == null) {
            studentLevel.setStudentId(userId);
            studentLevel.setStatus(true);
        }
        studentLevel.setStartLevel(level);
        studentLevelService.save(studentLevel);
    }

    private String getStartLevelFromDB(Long userId){
        LearningGoalStudentLevel studentLevel = studentLevelService.getStudentLevel(userId);
        return studentLevel.getStartLevel();
    }

    private AdvisorResponse getLevelAdvisor(Long userId) throws BusinessException {
        PersonalInfoDTO infoData = userServicePortal.findPersonalInfo(userId, getUserSession().getServiceType());

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Authorization", this.getBasicAuthToken());
        headers.add("key", advisorKey);
        String url = advisorUrl.concat("/api/studentAPI/getAllLevel?contact_id=") + infoData.getContactId();

        Optional<AdvisorResponse> response = invokerService.get(url, headers, AdvisorResponse.class);
        AdvisorResponse data = new AdvisorResponse();
        if (response.isPresent()) {
            data = response.get();
        }
        String startLevelDB = this.getStartLevelFromDB(userId);
        if (StringUtils.isEmpty(startLevelDB) && data.getData() != null){
            GoalLevel startLevel = MappingLevelUtil.mappingLevelAdvisor(data.getData().getStart_level());
            this.saveStartLevelToDB(startLevel.getLevel());
        }
        return data;
    }

    private String getBasicAuthToken() {
        String auth = username + ":" + password;
        String authEncode = Base64.getEncoder().encodeToString(auth.getBytes());
        return "Basic " + authEncode;
    }
}
