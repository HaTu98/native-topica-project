package com.topica.adapter.common.dto.response;

import lombok.Data;

@Data
public class Comment {
  private Long id;

  private String externalUserId;

  private String name;

  private String role;

  private String content;

  private Long time;

  private String quoteUser;

  private String quoteExternalUserId;

  private String quoteContent;

  private Long quoteTime;

  private Boolean active;
}
