package com.topica.adapter.common.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.topica.adapter.common.auth.TokenAuthenticationHelper;
import com.topica.adapter.common.constant.LevelStudent;
import com.topica.adapter.common.constant.ServiceType;
import com.topica.adapter.common.model.MdlUser;
import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.model.StarterUserData;
import com.topica.adapter.common.request.LoginRequest;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Arrays;
import java.util.List;

@Data
@NoArgsConstructor
public class PersonalInfoDTO {

    public static final int LEVEL = 86;
    public static final int PACKAGE_CODE = 91;
    public static final int PACKAGE_PARENT = 92;
    public static final int CONTACT_ID = 88;
    public static final int GENDER = 5;
    public static final int BIRTHDAY = 89;
    public static final List<Integer> listField = Arrays.asList(LEVEL, PACKAGE_PARENT, PACKAGE_CODE, CONTACT_ID, GENDER, BIRTHDAY);

    private Long id;
    @JsonIgnore
    private String roleName;
    private String firstName;
    private String lastName;
    private String userName;
    private String phone1;
    private String phone2;
    private String email;
    @JsonIgnore
    private String job;
    private String level;
    private String birthday;
    private String gender;
    @JsonIgnore
    private String address;
    /*@JsonIgnore
    private String learningGoals;*/
    private String avatarLink;
    @JsonIgnore
    private String publicStatsToken;
    private String token;
    private String tokenStarter;
    private UserInfoDTO userInfo;
    private String productCode;
    private String packageStatus;
    private boolean isTenupPackage;
    private String packageCode;
    private String packageParent;
    private ServiceType serviceType;
    private String contactId;
    private List<PackageDTO> packageList;
    private Object configInfo;
    private String streamSocketBaseUrl;
    private String streamSocketBaseUrlHttps;
    private List<String> functions;

    public PersonalInfoDTO(Long id) {
        this.id = id;
    }

    public void setLevel(String level) {
        this.level = level;
        this.userInfo.setUserlv(level);
    }

    public void buildToken(LoginRequest request) {
        MdlUser mdlUser = new MdlUser();
        mdlUser.setId(this.id);
        mdlUser.setUsername(this.userName);
        mdlUser.setPassword(request.getPassword());
        PortalMdlUser userSession = PortalMdlUser.builder()
                .mdlUser(mdlUser)
                .vcrxUserId(this.userInfo.getVcrxuserid())
                .email(this.email)
                .firstName(this.firstName)
                .lastName(this.lastName)
                .serviceType(request.getServiceType())
                .activedPackage("ACTIVED".equalsIgnoreCase(this.packageStatus))
                .role(this.roleName)
                .level(this.level)
                .packageParent(this.packageParent)
                .build();
        this.token = TokenAuthenticationHelper.generatePortalToken(userSession);
    }
    public void buildTokenForStarter() {
        if(!LevelStudent.starter.name().equalsIgnoreCase(this.level)) return;

        StarterUserData userStarter = StarterUserData.builder()
                .firstName(this.firstName)
                .lastName(this.lastName)
                .level(this.level)
                .packageParent(this.packageParent)
                .packageStatus(this.packageStatus)
                .userId(this.id)
                .userName(this.userName)
                .avatar(this.avatarLink)
                .build();
        this.tokenStarter = TokenAuthenticationHelper.generateStarterToken(userStarter);
    }
}