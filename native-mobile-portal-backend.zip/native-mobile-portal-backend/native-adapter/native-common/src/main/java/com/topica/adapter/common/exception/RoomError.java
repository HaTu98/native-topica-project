package com.topica.adapter.common.exception;

public class RoomError {
    public static final int ROOM_DELETED = 35;
    public static final int VCR_CHANGED = 36;
    public static final int NOT_FOUND_NEW_VALID_ROOM = 37;
    public static final int JOIN_MANY_TIMES = 38;
    public static final int OUT_OF_TICKET = 39;

    public static final int NOT_FOUND_VALID_ROOM = 40;
    public static final int NOT_FOUND_ROOM = 41;
    public static final int INVALID_PACKAGE_TYPE = 42;
    public static final int FULL_USER_IN_ROOM = 43;
    public static final int ROOM_NOT_OPEN = 44;
    public static final int INVALID_TIME_QUICK_JOIN = 45;
    public static final int INVALID_TIME_JOIN = 46;
    public static final int OUT_OF_SLOT_IN_ROOM = 47;
    public static final int NOT_SUPPORT_VCR = 48;

    public static final int NOT_FOUND_ROOM_AUDIT = 49;
    public static final int FULL_USER_IN_ROOM_AUDIT = 50;
    public static final int INVALID_AUDIT_ROOM = 51;


    public static int fromVCRXCode (int code) {
        switch (code) {
            case -5: return NOT_FOUND_ROOM;
            case -4: return ROOM_NOT_OPEN;
            default: return NOT_FOUND_ROOM;
        }

    }
}