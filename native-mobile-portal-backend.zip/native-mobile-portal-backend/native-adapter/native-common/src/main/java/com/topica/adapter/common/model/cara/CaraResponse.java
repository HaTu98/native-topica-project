package com.topica.adapter.common.model.cara;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class CaraResponse {
    private Boolean status;
    private String msg_code;
    private String msg;
    private CaraData data;

    public CaraResponse(Boolean status){
        this.status = status;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CaraData {

        public static final String RATE_TYPE_DEFAULT = "MULTI";
        public static final String RATE_TYPE_SINGLE = "SINGLE";

        private ClassInfo class_info;
        private Boolean need_rating;
        private List<CaraOption> option_rate_list;
        private String rate_type = RATE_TYPE_DEFAULT;

        public CaraData(ClassInfo class_info, Boolean need_rating) {
            this.class_info = class_info;
            this.need_rating = need_rating;
        }

        public CaraData(Boolean need_rating) {
            this.need_rating = need_rating;
        }
    }

    @Data
    @AllArgsConstructor
    public static class ClassInfo {
        private Long teacher_id;
        private Long room_id;
        private Long time;
        private String role;
    }
}
