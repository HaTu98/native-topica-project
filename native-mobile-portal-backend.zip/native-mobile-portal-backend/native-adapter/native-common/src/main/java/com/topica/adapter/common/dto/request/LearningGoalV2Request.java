package com.topica.adapter.common.dto.request;

import lombok.Data;

import java.util.Map;

@Data
public class LearningGoalV2Request {
    private Long step;
    private Map<String, Long> option;
}
