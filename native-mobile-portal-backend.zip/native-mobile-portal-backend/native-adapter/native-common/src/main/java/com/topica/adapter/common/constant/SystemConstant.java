package com.topica.adapter.common.constant;

public interface SystemConstant {
	String CODE_SUCCESS = "SUCCESS";

    String HTTP_PROTOCOL = "http://";
    
    String COMMA_STRING = ",";
    
    String EMPTY_STRING = "";
    
    String SPACE_STRING = " ";
    
    String TICK_STRING = "x";
    
    String UNDERLINE_STRING = "_";
    
    String DATE_FORMAT = "dd/MM/yyyy";
    
    String DATETIME_FORMAT = "dd/MM/yyyy_HH:mm:ss";
    
    String TIME_FORMAT = "HH:mm:ss";
    
    String ALPHABET = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
    
    String DNS_GOOGLE_PUBLIC_HOST = "8.8.8.8";
    
    int DNS_GOOGLE_PUBLIC_PORT = 10002;
    
    String CLASS_POSTFIX_STRING = "-NLS";
    
    int SIZE_ID_CLASS_FORMAT = 7;
}
