package com.topica.adapter.common.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class NoCertificateDTO {
    private Long optionId;
    private String value;
    private Long weight;
}
