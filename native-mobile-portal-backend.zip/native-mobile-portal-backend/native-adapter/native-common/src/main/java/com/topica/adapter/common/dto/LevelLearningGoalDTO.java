package com.topica.adapter.common.dto;

import java.util.Map;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class LevelLearningGoalDTO {
    private String startLevel;
    private String goalLevel;
    private String currentLevel;
    private Map<String, Long> usedPoint;
}
