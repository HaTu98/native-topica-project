package com.topica.adapter.common.service.course;

import com.topica.adapter.common.constant.PackageStatus;
import com.topica.adapter.common.constant.ServiceType;
import com.topica.adapter.common.dto.MarketPackage;
import com.topica.adapter.common.dto.request.ActiveRequest;
import com.topica.adapter.common.dto.request.GetPackageRequest;
import com.topica.adapter.common.dto.response.ActivePackageResponse;
import com.topica.adapter.common.dto.response.GetPackageResponse;
import com.topica.adapter.common.dto.response.TransactionHistory;
import com.topica.adapter.common.dto.response.TransactionHistoryResponse;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.service.invoker.InvokerService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@Slf4j
public class ActivePackageService {
  @Value("${api.market.url}")
  private String marketUrl;

  @Value("${app.market.url}")
  private String marketHost;

  @Value("${app.market.uri.package.get}")
  private String getPackageUri;

  @Value("${app.market.uri.package.active}")
  private String activeMarketUri;

  @Value("${app.market.uri.transaction-history.get}")
  private String getTransactionHistory;

  @Value("${app.market.username}")
  private String marketUserName;

  @Value("${app.market.password}")
  private String marketPassword;

  @Value("${app.market.key}")
  private String marketKey;

  @Value("${lms.api.package.active.url}")
  private String lmsApiUrl;

  @Value("${lms.api.package.active.key}")
  private String lmsApiKey;

  @Value("${lms.api.package.active.username}")
  private String lmsApiUsername;

  @Value("${lms.api.package.active.password}")
  private String lmsApiPassword;

  @Value("${lmsVip.api.package.active.url}")
  private String lmsVipApiUrl;

  @Value("${lmsVip.api.package.active.key}")
  private String lmsVipApiKey;

  @Value("${lmsVip.api.package.active.username}")
  private String lmsVipApiUsername;

  @Value("${lmsVip.api.package.active.password}")
  private String lmsVipApiPassword;

  @Autowired
  private InvokerService invokerService;

  public Optional<Boolean> activePackage(ActiveRequest activeRequest, ServiceType serviceType){
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);

    String authBasic = invokerService.toBase64Token(getLmsUsername(serviceType), getLmsPassword(serviceType));
    headers.set("Authorization", authBasic);
    headers.set("X-API-KEY", getLmsKey(serviceType));
    log.info("(activePackage) {}", activeRequest);
    HttpEntity<Object> request = new HttpEntity<>(activeRequest, headers);
    Optional<ActivePackageResponse> response = invokerService.postHeader(getLmsUrl(serviceType), request, ActivePackageResponse.class);
    log.info("(activePackage) {}", response);

    if (!response.isPresent()) {
      return Optional.of(false);
    }

    return Optional.of(response.get().getStatus());
  }

  public GetPackageResponse getListPackage(String contactId) {

    String url = marketUrl.concat(getPackageUri);
    String auth = marketUserName + ":" + marketPassword;
    String authEncode = Base64.getEncoder().encodeToString(auth.getBytes());

    String authHeader = "Basic " + authEncode;
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.set("Authorization", authHeader);
    GetPackageRequest getPacketRequest = new GetPackageRequest(marketKey, contactId);
    HttpEntity<Object> request = new HttpEntity<>(getPacketRequest, headers);
    Optional<GetPackageResponse> response = invokerService.postHeader(url, request, GetPackageResponse.class);

    if (!response.isPresent()) {
      return null;
    }
    return response.get();
  }

  public List<MarketPackage> isCanActive(List<MarketPackage> listPackage) throws BusinessException {
    List<MarketPackage> isExistActive = listPackage.stream()
            .filter(t -> isActive(t.getStatus()))
            .collect(Collectors.toList());
    if(!CollectionUtils.isEmpty(isExistActive)){
      throw new BusinessException();
    }

    List<MarketPackage> suspendedPackage = listPackage.stream()
            .filter(t -> isSuspended(t.getStatus()))
            .collect(Collectors.toList());
    if(!CollectionUtils.isEmpty(suspendedPackage)) {
      throw new BusinessException();
    }

    List<MarketPackage> isExistDeactived = listPackage.stream()
            .filter(t -> isDeactive(t.getStatus()))
            .collect(Collectors.toList());
    if(CollectionUtils.isEmpty(isExistDeactived)) {
      throw new BusinessException();
    }
    return isExistDeactived;
  }

  public TransactionHistoryResponse getTransactionHistory(String contactId) {
    String url = marketHost.concat(getTransactionHistory).concat("?contact_id=").concat(contactId);
    String auth = marketUserName + ":" + marketPassword;
    String authEncode = Base64.getEncoder().encodeToString(auth.getBytes());

    String authHeader = "Basic " + authEncode;
    HttpHeaders headers = new HttpHeaders();
    headers.set("Authorization", authHeader);
    headers.set("key", marketKey);
    Optional<TransactionHistoryResponse> response = invokerService.get(url, headers, TransactionHistoryResponse.class);

    if (!response.isPresent()) {
      return TransactionHistoryResponse.builder().data(new ArrayList<>()).build();
    }
    return response.get();
  }

  private boolean isActive(PackageStatus packageStatus){
    return packageStatus == PackageStatus.ACTIVED;
  }

  private boolean isSuspended(PackageStatus packageStatus){
    return packageStatus == PackageStatus.SUSPENDED;
  }

  private boolean isDeactive(PackageStatus packageStatus){
    return packageStatus == PackageStatus.DEACTIVED;
  }

  private String getLmsUrl(ServiceType serviceType){
    if(serviceType == ServiceType.LMS){
      return lmsApiUrl;
    }
    return lmsVipApiUrl;
  }

  private String getLmsKey(ServiceType serviceType){
    if(serviceType == ServiceType.LMS){
      return lmsApiKey;
    }
    return lmsVipApiKey;
  }

  private String getLmsUsername(ServiceType serviceType){
    if(serviceType == ServiceType.LMS){
      return lmsApiUsername;
    }
    return lmsVipApiUsername;
  }

  private String getLmsPassword(ServiceType serviceType){
    if(serviceType == ServiceType.LMS){
      return lmsApiPassword;
    }
    return lmsVipApiPassword;
  }
}