package com.topica.adapter.common.service.levelClassMapping;

import com.topica.adapter.common.model.portal.LevelClassMapping;
import com.topica.adapter.common.request.LevelClassMappingRequest;

public interface LevelClassMappingService {
    LevelClassMapping getLevelClass(LevelClassMappingRequest request);
    void save(LevelClassMappingRequest request);
    void delete(LevelClassMappingRequest request);

}
