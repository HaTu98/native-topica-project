package com.topica.adapter.common.dto;

import lombok.Data;

@Data
public class LevelAdvisorResponse {
    private String start_level;
    private String current_level;
}
