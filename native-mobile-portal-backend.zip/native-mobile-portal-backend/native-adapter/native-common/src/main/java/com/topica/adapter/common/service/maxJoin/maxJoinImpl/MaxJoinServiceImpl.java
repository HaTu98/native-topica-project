package com.topica.adapter.common.service.maxJoin.maxJoinImpl;

import com.topica.adapter.common.model.portal.MaxJoin;
import com.topica.adapter.common.repository.portal.MaxJoinRepository;
import com.topica.adapter.common.request.MaxJoinRequest;
import com.topica.adapter.common.service.BaseUserSessionService;
import com.topica.adapter.common.service.maxJoin.MaxJoinService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MaxJoinServiceImpl extends BaseUserSessionService implements MaxJoinService {

    @Autowired
    private MaxJoinRepository maxJoinRepository;

    @Override
    public MaxJoin getMaxUser(MaxJoinRequest request) {
        List<MaxJoin> maxJoin = maxJoinRepository.findByPackageTypeAndLevelClassAndTypeClass(request.getPackageType(),request.getLevelClass(),request.getTypeClass());
        if (maxJoin.size() < 1)
            return null;
        return maxJoin.get(0);
    }

    @Override
    public void save(MaxJoin maxJoin) {
        maxJoinRepository.save(maxJoin);
    }

    @Override
    public void delete(MaxJoin maxJoin) {
        maxJoinRepository.delete(maxJoin);
    }
}
