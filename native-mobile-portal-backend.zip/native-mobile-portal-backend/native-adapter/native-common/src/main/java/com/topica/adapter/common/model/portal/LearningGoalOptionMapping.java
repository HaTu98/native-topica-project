package com.topica.adapter.common.model.portal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;

import javax.persistence.*;
import java.util.List;

@AllArgsConstructor
@Data
@Entity
@NoArgsConstructor
@Table(name = "learning_goal_option_mapping")
public class LearningGoalOptionMapping {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "option_id")
    private Long optionId;

    @Column(name = "option_previous_id")
    private Long optionPreviousId;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "option_id", insertable = false, updatable = false)
    private LearningGoalOption learningGoalOption;
}
