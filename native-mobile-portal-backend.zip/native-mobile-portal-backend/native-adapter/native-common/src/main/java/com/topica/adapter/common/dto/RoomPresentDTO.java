package com.topica.adapter.common.dto;

import lombok.Data;

@Data
public class RoomPresentDTO {
	    private Long roomId;
	    private String title;
	    private Long hourStart;
	    private String topic;
	    private String vcrType;
	    private Long timedue;
	    private Long timeavailable;
	    private String levelClass;
	    private String typeClass;
	    private String objective;
	    private String background;
	    private String fileUrl;
	    private String imageUrl;
	    private boolean isVCRX;

	    public RoomPresentDTO() {
	    }

		public RoomPresentDTO(Long roomId, String title, Long hourStart, String topic, String vcrType, Long timedue,
				Long timeavailable, String levelClass, String typeClass, String objective, String background, String fileUrl, int isVCRX) {
			super();
			this.roomId = roomId;
			this.title = title;
			this.hourStart = hourStart;
			this.topic = topic;
			this.vcrType = vcrType;
			this.timedue = timedue;
			this.timeavailable = timeavailable;
			this.levelClass = levelClass;
			this.typeClass = typeClass;
			this.objective = objective;
			this.background = background;
			this.fileUrl = fileUrl;
			this.isVCRX = isVCRX == 1? true : false;
		}



	    
	    
}
