package com.topica.adapter.common.model.portal;

import lombok.*;

import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name = "learning_goal_option")
public class LearningGoalOption {
    @Id
    @Column(name = "option_id")
    private Long optionId;

    @Column(name = "step_id")
    private Long stepId;

    @Column(name = "option_parent_id")
    private Long optionParentId;

    @Column(name = "option_name")
    private String optionName;

    @Column(name = "option_name_en")
    private String optionNameEN;

    @Column(name = "option_description")
    private String optionDescription;

    @Column(name = "option_order")
    private Long optionOrder;

    @Column(name = "option_value")
        private String optionValue;

    @Column(name = "option_weight")
    private Long optionWeight;

    @Column(name = "option_status")
    private Boolean optionStatus;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "step_id", insertable = false, updatable = false)
    private LearningGoalStep steps;

    @OneToMany(mappedBy = "learningGoalOption")
    private List<LearningGoalOptionMapping> optionMappings;
}
