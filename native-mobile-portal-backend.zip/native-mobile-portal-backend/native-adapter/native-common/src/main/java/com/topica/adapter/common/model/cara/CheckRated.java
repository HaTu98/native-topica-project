package com.topica.adapter.common.model.cara;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Data
@NoArgsConstructor
public class CheckRated {

  private Boolean isCanRate;
  private Long timeAvailable;

  public static CheckRated getCantRate() {
    return new CheckRated(false, null);
  }
}
