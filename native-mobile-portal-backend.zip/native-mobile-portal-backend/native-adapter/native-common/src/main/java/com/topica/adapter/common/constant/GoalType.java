package com.topica.adapter.common.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum GoalType {
    CERTIFICATE("certificate"),
    IELT("IELTS"),
    TOIEC("TOIEC"),
    CERF("CERF"),
    NO_CERTIFICATE("noCertificate");

    private final String goalType;
}
