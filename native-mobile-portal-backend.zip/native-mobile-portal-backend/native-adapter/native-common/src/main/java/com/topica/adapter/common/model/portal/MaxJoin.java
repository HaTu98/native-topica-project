package com.topica.adapter.common.model.portal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@AllArgsConstructor
@Data
@Entity
@NoArgsConstructor
@Table(name="max_join")
public class MaxJoin {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;

    @Column(name="package_type")
    private String packageType;

    @Column(name="level_class")
    private String levelClass;

    @Column(name="type_class")
    private String typeClass;

    @Column(name="max_user")
    private Integer maxUser;
}