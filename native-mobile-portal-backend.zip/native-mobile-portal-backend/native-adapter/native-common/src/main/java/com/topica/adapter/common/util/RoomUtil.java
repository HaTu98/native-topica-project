package com.topica.adapter.common.util;

import com.topica.adapter.common.constant.LevelStudent;
import com.topica.adapter.common.constant.SubjectType;
import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.dto.RoomPresentDTO;
import com.topica.adapter.common.dto.response.RoomPresentResponse;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.exception.RoomError;
import com.topica.adapter.common.model.portal.LevelClassMapping;
import com.topica.adapter.common.request.LevelClassMappingRequest;
import com.topica.adapter.common.service.levelClassMapping.LevelClassMappingService;
import com.topica.adapter.common.service.levelClassMapping.levelClassMappingImpl.LevelClassMappingServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static com.topica.adapter.common.constant.LevelStudent.basic;
import static com.topica.adapter.common.constant.LevelStudent.sbasic;
import static com.topica.adapter.common.constant.LevelStudent.starter;
import static com.topica.adapter.common.constant.SubjectType.*;
import static com.topica.adapter.common.dto.RoomDTO.ADB;

@Slf4j
@Component
public class RoomUtil {

  @Autowired
  private LevelClassMappingService levelClassMappingService;

  public static RoomPresentResponse convertToRoomPresent(List<RoomPresentDTO> roomPresentDTOS, RoomDTO joinedRoom) {
    if (CollectionUtils.isEmpty(roomPresentDTOS)) {
      return RoomPresentResponse.builder()
              .nextTime(0)
              .nextHourStart(0)
              .recentRoom(joinedRoom)
              .build();
    }

    int nextHourStart = nextHourStart();
    long nextTime = getNextTimeOfRoomPersent(roomPresentDTOS.get(0).getTimeavailable());

    RoomPresentResponse.RoomPresentResponseBuilder responseBuilder = RoomPresentResponse.builder();
    responseBuilder
            .nextTime(nextTime)
            .hourStart(roomPresentDTOS.get(0).getHourStart())
            .nextHourStart(nextHourStart);

    Map<SubjectType, RoomPresentDTO> content = new LinkedHashMap<>();
    for (RoomPresentDTO room : roomPresentDTOS) {
      if (SC == SubjectType.valueOf(room.getTypeClass()) && sbasic == LevelStudent.of(room.getLevelClass())) {
        room.setTypeClass(SN.name());
        content.put(SN, room);
      }
      if (LS.toString().equals(room.getTypeClass())) {
        content.put(LS, room);
      }
      if (SubjectType.ORI.toString().equals(room.getTypeClass())) {
        content.put(SubjectType.ORI, room);
      }
      if (SC.toString().equals(room.getTypeClass())) {
        content.put(SC, room);
      }
      concatLinkMaterial(room);
    }
    return responseBuilder
            .content(content)
            .recentRoom(joinedRoom)
            .build();
  }

  public static int toHour(Long timeAvailable) {
    Calendar cal = Calendar.getInstance();
    cal.setTimeInMillis(timeAvailable * 1000);
    return cal.get(Calendar.HOUR_OF_DAY);
  }

  public static void concatLinkMaterial(RoomPresentDTO room) {
    String imageUrl = room.getBackground();
    String fileUrl = room.getFileUrl();
    if (!StringUtils.isEmpty(imageUrl) && !StringUtils.isEmpty(fileUrl)) {
      room.setImageUrl(fileUrl + "/" + imageUrl);
    }
  }

  public static Long getTimeAvailableToSeconds() {
    Calendar cal = Calendar.getInstance();
    int hour = cal.get(Calendar.HOUR_OF_DAY);
    int minute = cal.get(Calendar.MINUTE);

    if(minute >= 45) {
      hour++;
    }

    cal.set(Calendar.HOUR_OF_DAY, hour);
    cal.clear(Calendar.MINUTE);
    cal.clear(Calendar.SECOND);
    cal.clear(Calendar.MILLISECOND);
    return cal.getTimeInMillis() / 1000;
  }

  public static Long getTimeAvailableOfNextSession() {
    Calendar cal = Calendar.getInstance();
    int hour = cal.get(Calendar.HOUR_OF_DAY);
    cal.set(Calendar.HOUR_OF_DAY, ++hour);
    cal.clear(Calendar.MINUTE);
    cal.clear(Calendar.SECOND);
    cal.clear(Calendar.MILLISECOND);
    return cal.getTimeInMillis() / 1000;
  }

  public static long getNextTimeOfRoomPersent(Long nextTimeAvailable) {
    if(nextTimeAvailable == null) return 0;
    long remainTime = nextTimeAvailable - (System.currentTimeMillis()/1000);
    return remainTime > 0 ? remainTime : remainTimeToNextHour();
  }

  public static int nextHourStart() {
    Calendar cal = Calendar.getInstance();
    int hour = cal.get(Calendar.HOUR_OF_DAY);
    int minute = cal.get(Calendar.MINUTE);

    if(minute >= 45) {
      hour++;
    }
    return hour;
  }

  public static long remainTimeToNextHour() {
    Calendar cal = Calendar.getInstance();
    int hour = cal.get(Calendar.HOUR_OF_DAY);

    cal.set(Calendar.HOUR_OF_DAY, ++hour);
    cal.clear(Calendar.MINUTE);
    cal.clear(Calendar.SECOND);
    cal.clear(Calendar.MILLISECOND);

    return cal.getTimeInMillis()/1000 - System.currentTimeMillis()/1000;
  }

  public static String getLSLevelClassVip(String userLevel){
    switch (LevelStudent.of(userLevel.toLowerCase())) {
      case sbasic:
      case basic:
      case basic1:
      case basic23: return basic.name();
      default: return userLevel;
    }
  }

  public static String checkTypeClass(String classType){
    if (SN == SubjectType.getEnum(classType)) {
      return SC.name();
    }
    return classType;
  }

  public static String getTeacherType(String packageCode, String classType) {
    if (isTENUPPackage(packageCode)) {
      return getTeacherTypeTenup(classType);
    }
    return getTeacherTypeSimple(classType);
  }

  public static String getLevelClass(String packageCode, String classType, String levelClass) {
    if (isTENUPPackage(packageCode)) {
      return getLevelClassForTENUP(classType, levelClass);

    }
    if(isStarter(levelClass)) {
      return getLevelClassStarter(classType, levelClass);
    }
    return levelClass;
  }

//  public String getLevelClass(String packageCode, String classType, String levelUser) {
//    LevelClassMappingRequest request = LevelClassMappingRequest.builder()
//            .packageParent(packageCode)
//            .typeClass(classType)
//            .levelUser(levelUser)
//            .build();
//    LevelClassMapping levelClassMapping = levelClassMappingService.getLevelClass(request);
//    if (levelClassMapping == null) {
//      return levelUser;
//    }
//    return levelClassMapping.getLevelClass();
//  }

  public static boolean isStarter(String level) {
    return !StringUtils.isEmpty(level) && LevelStudent.starter.name().equalsIgnoreCase(level);
  }

  public static boolean isTENUPPackage(String packageCode) {
    return !org.springframework.util.StringUtils.isEmpty(packageCode) && packageCode.toLowerCase().contains("tenup");
  }

  public static void checkTimeToJoin() throws BusinessException {
    if(!TimeUtil.isEnableJoinClass() && !TimeUtil.isTimeToQuickJoinClass()) {
      throw new BusinessException(RoomError.INVALID_TIME_JOIN, "Invalid Time Join Class");
    }
    if(TimeUtil.isTimeToQuickJoinClass()) {
      throw new BusinessException(RoomError.INVALID_TIME_QUICK_JOIN, "Time to Quick Join Class");
    }
  }

  public static void checkTimeToQuickJoin() throws BusinessException {
    if(!TimeUtil.isEnableQuickJoinClass()) {
      throw new BusinessException(RoomError.INVALID_TIME_JOIN, "Invalid Time Join Class");
    }
  }

  public static String getTeacherTypeSimple(String classType) {
    switch (SubjectType.getEnum(classType)){
      case SC: return "VN";
      case LS: return "AM";
      default: return "";
    }
  }

  public static String getTeacherTypeTenup(String classType) {
    if (SC == SubjectType.getEnum(classType)) {
      return "VN";
    }
    return "PHI";
  }

  public static String getLevelClassForTENUP(String classType, String levelClass) {
    switch (SubjectType.getEnum(classType)) {
      case LS:
        if(sbasic == LevelStudent.of(levelClass)) {
          return basic.name();
        }
        if(starter == LevelStudent.of(levelClass)) {
          return basic.name();
        }
      case SC:
      default: return levelClass;
    }
  }

  public static String getLevelClassStarter(String classType, String levelClass) {
    switch (SubjectType.getEnum(classType)) {
      case LS: return sbasic.name();
      case SC:
      default: return levelClass;
    }
  }

  public static boolean isRoomSN(String level, String classType) {
    return sbasic == LevelStudent.of(level) && !LS.name().equalsIgnoreCase(classType);
  }

  public static boolean isNotBBBRoom(RoomDTO room) {
    return room.isVCRX() || ADB.equalsIgnoreCase(room.getVcrType());
  }

  public static boolean isNotBBBRoom(RoomPresentDTO room) {
    return room.isVCRX() || ADB.equalsIgnoreCase(room.getVcrType());
  }
}