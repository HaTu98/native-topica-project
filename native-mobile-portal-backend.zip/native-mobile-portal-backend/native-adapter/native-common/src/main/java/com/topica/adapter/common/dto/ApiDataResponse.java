package com.topica.adapter.common.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.topica.adapter.common.util.Messages;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

@AllArgsConstructor
@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ApiDataResponse<T> {
    private static @Autowired Messages messages;
    private T data;
    private int code;
    private String message;

    public ApiDataResponse(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public static ApiDataResponse ok(Object data) {
        return new ApiDataResponse(data, HttpStatus.OK.value(), "successful");
    }

    public static ApiDataResponse error(int statusCode, String message) {
        return new ApiDataResponse(null, statusCode, message);
    }

    public static ApiDataResponse error(Object data, int statusCode) {
        return new ApiDataResponse(data, statusCode, "");
    }

    public static ApiDataResponse error(Object data, int statusCode, String message) {
        return new ApiDataResponse(data, statusCode, message);
    }

	
}
