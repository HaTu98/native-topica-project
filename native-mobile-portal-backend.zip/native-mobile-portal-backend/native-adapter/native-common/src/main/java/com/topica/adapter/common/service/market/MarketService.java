package com.topica.adapter.common.service.market;

import com.topica.adapter.common.constant.ServiceType;
import com.topica.adapter.common.dto.PackageDTO;
import com.topica.adapter.common.dto.PersonalInfoDTO;

import java.util.List;

public interface MarketService {
    List<PackageDTO> getPackageByContactId(String contactId, ServiceType type);
    <P extends PersonalInfoDTO> P setPackages(P input, ServiceType type);
}
