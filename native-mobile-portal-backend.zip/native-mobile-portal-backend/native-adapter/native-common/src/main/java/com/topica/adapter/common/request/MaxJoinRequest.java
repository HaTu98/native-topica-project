package com.topica.adapter.common.request;

import lombok.Data;

@Data
public class MaxJoinRequest {
    private String packageType;
    private String levelClass;
    private String typeClass;
    private Integer maxUser;
}
