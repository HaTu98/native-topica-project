package com.topica.adapter.common.repository.portal;

import com.amazonaws.services.dynamodbv2.xspec.L;
import com.topica.adapter.common.model.portal.LevelClassMapping;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LevelClassMappingRepository extends JpaRepository<LevelClassMapping, Long> {
    List<LevelClassMapping> findByPackageParentAndTypeClassAndLevelUser(String packageParent, String typeClass, String levelUser);
}
