package com.topica.adapter.common.util;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.UUID;

/**
 * Created by ico on 9/26/17.
 */
public class StringUtil {

  public static String getFirstPart(String input, String delimiter) {
    String[] parts = input.split(delimiter);
    if (parts.length > 0) {
      return parts[0];
    } else {
      return "N/A";
    }
  }

  public static String generateRandomUuid(String prefix) {
    if (prefix == null) {
      prefix = "_";
    }
    return prefix + "_" + UUID.randomUUID().toString();
  }

  public static String format(int min, int max, String input) {
    if (input.length() > max) {
      return input.substring(0, max - 3) + "...";
    }

    return input;
  }

  public static String toString(InputStream inputStream) throws IOException {
    StringBuilder textBuilder = new StringBuilder();
    try (Reader reader = new BufferedReader(new InputStreamReader
        (inputStream, Charset.forName(StandardCharsets.UTF_8.name())))) {
      int c = 0;
      while ((c = reader.read()) != -1) {
        textBuilder.append((char) c);
      }
    }
    return textBuilder.toString();
  }

  public static String toString(List<String> stringList) {
    String result = "";
    int index = 0;
    for (String string : stringList) {
      if (index != 0) {
        result += ", " + string;
      } else {
        result += string;
      }
      index++;
    }
    return result;
  }

  public static String hashInfo(String info, String token) {
    return bytesToHex(hash(info, token));
  }

  private static byte[] hash(String info, String token) {
    try {
      MessageDigest digest = MessageDigest.getInstance("SHA-256");

      return digest.digest((info + token).getBytes("UTF-8"));
    } catch (UnsupportedEncodingException | NoSuchAlgorithmException e) {
      return null;
    }
  }

  private static String bytesToHex(byte[] hash) {
    StringBuffer hexString = new StringBuffer();
    for (int i = 0; i < hash.length; i++) {
      String hex = Integer.toHexString(0xff & hash[i]);
      if (hex.length() == 1) hexString.append('0');
      hexString.append(hex);
    }
    return hexString.toString();
  }

}
