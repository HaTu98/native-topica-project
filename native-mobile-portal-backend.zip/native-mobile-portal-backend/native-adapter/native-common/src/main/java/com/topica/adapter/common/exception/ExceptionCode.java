package com.topica.adapter.common.exception;

public interface ExceptionCode {

	// 	From 300
	public static final Integer BAD_REQUEST = 300;
	public static final Integer CONSTRAINT_VIOLATION = 301;
	public static final Integer METHOD_ARGUMENT_TYPE_MISMATCH = 304;
	public static final Integer ERROR_RUNTIME = 305;

	// From 400
	public interface Authentication {
		static final Integer AUTHENTICATION_USER_PASSWORD_INVALID = 400;
		static final Integer AUTHENTICATION_USER_INACTIVE = 401;
		static final Integer AUTHENTICATION_CATPCHAR_IS_REQUIRED = 402;
		static final Integer AUTHENTICATION_CATPCHAR_IS_INVALID = 403;
		static final Integer REQUEST_INVALID = 404;
		static final Integer REQUEST_SESSION_IS_INVALID = 405;
		static final Integer AUTHENTICATION_TOKEN_INVALID = 406;
		static final Integer AUTHENTICATION_GEN_INVALID = 2509;
	}

	// From 500
	public interface User {
		public static final Integer USER_NOT_FOUND = 500;
		public static final Integer INCORRECT_PASSWORD = 501;
	}

	// From 600
	public interface UploadFile {
		public static final Integer UPLOAD_FILE_ERROR = 600;
	}
}
