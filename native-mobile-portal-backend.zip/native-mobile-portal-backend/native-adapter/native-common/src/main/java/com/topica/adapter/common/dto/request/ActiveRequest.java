package com.topica.adapter.common.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ActiveRequest {

  @JsonProperty("user_id")
  private Long userId;

  @JsonProperty("product_id")
  private Long productId;

  @JsonProperty("cat_code")
  private String catCode;

  @JsonProperty("package_parent")
  private String packageParent;

  @JsonProperty("gen_code")
  private String genCode;
}