package com.topica.adapter.common.service.room;

import com.topica.adapter.common.constant.SubjectType;
import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.dto.response.JoinRoomResponse;
import com.topica.adapter.common.exception.BusinessException;

import java.util.Optional;

public interface JoinRoomMaker {

    default JoinRoomResponse reJoin(RoomDTO joinedRoom) throws BusinessException {
        return this.joinInto(joinedRoom);
    }

    default JoinRoomResponse join(RoomDTO targetRoom) throws BusinessException {
        this.validRoom(targetRoom);
        return this.joinInto(targetRoom);
    }

    default JoinRoomResponse quickJoin(SubjectType subjectType) throws BusinessException {
        Optional<RoomDTO> targetRoom = this.findTargetRoom(subjectType);
        if(targetRoom.isPresent()) {
            return this.joinInto(targetRoom.get());
        }
        return JoinRoomResponse.empty;
    }

    boolean validRoom(RoomDTO targetRoom) throws BusinessException;
    Optional<RoomDTO> findTargetRoom(SubjectType type) throws BusinessException;
    JoinRoomResponse joinInto(RoomDTO targetRoom) throws BusinessException;
    void alertFullUser(SubjectType subjectType);
}