package com.topica.adapter.common.service.LearningGoalNew.learningGoalImpl;

import com.topica.adapter.common.model.portal.LearningGoalStep;
import com.topica.adapter.common.repository.portal.LearningGoalStepRepository;
import com.topica.adapter.common.service.LearningGoalNew.LearningGoalStepService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StepServiceImpl implements LearningGoalStepService {
    @Autowired
    private LearningGoalStepRepository stepRepository;

    @Override
    public List<LearningGoalStep> getAllStep() {
        return stepRepository.findAll();
    }

    @Override
    public List<LearningGoalStep> getAllStepActive() {
        return stepRepository.findByStepStatusIsTrue();
    }


}
