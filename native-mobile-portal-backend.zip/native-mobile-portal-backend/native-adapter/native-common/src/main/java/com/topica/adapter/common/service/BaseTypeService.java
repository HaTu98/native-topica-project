package com.topica.adapter.common.service;

import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.model.PortalMdlUser;
import org.springframework.http.HttpStatus;

public abstract class BaseTypeService<S> extends BaseUserSessionService{

    protected boolean checkActivePackage() throws BusinessException {
        PortalMdlUser user = this.getUserSession();
        if(!user.isActivedPackage()) {
            throw new BusinessException(HttpStatus.BAD_REQUEST.value(), "No package actived");
        }
        return true;
    }

    public S getService() throws BusinessException {
        PortalMdlUser userSession = this.getUserSession();
        switch (userSession.getServiceType()) {
            case LMS: return simpleService();
            case LMS_WEB: return simpleWebService();
            case LMS_VIP: return vipService();
            default:
                throw new BusinessException(HttpStatus.BAD_REQUEST.value(), "No service for: " + userSession.getServiceType().toString());
        }
    }

    public abstract S vipService();
    public abstract S simpleService();
    public abstract S simpleWebService();
}
