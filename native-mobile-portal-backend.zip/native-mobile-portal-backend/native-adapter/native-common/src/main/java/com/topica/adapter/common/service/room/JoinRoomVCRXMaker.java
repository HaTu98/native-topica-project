package com.topica.adapter.common.service.room;

import com.topica.adapter.common.constant.SubjectType;
import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.dto.response.JoinRoomResponse;
import com.topica.adapter.common.exception.BusinessException;

public interface JoinRoomVCRXMaker {
    JoinRoomResponse join(RoomDTO targetRoom) throws BusinessException;
    JoinRoomResponse quickJoin(SubjectType subjectType) throws BusinessException;
}
