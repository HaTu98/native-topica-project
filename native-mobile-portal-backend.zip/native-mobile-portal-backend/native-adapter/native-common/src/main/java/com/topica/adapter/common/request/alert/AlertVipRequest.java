package com.topica.adapter.common.request.alert;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AlertVipRequest implements AlertRequest{
    private Long userId;
    private String userEmail;
    private String typeClass;
    private String levelUser;

    @Override
    @JsonIgnore
    public Object getContent() {
        return this;
    }
}