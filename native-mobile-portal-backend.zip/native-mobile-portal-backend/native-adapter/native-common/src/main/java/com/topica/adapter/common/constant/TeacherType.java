package com.topica.adapter.common.constant;

public enum TeacherType {
    AM, PHI, VN
}
