package com.topica.adapter.common.service.course;

import com.topica.adapter.common.dto.MarketPackage;
import com.topica.adapter.common.dto.request.ActiveRequest;
import com.topica.adapter.common.dto.response.GetPackageResponse;
import com.topica.adapter.common.exception.BusinessException;

import java.util.List;
import java.util.Optional;

public interface PackageServicePortal {
  Optional<GetPackageResponse> getListPackage() throws BusinessException;
  Optional<Boolean> activePackage(ActiveRequest request) throws BusinessException;
  List<MarketPackage> isCanActive() throws BusinessException;
}
