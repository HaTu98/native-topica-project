package com.topica.adapter.common.service;

import com.topica.adapter.common.model.PortalMdlUser;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

public class BaseUserSessionService {

    protected Authentication getAuthentication() {
        return SecurityContextHolder.getContext().getAuthentication();
    }

    protected PortalMdlUser getUserSession() {
        return (PortalMdlUser) this.getAuthentication().getPrincipal();
    }
}