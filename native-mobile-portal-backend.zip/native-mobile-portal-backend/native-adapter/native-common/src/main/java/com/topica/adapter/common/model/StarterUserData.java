package com.topica.adapter.common.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class StarterUserData {
    private Long userId;
    private String userName;
    private String level;
    private String firstName;
    private String lastName;
    private String packageParent;
    private String packageStatus;
    private String avatar;
}
