package com.topica.adapter.common.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PackageDetailDTO {
    private String catCode;
    private String packageName;
    private String packageCode;
    private String packageParent;
    private String imgLink;
}