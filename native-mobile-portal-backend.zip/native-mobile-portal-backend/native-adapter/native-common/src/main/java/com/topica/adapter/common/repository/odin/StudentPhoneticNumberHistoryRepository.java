package com.topica.adapter.common.repository.odin;

import com.topica.adapter.common.model.odin.StudentPhoneticNumberHistory;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StudentPhoneticNumberHistoryRepository extends JpaRepository<StudentPhoneticNumberHistory, Long> {

  @Query(value = "select spnh from StudentPhoneticNumberHistory spnh " +
      "join spnh.learningObject " +
      "where spnh.studentId = :studentId " +
      "and spnh.numberType = :numberType " +
      "and spnh.createdDateId = :createdDateId " +
      "order by spnh.learningObjectNumber desc," +
      "spnh.learningLastDateId desc ")
  List<StudentPhoneticNumberHistory> findTopByStudentIdAndNumberType(@Param("studentId") Long studentId,
                                                                     @Param("numberType") int numberType,
                                                                     @Param("createdDateId") Long createdDateId,
                                                                     Pageable pageable);
}
