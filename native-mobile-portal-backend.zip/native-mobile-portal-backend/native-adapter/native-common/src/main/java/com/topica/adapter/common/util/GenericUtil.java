package com.topica.adapter.common.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Map;

public class GenericUtil<U> {

  public Map<String, String> toMap(U object) {
    ObjectMapper mapper = new ObjectMapper();
    return mapper.convertValue(object, Map.class);
  }
}
