package com.topica.adapter.common.model.portal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@AllArgsConstructor
@Data
@Entity
@NoArgsConstructor
@Table(name = "question_learning_goal")
@Builder
public class QuestionLearningGoal {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "content_vn")
    private String contentVN;

    @Column(name = "content_en")
    private String contentEN;

    @Column(name = "description")
    private String description;

    @Column(name = "image")
    private String image;

    @Column(name = "step")
    private Integer step;
}
