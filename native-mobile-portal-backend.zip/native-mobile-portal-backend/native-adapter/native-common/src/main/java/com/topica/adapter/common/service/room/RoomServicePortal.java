package com.topica.adapter.common.service.room;

import com.topica.adapter.common.constant.SubjectType;
import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.dto.response.JoinRoomResponse;
import com.topica.adapter.common.dto.response.RoomPresentResponse;
import com.topica.adapter.common.exception.BusinessException;

import java.util.List;
import java.util.Optional;

public interface RoomServicePortal {

    RoomDTO getJoinedRoom () throws BusinessException;

    RoomPresentResponse presentRoom() throws BusinessException;

    List<RoomDTO> listRoom(String classType) throws BusinessException;

    Optional<RoomDTO> getRoom(Long classId) throws BusinessException;

    JoinRoomResponse reJoinRoom(RoomDTO joinedRoom) throws BusinessException;

    JoinRoomResponse quickJoinRoom(SubjectType subjectType) throws BusinessException;

    JoinRoomResponse quickJoinRoomAudit(SubjectType subjectType) throws BusinessException;

    JoinRoomResponse joinRoom(Long classId) throws BusinessException;

    List<RoomDTO> getAllRoomByTime(Long timeAvailable) throws BusinessException;
}