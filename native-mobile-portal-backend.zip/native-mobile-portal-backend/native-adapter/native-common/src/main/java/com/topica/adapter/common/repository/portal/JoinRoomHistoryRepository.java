package com.topica.adapter.common.repository.portal;

import com.topica.adapter.common.model.portal.JoinRoomHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface JoinRoomHistoryRepository extends JpaRepository<JoinRoomHistory, Long> {

    List<JoinRoomHistory> findByUserIdAndServiceTypeAndTimeAvailableOrderByCreatedTimeDesc(Long userId, String serviceType, Long timeAvailable);
}
