package com.topica.adapter.common.service.LearningGoalNew.learningGoalImpl;

import com.topica.adapter.common.model.portal.LevelStudy;
import com.topica.adapter.common.repository.portal.LevelStudyRepository;
import com.topica.adapter.common.service.LearningGoalNew.LevelStudyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LevelStudyServiceImpl implements LevelStudyService {
    @Autowired
    private LevelStudyRepository levelStudyRepository;

    @Override
    public List<LevelStudy> getAllLevelUser() {
        return levelStudyRepository.findAll();
    }

    @Override
    public LevelStudy getLevelValue(String content) {
        return levelStudyRepository.findByContent(content);
    }

    @Override
    public LevelStudy getLevelContent(String value) {
        return levelStudyRepository.findByValue(value);
    }
}
