package com.topica.adapter.common.util;

import com.topica.adapter.common.constant.GoalLevel;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class MappingLevelUtil {
    public static GoalLevel mappingLevelAdvisor(String value) {
        switch (value){
            case "starter" : return GoalLevel.STARTER;
            case "sbasic" : return GoalLevel.SUPER_BASIC;
            case "basic" :
            case "basic100" : return GoalLevel.BASIC_100;
            case "basic200" : return GoalLevel.BASIC_200;
            case "basic300" : return GoalLevel.BASIC_300;
            case  "inter" :
            case  "inter100" : return  GoalLevel.INTERMEDIATE_100;
            case  "inter200" : return  GoalLevel.INTERMEDIATE_200;
            case  "inter300" : return  GoalLevel.INTERMEDIATE_300;
            case  "advan100" :
            case "advan200" :
            case "advan300" : return GoalLevel.ADVANCED;
            default:
                log.error("Unexpected value: {}", value);
                return GoalLevel.STARTER;
        }
    }


}
