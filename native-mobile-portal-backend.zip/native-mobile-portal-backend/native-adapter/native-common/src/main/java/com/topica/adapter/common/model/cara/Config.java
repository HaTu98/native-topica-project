package com.topica.adapter.common.model.cara;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Data
@NoArgsConstructor
public class Config {
  private Long id;
  private String key;
  private String value;
  private String description;
  private Long createdDate;
  private Boolean active;
}
