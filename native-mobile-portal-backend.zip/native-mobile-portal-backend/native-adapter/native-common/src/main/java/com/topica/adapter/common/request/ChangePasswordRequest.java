package com.topica.adapter.common.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ChangePasswordRequest {
  @ApiModelProperty(value = "oldPassword")
  private String oldPassword;
  @ApiModelProperty(value = "newPassword")
  private String newPassword;
}
