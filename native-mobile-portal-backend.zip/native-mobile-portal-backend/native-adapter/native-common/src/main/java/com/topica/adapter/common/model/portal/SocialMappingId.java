package com.topica.adapter.common.model.portal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SocialMappingId implements Serializable {
    @Id
    @Column(name = "user_id")
    private long userId;

    @Id
    @Column(name = "service_type")
    private String serviceType;

    @Id
    @Column(name = "social_type")
    private String socialType;

    @Id
    @Column(name = "social_id")
    private String socialId;

    @Override
    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;
        SocialMappingId that = (SocialMappingId) object;
        return userId == that.userId &&
                Objects.equals(serviceType, that.serviceType) &&
                Objects.equals(socialType, that.socialType) &&
                Objects.equals(socialId, that.socialId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(userId, serviceType, socialType, socialId);
    }
}
