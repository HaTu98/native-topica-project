package com.topica.adapter.common.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateInfoRequest {
  @ApiModelProperty(value = "firstName")
  private String firstName;
  @ApiModelProperty(value = "lastName")
  private String lastName;
  @ApiModelProperty(value = "email")
  private String email;
  @ApiModelProperty(value = "phone")
  private String phone;
  @ApiModelProperty(value = "birthday")
  private String birthday;
  @ApiModelProperty(value = "gender")
  private String gender;
  @ApiModelProperty(value = "password")
  private String password;
}
