package com.topica.adapter.common.dto;

public abstract class ExternalLog {
}
