package com.topica.adapter.common.util;

import org.springframework.beans.factory.annotation.Value;

import java.util.LinkedHashMap;
import java.util.Map;

public class ConfigInfoUtil {

	   @Value("${domain.lmsvip}")
	    private  String lmsvipDomain;
	   
	   @Value("${domain.lmsvip.link.adb}")
	    private  String lmsvipLinkAdobe;
	   
	   @Value("${domain.lmsvip.adb.roompresent}")
	    private  String lmsvipRoomRecent;

public  Object configInfo() {
	
	Map<Object, Object> configInfo = new LinkedHashMap<>();
	Map<String, String> lms = new LinkedHashMap<>();
	Map<String, String> lmsvip = new LinkedHashMap<>();
	lmsvip.put("lmsvipDomain", lmsvipDomain);
	lmsvip.put("lmsvipLinkAdobe", lmsvipDomain);
	lmsvip.put("lmsvipRoomRecent", lmsvipDomain);
	configInfo.put("lmsvip", lmsvip);
	configInfo.put("lms", lms);
	return configInfo;
}

}
