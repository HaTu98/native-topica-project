package com.topica.adapter.common.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GetSmileStudentResponse {
  private Integer status;
  private String message;
  private String student_id;
}
