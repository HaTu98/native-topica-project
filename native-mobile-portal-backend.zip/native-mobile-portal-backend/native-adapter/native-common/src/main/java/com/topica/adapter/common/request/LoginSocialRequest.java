package com.topica.adapter.common.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.topica.adapter.common.constant.ServiceType;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class LoginSocialRequest {

  @JsonProperty("access_token")
  private String accessToken;

  @ApiModelProperty(value = "ServiceType")
  private ServiceType serviceType;

  @ApiModelProperty(value = "device")
  private String device;
  @ApiModelProperty(value = "appVersion")
  private String appVersion;
  @ApiModelProperty(value = "deviceId")
  private String deviceId;
  @ApiModelProperty(value = "operatingSystem")
  private String operatingSystem;
  @ApiModelProperty(value = "deviceToken")
  private String deviceToken;
}
