package com.topica.adapter.common.model.cara;

import java.util.List;

import com.topica.adapter.common.constant.CaraRateType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Data
@NoArgsConstructor
public class RateFromClient {

  private Long userId;
  private Integer rateValue;
  private String rateComment;
  private List<CaraRateType> extraInfos;
}
