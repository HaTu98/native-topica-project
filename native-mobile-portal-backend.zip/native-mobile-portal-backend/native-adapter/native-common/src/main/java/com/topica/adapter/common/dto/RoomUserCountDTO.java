package com.topica.adapter.common.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Data
@NoArgsConstructor
public class RoomUserCountDTO {
  private Long roomId;

  private long totalJoin;
}
