package com.topica.adapter.common.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.util.AdobeUtil;
import com.topica.adapter.common.util.RoomUtil;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.util.StringUtils;

import static com.topica.adapter.common.dto.RoomDTO.ADB;
import static com.topica.adapter.common.dto.RoomDTO.BBB;
import static com.topica.adapter.common.dto.RoomDTO.VCRX;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class JoinRoomResponse {
    public static JoinRoomResponse empty = new JoinRoomResponse();

    private Long roomId;
    private Long ticketId;
    private String vcrType;
    private String link;
    private boolean useDeeplink;
    private String deeplink;
    private String message;
    private String errorMessage;
    private String role;
    private Long createdTime;
    private JoinRoomVCRXRespose.Result data;

    public JoinRoomResponse(JoinRoomVCRXRespose.Result data, RoomDTO targetRoom) {
        this.data = data;
        this.data.setClassId(targetRoom.getId());
        this.data.setClassIdVcrx(targetRoom.getClassIdVcrx());
        this.data.setTimeAvailable(RoomUtil.getTimeAvailableToSeconds());
        this.roomId = targetRoom.getId();
    }

    public JoinRoomResponse toVCRX(RoomDTO targetRoom) {
        if(StringUtils.isEmpty(this.getLink())) {
            return JoinRoomResponse.empty;
        }
        this.setRoomId(targetRoom.getId());
        this.setRole(targetRoom.getRole());
        this.setVcrType(VCRX);
        this.setData(new JoinRoomVCRXRespose.Result());
        this.getData().setClassIdVcrx(targetRoom.getClassIdVcrx());
        this.getData().setClassId(targetRoom.getId());
        this.getData().setStatus(true);
        this.setTicketId(targetRoom.getTicketId());
        return this;
    }

    public JoinRoomResponse toAdobe(RoomDTO targetRoom, boolean useDeeplink) {
        if(StringUtils.isEmpty(this.getLink())) {
            return JoinRoomResponse.empty;
        }
        this.setVcrType(ADB);
        this.setRoomId(targetRoom.getId());
        this.setTicketId(targetRoom.getTicketId());
        this.setRole(targetRoom.getRole());
        if(!useDeeplink) {
            return this;
        }
        String deepLink = AdobeUtil.getDeepLink(this.getLink());
        if(!StringUtils.isEmpty(deepLink)) {
            this.setDeeplink(deepLink);
            this.setUseDeeplink(true);
        }
        return this;
    }

    public JoinRoomResponse toBBB(RoomDTO targetRoom) {
        if(StringUtils.isEmpty(this.getLink())) {
            return JoinRoomResponse.empty;
        }
        this.setRoomId(targetRoom.getId());
        this.setTicketId(targetRoom.getTicketId());
        this.setVcrType(BBB);
        this.setRole(targetRoom.getRole());
        return this;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class JoinRoomDataRes {
        private Boolean success;
        private JoinRoomResponse data;
    }
}
