package com.topica.adapter.common.config.room;

import com.topica.portal.redis.service.config.ConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ErrorMessageConfig {
    public static String INVALID_GEN = "INVALID_GEN";
    public static String PACKAGE_EXPIRED = "PACKAGE_EXPIRED";
    public static String PACKAGE_DEACTIVED = "PACKAGE_DEACTIVED";
    public static String DEFAULT_PACKAGE_EXPIRED = "Tài khoản của bạn đã hết hạn";
    public static String DEFAULT_PACKAGE_DEACTIVED = "Tài khoản của bạn đang tạm khóa";
    public static String DEFAULT_INVALID_GEN = "Tài khoản của bạn không được sử dụng tính năng này. Vui lòng nâng cấp gói học để được trải nghiệm";

    @Autowired
    private ConfigService configService;

    public String getByKey(String key) {
        return configService.getFromRemote(key);
    }
}