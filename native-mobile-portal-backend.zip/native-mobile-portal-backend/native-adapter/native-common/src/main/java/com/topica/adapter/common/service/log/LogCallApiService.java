package com.topica.adapter.common.service.log;

import com.topica.adapter.common.model.portal.LogCallApi;

public interface LogCallApiService {
    void save(LogCallApi log);
}
