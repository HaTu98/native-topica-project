package com.topica.adapter.common.constant;

public enum ServiceType {
	LMS, LMS_VIP, TENUP, LMS_WEB, LMS_VIP_WEB
}
