package com.topica.adapter.common.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FilterQuestionRequest {

  private String topicId;
  private String status;
  private String attach;
}
