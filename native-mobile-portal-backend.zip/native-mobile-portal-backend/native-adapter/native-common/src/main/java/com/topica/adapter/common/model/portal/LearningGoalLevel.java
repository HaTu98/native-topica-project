package com.topica.adapter.common.model.portal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "learning_goal_level")
public class LearningGoalLevel {
    @Id
    @Column(name = "student_level_id")
    private Long studentLevelId;

    @Column(name = "student_level_name")
    private String studentLevelName;

    @Column(name = "phonetic")
    private Integer phonetic;

    @Column(name = "grammar")
    private Integer grammar;

    @Column(name = "vocabulary")
    private Integer vocabulary;

    @Column(name = "bloom")
    private Integer bloom;
}
