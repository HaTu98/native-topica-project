package com.topica.adapter.common.dto.response;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Builder
@Data
@NoArgsConstructor
public class PronounceDetailHistory {
  private List<PronounceDetail> topCorrects;
  private List<PronounceDetail> topWrongs;
}
