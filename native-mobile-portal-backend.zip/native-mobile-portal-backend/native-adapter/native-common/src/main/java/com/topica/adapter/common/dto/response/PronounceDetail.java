package com.topica.adapter.common.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Builder
@Data
@NoArgsConstructor
public class PronounceDetail {
  private String objectName;
  private String transcription;
  private String referenceLink;
}
