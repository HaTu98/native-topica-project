package com.topica.adapter.common.service.LearningGoalNew;

import com.topica.adapter.common.model.portal.LearningGoalLevel;

import java.util.List;

public interface LearningGoalLevelService {
    List<LearningGoalLevel> getAllLevel();

}
