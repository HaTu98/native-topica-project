package com.topica.adapter.common.model.portal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@AllArgsConstructor
@Data
@Entity
@NoArgsConstructor
@Table(name="level_class_mapping")
@Builder
public class LevelClassMapping {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;

    @Column(name = "package_parent")
    private String packageParent;

    @Column(name = "type_class")
    private String typeClass;

    @Column(name = "level_user")
    private String levelUser;

    @Column(name = "level_class")
    private String levelClass;
}
