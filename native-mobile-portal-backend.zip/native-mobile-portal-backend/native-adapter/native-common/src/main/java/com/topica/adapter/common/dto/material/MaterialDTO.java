package com.topica.adapter.common.dto.material;

import com.topica.adapter.common.constant.SubjectType;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class MaterialDTO {
    private Long id;
    private SubjectType subjectType;
    private String objective;
    private String topic;
    private String subject;
    private String classOutline;
    private String fileurl;
    private String outlineHomework;
    private String lessonPlan;
    private String videoWarmup;
    private String background;
    private Long timeBegin;
    private String teacherType;
    private String levelOutline;
    private String code;

    public SubjectType getSubjectType() {
        return subjectType;
    }


}
