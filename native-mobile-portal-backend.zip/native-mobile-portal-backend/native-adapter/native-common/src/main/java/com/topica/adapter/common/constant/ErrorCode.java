package com.topica.adapter.common.constant;

import lombok.Getter;

@Getter
public enum ErrorCode {
  SUCCESS(200, "Request success"),

  BAD_REQUEST(400, "Bad request"),
  FORBIDDEN(403, "Forbidden"),

  SYSTEM_ERROR(500, "System error"),

  INVALID_TOKEN(600, "Invalid token"),
  INVALID_APPLICATION(601, "Invalid application"),

  MEMBER_DEACTIVATED(603, "Member has been deactivated"),

  INVALID_SOCIAL_ACCESS_TOKEN(610, "Invalid social access token"),

  ACCOUNT_ALREADY_EXISTS(701, "Account already exists"),
  ACCOUNT_IS_NOT_LINKED(700, "Account is not linked");

  private int code;
  private String message;

  ErrorCode(int code, String message) {
    this.code = code;
    this.message = message;
  }
}
