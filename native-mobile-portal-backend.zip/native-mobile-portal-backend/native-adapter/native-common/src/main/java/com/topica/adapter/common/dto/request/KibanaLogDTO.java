package com.topica.adapter.common.dto.request;

import com.topica.adapter.common.dto.ExternalLog;
import lombok.*;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class KibanaLogDTO extends ExternalLog {
    protected String objectType;
    protected String objectId;
    protected String objectKey;
    protected String objectName;
    protected String objectAttribute;
    protected String actionType;
    protected String actionAttribute;
    protected long actionTime;
    protected String source = "portal_nvn";
    protected String targetType;
    protected String targetId;
    protected String targetKey;
    protected String targetName;
    protected String targetAttribute;
    protected Map<String, Object> customAttribute = new HashMap<>();
}
