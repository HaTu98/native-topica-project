package com.topica.adapter.common.service.LearningGoalNew;

import com.topica.adapter.common.model.portal.LearningGoalOption;

import java.util.List;

public interface LearningGoalOptionService {
    List<LearningGoalOption> getAllOption();
    List<LearningGoalOption> getAllOptionActive();
    List<LearningGoalOption> getAllByOptionId(List<Long> optionIds);
    List<LearningGoalOption> getAllByOptionIdAndStepId(List<Long> optionIds,Long stepId);
    LearningGoalOption getOption(Long optionId);
}
