package com.topica.adapter.common.dto.response;

import com.topica.adapter.common.dto.ApiDataResponse;
import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.util.RoomUtil;
import lombok.Data;
import org.springframework.http.HttpStatus;
import org.springframework.util.CollectionUtils;

import java.util.List;

@Data
public class ListRoomResponse extends ApiDataResponse {

    private long nextTime;

    public ListRoomResponse(List<RoomDTO> roomDTOS) {
        super(roomDTOS, HttpStatus.OK.value(), "successful");

        if(CollectionUtils.isEmpty(roomDTOS)) {
            this.nextTime = RoomUtil.getNextTimeOfRoomPersent(RoomUtil.remainTimeToNextHour());
        } else {
            this.nextTime = RoomUtil.getNextTimeOfRoomPersent(roomDTOS.get(0).getTimeAvailable());
        }
    }
}
