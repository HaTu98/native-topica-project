package com.topica.adapter.common.service.log;

import com.topica.adapter.common.dto.ExternalLog;
import com.topica.adapter.common.service.invoker.InvokerService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

@Service("kibanaLogService")
@Slf4j
public class KibanaLogService implements ExternalLogService {

    @Value("${kibana.url}")
    private String kibanaURL;

    @Value("${kibana.report-key}")
    private String reportKey;

    @Value("${kibana.report-secret}")
    private String reportSecret;

    @Autowired
    private InvokerService invokerService;

    @Override
    public <T extends ExternalLog> T save(T externalLog) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("report-key", reportKey);
        headers.add("report-secret", reportSecret);
        HttpEntity entity = new HttpEntity<>(externalLog, headers);

        invokerService.postHeader(kibanaURL, entity, String.class);
        return externalLog;
    }
}
