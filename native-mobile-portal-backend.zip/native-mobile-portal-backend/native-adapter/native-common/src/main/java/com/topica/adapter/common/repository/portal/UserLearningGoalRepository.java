package com.topica.adapter.common.repository.portal;

import com.topica.adapter.common.model.portal.UserLearningGoal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserLearningGoalRepository extends JpaRepository<UserLearningGoal, Long> {
    List<UserLearningGoal> findByUserId(Long userId);
}
