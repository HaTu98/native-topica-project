package com.topica.adapter.common.request;

import lombok.Data;

@Data
public class TokenVerifyRequest {

	private String username;
	private String token;
	
}
