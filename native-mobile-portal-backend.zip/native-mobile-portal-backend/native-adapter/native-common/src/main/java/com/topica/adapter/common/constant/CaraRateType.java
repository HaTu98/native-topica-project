package com.topica.adapter.common.constant;

public enum CaraRateType {
  TEACHER, PO, MATERIAL, SYSTEM, GENERAL, NONE;

  public static int getCode(CaraRateType caraRateType){
    switch (caraRateType){
      case TEACHER: return 1;
      case PO: return 4;
      case MATERIAL: return 3;
      case SYSTEM: return 2;
      case GENERAL:
      default: return 0;
    }
  }

  public static CaraRateType fromString(String value) {
    for(CaraRateType type: values()) {
      if(type.name().equalsIgnoreCase(value)) {
        return type;
      }
    }
    return NONE;
  }
}