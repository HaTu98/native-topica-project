package com.topica.adapter.common.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum Status {
    ACTIVE("active"),
    DISABLE("disable"),
    REMOVE("remove");

    private final String status;
}
