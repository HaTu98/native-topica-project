package com.topica.adapter.common.service.social;

import com.topica.adapter.common.dto.PersonalInfoDTO;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.model.portal.SocialMapping;
import org.springframework.social.oauth2.GrantType;

public interface BaseProviderService<P> {

    /***
     * Get URI String for client login via social from grant type and redirect uri default by provider
     * @return URI String social login
     * @throws BusinessException throw exception when occur error when generate parameter oauth2
     */
    String createAuthorizationURL() throws BusinessException;

    /***
     * Get URI String for client login via social from grant type and redirect uri
     * @param grantType GrantType
     * @param url Redirect URI
     * @return URI String social login
     * @throws BusinessException throw exception when occur error when generate parameter oauth2
     */
    String createAuthorizationURL(GrantType grantType, String url) throws BusinessException;

    /***
     * Get access token from code and redirect uri default
     * @param code Code from social network service return
     * @return String Access Token
     */
    String getAccessToken(String code);

    /***
     * Get access token from code and redirect uri
     * @param code Code from social network service return
     * @return String Access Token
     */
    String getAccessToken(String code, String uri);

    /***
     * Get user profile from provider object
     * @param providerObject Provider Object to get user profile info
     * @return UserBean of SNS Provider
     * @throws BusinessException throw exception when get user profile from SNS
     */
    PersonalInfoDTO getUserProfile(P providerObject) throws BusinessException;

    /***
     * Get user profile from access token or access token secret
     * @param accessToken access token exchange from code or get from sns
     * @param accessTokenSecret  access token secret
     * @return UserBean of SNS Provider
     * @throws BusinessException throw exception when get user profile from SNS
     */
    PersonalInfoDTO getUserProfile(String accessToken, String accessTokenSecret) throws BusinessException;

    /***
     *
     * @param providerName provider name
     * @return true if sns provider supported else false
     */
    boolean supports(String providerName);

    /**
     * Get user profile sns from access token or token secret
     *
     * @param accessToken       access token exchange from code or get from sns
     * @param accessTokenSecret access token secret
     * @return User profile SNS
     * @throws BusinessException throw exception when get user profile from SNS
     */
    Object getSnsProfile(String accessToken, String accessTokenSecret) throws BusinessException;

    /**
     * SNS user profile
     *
     * @param providerObject provider name
     * @return User profile SNS
     * @throws BusinessException throw exception when get user profile from SNS
     */
    Object getSnsProfile(P providerObject) throws BusinessException;

    /**
     * @param code authentication code from sns
     * @param urlRedirect url callback
     * @return data mapping
     * @throws BusinessException throw exception when get user profile from SNS
     */
    SocialMapping mappingSns(String code, String urlRedirect) throws BusinessException;

    SocialMapping mappingSns(String accessToken) throws BusinessException;

    PersonalInfoDTO getUserProfile(String snsId) throws BusinessException;

    SocialMapping mappingSnsSocialId(String socialId) throws BusinessException;

    void unlinkMapping() throws BusinessException;
}
