package com.topica.adapter.common.constant;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

public class PageUtil {
    public static final Pageable FIRST_RESULT = new PageRequest(0, 1);
    public static final Pageable MAX_RESULT = new PageRequest(0, 2000);
}