package com.topica.adapter.common.service.LearningGoalNew;

public interface LearningGoalOptionMappingService {
}
