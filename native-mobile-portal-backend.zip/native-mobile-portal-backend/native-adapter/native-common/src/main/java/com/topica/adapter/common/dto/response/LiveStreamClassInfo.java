package com.topica.adapter.common.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class LiveStreamClassInfo {
  private Long id;

  private Long dateTime;

  private Long hourStart;

  private Long hourEnd;

  private String firstName;

  private String lastName;

  private String subject;

  private String material;

  private String backupLink;

  private String supportLink;

  private String description;

  private String linkVideo;

  private Long videoStatus;

  private String roomId;

  private Long teacherStatus;

  private String poLink;

  private String firstNameBackup;

  private String lastNameBackup;

  private String objective;

  private String materialMp4;

  private Long hourId;

  private String typeClass;

  private String thumbnail;

  private String avatar;

  private Long classStatus;

  private Long liveStreamStatus;

  private Boolean isRemind;

  private RoomComment roomComment;

  private Long likeCount;

  private Long videoClick;

  private Long passTime;
}
