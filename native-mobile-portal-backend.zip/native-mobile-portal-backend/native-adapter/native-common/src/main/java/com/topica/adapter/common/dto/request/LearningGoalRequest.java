package com.topica.adapter.common.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@AllArgsConstructor
@Data
@NoArgsConstructor
@Builder
public class LearningGoalRequest {
    private List<String> answer;

    private Map<String,String> info;

    private String type;
}
