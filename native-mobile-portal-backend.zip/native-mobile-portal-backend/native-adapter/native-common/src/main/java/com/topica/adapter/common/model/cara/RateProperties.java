package com.topica.adapter.common.model.cara;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Data
@NoArgsConstructor
public class RateProperties {
  private Integer optionId;
  private Long targetId;

  public RateProperties(Integer optionId) {
    this.optionId = optionId;
  }
}
