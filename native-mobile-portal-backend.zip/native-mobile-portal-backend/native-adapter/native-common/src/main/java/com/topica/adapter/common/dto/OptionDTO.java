package com.topica.adapter.common.dto;

import lombok.Data;

import java.util.List;

@Data
public class OptionDTO {
    private Long optionId;
    private String optionName;
    private String optionNameEn;
    private String optionDesc;
    private Long optionOrder;
    private Long optionPrevious;
    private Long  optionParent;
    private String optionValue;
    private List<OptionDTO>optionChild;
}
