package com.topica.adapter.common.dto.response;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AdvisorResponse {
  private boolean status;
  private String msg;
}
