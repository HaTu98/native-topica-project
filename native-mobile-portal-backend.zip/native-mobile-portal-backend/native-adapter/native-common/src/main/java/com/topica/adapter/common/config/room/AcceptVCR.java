package com.topica.adapter.common.config.room;

import com.google.common.collect.Lists;
import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.service.BaseUserSessionService;
import com.topica.portal.redis.service.config.ConfigService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.*;

import static com.topica.portal.redis.constant.KeyConfig.*;

@Slf4j
@Component
public class AcceptVCR extends BaseUserSessionService {
    private static final String DEFAULT_VCR_WEB = "ADB,VCRX,BBB";
    private static final String DEFAULT_VCR = "ADB,VCRX";
    private static final String DEFAULT_VCR_AUDIT = "VCRX";

    @Autowired
    private ConfigService configService;

    public List<String> getForSimpleWeb() {
        String value = this.configService.get(LMS_WEB_VCR_KEY);
        if(StringUtils.isEmpty(value)) {
            value = DEFAULT_VCR_WEB;
        }
        return this.toListSimple(value);
    }

    public List<String> getForSimple() {
        String value = this.configService.get(LMS_VCR_KEY);
        if(StringUtils.isEmpty(value)) {
            value = DEFAULT_VCR;
        }
        return this.toListSimple(value);
    }

    public List<String> getForSimpleAudit() {
        String value = this.configService.get(LMS_VCR_AUDIT_KEY);
        if(StringUtils.isEmpty(value)) {
            value = DEFAULT_VCR_AUDIT;
        }
        return this.toListSimple(value);
    }

    public List<String> getForVip() {
        String value = this.configService.get(LMS_VIP_VCR_KEY);
        if(StringUtils.isEmpty(value)) {
            value = DEFAULT_VCR;
        }
        return Arrays.asList(value.split(","));
    }

    public Comparator<RoomDTO> sortLMS() {
        return (RoomDTO r1, RoomDTO r2) -> {
            List<String> priorityVCR = this.getForSimple();
            return priorityVCR.indexOf(r1.getVcrType()) - priorityVCR.indexOf(r2.getVcrType());
        };
    }

    public Comparator<RoomDTO> sortLMSWeb() {
        return (RoomDTO r1, RoomDTO r2) -> {
            List<String> priorityVCR = this.getForSimpleWeb();
            return priorityVCR.indexOf(r1.getVcrType()) - priorityVCR.indexOf(r2.getVcrType());
        };
    }

    public Comparator<RoomDTO> sortVip() {
        return (RoomDTO r1, RoomDTO r2) -> {
            List<String> priorityVCR = this.getForVip();
            return priorityVCR.indexOf(r1.getVcrType()) - priorityVCR.indexOf(r2.getVcrType());
        };
    }

    public Collection<String> changeBBBToVCRX(List<String> vcrs){
        if(vcrs.contains(RoomDTO.VCRX)){
            Set<String> realVcr = new HashSet<>(vcrs);
            realVcr.add(RoomDTO.BBB);
            return realVcr;
        }
        return vcrs;
    }

    private List<String> toListSimple(String acceptStr) {
        List<String> result = Lists.newArrayList(acceptStr.split(","));
        return this.checkCanJoinVCRX(result);
    }

    private List<String> checkCanJoinVCRX(List<String> acceptVCR) {
        try {
            PortalMdlUser user = this.getUserSession();
            if(user.getVcrxUserId() != null) return acceptVCR;
            acceptVCR.removeIf(v -> v.equalsIgnoreCase(RoomDTO.VCRX));
            log.info("Cannot join VCRX because userVCRXId emppty - user: {}", user.getMdlUser().getUsername());
        } catch (Exception e) {
        }
        return acceptVCR;
    }
}