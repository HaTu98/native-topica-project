package com.topica.adapter.common.service.LearningGoalNew;

import com.topica.adapter.common.model.portal.LearningGoalStudentLevel;

import java.util.List;

public interface LearningGoalStudentLevelService {
    LearningGoalStudentLevel  getStudentLevel(Long studentId);
    void save(LearningGoalStudentLevel studentLevel);
}
