package com.topica.adapter.common.constant;
import lombok.Getter;

@Getter
public enum RoleType {
    POVH(9), Teacher(4), Student(5);

    private long value;

    RoleType(long value) {
        this.value = value;
    }
}
