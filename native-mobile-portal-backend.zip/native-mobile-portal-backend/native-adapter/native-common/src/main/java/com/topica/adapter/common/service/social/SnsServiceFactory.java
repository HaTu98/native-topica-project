package com.topica.adapter.common.service.social;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class SnsServiceFactory {
    private final List<BaseProviderService> serviceList;

    @Autowired
    public SnsServiceFactory(List<BaseProviderService> serviceList) {
        this.serviceList = serviceList;
    }

    public BaseProviderService get(String snsName) {
        return serviceList
            .stream()
            .filter(service -> service.supports(snsName))
            .findFirst()
            .orElseThrow(IllegalArgumentException::new);
    }
}
