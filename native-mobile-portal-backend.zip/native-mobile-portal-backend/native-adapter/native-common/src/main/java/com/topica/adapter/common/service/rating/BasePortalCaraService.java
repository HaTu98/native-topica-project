package com.topica.adapter.common.service.rating;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.topica.adapter.common.constant.CaraRateType;
import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.model.cara.*;
import com.topica.adapter.common.model.cara.CaraResponse.CaraData;
import com.topica.adapter.common.model.cara.CaraResponse.ClassInfo;
import com.topica.adapter.common.request.CaraRequest;
import com.topica.adapter.common.service.BaseUserSessionService;
import com.topica.adapter.common.service.invoker.InvokerService;
import com.topica.adapter.common.util.JsonUtil;
import com.topica.adapter.common.util.TimeUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Component
public abstract class BasePortalCaraService extends BaseUserSessionService {

  @Value("${cara.domain}")
  protected String domainCaraServer;

  protected static final String uriLogin = "/user/login";
  protected static final String uriListConfig = "/api/configuration/list";
  protected static final String uriCheckRated = "/api/rateRecord/checkRatedForClass";
  protected static final String uriCreateRate = "/api/rateRecord/create";
  protected static final String uriGetOptionByRateId = "/api/rateOption/getByRateId";
  protected static final String uriGetRateType = "/api/rateType/list";
  protected static final String timeAvailableKey = "RATING_AVAILABLE_TIME";

  @Value("${cara.login.username}")
  protected String loginUserName;

  @Value("${cara.login.password}")
  protected String loginPassword;

  @Value("${cara.config.time.learn}")
  protected Long timeLearnConfig;

  @Autowired
  private InvokerService invokerService;

  @Autowired
  private JsonUtil jsonUtil;

  protected String getCaraToken(){
    RestTemplate restTemplate = new RestTemplate();
    String urlLogin = domainCaraServer.concat(uriLogin);

    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    Map map = new HashMap<String, String>();
    map.put("username", loginUserName);
    map.put("password", loginPassword);
    HttpEntity<?> request = new HttpEntity<>(map, headers);

    ResponseEntity<?> response = restTemplate.postForEntity(urlLogin, request, String.class);
    if(response == null | CollectionUtils.isEmpty(response.getHeaders().get("Authorization"))) {
      log.error("(rate) Cannot connect to CARA server!");
      return "";
    }
    String token = response.getHeaders().get("Authorization").get(0);
    return token;
  }

  protected Long getTimeConfig(String token){
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.set("Authorization",token);

    String url = domainCaraServer.concat(uriListConfig);
    Optional<List> response = this.invokerService.get(url, headers, List.class);
    if (!response.isPresent() || CollectionUtils.isEmpty(response.get())) {
      return 0L;
    }

    Config[] configs = new Gson().fromJson(jsonUtil.convertToJson(response.get()), Config[].class);
    for(Config config: Arrays.asList(configs)) {
      String key = config.getKey().trim();
      String configKey = timeAvailableKey.trim();
      if(key.equalsIgnoreCase(configKey)){
        return Long.parseLong(config.getValue());
      }
    }
    log.info("(getTimeConfig) Err {}",response);
    return 0L;
  }


  protected Boolean isRated(Long userId, Long roomId, String token){
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.set("Authorization",token);
    Map map = new HashMap<String, String>();
    map.put("userId", userId);
    map.put("name", roomId);
    HttpEntity httpEntity = new HttpEntity<>(map, headers);

    String url = domainCaraServer.concat(uriCheckRated);
    Optional response = this.invokerService.postHeader(url, httpEntity, Object.class);
    if(!response.isPresent()) {
      return true;
    }

    JsonObject rateCheckedResponse = new Gson().fromJson(response.get().toString(), JsonObject.class);
    return Boolean.valueOf(rateCheckedResponse.get("message").getAsString());
  }

  protected Integer getStatusRate(Long timeAvailableInSeconds, Long timeConfig){
    if(timeAvailableInSeconds == null) return RateInfo.STATUS_OK;

    Calendar calendar = Calendar.getInstance();
    calendar.setTimeInMillis(timeAvailableInSeconds * 1000);
    calendar.add(Calendar.SECOND, timeConfig.intValue());

    Long totalTime = calendar.getTimeInMillis();

    Long timeNow = System.currentTimeMillis();
    if(timeNow >= totalTime){
      return RateInfo.STATUS_FAIL;
    }
    return RateInfo.STATUS_OK;
  }

  protected List<RateProperties> getExtraInfos(CaraRequest request) {
    return request.getVotes().parallelStream()
            .map(rateType -> {
              RateProperties properties = new RateProperties();
              properties.setOptionId(CaraRateType.getCode(rateType));
              if (CaraRateType.TEACHER == rateType) {
                properties.setTargetId(request.getTeacher_id());
              }
              return properties;
            }).collect(Collectors.toList());
  }

  protected List<RateProperties> getRateProperties(CaraRequest request){
    return request.getOptions().parallelStream()
            .map(option -> {
              RateProperties ratePropertie = new RateProperties(option.getId());
              if(CaraRateType.TEACHER.name().equals(option.getName())) {
                ratePropertie.setTargetId(request.getTeacher_id());
              }
              return ratePropertie;
            }).collect(Collectors.toList());
  }

  protected boolean isCurrentTime(Long timeAvailable){
    return timeAvailable.equals(TimeUtil.getCurrentHour());
  }

  protected CaraResponse getCaraResponse(RoomDTO room, Long rateId, String token, String role) throws BusinessException {
    CaraResponse caraResponse = new CaraResponse();
    caraResponse.setStatus(true);

    Long teacherId = getTeacherIdByRoomId(room.getId());
    ClassInfo classInfo = new ClassInfo(teacherId, room.getId(), room.getTimeAvailable(), role);
    CaraData caraData = new CaraData(classInfo, true);
    caraResponse.setData(caraData);
    caraResponse.getData().setOption_rate_list(this.getOptionByRateId(rateId, token));
    return caraResponse;
  }

  public List<CaraOption> getOptionByRateId(Long rateId, String token) throws BusinessException {
    log.info("Get option rate by rateId: {}", rateId);
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.set("Authorization",token);

    String url = domainCaraServer.concat(uriGetOptionByRateId);
    url += "?rateId=" + rateId;
    Optional<CaraOption[]> response = invokerService.get(url, headers, CaraOption[].class);
    if(!response.isPresent() || !ArrayUtils.isNotEmpty(response.get())) {
      throw new BusinessException(HttpStatus.BAD_REQUEST.value(), "getOptionByRateId empty: " + rateId);
    }
    return Arrays.asList(response.get());
  }

  public abstract Long getTeacherIdByRoomId(Long roomId);
}
