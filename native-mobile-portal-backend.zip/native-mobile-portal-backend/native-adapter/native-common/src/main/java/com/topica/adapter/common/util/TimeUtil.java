package com.topica.adapter.common.util;

import sun.util.calendar.CalendarUtils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class TimeUtil {

    public static final String DATE_FORMAT_ALERT_POCO_LMS = "yyyy-MM-dd HH:mm:ss";

    public static long getFirstDayOfWeekToSeconds(int week) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.WEEK_OF_YEAR, week);
        cal.setFirstDayOfWeek(Calendar.MONDAY);
        cal.set(Calendar.DAY_OF_WEEK, cal.getFirstDayOfWeek());
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.clear(Calendar.MINUTE);
        cal.clear(Calendar.SECOND);
        cal.clear(Calendar.MILLISECOND);
        return cal.getTimeInMillis() / 1000;
    }

    public static long getLastDayOfWeekToSeconds(int week) {
        return TimeUtil.getFirstDayOfWeekToSeconds(week + 1) - 1;
    }

    public static boolean isEnableJoinClass() {
        Calendar cal = Calendar.getInstance();
        int minute = cal.get(Calendar.MINUTE);
        return minute >= 45 && minute <= 54;
    }

    public static boolean isEnableQuickJoinClass() {
        Calendar cal = Calendar.getInstance();
        int minute = cal.get(Calendar.MINUTE);
        return minute >= 45 && minute <= 59;
    }

    public static boolean isTimeToQuickJoinClass() {
        Calendar cal = Calendar.getInstance();
        int minute = cal.get(Calendar.MINUTE);
        return minute >= 55 && minute <= 59;
    }

    public static Long getCurrentHour(){
        Calendar calendar = Calendar.getInstance();
        calendar.clear(Calendar.MILLISECOND);
        calendar.clear(Calendar.SECOND);
        int minute = calendar.get(Calendar.MINUTE);
        int hour = calendar.get(Calendar.HOUR);
        if(minute >= 45){
            hour = hour + 1;
        }
        calendar.clear(Calendar.MINUTE);
        calendar.set(Calendar.HOUR, hour);
        return calendar.getTimeInMillis()/1000;
    }

    public static String toString(String format) {
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        return sdf.format(Calendar.getInstance().getTime());
    }

    public static LocalDate convertToLocalDate(long time) {
        return Instant.ofEpochMilli(time)
            .atZone(TimeZone.getDefault().toZoneId())
            .toLocalDate();
    }

    public static Long convertToTimeId(LocalDate date) {
        String formated = date.format(DateTimeFormatter.ofPattern("yyyyMMdd", Locale.getDefault()));
        return Long.parseLong(formated);
    }

    public static Long convertToTimeId(Date date){
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd", Locale.getDefault());
        String formated = dateFormat.format(date);
        return Long.parseLong(formated);
    }

    public static Calendar getLastDayInWeek(Long time) {
        Calendar instance = Calendar.getInstance(TimeZone.getDefault());
        instance.setTimeInMillis(time);
        instance.add(Calendar.DAY_OF_WEEK,8 - instance.get(Calendar.DAY_OF_WEEK));

        return instance;
    }

    public static Calendar getLastDayInWeekBeforePresent(Long time) {
        Calendar lastDayInWeek = getLastDayInWeek(time);
        if (Calendar.getInstance(TimeZone.getDefault()).before(lastDayInWeek)) {
            return Calendar.getInstance(TimeZone.getDefault());
        }
        return lastDayInWeek;
    }


    public static LocalDate getLocaleDateLastDayInWeek(Long time) {
        return convertToLocalDate(getLastDayInWeek(time));
    }

    public static LocalDate getLocaleDateLastDayInWeekBeforePresent(Long time) {
        return convertToLocalDate(getLastDayInWeekBeforePresent(time));
    }

    public static Calendar getLastDayInMonth(Long time) {
        Calendar instance = Calendar.getInstance();
        instance.setTimeZone(TimeZone.getDefault());
        instance.setTimeInMillis(time);
        instance.add(Calendar.DAY_OF_YEAR,instance.getActualMaximum(Calendar.DAY_OF_MONTH) - instance.get(Calendar.DAY_OF_MONTH));
        return instance;
    }

    public static Calendar getLastDayInMonthBeforePresent(Long time) {
        Calendar lastDayInMonth = getLastDayInMonth(time);
        if (Calendar.getInstance(TimeZone.getDefault()).before(lastDayInMonth)) {
            return Calendar.getInstance(TimeZone.getDefault());
        }
        return lastDayInMonth;
    }

    public static LocalDate getLocalDateLastInMonth(Long time) {
        return convertToLocalDate(getLastDayInMonth(time));
    }

    public static LocalDate getLocalDateLastInMonthBeforePresent(Long time) {
        return convertToLocalDate(getLastDayInMonthBeforePresent(time));
    }

    private static LocalDate convertToLocalDate(Calendar calendar) {
        return LocalDateTime.ofInstant(calendar.toInstant(), calendar.getTimeZone().toZoneId()).toLocalDate();
    }

    public static Long getLastTimeOdin() {
        Calendar instance = Calendar.getInstance(TimeZone.getDefault());
        int hour = instance.get(Calendar.HOUR_OF_DAY);
        int delayByDay = hour <= 6 ? 2 : 1;
        instance.add(Calendar.DAY_OF_YEAR, -delayByDay);
        return convertToTimeId(instance.getTime());
    }

    public static int getWeekOfYearFromLocaleDate(LocalDate localDate) {
        Calendar instance = Calendar.getInstance(TimeZone.getDefault(), Locale.getDefault());
        instance.set(localDate.getYear(), localDate.getMonthValue() - 1, localDate.getDayOfMonth());
        return instance.get(Calendar.WEEK_OF_YEAR);
    }
}
