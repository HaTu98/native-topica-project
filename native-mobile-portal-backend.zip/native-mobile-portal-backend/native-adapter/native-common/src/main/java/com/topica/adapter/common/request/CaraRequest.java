package com.topica.adapter.common.request;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.topica.adapter.common.constant.CaraRateType;
import com.topica.adapter.common.model.cara.CaraOption;
import lombok.Data;

import java.io.IOException;
import java.util.List;

@Data
public class CaraRequest {

    @JsonDeserialize(using = CaraRequestDeserializer.class)
    private CaraRateType vote;

    @JsonDeserialize(using = TeacherIdDeserializer.class)
    private Long teacher_id;

    private List<CaraRateType> votes;
    private List<CaraOption> options;
    private int points;
    private Long room_id;
    private Long student_id;
    private String opinion;
    private Long timeAvailable;
}
class CaraRequestDeserializer extends JsonDeserializer<CaraRateType> {
    @Override
    public CaraRateType deserialize(JsonParser jsonParser, DeserializationContext deserializationContext) throws IOException {
        return CaraRateType.fromString(jsonParser.getValueAsString());
    }
}

class TeacherIdDeserializer extends JsonDeserializer<Long> {
    @Override
    public Long deserialize(JsonParser jsonParser, DeserializationContext deserializationContext) {
        try {
            return Long.valueOf(jsonParser.getValueAsString());
        } catch (Exception e) {
            return 0L;
        }
    }
}

