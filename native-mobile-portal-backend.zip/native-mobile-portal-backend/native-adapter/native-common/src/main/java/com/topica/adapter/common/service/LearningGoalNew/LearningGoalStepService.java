package com.topica.adapter.common.service.LearningGoalNew;

import com.topica.adapter.common.dto.StepDTO;
import com.topica.adapter.common.model.portal.LearningGoalStep;

import java.util.List;

public interface LearningGoalStepService  {
    List<LearningGoalStep> getAllStep();
    List<LearningGoalStep> getAllStepActive();
}
