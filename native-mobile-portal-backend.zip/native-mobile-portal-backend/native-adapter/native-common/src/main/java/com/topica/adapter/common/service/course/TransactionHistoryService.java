package com.topica.adapter.common.service.course;

import com.topica.adapter.common.dto.response.TransactionHistory;
import com.topica.adapter.common.exception.BusinessException;

import java.util.List;
import java.util.Optional;

public interface TransactionHistoryService {
  Optional<List<TransactionHistory>> getTransactionHistory() throws BusinessException;
}
