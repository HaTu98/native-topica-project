package com.topica.adapter.common.dto.request;

import lombok.*;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TotalLearningObjectRequest extends TotalLearningObjectClient {
  private Long userId;

  public void setRequest(TotalLearningObjectClient request) {
    this.setTimeType(request.getTimeType());
    this.setLearningObjectType(request.getLearningObjectType());
    this.setStartTime(request.getStartTime());
    this.setEndTime(request.getEndTime());
  }
}
