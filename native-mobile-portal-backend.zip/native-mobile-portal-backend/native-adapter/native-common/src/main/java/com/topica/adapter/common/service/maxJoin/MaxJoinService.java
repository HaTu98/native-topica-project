package com.topica.adapter.common.service.maxJoin;

import com.topica.adapter.common.model.portal.MaxJoin;
import com.topica.adapter.common.request.MaxJoinRequest;

public interface MaxJoinService {
    MaxJoin getMaxUser(MaxJoinRequest request);
    void save(MaxJoin maxJoin);
    void delete(MaxJoin maxJoin);
}
