package com.topica.adapter.common.repository.portal;

import com.topica.adapter.common.model.portal.LevelStudy;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.logging.Level;

@Repository
public interface LevelStudyRepository extends JpaRepository<LevelStudy, Long> {
    List<LevelStudy> findAll();
    LevelStudy findByContent(String content);
    LevelStudy findByValue(String value);
}
