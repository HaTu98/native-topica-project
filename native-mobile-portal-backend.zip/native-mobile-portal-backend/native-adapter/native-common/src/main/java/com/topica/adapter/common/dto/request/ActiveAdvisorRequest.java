package com.topica.adapter.common.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ActiveAdvisorRequest {
  private String key;

  @JsonProperty("contact_id")
  private String contactId;

  @JsonProperty("product_id")
  private Long productId;

  @JsonProperty("package_code")
  private String packageCode;
}
