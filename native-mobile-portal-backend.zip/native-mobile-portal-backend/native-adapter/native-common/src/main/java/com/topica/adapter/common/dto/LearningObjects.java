package com.topica.adapter.common.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class LearningObjects {
    private Integer phonetic;
    private Integer grammar;
    private Integer vocabulary;
    private Integer bloom;
}
