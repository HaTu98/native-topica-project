package com.topica.adapter.common.model.portal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.joda.time.DateTime;
import org.joda.time.LocalDateTime;

import javax.persistence.*;
import java.sql.Timestamp;

@AllArgsConstructor
@Data
@Entity
@NoArgsConstructor
@Table(name = "learning_goal_student_level")
public class LearningGoalStudentLevel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "student_id")
    private Long studentId;

    @Column(name = "start_level")
    private String startLevel;

    @Column(name = "end_level")
    private String endLevel;

    @Column(name = "status")
    private boolean status;

    @Column(name = "created_date")
    @CreationTimestamp
    private Timestamp createdDate;

    @Column(name = "modified_date")
    @UpdateTimestamp
    private Timestamp modifiedDate;
}
