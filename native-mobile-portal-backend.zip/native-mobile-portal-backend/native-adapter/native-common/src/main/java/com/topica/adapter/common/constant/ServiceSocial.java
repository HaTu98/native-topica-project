package com.topica.adapter.common.constant;

public enum ServiceSocial {
    FACEBOOK, GOOGLE, ZALO, TWITTER, NATIVE_PORTAL, NATIVE_SMILE
}
