package com.topica.adapter.common.repository.portal;

import com.topica.adapter.common.dto.StepDTO;
import com.topica.adapter.common.model.portal.LearningGoalStep;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LearningGoalStepRepository extends JpaRepository<LearningGoalStep, Long> {
    List<LearningGoalStep> findByStepStatusIsTrue();
    List<LearningGoalStep> findAll();
}
