package com.topica.adapter.common.service.LearningGoalNew.learningGoalImpl;

import com.topica.adapter.common.model.portal.LearningGoalStudentLevel;
import com.topica.adapter.common.repository.portal.LearningGoalStudentLevelRepository;
import com.topica.adapter.common.service.LearningGoalNew.LearningGoalStudentLevelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;

@Service
public class StudentLevelServiceImpl implements LearningGoalStudentLevelService {
    @Autowired
    private LearningGoalStudentLevelRepository studentLevelRepository;

    @Override
    public LearningGoalStudentLevel getStudentLevel(Long studentId) {
        List<LearningGoalStudentLevel> studentLevels = studentLevelRepository.findByStudentIdAndStatusIsTrue(studentId);
        if (CollectionUtils.isEmpty(studentLevels)){
            return new LearningGoalStudentLevel();
        }
        return studentLevels.get(0);
    }

    @Override
    public void save(LearningGoalStudentLevel studentLevel) {
        studentLevelRepository.save(studentLevel);
    }
}
