package com.topica.adapter.common.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TransactionHistory {
  @JsonProperty("id")
  private Long id;

  @JsonProperty("used_product_id")
  private Long usedProductId;

  @JsonProperty("product_id")
  private Long productId;

  @JsonProperty("type")
  private String type;

  @JsonProperty("value")
  private Double value;

  @JsonProperty("balance_value")
  private Double balanceValue;

  @JsonProperty("description")
  private String description;

  @JsonProperty("usercreated")
  private String userCreated;

  @JsonProperty("timecreated")
  private Long timeCreated;

  @JsonProperty("starttime")
  private Long startTime;

  @JsonProperty("endTime")
  private Long endtime;

  @JsonProperty("type_trans")
  private int typeTrans;

  @JsonProperty("endtime_value")
  private Long endTimeValue;

  @JsonProperty("roomid")
  private Long roomId;

  private String note;

  @JsonProperty("contact_id")
  private String contactId;

  @JsonProperty("balance_used")
  private Double balanceUsed;

  @JsonProperty("usetime")
  private Long useTime;

  @JsonProperty("lms_id")
  private Long userId;

  @JsonProperty("enduser_name")
  private String userName;

  @JsonProperty("enduser_email")
  private String email;

  @JsonProperty("enduser_phone")
  private String phone;

  @JsonProperty("package_attrs")
  private String packageAttrs;
}
