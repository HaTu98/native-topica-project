package com.topica.adapter.common.constant;

import org.springframework.util.StringUtils;

public enum SubjectType {
    LS, SC, SN, LIVE, ORI, NONE;

    public static SubjectType getEnum(String value) {
        if(StringUtils.isEmpty(value)) return NONE;
        for(SubjectType v : values())
            if(v.name().equalsIgnoreCase(value)) return v;
        throw new IllegalArgumentException();
    }
}