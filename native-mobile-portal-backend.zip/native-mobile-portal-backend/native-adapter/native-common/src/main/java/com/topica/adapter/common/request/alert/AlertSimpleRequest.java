package com.topica.adapter.common.request.alert;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AlertSimpleRequest implements AlertRequest{
    private Long userId;
    private String lastName;
    private String subjectType;
    private String levelStudent;
    private String time;

    @Override
    public Object getContent() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add("userId", this.userId.toString());
        map.add("lastName", this.lastName);
        map.add("subjectType", this.subjectType);
        map.add("levelStudent", this.levelStudent);
        map.add("time", this.time);
        HttpEntity httpEntity = new HttpEntity<>(map, headers);
        return httpEntity;
    }
}