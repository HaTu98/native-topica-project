package com.topica.adapter.common.request;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class JoinRoomRequest {
    private String username;
    private String password;
    private String typeClass;
    private Long classId;
}
