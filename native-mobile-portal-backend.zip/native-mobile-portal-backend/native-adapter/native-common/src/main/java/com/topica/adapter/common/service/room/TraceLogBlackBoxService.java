package com.topica.adapter.common.service.room;

import com.topica.adapter.common.model.portal.SigninHistory;
import org.springframework.scheduling.annotation.Async;

public interface TraceLogBlackBoxService {
    @Async
    default void traceReJoinRoomAfterLongTime(Long userId, String serviceType, Long roomId, boolean isFromCurrentTime) {
        long time = calTimeComeBackFromLast(userId, isFromCurrentTime);
        if (time > 0) {
            traceLogWarningReJoinRoom(userId, serviceType, roomId, time);
        }
    }

    @Async
    void traceLogLogin(SigninHistory model);

    long calTimeComeBackFromLast(Long userId, boolean isFromCurrentTime);
    void traceLogWarningReJoinRoom(Long userId, String serviceType, Long roomId, Long timeBack);
}
