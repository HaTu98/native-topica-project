package com.topica.adapter.common.model.odin;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Data
@Builder
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "learning_object")
public class LearningObject {
  @Id
  @Column(name = "learning_object_id")
  private Long learningObjectId;

  @Column(name = "learning_object_code")
  private String learningObjectCode;

  @Column(name = "learning_object_name")
  private String learningObjectName;

  @Column(name = "learning_object_type")
  private String learningObjectType;

  @Column(name = "transcription")
  private String transcription;

  @Column(name = "description")
  private String description;

  @Column(name = "learning_object_lowername")
  private String loLowerName;
}
