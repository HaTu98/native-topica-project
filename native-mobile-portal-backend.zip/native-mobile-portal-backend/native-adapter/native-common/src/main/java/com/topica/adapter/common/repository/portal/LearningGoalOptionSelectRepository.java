package com.topica.adapter.common.repository.portal;

import com.amazonaws.services.dynamodbv2.xspec.L;
import com.topica.adapter.common.model.portal.LearningGoalOption;
import com.topica.adapter.common.model.portal.LearningGoalOptionSelect;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LearningGoalOptionSelectRepository extends JpaRepository<LearningGoalOptionSelect, Long> {
    List<LearningGoalOptionSelect> findByStudentIdAndStatusIsTrue(Long studentId);
    List<LearningGoalOptionSelect> findByStudentIdAndStepIdAndStatusIsTrue(Long studentId,Long stepId);
    List<LearningGoalOptionSelect> findByStudentIdAndStepIdInAndStatusIsTrue(Long studentId,List<Long> stepIds);
    List<LearningGoalOptionSelect> findByStudentIdAndOptionIdInAndStatusIsTrue(Long studentId, List<Long> optionIds);
}
