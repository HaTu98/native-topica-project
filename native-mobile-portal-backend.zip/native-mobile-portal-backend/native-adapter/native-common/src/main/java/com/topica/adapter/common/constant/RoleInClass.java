package com.topica.adapter.common.constant;

public enum RoleInClass {
    AUDIT, NORMAL;

    public static RoleInClass ofString(String role) {
        for(RoleInClass e : values()) {
            if(e.name().equalsIgnoreCase(role)) {
                return e;
            }
        }

        return NORMAL;
    }
}
