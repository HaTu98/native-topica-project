package com.topica.adapter.common.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class JoinRoomVCRXRespose {
    private Boolean success;
    private Result result;
    private int error_code;

    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Result {
        private Boolean status;
        private Long classIdVcrx;
        private Long classId;
        private String msg;
        private Integer code;
        private Long timeAvailable;
    }
}