package com.topica.adapter.common.dto.response;

import com.topica.adapter.common.constant.SubjectType;
import com.topica.adapter.common.dto.RoomPresentDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RoomPresentResponse {
    public static final RoomPresentResponse empty = new RoomPresentResponse();
    private long hourStart;
    private long nextTime;
    private int nextHourStart;
    private Object recentRoom;
    private Map<SubjectType, RoomPresentDTO> content;
}
