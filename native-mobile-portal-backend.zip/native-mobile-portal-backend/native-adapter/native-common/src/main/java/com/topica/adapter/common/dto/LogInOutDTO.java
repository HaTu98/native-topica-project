package com.topica.adapter.common.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Data
@NoArgsConstructor
public class LogInOutDTO {
  private Long roomId;

  private Long roleId;
}
