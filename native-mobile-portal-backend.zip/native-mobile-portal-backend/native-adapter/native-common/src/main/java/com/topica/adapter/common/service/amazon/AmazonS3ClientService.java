package com.topica.adapter.common.service.amazon;

import org.springframework.web.multipart.MultipartFile;

public interface AmazonS3ClientService
{
    String uploadFileToS3Bucket(MultipartFile multipartFile);
}