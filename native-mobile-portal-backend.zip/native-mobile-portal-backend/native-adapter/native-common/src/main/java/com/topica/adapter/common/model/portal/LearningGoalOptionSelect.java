package com.topica.adapter.common.model.portal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.joda.time.LocalDateTime;

import javax.persistence.*;
import java.sql.Timestamp;

@AllArgsConstructor
@Data
@Entity
@NoArgsConstructor
@Table(name = "learning_goal_option_select")
public class LearningGoalOptionSelect {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "student_id")
    private Long studentId;

    @Column(name = "step_id")
    private Long stepId;

    @Column(name = "option_id")
    private Long optionId;

    @Column(name = "parent_id")
    private Long parentId;

    @Column(name = "option_answer")
    private String optionAnswer;

    @Column(name = "created_date")
    @CreationTimestamp
    private Timestamp createdDate;

    @Column(name = "status")
    private Boolean status;
}
