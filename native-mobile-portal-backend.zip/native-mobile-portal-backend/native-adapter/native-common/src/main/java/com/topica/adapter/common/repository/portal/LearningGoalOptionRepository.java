package com.topica.adapter.common.repository.portal;

import com.topica.adapter.common.model.portal.LearningGoalOption;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LearningGoalOptionRepository extends JpaRepository<LearningGoalOption, Long> {
    List<LearningGoalOption> findAll();
    List<LearningGoalOption> findAllByOptionStatusIsTrue();
    List<LearningGoalOption> findByOptionIdInAndOptionStatusIsTrue(List<Long> optionIds);
    List<LearningGoalOption> findByOptionIdInAndStepIdAndOptionStatusIsTrue(List<Long> optionIds, Long stepId);
    LearningGoalOption findByOptionIdAndOptionStatusIsTrue(long optionId);
}
