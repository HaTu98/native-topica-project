package com.topica.adapter.common.model.cara;

import com.topica.adapter.common.request.CaraRequest;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@Data
@NoArgsConstructor
public class RateInfo {

  public static final int STATUS_OK = 0;
  public static final int STATUS_FAIL = 2;

  private Long userId;
  private Long name;
  private Long rateId;
  private Integer rateValue;
  private String rateComment;
  private Long studyTime;
  private Integer status;
  private List<RateProperties> extraInfos;

  public RateInfo(CaraRequest request){
    this.userId = request.getStudent_id();
    this.rateValue = request.getPoints();
    this.rateComment = request.getOpinion();
    this.name = request.getRoom_id();

  }
}
