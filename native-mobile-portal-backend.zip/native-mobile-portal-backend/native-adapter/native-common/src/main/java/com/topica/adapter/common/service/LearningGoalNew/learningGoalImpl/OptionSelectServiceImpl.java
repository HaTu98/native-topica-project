package com.topica.adapter.common.service.LearningGoalNew.learningGoalImpl;

import com.topica.adapter.common.model.portal.LearningGoalOptionSelect;
import com.topica.adapter.common.repository.portal.LearningGoalOptionSelectRepository;
import com.topica.adapter.common.service.LearningGoalNew.LearningGoalOptionSelectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class OptionSelectServiceImpl implements LearningGoalOptionSelectService {
    @Autowired
    private LearningGoalOptionSelectRepository selectRepository;

    @Override
    public void saveAll(List<LearningGoalOptionSelect> data) {
        Long studentId = data.get(0).getStudentId();
        List<LearningGoalOptionSelect> oldData = selectRepository.findByStudentIdAndStatusIsTrue(studentId);
        if (!isEqual(data, oldData)) {
            if(!CollectionUtils.isEmpty(oldData)) {
                for (LearningGoalOptionSelect old : oldData) {
                    old.setStatus(false);
                }
                selectRepository.save(oldData);
            }
            selectRepository.save(data);
        }
    }

    @Override
    public List<LearningGoalOptionSelect> getUserSelect(Long studentId) {
        return selectRepository.findByStudentIdAndStatusIsTrue(studentId);
    }

    @Override
    public List<LearningGoalOptionSelect> getUserInfo(Long studentId, List<Long> optionId) {
        return selectRepository.findByStudentIdAndOptionIdInAndStatusIsTrue(studentId, optionId);
    }

    @Override
    public List<LearningGoalOptionSelect> saveUserInfo(Long studentId, List<LearningGoalOptionSelect> newInfo) {
        List<LearningGoalOptionSelect> oldInfo = selectRepository.findByStudentIdAndStepIdAndStatusIsTrue(studentId, 1L);
        if (!CollectionUtils.isEmpty(oldInfo)) {
            if (!isEqual(newInfo, oldInfo)) {
                for (LearningGoalOptionSelect old : oldInfo) {
                    old.setStatus(false);
                }
                selectRepository.save(oldInfo);
            }

        }
        return selectRepository.save(newInfo);
    }

    @Override
    public Boolean saveUserGoal(Long studentId, List<LearningGoalOptionSelect> newInfo) {
        List<LearningGoalOptionSelect> oldInfo = selectRepository.findByStudentIdAndStepIdInAndStatusIsTrue(studentId, Arrays.asList(2L, 3L, 4L));
        if (!isEqual(newInfo, oldInfo)) {
            if (!CollectionUtils.isEmpty(oldInfo)) {
                for (LearningGoalOptionSelect old : oldInfo) {
                    old.setStatus(false);
                }
                selectRepository.save(oldInfo);
            }
            selectRepository.save(newInfo);
            return true;
        }
        return false;
    }

    private Boolean isEqual(List<LearningGoalOptionSelect> newData, List<LearningGoalOptionSelect> oldData) {
        Map<Long, LearningGoalOptionSelect> data = newData.stream()
                .collect(Collectors.toMap(LearningGoalOptionSelect::getOptionId, option -> option));
        for (LearningGoalOptionSelect optionSelect : oldData) {
            Long optionId = optionSelect.getOptionId();
            if (!data.containsKey(optionId)) {
                return false;
            }
            data.remove(optionId);
        }
        return CollectionUtils.isEmpty(data);
    }
}
