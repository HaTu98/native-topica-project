package com.topica.adapter.common.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.topica.adapter.common.dto.MarketPackage;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class  GetPackageResponse {
  private Boolean status;

  @JsonProperty("status_code")
  private String statusCode;

  private String msg;

  private List<MarketPackage> data;
}
