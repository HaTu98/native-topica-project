package com.topica.adapter.common.model.portal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@AllArgsConstructor
@Data
@Entity
@NoArgsConstructor
@Table(name = "user_learning_goal")
@Builder
public class UserLearningGoal {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "userId")
    private Long userId;

    @Column(name = "service_type")
    private String serviceType;

    @Column(name = "answer")
    private String answer;

    @Column(name = "goal_type")
    private String goalType;

    @Column(name = "level")
    private String level;

    @Column(name = "user_city")
    private String city;

    @Column(name = "user_work")
    private String work;

    @Column(name = "user_age")
    private String age;

    @Column(name = "user_spend_time")
    private String time;

    @Column(name = "value")
    private String value;
}