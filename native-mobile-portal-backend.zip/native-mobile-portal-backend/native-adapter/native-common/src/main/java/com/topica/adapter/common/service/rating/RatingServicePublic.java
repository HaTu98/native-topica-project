package com.topica.adapter.common.service.rating;

import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.model.cara.CaraResponse;
import java.util.Optional;

public interface RatingServicePublic {
  Optional<CaraResponse> checkRated(Long userId, Long roomId) throws BusinessException;
}
