package com.topica.adapter.common.dto.response;

import java.util.List;
import lombok.Data;

@Data
public class RoomComment {
  private String roomId;

  private List<Comment> roomComments;
}
