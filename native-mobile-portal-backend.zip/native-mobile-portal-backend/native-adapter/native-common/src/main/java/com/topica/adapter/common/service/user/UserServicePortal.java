package com.topica.adapter.common.service.user;

import com.topica.adapter.common.constant.ServiceType;
import com.topica.adapter.common.dto.PackageDTO;
import com.topica.adapter.common.dto.PersonalInfoDTO;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.exception.ExceptionCode;
import com.topica.adapter.common.model.PortalUser;
import com.topica.adapter.common.request.LoginRequest;
import com.topica.adapter.common.request.UpdateInfoRequest;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.topica.adapter.common.constant.PackageStatus.ACTIVED;
import static com.topica.adapter.common.constant.PackageStatus.DEACTIVED;

public interface UserServicePortal {
    Optional<? extends PortalUser> findUser(String userName, ServiceType type) throws BusinessException;
    PersonalInfoDTO findPersonalInfo(Long userId, ServiceType type) throws BusinessException;
    Optional<Long> registerVCRXUser(LoginRequest loginRequest) throws BusinessException;
    String getMsgForExpiredPackage();
    String getMsgForDeactivedPackage();
    String getMsgForInvalidGEN();
    void checkValidGen(PersonalInfoDTO info, ServiceType serviceType) throws BusinessException;
    boolean changePassword(ServiceType serviceType, Long userId, String oldPassword, String newPassword) throws BusinessException;
    Optional<? extends PortalUser> update(Long userId, ServiceType type, UpdateInfoRequest updateInfoRequest) throws BusinessException;

    default List<String> getListGenCode(PersonalInfoDTO info) throws BusinessException {
        List<PackageDTO> packageList = info.getPackageList();
        List<PackageDTO> activedPackages = packageList
                .parallelStream()
                .filter(p -> ACTIVED.name().equalsIgnoreCase(p.getStatus()))
                .collect(Collectors.toList());
        if(!CollectionUtils.isEmpty(activedPackages)) {
            return activedPackages.parallelStream()
                    .map(p -> p.getGenCode())
                    .collect(Collectors.toList());
        }

        List<PackageDTO> deactivedPackages = packageList.parallelStream()
                .filter(p -> DEACTIVED.name().equalsIgnoreCase(p.getStatus())).collect(Collectors.toList());
        if(!CollectionUtils.isEmpty(deactivedPackages)) {
            return deactivedPackages.parallelStream()
                    .map(p -> p.getGenCode())
                    .collect(Collectors.toList());
        }
        throw new BusinessException(ExceptionCode.Authentication.AUTHENTICATION_GEN_INVALID, getMsgForExpiredPackage());
    }
}