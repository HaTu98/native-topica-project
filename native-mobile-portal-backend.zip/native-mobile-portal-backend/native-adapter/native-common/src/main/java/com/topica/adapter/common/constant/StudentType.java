package com.topica.adapter.common.constant;

public enum StudentType {
    VIP, NORMAL
}