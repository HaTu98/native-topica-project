package com.topica.adapter.common.config.room;

import com.topica.portal.redis.service.config.ConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import static com.topica.portal.redis.constant.KeyConfig.TOTAL_EMPTY_ROOM_SHOW;
import static com.topica.portal.redis.constant.KeyConfig.TOTAL_EMPTY_ROOM_SHOW_MAX;

@Component
public class TotalEmptyRoomDisplay {

    public static final int DEFAULT = 20;
    public static final int MAX_DEFAULT = 2;

    @Autowired
    private ConfigService configService;

    public float get() {
        String total = this.configService.get(TOTAL_EMPTY_ROOM_SHOW);
        if(StringUtils.isEmpty(total)) {
            return DEFAULT;
        }
        return Float.valueOf(total);
    }

    public int getMax() {
        String max = this.configService.get(TOTAL_EMPTY_ROOM_SHOW_MAX);
        if(StringUtils.isEmpty(max)) {
            return MAX_DEFAULT;
        }
        return Integer.valueOf(max);
    }

    public int set(int number) {
        this.configService.save(TOTAL_EMPTY_ROOM_SHOW, String.valueOf(number));
        return number;
    }
    public int setMax(int max) {
        this.configService.save(TOTAL_EMPTY_ROOM_SHOW_MAX, String.valueOf(max));
        return max;
    }
}
