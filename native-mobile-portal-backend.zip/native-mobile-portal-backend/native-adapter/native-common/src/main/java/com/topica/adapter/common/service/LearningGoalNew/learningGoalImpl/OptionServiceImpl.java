package com.topica.adapter.common.service.LearningGoalNew.learningGoalImpl;

import com.topica.adapter.common.model.portal.LearningGoalOption;
import com.topica.adapter.common.repository.portal.LearningGoalOptionRepository;
import com.topica.adapter.common.service.LearningGoalNew.LearningGoalOptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OptionServiceImpl implements LearningGoalOptionService {
    @Autowired
    private LearningGoalOptionRepository optionRepository;

    @Override
    public List<LearningGoalOption> getAllOption() {
        return optionRepository.findAll();
    }

    @Override
    public List<LearningGoalOption> getAllOptionActive() {
        return optionRepository.findAllByOptionStatusIsTrue();
    }

    @Override
    public List<LearningGoalOption> getAllByOptionId(List<Long> optionIds) {
        return optionRepository.findByOptionIdInAndOptionStatusIsTrue(optionIds);
    }

    @Override
    public List<LearningGoalOption> getAllByOptionIdAndStepId(List<Long> optionIds, Long stepId) {
        return optionRepository.findByOptionIdInAndStepIdAndOptionStatusIsTrue(optionIds,stepId);
    }

    @Override
    public LearningGoalOption getOption(Long optionId) {
        return optionRepository.findByOptionIdAndOptionStatusIsTrue(optionId);
    }
}
