package com.topica.adapter.common.model.odin;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Builder
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "student_knowledge_number_history")
public class StudentKnowledgeNumberHistory {
  @Id
  @Column(name = "id")
  private Long id;

  @Column(name = "student_id")
  private Long studentId;

  @Column(name = "user_id")
  private Long userId;

  @Column(name = "grammar_number")
  private Long grammarNumber;

  @Column(name = "phonetic_number")
  private Long phoneticNumber;

  @Column(name = "vocabulary_number")
  private Long vocabularyNumber;

  @Column(name = "created_date_id")
  private Long createdDateId;

  public Long getLoNumberByType(String loType) {
    switch (loType) {
      case "grammar":
        return grammarNumber;
      case "vocabulary":
        return vocabularyNumber;
      case "phonetic":
        return phoneticNumber;
      default:
        return 0L;
    }
  }
}
