package com.topica.adapter.common.dto;

import lombok.Data;

import java.util.Map;

@Data
public class AdvisorResponse {
    private Boolean status;
    private String status_code;
    private String msg;
    private Integer total;
    private LevelAdvisorResponse data;
}
