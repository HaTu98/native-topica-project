package com.topica.adapter.common.service.invoker;

import com.topica.adapter.common.model.portal.LogCallApi;
import com.topica.adapter.common.service.log.LogCallApiService;
import com.topica.adapter.common.util.JsonUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.Base64;
import java.util.Optional;

@Slf4j
@Service
public class InvokerService {
    private static final String SUCCESS = "SUCCESS";
    private static final String FAIL = "FAIL";
    private static final String POST = "POST";
    private static final String GET = "GET";
    private static final String RETRY = "RETRY";

    @Autowired
    @Qualifier("portalRestTemplate")
    private RestTemplate restTemplate;

    @Autowired
    private JsonUtil jsonUtil;

    @Autowired
    private LogCallApiService logCallApiService;

    public <T> Optional<T> get(String url, HttpHeaders headers, Class<T> responseType){
        HttpEntity<String> entity = new HttpEntity<>("parameters", headers);
        String responseStr;
        long start = System.currentTimeMillis();
        try {
            responseStr = restTemplate.exchange(url, HttpMethod.GET, entity, String.class).getBody();
            Optional res = Optional.ofNullable(jsonUtil.convert(responseStr, responseType));
            this.saveLogWhenSuccess(start, url, responseStr, GET, null);
            return res;
        } catch (RestClientException e) {
            this.saveLogWhenFail(start, url, e.getMessage(), GET, null);
        }
        return Optional.empty();
    }

    public <T> Optional<T> postHeader(String url, HttpEntity<Object> header, Class<T> responseType){
        String responseStr;
        long start = System.currentTimeMillis();
        Object body = header != null ? header.getBody() : null;
        try {
            responseStr = this.restTemplate.exchange(url, HttpMethod.POST, header, String.class).getBody();
            Optional res = Optional.ofNullable(jsonUtil.convert(responseStr, responseType));
            this.saveLogWhenSuccess(start, url, responseStr, POST, jsonUtil.convertToJson(body));
            return res;
        } catch (RestClientException e) {
            this.saveLogWhenFail(start, url, e.getMessage(), POST, jsonUtil.convertToJson(body));
        }
        return Optional.empty();
    }

    public String toBase64Token(String userName, String password) {
        String auth = userName + ":" + password;
        return "Basic " + Base64.getEncoder().encodeToString(auth.getBytes());
    }

    private void saveLogWhenSuccess(long start, String url, String responseStr, String method, String request) {
        LogCallApi log = LogCallApi.builder()
                .method(method)
                .duration(System.currentTimeMillis() - start)
                .response(responseStr)
                .status(SUCCESS)
                .url(url)
                .request(request)
                .build();
        this.logCallApiService.save(log);
    }

    private void saveLogWhenFail(long start, String url, String responseStr, String method, String request) {
        LogCallApi log = LogCallApi.builder()
                .method(method)
                .duration(System.currentTimeMillis() - start)
                .response(responseStr)
                .status(FAIL)
                .url(url)
                .request(request)
                .build();
        this.logCallApiService.save(log);
    }
}