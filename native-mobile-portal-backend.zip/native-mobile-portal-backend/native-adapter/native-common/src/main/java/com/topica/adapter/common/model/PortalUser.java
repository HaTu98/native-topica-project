package com.topica.adapter.common.model;

public interface PortalUser {
    Long getUserId();
    String password();
    Long delete();
    Long suspended();
}
