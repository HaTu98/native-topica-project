package com.topica.adapter.common.request;

import lombok.*;

import java.util.Collection;

@Data
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ListRoomRequest {
    private Long timeAvailable;
    private String level;
    private String classType;
    private String teacherType;
    private Collection<String> queryVCRTypes;
    private Collection<String> acceptVCRTypes;
}
