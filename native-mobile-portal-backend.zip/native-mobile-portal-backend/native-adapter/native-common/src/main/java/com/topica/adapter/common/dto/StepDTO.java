package com.topica.adapter.common.dto;

import com.topica.adapter.common.model.portal.LearningGoalOption;
import com.topica.adapter.common.model.portal.LearningGoalOptionMapping;
import com.topica.adapter.common.model.portal.LearningGoalStep;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class StepDTO {
    private Long step;
    private Long stepPrevious;
    private String stepName;
    private List<OptionDTO> options;
}
