package com.topica.adapter.common.config.room;

import com.topica.adapter.common.constant.ServiceType;
import com.topica.adapter.common.constant.SubjectType;
import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.model.portal.MaxJoin;
import com.topica.adapter.common.request.MaxJoinRequest;
import com.topica.adapter.common.service.maxJoin.MaxJoinService;
import com.topica.portal.redis.service.config.ConfigService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import static com.topica.adapter.common.util.RoomUtil.isRoomSN;
import static com.topica.adapter.common.util.RoomUtil.isStarter;
import static com.topica.portal.redis.constant.KeyConfig.*;

@Slf4j
@Component
public class MaxUserInRoom {

    @Autowired
    private ConfigService configService;

    @Autowired
    private MaxJoinService maxJoinService;

    public int getMaxSimple() {
        String strValue = this.configService.get(MAX_USER_JOIN_SIMPLE);
        if (StringUtils.isEmpty(strValue)) {
            return 6;
        }
        return Integer.valueOf(strValue);
    }

    public int getMaxSimpleForRoomSN() {
        String strValue = this.configService.get(MAX_USER_JOIN_SIMPLE_SN);
        if (StringUtils.isEmpty(strValue)) {
            return 4;
        }
        return Integer.valueOf(strValue);
    }

    public int getMaxSimpleStarter(String classType) {
        switch (SubjectType.valueOf(classType)) {
            case LS:
                return 6;
            case SC:
                String strValue = this.configService.get(MAX_USER_JOIN_SIMPLE_STARTER);
                if (StringUtils.isEmpty(strValue)) {
                    return 4;
                }
                return Integer.valueOf(strValue);
            default:
                return 4;
        }
    }

    public int getMaxAuditSimple() {
        String strValue = this.configService.get(MAX_USER_JOIN_AUDIT_SIMPLE);
        if (StringUtils.isEmpty(strValue)) {
            return 2;
        }
        return Integer.valueOf(strValue);
    }

    public int getMaxAuditSimpleForRoomSN() {
        String strValue = this.configService.get(MAX_USER_JOIN_AUDIT_SIMPLE_SN);
        if (StringUtils.isEmpty(strValue)) {
            return 2;
        }
        return Integer.valueOf(strValue);
    }

    public int getMaxVip() {
        String strValue = this.configService.get(MAX_USER_JOIN_VIP);
        if (StringUtils.isEmpty(strValue)) {
            return 3;
        }
        return Integer.valueOf(strValue);
    }

    public int getMaxVipForRoomSN() {
        String strValue = this.configService.get(MAX_USER_JOIN_VIP_SN);
        if (StringUtils.isEmpty(strValue)) {
            return 3;
        }
        return Integer.valueOf(strValue);
    }


    public int getMaxAuditVip() {
        String strValue = this.configService.get(MAX_USER_JOIN_AUDIT_VIP);
        if (StringUtils.isEmpty(strValue)) {
            return 2;
        }
        return Integer.valueOf(strValue);
    }

    public int getMaxUserForRoom(RoomDTO room) {
        ServiceType type = ServiceType.valueOf(room.getPackageType());
        String level = room.getLevelClass();
        String classType = room.getTypeClass();
        switch (type) {
            case LMS_VIP:
                if (isRoomSN(level, classType)) {
                    return this.getMaxVipForRoomSN();
                }
                return this.getMaxVip();

            case LMS:
            case TENUP:
                if (isRoomSN(level, classType)) {
                    return this.getMaxSimpleForRoomSN();
                }
                if (isStarter(level)) {
                    return this.getMaxSimpleStarter(classType);
                }
                return this.getMaxSimple();
            default:
                log.error("getMaxUserForRoom ERROR: NOT FOUND SERVICE TYPE !");
        }
        return this.getMaxSimple();
    }

//    public int getMaxUserForRoom(RoomDTO room) {
//        Integer maxUser = null;
//        MaxJoinRequest request = new MaxJoinRequest();
//        ServiceType type = ServiceType.valueOf(room.getPackageType());
//        request.setPackageType(room.getPackageType());
//        request.setLevelClass(room.getLevelClass());
//        request.setTypeClass(room.getTypeClass());
//        MaxJoin maxJoin = maxJoinService.getMaxUser(request);
//        if (maxJoin != null){
//            maxUser = maxJoin.getMaxUser();
//        }
//        if (maxUser == null) {
//            switch (type) {
//                case LMS_VIP:
//                    maxUser = 3;
//                    break;
//                case LMS:
//                    case TENUP:
//                    maxUser = 6;
//                    break;
//                default:
//                    maxUser = 6;
//                    log.error("getMaxUserForRoom ERROR: NOT FOUND SERVICE TYPE !");
//            }
//        }
//        return maxUser;
//    }

    public void insetMaxJoin(MaxJoinRequest request) {
        MaxJoin maxJoin = maxJoinService.getMaxUser(request);
        if(maxJoin == null) {
            maxJoin = new MaxJoin();
            maxJoin.setPackageType(request.getPackageType());
            maxJoin.setLevelClass(request.getLevelClass());
            maxJoin.setTypeClass(request.getTypeClass());
        }
        maxJoin.setMaxUser(request.getMaxUser());

        maxJoinService.save(maxJoin);
    }

    public void deleteMaxJoin(MaxJoinRequest request) {
        MaxJoin maxJoin = maxJoinService.getMaxUser(request);
        if (maxJoin != null) {
            maxJoinService.delete(maxJoin);
        }
    }

    public int getMaxUserForRoomAudit(RoomDTO room) {
        ServiceType type = ServiceType.valueOf(room.getPackageType());
        switch (type) {
            case LMS_VIP:
                return this.getMaxAuditSimple();
            case LMS:
            case TENUP:
                return this.getMaxAuditVip();
            default:
                log.error("getMaxUserForRoom ERROR: NOT FOUND SERVICE TYPE !");
        }
        return this.getMaxAuditVip();
    }
}