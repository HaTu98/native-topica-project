package com.topica.adapter.common.auth;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.model.StarterUserData;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.util.Arrays;
import java.util.Collection;
import java.util.stream.Collectors;

@Slf4j
@Component
public class TokenAuthenticationHelper {
    static final long EXPIRATIONTIME = 864_000_000; // 10 days
    static String PORTAL_SECRET_KEY;
    static String STARTER_SECRET_KEY;
    static final String TOKEN_PREFIX = "Bearer";
    static final String HEADER_STRING = "Authorization";
    static final String ROLE = "ROLE";


    @Value("${portal.secret.key}")
    public void setPortalSecretKey(String portalSecretKey) {
        PORTAL_SECRET_KEY = portalSecretKey;
    }

    @Value("${starter.secret.key}")
    public void setStarterSecretKey(String starterSecretKey) {
        STARTER_SECRET_KEY = starterSecretKey;
    }

    private TokenAuthenticationHelper() {
    }

    public static String generateStarterToken(StarterUserData user) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            return Jwts.builder()
                    .setPayload(mapper.writeValueAsString(user))
                    .signWith(SignatureAlgorithm.HS512, STARTER_SECRET_KEY)
                    .compact();
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String generatePortalToken(PortalMdlUser user) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            String token = Jwts.builder()
                    .setSubject(mapper.writeValueAsString(user))
                    .claim(ROLE, user.getRole())
                    .signWith(SignatureAlgorithm.HS512, PORTAL_SECRET_KEY)
                    .compact();
            return TOKEN_PREFIX + " " + token;
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static Authentication getAuthentication(HttpServletRequest request) {
        String token = request.getHeader(HEADER_STRING);
        return getAuthenticationByToken(token);
    }

    private static Authentication getAuthenticationByToken(String token) {
        if (token == null || !token.startsWith(TOKEN_PREFIX)) return null;
        Authentication auth = null;
        try {
            ObjectMapper mapper = new ObjectMapper();
            Claims claims = Jwts.parser()
                    .setSigningKey(PORTAL_SECRET_KEY)
                    .parseClaimsJws(token.replace(TOKEN_PREFIX, ""))
                    .getBody();

            final Collection authorities =
                    Arrays.stream(claims.get(ROLE).toString().split(","))
                            .map(SimpleGrantedAuthority::new)
                            .collect(Collectors.toList());

            PortalMdlUser user = mapper.readValue(claims.getSubject(), PortalMdlUser.class);
            auth = new UsernamePasswordAuthenticationToken(user,null,authorities);
        } catch (Exception e) {
            log.error("Invalid token !");
        }
        return auth;
    }
}