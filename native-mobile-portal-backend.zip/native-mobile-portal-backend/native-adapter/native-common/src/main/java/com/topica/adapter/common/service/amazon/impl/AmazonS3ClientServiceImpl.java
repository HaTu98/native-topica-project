package com.topica.adapter.common.service.amazon.impl;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.TransferManagerBuilder;
import com.amazonaws.services.s3.transfer.Upload;
import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.service.BaseUserSessionService;
import com.topica.adapter.common.service.amazon.AmazonS3ClientService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

@Slf4j
@Component
public class AmazonS3ClientServiceImpl extends BaseUserSessionService implements AmazonS3ClientService {
    @Value("${aws.region}")
    private String awsRegion;
    private String awsS3Bucket;
    private AmazonS3 amazonS3;
    private TransferManager transferManager;

    @Autowired
    public AmazonS3ClientServiceImpl(Region awsRegion, AWSCredentialsProvider awsCredentialsProvider, String awsS3Bucket) {
        this.amazonS3 = AmazonS3ClientBuilder
                .standard()
                .withCredentials(awsCredentialsProvider)
                .withRegion(awsRegion.getName())
                .build();

        this.awsS3Bucket = awsS3Bucket;

        this.transferManager = TransferManagerBuilder.standard()
                .withS3Client(amazonS3)
                .withMultipartUploadThreshold((long) (5 * 1024 * 1025))
                .build();
    }

    public String uploadFileToS3Bucket(MultipartFile multipartFile) {
        PortalMdlUser user = this.getUserSession();
        String fileName = user.getMdlUser().getId() +"_"+ System.currentTimeMillis() + "_" +  multipartFile.getOriginalFilename();
        log.info("uploadAvatar user: {} - fileName: {} - size: {}",user.getMdlUser().getUsername(), fileName, multipartFile.getSize());

        File file = new File(fileName);
        try {
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(multipartFile.getBytes());
            fos.close();

            PutObjectRequest putObjectRequest = new PutObjectRequest(this.awsS3Bucket, fileName, file);
            putObjectRequest.withCannedAcl(CannedAccessControlList.PublicRead);
            Upload upload = this.transferManager.upload(putObjectRequest);
            upload.waitForCompletion();
            return this.getURLFile(fileName);
        } catch (IOException | AmazonServiceException | InterruptedException ex) {
            log.error("error [" + ex.getMessage() + "] when uploading [" + fileName + "] ");
        } finally {
            file.delete();
        }
        return "";
    }

    private String getURLFile(String fileName) {
        StringBuilder url = new StringBuilder();
        url.append("https://s3-")
            .append(this.awsRegion)
            .append(".amazonaws.com/")
            .append(this.awsS3Bucket)
            .append("/" + fileName);
        return url.toString();
    }
}