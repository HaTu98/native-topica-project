package com.topica.adapter.common.request;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class LevelClassMappingRequest {
    private String packageParent;
    private String typeClass;
    private String levelUser;
    private String levelClass;
}
