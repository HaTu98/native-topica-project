package com.topica.adapter.common.model.portal;

import lombok.*;
import org.hibernate.annotations.Where;

import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name = "learning_goal_step")
public class LearningGoalStep {
    @Id
    @Column(name = "step_id")
    private Long stepId;

    @Column(name = "step_previous_id")
    private Long stepPreviousId;

    @Column(name = "step_name")
    private String stepName;

    @Column(name = "step_description")
    private String stepDescription;

    @Column(name = "step_status")
    private Boolean stepStatus;

    @OneToMany(mappedBy = "steps")
    private List<LearningGoalOption> options;
}
