package com.topica.booking.model;

public enum TicketStatus {
    READY, DELETED, SOLD,
}