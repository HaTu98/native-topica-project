package com.topica.booking.service.impl;

import com.topica.adapter.common.constant.ServiceType;
import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.exception.RoomError;
import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.service.BaseUserSessionService;
import com.topica.booking.model.Ticket;
import com.topica.booking.model.TicketSold;
import com.topica.booking.repository.TicketRepository;
import com.topica.booking.request.TicketInRoomRequest;
import com.topica.booking.request.TicketRequest;
import com.topica.booking.service.BookingRoomService;
import com.topica.booking.service.TicketService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Slf4j
@Service
public class BookingRoomServiceImpl extends BaseUserSessionService implements BookingRoomService {

    @Autowired
    private TicketService ticketService;

    @Autowired
    private TicketRepository ticketRepository;

    @Override
    @Transactional
    public Optional<Ticket> buyTicket(Long roomId, String role, ServiceType type) throws BusinessException {
        PortalMdlUser user = this.getUserSession();
        TicketInRoomRequest request = TicketInRoomRequest.builder()
                .role(role)
                .roomId(roomId)
                .serviceType(type.name())
                .userId(user.getMdlUser().getId())
                .userName(user.getMdlUser().getUsername())
                .build();
        Optional<Ticket> ticket = this.ticketService.orderWithRoomId(request);
        if(ticket.isPresent()) {
            this.ticketService.buyTicket(ticket.get());
            return ticket;
        }
        throw new BusinessException(RoomError.OUT_OF_TICKET, "OUT OF TICKET");
    }

    @Override
    @Transactional
    public Optional<Ticket> buyTicket(Long roomId, Long userId, String role, ServiceType type) throws BusinessException {
        TicketInRoomRequest request = TicketInRoomRequest.builder()
                .role(role)
                .roomId(roomId)
                .serviceType(type.name())
                .userId(userId)
                .build();
        Optional<Ticket> ticket = this.ticketService.orderWithRoomId(request);
        if(ticket.isPresent()) {
            this.ticketService.buyTicketForUser(ticket.get(), userId);
            return ticket;
        }
        throw new BusinessException(RoomError.OUT_OF_TICKET, "OUT OF TICKET");
    }

    @Override
    @Transactional
    public Optional<Ticket> order(TicketRequest request) throws BusinessException {
        Optional<Ticket> ticketOpt = this.ticketService.order(request);
        if(ticketOpt.isPresent()) {
            this.ticketService.buyTicket(ticketOpt.get());
            return ticketOpt;
        }
        log.info("Out of Ticket: {}", request);
        return Optional.empty();
    }

    @Override
    public Optional<Ticket> refreshAndRetryOrder(TicketRequest request, List<RoomDTO> listRefreshRoom) throws BusinessException {
        log.info("Refresh Ticket: {}", request);
        List<Ticket> listRoomOfTicket = this.ticketService.getListRoomOfTicket(request);
        Map<Long, Ticket> roomIdTicketMap = listRoomOfTicket
                .parallelStream()
                .collect(Collectors.toMap(Ticket::getRoomId, Function.identity()));
        Set<Long> roomIdsTicket = roomIdTicketMap.keySet();

        List<RoomDTO> listNewRoom = new LinkedList<>();
        listRefreshRoom
                .parallelStream()
                .forEach(room -> {
                    if(roomIdsTicket.contains(room.getId())) {
                        this.checkRoomHasChanged(room, roomIdTicketMap.get(room.getId()));
                    } else {
                        listNewRoom.add(room);
                    }
                });

        if(!CollectionUtils.isEmpty(listNewRoom)) {
            this.ticketService.generate(listNewRoom);
        }
        return this.order(request);
    }

    private void checkRoomHasChanged(RoomDTO room, Ticket ticket) {
        if(this.vcrTypeChanged(room, ticket)) {
            this.reportChangeVCR(room.getId(), room.getVcrType());
        }
    }

    private boolean vcrTypeChanged(RoomDTO room, Ticket ticket) {
        return !room.getVcrType().equalsIgnoreCase(ticket.getVcrType());
    }

    @Override
    public void cancelRoom(Long roomId) {
        log.info("CANCEL ROOM: {}", roomId);
        this.ticketService.cancelWithRoomId(roomId);
    }

    @Override
    public void returnTicket(Long ticketId) {
        log.info("RETURN TICKET: {}", ticketId);
        this.ticketService.returnTicket(ticketId);
    }

    @Override
    public void reportChangeVCR(Long roomId, String newVCRType) {
        log.info("CHANGE VCR TICKET for Room: {}", roomId);
        this.ticketService.changeTicketVCR(newVCRType, roomId);
    }

    @Override
    public List<TicketSold> ticketSoldPerRoomInLession(Long timeAvailable) {
        return ticketRepository.countTiketSoldPerRoomInSession(timeAvailable);
    }

    @Override
    public long countTicketReady(TicketRequest request) {
        return ticketService.countTicketReady(request);
    }
}