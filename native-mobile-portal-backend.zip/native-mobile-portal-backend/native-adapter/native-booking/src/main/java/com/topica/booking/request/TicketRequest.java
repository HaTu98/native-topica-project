package com.topica.booking.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TicketRequest {
    private String roomType;
    private String level;
    private List<String> acceptVCRType;
    private Long timeAvailable;
    private String teacherType;
    private String serviceType;
    private String role;
    private Long userId;
    private String userName;
}