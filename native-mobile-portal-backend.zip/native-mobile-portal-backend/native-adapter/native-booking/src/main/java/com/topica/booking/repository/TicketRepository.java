package com.topica.booking.repository;

import com.topica.booking.model.Ticket;
import com.topica.booking.model.TicketSold;
import com.topica.booking.request.TicketInRoomRequest;
import com.topica.booking.request.TicketRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.LockModeType;
import java.util.List;
import java.util.Optional;

@Repository
@Transactional
public interface TicketRepository extends JpaRepository<Ticket, Long> {

    Optional<Ticket> findById(Long ticketId);
    Optional<Ticket> findByUserIdAndTimeAvailableAndStatus(Long userId, Long timeAvailable, String status);
    Optional<Ticket> findByUserIdAndRoomIdAndStatus(Long userId, Long roomId, String status);
    boolean existsTicketByStatusEqualsAndRoomIdEqualsAndRoleEquals(String status, Long roomId, String role);

    @Query("select new com.topica.booking.model.TicketSold(COUNT(t.id), t.roomId) " +
            "from Ticket t " +
            "where t.timeAvailable =:timeAvailable and t.status = 'SOLD' " +
            "group by t.roomId")
    List<TicketSold> countTiketSoldPerRoomInSession(@Param("timeAvailable") Long timeAvailable);

    @Query("select t from Ticket t where " +
            "t.roomType = :#{#request.roomType} And " +
            "t.level = :#{#request.level} And " +
            "t.timeAvailable = :#{#request.timeAvailable} And " +
            "t.teacherType = :#{#request.teacherType} And " +
            "t.serviceType = :#{#request.serviceType} " +
            "group by t.roomId")
    List<Ticket> getListRoomOfTicket(@Param("request") TicketRequest request);

    @Modifying(clearAutomatically = true)
    @Query("UPDATE Ticket t set t.status = :status where t.roomId =:roomId")
    void removeByRoomId(@Param("status") String deletedStatus, @Param("roomId") Long roomId);

    @Modifying(clearAutomatically = true)
    @Query("UPDATE Ticket t set t.status = :status where t.id =:ticketId")
    void changeStatus(@Param("status") String status, @Param("ticketId") Long ticketId);


    @Modifying(clearAutomatically = true)
    @Query("UPDATE Ticket t set t.vcrType = :vcrType where t.roomId =:roomId")
    void changeVCRtype(@Param("vcrType") String vcrType, @Param("roomId") Long roomId);

    @Query(value = "SELECT t FROM Ticket t where " +
            "t.roomType = :#{#request.roomType} And " +
            "t.level = :#{#request.level} And " +
            "t.timeAvailable = :#{#request.timeAvailable} And " +
            "t.teacherType = :#{#request.teacherType} And " +
            "t.serviceType = :#{#request.serviceType} And " +
            "t.vcrType in :#{#request.acceptVCRType} And " +
            "t.role = :#{#request.role} And " +
            "t.status = 'READY' " +
            "group by t.roomId " +
            "order by count(t) ASC, locate(t.vcrType, :#{#priorityVCR}) ASC, t.roomId ASC")
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    List<Ticket> findAvailableTicket(@Param("request") TicketRequest request,
                                     @Param("priorityVCR") String priorityVCR,
                                     Pageable firstResult);

    @Query(value = "SELECT t FROM Ticket t WHERE " +
            "t.roomType = :#{#request.roomType} AND " +
            "t.level = :#{#request.level} AND " +
            "t.timeAvailable = :#{#request.timeAvailable} AND " +
            "t.teacherType = :#{#request.teacherType} AND " +
            "t.serviceType = :#{#request.serviceType} AND " +
            "t.vcrType in :#{#request.acceptVCRType} AND " +
            "t.role = :#{#request.role} AND " +
            "t.status = 'READY' AND " +
            "EXISTS ( SELECT t2 from Ticket t2 WHERE t2.role = 'NORMAL' AND t2.status = 'SOLD' AND t2.roomId = t.roomId) " +
            "order by t.roomId")
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    List<Ticket> findAvailableTicketAudit(@Param("request") TicketRequest request,
                                          Pageable firstResult);

    @Query(value = "SELECT t FROM Ticket t WHERE " +
            "t.roomType = :#{#request.roomType} AND " +
            "t.level = :#{#request.level} AND " +
            "t.timeAvailable = :#{#request.timeAvailable} AND " +
            "t.teacherType = :#{#request.teacherType} AND " +
            "t.serviceType = :#{#request.serviceType} AND " +
            "t.vcrType in :#{#request.acceptVCRType} AND " +
            "t.role = :#{#request.role} AND " +
            "t.status = 'READY' " +
            "order by t.roomId")
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    List<Ticket> findAvailableTicketAudit_2(@Param("request") TicketRequest request);

    @Query(value = "SELECT t FROM Ticket t where " +
            "t.serviceType = :#{#request.serviceType} And " +
            "t.role = :#{#request.role} And " +
            "t.roomId = :#{#request.roomId} and " +
            "t.status = 'READY' " +
            "order by t.id ASC")
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    List<Ticket> findAvailableInRoom(@Param("request") TicketInRoomRequest request, Pageable firstResult);

    @Query(value = "SELECT COUNT(t) FROM Ticket t where " +
            "t.roomType = :#{#request.roomType} And " +
            "t.level = :#{#request.level} And " +
            "t.timeAvailable = :#{#request.timeAvailable} And " +
            "t.teacherType = :#{#request.teacherType} And " +
            "t.serviceType = :#{#request.serviceType} And " +
            "t.vcrType in :#{#request.acceptVCRType} And " +
            "t.role = :#{#request.role} And " +
            "t.status = 'READY' ")
    long countTicketReady(@Param("request") TicketRequest request);
}