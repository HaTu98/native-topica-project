package com.topica.booking.model;

import com.topica.adapter.common.dto.RoomDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Calendar;
import java.util.Date;

import static com.topica.adapter.common.constant.SubjectType.SC;
import static com.topica.adapter.common.constant.SubjectType.SN;

@Data
@Builder
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "ticket")
public class Ticket {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "room_id")
    private Long roomId;

    @Column(name = "room_type")
    private String roomType;

    @Column(name = "level")
    private String level;

    @Column(name = "vcr_type")
    private String vcrType;

    @Column(name = "time_available")
    private Long timeAvailable;

    @Column(name = "teacher_type")
    private String teacherType;

    @Column(name = "service_type")
    private String serviceType;

    @Column(name = "status")
    private String status;

    @Column(name = "role")
    private String role;

    @Column(name = "created_time")
    private Date createdTime;

    @Column(name = "updated_time")
    private Date updatedTime;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "user_name")
    private String userName;

    @PrePersist
    protected void onCreate() {
        this.createdTime = Calendar.getInstance().getTime();
    }
    @PreUpdate
    protected void onUpate() {
        this.updatedTime = Calendar.getInstance().getTime();
    }

    public static Ticket fromRoom(RoomDTO room, String role) {
        String roomType = room.getTypeClass().equalsIgnoreCase(SN.name()) ? SC.name() : room.getTypeClass();
        return Ticket.builder()
                .level(room.getLevelClass())
                .roomId(room.getId())
                .roomType(roomType)
                .serviceType(room.getPackageType())
                .teacherType(room.getTeacherType())
                .timeAvailable(room.getTimeAvailable())
                .vcrType(room.getVcrType())
                .status(TicketStatus.READY.name())
                .role(role)
                .build();
    }
}