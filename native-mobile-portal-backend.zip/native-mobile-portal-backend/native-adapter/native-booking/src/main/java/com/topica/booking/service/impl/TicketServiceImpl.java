package com.topica.booking.service.impl;

import com.topica.adapter.common.config.room.MaxUserInRoom;
import com.topica.adapter.common.constant.PageUtil;
import com.topica.adapter.common.constant.RoleInClass;
import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.adapter.common.model.PortalMdlUser;
import com.topica.adapter.common.service.BaseUserSessionService;
import com.topica.booking.model.Ticket;
import com.topica.booking.model.TicketStatus;
import com.topica.booking.repository.TicketRepository;
import com.topica.booking.request.TicketInRoomRequest;
import com.topica.booking.request.TicketRequest;
import com.topica.booking.service.TicketService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import static com.topica.adapter.common.constant.RoleInClass.NORMAL;
import static com.topica.booking.model.TicketStatus.SOLD;

@Slf4j
@Service
public class TicketServiceImpl extends BaseUserSessionService implements TicketService {

    @Autowired
    private TicketRepository repository;

    @Autowired
    private MaxUserInRoom maxUserInRoom;

    @Override
    public void generate(List<RoomDTO> rooms) {
        log.info("Gen ticket from list size: {}", rooms.size());
        for(RoomDTO room: rooms) {
            try {
                List<Ticket> tickets = this.generateTicketForRoom(room);
                this.importTicket(tickets);
            } catch (Exception e) {
                log.error("!!! Gen ticket FAIL: {}", e.getMessage());
            }
        }
    }

    @Override
    public List<Ticket> getListRoomOfTicket(TicketRequest request) {
        return this.repository.getListRoomOfTicket(request);
    }

    private void importTicket(List<Ticket> tickets) {
        tickets.stream().forEach(t -> this.repository.save(t));
    }

    private List<Ticket> generateTicketForRoom(RoomDTO room) {
        int maxTicketNormal = this.getMaxTicketNormalInRoom(room);
        int maxTicketAudit = this.getMaxTicketAuditInRoom(room);

        log.info("Gen ticket for roomid: {} - normal: {} - audit: {}", room.getId(), maxTicketNormal, maxTicketAudit);
        List<Ticket> tickets = new LinkedList<>();
        for(int i=0; i < maxTicketNormal; i++) {
            tickets.add(Ticket.fromRoom(room, NORMAL.name()));
        }
        for(int j=0; j < maxTicketAudit; j++) {
            tickets.add(Ticket.fromRoom(room, RoleInClass.AUDIT.name()));
        }
        return tickets;
    }

    private int getMaxTicketNormalInRoom(RoomDTO room) {
        return maxUserInRoom.getMaxUserForRoom(room);
    }
    private int getMaxTicketAuditInRoom(RoomDTO room) {
        return maxUserInRoom.getMaxUserForRoomAudit(room);
    }

    @Override
    public Optional<Ticket> order(TicketRequest request) {
        Optional<Ticket> boughtTicket = this.boughtInSession(request);
        if(boughtTicket.isPresent()) {
            return boughtTicket;
        }
        return this.findTicket(request);
    }

    private Optional<Ticket> findTicket(TicketRequest request) {
        String priorityVCR = StringUtils.join(request.getAcceptVCRType(), "");
        List<Ticket> tickets = null;
        RoleInClass role = RoleInClass.valueOf(request.getRole());
        switch (role) {
            case NORMAL:
                tickets = this.repository.findAvailableTicket(request, priorityVCR, PageUtil.FIRST_RESULT);
                break;
            case AUDIT:
//                tickets = this.repository.findAvailableTicketAudit(request, PageUtil.FIRST_RESULT);
                Optional<Ticket> auditTicket = this.findAuditTicket(request);
                if(auditTicket.isPresent()) {
                    return auditTicket;
                }
                break;
        }
        if(CollectionUtils.isEmpty(tickets)) {
            return Optional.empty();
        }
        return Optional.of(tickets.get(0));
    }

    private Optional<Ticket> findAuditTicket(TicketRequest request) {
        List<Ticket> tickets = this.repository.findAvailableTicketAudit_2(request);
        for(Ticket ticket: tickets) {
            Long roomId = ticket.getRoomId();
            boolean existUserNormal = repository.existsTicketByStatusEqualsAndRoomIdEqualsAndRoleEquals(SOLD.name(), roomId, NORMAL.name());
            if(existUserNormal) {
                return Optional.of(ticket);
            }
        }
        return Optional.empty();
    }

    @Override
    public Optional<Ticket> orderWithRoomId(TicketInRoomRequest r) {
        Optional<Ticket> boughtTicket = this.boughtInRoom(r.getUserId(), r.getRoomId());
        if(boughtTicket.isPresent()) {
            log.info("boughtInRoom: {}", boughtTicket);
            return boughtTicket;
        }

        List<Ticket> tickets = this.repository.findAvailableInRoom(r, PageUtil.FIRST_RESULT);
        if(CollectionUtils.isEmpty(tickets)) return Optional.empty();
        return Optional.of(tickets.get(0));
    }

    private Optional<Ticket> boughtInSession(TicketRequest request) {
        return this.repository.findByUserIdAndTimeAvailableAndStatus(request.getUserId(), request.getTimeAvailable(), SOLD.name());
    }
    private Optional<Ticket> boughtInRoom(Long userId, Long roomId) {
        return this.repository.findByUserIdAndRoomIdAndStatus(userId, roomId, SOLD.name());
    }

    @Override
    public Optional<Ticket> findById(Long ticketId) {
        return this.repository.findById(ticketId);
    }

    @Override
    public Ticket buyTicket(Ticket ticket) {
        PortalMdlUser user = this.getUserSession();
        ticket.setStatus(SOLD.name());
        ticket.setUserId(user.getMdlUser().getId());
        ticket.setUserName(user.getMdlUser().getUsername());
        return this.repository.save(ticket);
    }

    @Override
    public Ticket buyTicketForUser(Ticket ticket, Long userId) {
        ticket.setStatus(SOLD.name());
        ticket.setUserId(userId);
        return this.repository.save(ticket);
    }

    @Override
    public void remove(Long ticketRoomId) {
        this.repository.removeByRoomId(TicketStatus.DELETED.name(), ticketRoomId);
    }

    @Override
    public void changeTicketVCR(String vcrType, Long ticketRoomId) {
        this.repository.changeVCRtype(vcrType, ticketRoomId);
    }

    @Override
    public void cancelWithRoomId(Long roomId) {
        this.repository.removeByRoomId(TicketStatus.DELETED.name(), roomId);
    }

    @Override
    public void returnTicket(Long ticketId) {
        this.repository.changeStatus(TicketStatus.READY.name(), ticketId);
    }

    @Override
    public long countTicketReady(TicketRequest request) {
        return this.repository.countTicketReady(request);
    }

    @Override
    public Optional<Ticket> getBoughtTicketByTime(Long userId, Long timeAvailable) {
        return this.repository.findByUserIdAndTimeAvailableAndStatus(userId, timeAvailable, SOLD.name());
    }
}