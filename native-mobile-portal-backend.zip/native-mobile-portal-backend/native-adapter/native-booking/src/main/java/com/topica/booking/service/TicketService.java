package com.topica.booking.service;

import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.booking.model.Ticket;
import com.topica.booking.request.TicketInRoomRequest;
import com.topica.booking.request.TicketRequest;

import java.util.List;
import java.util.Optional;

public interface TicketService {
    void generate(List<RoomDTO> rooms) throws BusinessException;
    List<Ticket> getListRoomOfTicket(TicketRequest request);
    Optional<Ticket> findById(Long ticketid);
    Optional<Ticket> order(TicketRequest request) throws BusinessException;
    Optional<Ticket> orderWithRoomId(TicketInRoomRequest request);
    Ticket buyTicket(Ticket ticket);
    Ticket buyTicketForUser(Ticket ticket, Long userId);
    void remove(Long ticketRoomId);
    void changeTicketVCR(String vcrType, Long ticketRoomId);
    void cancelWithRoomId(Long roomId);
    void returnTicket(Long ticketId);
    long countTicketReady(TicketRequest request);
    Optional<Ticket> getBoughtTicketByTime(Long userId, Long timeAvailable);
}
