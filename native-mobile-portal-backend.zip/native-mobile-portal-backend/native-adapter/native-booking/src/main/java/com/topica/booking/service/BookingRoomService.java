package com.topica.booking.service;

import com.topica.adapter.common.constant.ServiceType;
import com.topica.adapter.common.dto.RoomDTO;
import com.topica.adapter.common.exception.BusinessException;
import com.topica.booking.model.Ticket;
import com.topica.booking.model.TicketSold;
import com.topica.booking.request.TicketRequest;

import java.util.List;
import java.util.Optional;

public interface BookingRoomService {
    Optional<Ticket> order(TicketRequest request) throws BusinessException;
    long countTicketReady(TicketRequest request);
    Optional<Ticket> buyTicket(Long roomId, String role, ServiceType type) throws BusinessException;
    Optional<Ticket> buyTicket(Long roomId, Long userId, String role, ServiceType type) throws BusinessException;
    Optional<Ticket> refreshAndRetryOrder(TicketRequest request, List<RoomDTO> listRefreshRoom) throws BusinessException;
    void returnTicket(Long ticketId);
    void cancelRoom(Long roomId);
    void reportChangeVCR(Long roomId, String newVCRType);
    List<TicketSold> ticketSoldPerRoomInLession(Long timeAvailable);
}
